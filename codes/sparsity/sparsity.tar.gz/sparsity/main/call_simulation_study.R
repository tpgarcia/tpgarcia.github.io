###########################
## Signal to noise ratio ##
###########################

signal.to.noise(seed,run.simon=FALSE,N,p.group,beta.coef,sigma)



#######################################
## Function to call simulation study ##
#######################################

# Simulation results
out.simu <- simu.study(N, index.subgroup,
                       sigma, beta.coef, delta,delta.sub, delta.ind,tau,
                       alpha.SGL,alpha,alpha1,alpha2,alpha3,lambdas,nlam,lambda.accuracy,
                       nsimu,seed,
                       run.Lasso,
                       run.Group.Lasso,
                       run.SGL,
                       run.subgroup.SGL,
                       run.Group.Lasso.Group.Lasso,
                       run.Group.Lasso.SGL,
                       run.Group.Lasso.Group.Lasso.Lasso,
                       run.simon,use.Gram,run.alphas.range,two.alphas,group.standardize,
                       SGL.cv,Group.Lasso.SGL.cv, subgroup.SGL.cv, ncv,
                       percents.range,nfold,alphas.cv.range)


# Write results to table
write.csv(out.simu$out,file)
write.csv(out.simu$mult.cv.alpha.sgl, paste("mult_cv_sgl_alpha_",file,sep=""))
write.csv(out.simu$mult.cv.alpha.group.sgl.lasso, paste("mult_cv_group_sgl_alpha_",file,sep=""))
write.csv(out.simu$mult.cv.alpha.sparse.gp.subgp.lasso, paste("mult_cv_subgroup_sgl_alpha_",file,sep=""))


