##################################
## Number of significant digits ##
##################################

sig.digits <- 2

##################
## Read Results ##
##################

out.simu <- read.csv(file,header=TRUE)[,-1]
out.mult.cv.sgl.alpha <- read.csv(paste("mult_cv_sgl_alpha_",file,sep=""), header=TRUE,
                                  row.names=1)
out.mult.cv.alpha.group.sgl.lasso <- read.csv(paste("mult_cv_group_sgl_alpha_",file,sep=""),
                                              header=TRUE,
                                              row.names=1)
out.mult.cv.alpha.sparse.gp.subgp.lasso <- read.csv(paste("mult_cv_subgroup_sgl_alpha_",
                                                          file,sep=""), header=TRUE,
                                                    row.names=1)




######################
## Organize results ##
######################

p.subgroup <- form.tools(index.subgroup)$p.subgroup
org.out <- org.simu(beta.set,p.subgroup,beta.coef,out.simu,nsimu)


###############################
## Repeated Cross-validation ##
###############################


## Table of results for SGSL after organizing data
cat("\n \n ##Table of results for organized variables with subgroup SGL after multiple CV\n\n")

print(xtable(org.out$out[,paste("mult.cv.sparse.gp.subgp.lasso.summary.",percents.range,sep="")],digits=sig.digits))
print(xtable(org.out$FDR[,paste("mult.cv.sparse.gp.subgp.lasso.summary.",percents.range,sep="")],digits=sig.digits))


dyn.unload("../Cpp_code/mylin.dll")
