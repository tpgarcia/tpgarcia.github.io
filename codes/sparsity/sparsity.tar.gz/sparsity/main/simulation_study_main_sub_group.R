##############################################################
## Warning: this code assumes: 				    ##
## - Each subgroup is uniquely labeled 			    ##
## - Each element belongs to one and only one subgroup.     ##
## - subgroups belong to one and only one group.  	    ##
##############################################################

#######################
## Clean out objects ##
#######################
rm(list=ls(all=TRUE))



###############
# Source code #
###############

dyn.load("../Cpp_code/mylin.dll")
source("../main/subgroup_SGL.R")
source("../main/main_code.R")


#####################################
## Data generation for Group lasso ##
#####################################
## N 	    : sample size
## p.group : number of covariates in each group
## p.subgroup : matrix of number of covariates in each subgroup (each row corresponds to a group)
## beta.coef : matrix of coefficient vectors (rows: groups, columns: coefficient values)
## sigma   : model error covariance
## index   : vector indicating which covariates are in which groups

data.group <- function(N,p.subgroup,beta.coef,sigma){
  
########################################
  ## Form beta vector ##
########################################
  
  beta <- as.vector(t(beta.coef))	## Make into a vector
  beta <- beta[!is.na(beta)]		## Remove NA values
  
##################################################################
  ## Make p.subgroup into a vector ##
##################################################################

  p.subgroup.vector <- p.subgroup	
  
######################################
  ## Form covariates ##
######################################
  ## X \sim Normal(mu,Sigma)
  
  no.subgroup <- length(p.subgroup.vector)
  Sigma.list <- vector("list",no.subgroup)
  for(j in 1:no.subgroup){
    Sigma.list[[j]] <- 0.7 * matrix(1,nrow=p.subgroup.vector[j],
                                    ncol=p.subgroup.vector[j]) +
                                      0.3 * diag(1,nrow=p.subgroup.vector[j])
  }
  
  ## Form Sigma covariance matrix
  X.Sigma <- as.matrix(bdiag(Sigma.list))	
  
  ## Form mean of normal distribution
  X.mu <- rep(0,length(beta))
  
  ## Form covariates
  X <- mvrnorm(N,X.mu,X.Sigma)
  colnames(X) <- paste("X_",seq(1,sum(p.group)),sep="")
  
  
################################################
  ## Form response vector ##
################################################
  
  y <- X %*% beta + rnorm(N,mean=0,sd=sigma)	
  
  
  list(y=y,X=X)
}



data.group.simon <- function(N,p.group,beta.coef,sigma){
  p <- sum(p.group)
  
########################################
  ## Form beta vector ##
########################################
  
  beta <- as.vector(t(beta.coef))		## Make into a vecor
  beta <- beta[!is.na(beta)]			## remove NA values
  
######################################
  ## Form covariates ##
######################################
  ## X iid gaussian
  
  X <- matrix(rnorm(N * p), ncol = p, nrow = N)
  colnames(X) <- paste("X_",seq(1,sum(p.group)),sep="")
  
  
################################################
  ## Form response vector ##
################################################
  
  y <- X %*% beta + rnorm(N,mean=0,sd=sigma)	
  
  
  list(y=y,X=X)
}



###############################################
## Function to compute signal to noise ratio ##
###############################################
signal.to.noise <- function(seed,run.simon=FALSE,N,p.group,beta.coef,sigma){
  
  ## set seed
  set.seed(seed)
    
  if(run.simon==TRUE){
    ## Data is similar to that generated in Simon et al. (2012)
    data <- data.group.simon(N,p.subgroup,beta.coef,sigma)
  } else {
    ## Data is similar to that generated in Tibshirani et al.(2010)
    data <- data.group(N,p.group,beta.coef,sigma)
  }
  
  
  X <- data$X

  ## Get beta vector
  beta <- as.vector(t(beta.coef))# Make into a vector
  beta <- beta[!is.na(beta)]# Remove NA values

  ## Compute noise
  noise <- sqrt(diag(sigma^2 * ginv(t(X)%*%X)))

  ## signal.to.noise
  stn <- beta/noise
  
  return(max(stn))
}



########################################
## Simulation setup ##
########################################
## N 	    : sample size
## sigma   : model error covariance
## beta.coef : matrix of coefficient vectors (rows: groups, columns: coefficient values)
## delta : C_p criterion 
## delta.sub : delta for subgroup selection using C_p criterion
## delta.ind : delta for individual feature selection using C_p criterion
## nsimu : number of simulations
## seed  : seed used for simulations
## tau   : parameter used to determine lambda values
## alpha : parameter used in sparse group lasso
## run.sparse : logical, if TRUE, we run sparse group lasso
## lambda.accuracy : accuracy for lambda.max in sparse group-subgroup lasso
## two.alphas : if TRUE, we use alpha1, alpha2, and alpha3=1-alpha1-alpha2

simu.study <- function(N, index.subgroup,
                       sigma, beta.coef, delta=2,
                       delta.sub =2, delta.ind=2,
                       tau=0.94,alpha.SGL=0.95,alpha=0.95,alpha1=0.45,alpha2=0.45,
                       alpha3=1-alpha1-alpha2,lambdas=NULL,nlam=100,
                       lambda.accuracy=1e-4,
                       nsimu=1000,seed=1110,
                       run.Lasso=TRUE,
                       run.Group.Lasso=TRUE,
                       run.SGL=TRUE,
                       run.subgroup.SGL=TRUE,
                       run.Group.Lasso.Group.Lasso=TRUE,
                       run.Group.Lasso.SGL=TRUE,
                       run.Group.Lasso.Group.Lasso.Lasso=TRUE,
                       run.simon=FALSE,use.Gram=TRUE,run.alphas.range=FALSE,
                       two.alphas=TRUE,
                       group.standardize=TRUE,
                       SGL.cv=FALSE,Group.Lasso.SGL.cv=FALSE, subgroup.SGL.cv=FALSE, ncv=100,
                       percents.range=c(50,60,70,80,90,100),nfold=10,
                       alphas.cv.range=seq(0.1,0.95,by=0.05)){
  
  tools <- form.tools(index.subgroup)
  index <- tools$index
  p.group <- tools$p.group
  p.subgroup <- tools$p.subgroup  
  p <- sum(p.group) 		## Total number of covariates

  out.rownames <- paste("X_",seq(1,p),sep="")  ## Names of microbes
  
  
  ## results from pure Lasso
  out.lasso <- as.data.frame(matrix(0,nrow = p, ncol=length(delta)))
  colnames(out.lasso) <- paste("lasso.delta.",delta,sep="")
  rownames(out.lasso) <- paste("X_",seq(1,p),sep="")	
  

  ## results from pure group Lasso
  out.pure.gp.lasso <-  as.data.frame(matrix(0,nrow = p, ncol=length(delta)))
  colnames(out.pure.gp.lasso) <- paste("pure.gp.lasso.delta.",delta,sep="")
  rownames(out.pure.gp.lasso) <- paste("X_",seq(1,p),sep="")


  ## results from SGL
  out.sgl <-  as.data.frame(matrix(0,nrow = p, ncol=length(delta)))
  colnames(out.sgl) <- paste("sgl.delta.",delta,sep="")
  rownames(out.sgl) <- paste("X_",seq(1,p),sep="")	

  ## results from SGL.cv (we fix delta=2)
  mult.cv.sgl <- as.data.frame(matrix(0,nrow=p,ncol=nsimu,
                                      dimnames = list(paste("X_",seq(1,p),sep=""),
                                        paste("mult.cv.sgl.all.",seq(1,nsimu),sep=""))))
  
  mult.cv.alpha.sgl <- as.data.frame(matrix(0, nrow=1, ncol=ncv,
                                            dimnames=list("alpha",seq(1,ncv))))
  
  mult.cv.sgl.summary <- as.data.frame(matrix(0,nrow=p,ncol=length(percents.range),
                                              dimnames=list(paste("X_",seq(1,p),sep=""),
                                                paste("mult.cv.sgl.summary.",percents.range,sep=""))))
                                           
  
  ## results from SGL over alpha.SGL range
  out.sgl.alpharange <-  as.data.frame(matrix(0,nrow = p, ncol=length(delta) * length(alpha.SGL)))

  tmp <- paste(".alpha.",alpha.SGL,sep="")
  tmp.names <- NULL

  for(k in 1:length(delta)){
    tmp.names <- c(tmp.names,paste("sgl.delta.",delta[k],tmp,
                                           sep=""))
  }
  
  colnames(out.sgl.alpharange) <- tmp.names
  rownames(out.sgl.alpharange) <- paste("X_",seq(1,p),sep="")

  

  
  ## results for group lasso at group level and group lasso at subgroup level
  out.gp.gp.lasso <- as.data.frame(matrix(0,nrow = p,ncol=length(delta) * length(delta.sub)))

  ## results for group lasso at group level and SGL at subgroup level
  out.group.sgl.lasso <- as.data.frame(matrix(0,nrow = p, ncol=length(delta) * length(delta.sub)))

  ## results from group lasso at group level and SGL at subgroup level with CV (we fix delta=2)
  mult.cv.group.sgl.lasso <- as.data.frame(matrix(0,nrow=p,ncol=nsimu,
                                                  dimnames = list(paste("X_",seq(1,p),sep=""),
                                                    paste("mult.cv.group.sgl.lasso.all.",seq(1,nsimu),sep=""))))
  
  mult.cv.alpha.group.sgl.lasso <- as.data.frame(matrix(0, nrow=1, ncol=ncv,
                                                        dimnames=list("alpha",seq(1,ncv))))
  
  mult.cv.group.sgl.lasso.summary <- as.data.frame(matrix(0,nrow=p,ncol=length(percents.range),
                                                          dimnames=list(paste("X_",seq(1,p),sep=""),
                                                            paste("mult.cv.group.sgl.lasso.summary.",
                                                                  percents.range,sep=""))))
  ## column names for group-group lasso
  tmp <- paste(".sub.delta.",delta.sub,sep="")
	
  tmp.names <- NULL
  tmp.sgl.names <- NULL
  
  for(k in 1:length(delta)){
    tmp.names <- c(tmp.names,paste("gp.lasso.delta.",delta[k],tmp,sep=""))
    tmp.sgl.names <- c(tmp.sgl.names,paste("gp.sgl.lasso.delta.",delta[k],tmp,
                                           sep=""))
  }
  colnames(out.gp.gp.lasso) <- 	tmp.names
  rownames(out.gp.gp.lasso) <- paste("X_",seq(1,p),sep="")	
  
  colnames(out.group.sgl.lasso) <- tmp.sgl.names
  rownames(out.group.sgl.lasso) <- paste("X_",seq(1,p),sep="")


  ## results for group lasso at group level, group lasso at subgroup level, and lasso among all subgroups remaining

  out.gp.gp.indlasso.lasso <- as.data.frame(matrix(0,nrow = p, ncol=length(delta) * length(delta.sub) *
                                                   length(delta.ind) ))

  ## column names for group-group lasso
  tmp <- paste(".ind.delta.",delta.ind,sep="")
  tmp.names.sub <- NULL

  for(k in 1:length(delta.sub)){
    tmp.names.sub <- c(tmp.names.sub,paste(".sub.delta.",delta.sub[k],
                                           tmp,sep=""))
  }

  tmp.names <- NULL
  for(k in 1:length(delta)){
    tmp.names <- c(tmp.names,paste("gp.lasso.delta.",delta[k],tmp.names.sub,
                                   sep=""))
  }
  colnames(out.gp.gp.indlasso.lasso) <- tmp.names
  rownames(out.gp.gp.indlasso.lasso) <- paste("X_",seq(1,p),sep="")

  ## results from group lasso at group level and SGL at subgroup level over a range of alpha values
  out.group.sgl.lasso.range <- as.data.frame(matrix(0,nrow = p, ncol=length(delta) * length(delta.sub) *
                                                    length(alpha) ))

  ## column names for group-group lasso
  tmp <- paste(".alpha.",alpha,sep="")
  tmp.names.sub <- NULL

  for(k in 1:length(delta.sub)){
    tmp.names.sub <- c(tmp.names.sub,paste(".sgl.delta.",delta.sub[k],tmp,
                                           sep=""))
  }
  
  tmp.names <- NULL
  for(k in 1:length(delta)){
    tmp.names <- c(tmp.names,paste("gp.lasso.delta.",delta[k],tmp.names.sub,
                                   sep=""))
  }
  colnames(out.group.sgl.lasso.range) <-         tmp.names
  rownames(out.group.sgl.lasso.range) <- paste("X_",seq(1,p),sep="")
  


  
  ## results from sparse group subgroup Lasso
  out.sparse.gp.subgp.lasso <- as.data.frame(matrix(0,nrow = p, ncol=length(delta)))
  colnames(out.sparse.gp.subgp.lasso) <- paste("sparse.gp.subgp.lasso.delta.",delta,sep="")
  rownames(out.sparse.gp.subgp.lasso) <- paste("X_",seq(1,p),sep="")

  ## results from sparse group subgroup Lasso with CV (we fix delta=2)
  mult.cv.sparse.gp.subgp.lasso <- as.data.frame(matrix(0,nrow=p,ncol=nsimu,
                                                        dimnames = list(paste("X_",seq(1,p),sep=""),
                                                          paste("mult.cv.sparse.gp.subgp.lasso.all.",
                                                                seq(1,nsimu),sep=""))))
  
  mult.cv.alpha.sparse.gp.subgp.lasso <- as.data.frame(matrix(0, nrow=3, ncol=ncv,
                                                              dimnames=list(paste("alpha",seq(1,3),sep="")
                                                                ,seq(1,ncv))))
  
  mult.cv.sparse.gp.subgp.lasso.summary <- as.data.frame(matrix(0,nrow=p,ncol=length(percents.range),
                                                                dimnames=list(paste("X_",seq(1,p),sep=""),
                                                                  paste("mult.cv.sparse.gp.subgp.lasso.summary.",
                                                                        percents.range,sep=""))))
  

  ## results from sparse group subgroup Lasso at different alpha1, alpha2 combinations
  ##tmp <- paste(".delta.",delta,sep="")
  tmp.names <- NULL
  
  for(k in 1:length(alpha1)){
    for(r in 1:length(alpha2)){
      if(two.alphas==TRUE){
        if(alpha1[k]+alpha2[r]<1){
          tmp.names <- c(tmp.names,paste(".a1.",alpha1[k],".a2.",alpha2[r],sep=""))
        }
      } else {
        for(s in 1:length(alpha3)){
          tmp.names <- c(tmp.names,paste(".a1.",alpha1[k],".a2.",alpha2[r],".a3.",alpha3[s],sep=""))
        }
      }
    }
  }
  
  tmp.names2 <- NULL
  for(k in 1:length(delta)){
    tmp.names2 <- c(tmp.names2,paste("sub.SGL.del.",delta[k],tmp.names,sep=""))
  }

  out.subgroup.SGL.all.alphas  <- as.data.frame(matrix(0,nrow = p, ncol=length(tmp.names2)))

  colnames(out.subgroup.SGL.all.alphas) <-         tmp.names2
  rownames(out.subgroup.SGL.all.alphas) <- paste("X_",seq(1,p),sep="")


  


  
  ## set seed
  set.seed(seed)


  for(j in 1:nsimu) {
    ##print(j)
    ##################################
    ## Generate data ##
    ##################################	
    if(run.simon==TRUE){
	## Data is similar to that generated in Simon et al. (2012)
      data <- data.group.simon(N,p.subgroup,beta.coef,sigma)
    } else {
	## Data is similar to that generated in Tibshirani et al.(2010)
      data <- data.group(N,p.group,beta.coef,sigma)
    }
    phenotypes <- as.data.frame(t(data$y))
    microbes   <- as.data.frame(t(data$X))
    rownames(phenotypes) <- "phenotype"

    tmp.alphas <- 1
    tmp.sgl.alphas <- 1

    if(run.Lasso==TRUE){
##############################
      ## Apply Lasso ##
##############################
      
      out.lasso <- out.lasso + lasso.computations(microbes,phenotypes,plots=FALSE,file="lasso_",
                                                          format.data=FALSE,
                                                          delta=delta,use.Gram=use.Gram)$interest
    }

    if(run.Group.Lasso==TRUE){
####################################################
      ## Apply pure group Lasso ##
####################################################
      
      out.pure.gp.lasso <- out.pure.gp.lasso +
        pure.grplasso.computations(microbes,phenotypes,
                                   index,p.group,tau,file.group="pure_group_lasso_",
                                   plots.group="FALSE",delta.group=delta,
                                   format.data=FALSE,standardize=group.standardize)$interest
    }

    if(run.SGL==TRUE){
####################################
      ## Apply SGL (sparse group Lasso) ##
####################################
      if(length(alpha.SGL)>1){
        for(qq in 1:length(alpha.SGL)){
          out.sgl.alpharange[,qq] <- out.sgl.alpharange[,qq] +
            sparse.group.computations(microbes,phenotypes,index,p.group,tau,
                                      alpha=alpha.SGL[qq],
                                      file.group="SGL_",plots.group=FALSE,
                                      delta.group=delta,
                                      format.data=FALSE)$interest
          ##print(alpha.SGL[qq])
        }
      } else {
        out.sgl <- out.sgl +
          sparse.group.computations(microbes,phenotypes,index,p.group,tau,alpha.SGL,
                                    file.group="SGL_",plots.group=FALSE,
                                    delta.group=delta,format.data=FALSE)$interest
      }
    }
    
    if(SGL.cv==TRUE){
      for(v in 1:ncv){
        mult.cv.sgl.tmp <- sparse.group.computations(microbes,phenotypes,index,p.group,tau,alpha.SGL,
                                                     file.group="SGL_",plots.group=FALSE,
                                                     delta.group=delta,format.data=FALSE,
                                                     cv.criterion=TRUE,nfold=nfold,
                                                     alpha.cv=setdiff(alphas.cv.range,0.5))
          
        mult.cv.sgl[,j] <- mult.cv.sgl[,j] + mult.cv.sgl.tmp$interest
        mult.cv.alpha.sgl[,v] <- mult.cv.alpha.sgl[,v] + mult.cv.sgl.tmp$alpha.out
      }
    }
      
      
    if(run.subgroup.SGL==TRUE){
##########################################################################
      ## Apply sparse group subgroup lasso ##
##########################################################################
      
        
      if(run.alphas.range==TRUE){
        if(two.alphas==TRUE){
          for(kk in 1:length(alpha1)){
            for(rr in 1:length(alpha2)){
              if(alpha1[kk] + alpha2[rr] < 1){
                out.subgroup.SGL.all.alphas[,tmp.alphas] <- out.subgroup.SGL.all.alphas[,tmp.alphas] +
                  sparse.group.subgroup.computations(microbes,phenotypes,
                                                     index,index.subgroup,tau,
                                                     alpha1=alpha1[kk],alpha2=alpha2[rr],
                                                     alpha3=1-alpha1[kk]-alpha2[rr],nlam=nlam,
                                                     lambdas=lambdas,lambda.accuracy=lambda.accuracy,
                                                     file.group="sparse_group_subgroup_lasso_",plots.group=FALSE,
                                                     delta.group=delta,format.data=FALSE)$interest
                tmp.alphas <- tmp.alphas + 1
                ##print(c("alpha1",alpha1[kk],"alpha2",alpha2[rr]))
                ##print(c("tmp.alphas",tmp.alphas))
              }
            }
          }
        } else {
          for(kk in 1:length(alpha1)){
            for(rr in 1:length(alpha2)){
              for(ss in 1:length(alpha3)){
                out.subgroup.SGL.all.alphas[,tmp.alphas] <- out.subgroup.SGL.all.alphas[,tmp.alphas] +
                  sparse.group.subgroup.computations(microbes,phenotypes,
                                                     index,index.subgroup,tau,
                                                     alpha1=alpha1[kk],alpha2=alpha2[rr],alpha3=alpha3[ss],
                                                     nlam=nlam,
                                                     lambdas=lambdas,lambda.accuracy=lambda.accuracy,
                                                     file.group="sparse_group_subgroup_lasso_",plots.group=FALSE,
                                                     delta.group=delta,format.data=FALSE)$interest
                tmp.alphas <- tmp.alphas + 1
                ##print(c("alpha1",alpha1[kk],"alpha2",alpha2[rr]))
                ##print(c("tmp.alphas",tmp.alphas))
              }
            }
          }
        }
      } else {
        
        out.sparse.gp.subgp.lasso <- out.sparse.gp.subgp.lasso +
          sparse.group.subgroup.computations(microbes,phenotypes,
                                             index,index.subgroup,tau,alpha1,alpha2,alpha3,nlam,lambdas,
                                             lambda.accuracy,
                                             file.group="sparse_group_subgroup_lasso_",plots.group=FALSE,
                                             delta.group=delta,format.data=FALSE)$interest
      }
    }
      
    if(subgroup.SGL.cv==TRUE){
      for(v in 1:ncv){
        mult.cv.sparse.gp.subgp.lasso.tmp <- sparse.group.subgroup.computations(microbes,phenotypes,
                                                                                index,index.subgroup,tau,
                                                                                alpha1,alpha2,alpha3,nlam,lambdas,
                                                                                lambda.accuracy,
                                                                                file.group=
                                                                                "sparse_group_subgroup_lasso_",
                                                                                plots.group=FALSE,
                                                                                delta.group=delta,format.data=FALSE,
                                                                                cv.criterion=TRUE,
                                                                                nfold=nfold,
                                                                                alphas.cv.range=alphas.cv.range)
        
        mult.cv.sparse.gp.subgp.lasso[,j] <- mult.cv.sparse.gp.subgp.lasso[,j] +
          mult.cv.sparse.gp.subgp.lasso.tmp$interest
          
        mult.cv.alpha.sparse.gp.subgp.lasso[,v] <- mult.cv.alpha.sparse.gp.subgp.lasso[,v] +
          mult.cv.sparse.gp.subgp.lasso.tmp$alpha.out
      }
    }
      
      
    
    if(run.Group.Lasso.Group.Lasso==TRUE){
      
######################################################################################
      ## Apply group Lasso at group level and	##
      ## group Lasso at subgroup level 		##
######################################################################################
      
      out.gp.gp.lasso <- out.gp.gp.lasso +
        group.group.lasso.computations(microbes,phenotypes,
                                       index,
                                       index.subgroup,p.group,tau,
                                       file.group="group_group_lasso_",plots.group=FALSE,plots.subgroup=FALSE,
                                       delta.group=delta,delta.subgroup=delta.sub,format.data=FALSE,
                                       standardize=group.standardize)$interest
    }
    
    if(run.Group.Lasso.SGL==TRUE){
####################################################################################
      ## Apply group Lasso at group level and   ##
      ##  sparse group lasso  at subgroup level ##
####################################################################################
      
      if(run.alphas.range==TRUE){
        for(a in 1:length(alpha)){
          out.group.sgl.lasso.range[,tmp.sgl.alphas] <- out.group.sgl.lasso.range[,tmp.sgl.alphas] +
            group.sgl.lasso.computations(microbes,phenotypes,
                                         index,index.subgroup, p.group,tau,alpha[a],
                                         file.group="group_sgl_lasso_",plots.group=FALSE, plots.subgroup=FALSE,
                                         delta.group=delta,delta.subgroup=delta.sub,
                                         format.data=FALSE,standardize=group.standardize)$interest
          tmp.sgl.alphas <- tmp.sgl.alphas + 1
        }
      } else {
        out.group.sgl.lasso <- out.group.sgl.lasso+
          group.sgl.lasso.computations(microbes,phenotypes,
                                       index,index.subgroup, p.group,tau,alpha,
                                       file.group="group_sgl_lasso_",plots.group=FALSE, plots.subgroup=FALSE,
                                       delta.group=delta,delta.subgroup=delta.sub,
                                       format.data=FALSE,standardize=group.standardize)$interest
      }
    }

    if(Group.Lasso.SGL.cv==TRUE){
      for(v in 1:ncv){
        mult.cv.group.sgl.lasso.tmp <-
          group.sgl.lasso.computations(microbes,phenotypes,
                                       index,index.subgroup, p.group,tau,alpha,
                                       file.group="group_sgl_lasso_",plots.group=FALSE, plots.subgroup=FALSE,
                                       delta.group=delta,delta.subgroup=delta.sub,
                                       format.data=FALSE,standardize=group.standardize,
                                       cv.criterion=TRUE,nfold=nfold,
                                       alpha.cv=setdiff(alphas.cv.range,0.5))
        
        mult.cv.group.sgl.lasso[,j] <- mult.cv.group.sgl.lasso[,j] +
          mult.cv.group.sgl.lasso.tmp$interest
        
        mult.cv.alpha.group.sgl.lasso[,v] <- mult.cv.alpha.group.sgl.lasso[,v] +
          mult.cv.group.sgl.lasso.tmp$alpha.out
      }
    }

    if(run.Group.Lasso.Group.Lasso.Lasso==TRUE){
########################################################################################################
      ## Apply group Lasso at group level, group Lasso  ##
      ## at subgroup level, and lasso at individual level ##
########################################################################################################
      
      out.gp.gp.indlasso.lasso <- out.gp.gp.indlasso.lasso +
        group.group.indlasso.lasso.computations(microbes,phenotypes,index,
                                                index.subgroup,p.group,tau,
                                                file.group="group_group_indlasso__lasso_",plots.group=FALSE,
                                                plots.subgroup=FALSE,plots.ind=FALSE,
                                                delta.group=delta,delta.subgroup=delta.sub,
                                                delta.ind=delta.ind, 
                                                use.Gram=use.Gram,format.data=FALSE,
                                                standardize=group.standardize)$interest
    }
  }

#######################################
  ## Organize results from multiple CV ##
#######################################
  
  if(SGL.cv==TRUE){
    for(v in 1:length(percents.range)){
      mult.cv.sgl.summary[,v] <- org.mult.cv(mult.cv.sgl,percents.range[v],ncv)
    }
  }
  
  if(Group.Lasso.SGL.cv==TRUE){
    for(v in 1:length(percents.range)){
      mult.cv.group.sgl.lasso.summary[,v] <- org.mult.cv(mult.cv.group.sgl.lasso,percents.range[v],ncv)
    }
  }

  if(subgroup.SGL.cv==TRUE){
    for(v in 1:length(percents.range)){
      mult.cv.sparse.gp.subgp.lasso.summary[,v] <- org.mult.cv(mult.cv.sparse.gp.subgp.lasso,percents.range[v],
                                                               ncv)        
    }
  }
    


########################################
  ## Organize results ##
########################################
  
  out <- cbind(out.lasso,out.pure.gp.lasso,out.gp.gp.lasso,out.gp.gp.indlasso.lasso, out.sgl,out.group.sgl.lasso,
               out.sparse.gp.subgp.lasso,
               mult.cv.sgl, mult.cv.sgl.summary,
               mult.cv.group.sgl.lasso,mult.cv.group.sgl.lasso.summary,                 
               mult.cv.sparse.gp.subgp.lasso,mult.cv.sparse.gp.subgp.lasso.summary)
  
  if(run.alphas.range==TRUE){
    out <- cbind(out.sgl.alpharange,out.subgroup.SGL.all.alphas)
  }
  
  list(out=out,
       mult.cv.alpha.sgl=mult.cv.alpha.sgl,
       mult.cv.alpha.group.sgl.lasso=mult.cv.alpha.group.sgl.lasso,
       mult.cv.alpha.sparse.gp.subgp.lasso=mult.cv.alpha.sparse.gp.subgp.lasso)
}


## function to organize output from multiple cv process
org.mult.cv <- function(mult.cv.output,percent,ncv){
  make.criteria <- function(ncv,percent){
    function(x){
      return(x >= ncv * percent/100)
    }
  }
  
  criteria <- make.criteria(ncv,percent)
  
  check.criteria <- apply(mult.cv.output,c(1,2),criteria)
  
  output <- apply(check.criteria,1,sum)
  return(output)
}



########################################
## Organize results ##
########################################
## p.group : number of covariates in each group
## beta.coef : matrix of coefficient vectors (rows: groups, columns: coefficient values)
## out.simu : data table containing results from simulation
## nsimu : number of simulations
## by.pairs : do we compute FDR in pairs?

org.simu <- function(beta.set,p.subgroup,beta.coef,out.simu,nsimu,by.pairs=FALSE){
  
  if(by.pairs==TRUE){
    beta <- as.vector(t(beta.coef))	## Make into a vector
    beta <- beta[!is.na(beta)]		## Remove NA values
    
    M <- length(beta)
    
    nrow.groups <- 0
    rnames.groups <- NULL
    X.list <- vector("list",M/2)		## There can be at most M/2 pairs
    X.list.zeros <- vector("list",M/2)	
    
    for(j in seq(1,M,2)){
      nrow.groups <- nrow.groups + 1
      nonzero.group <- sum(beta[j:(j+1)]!=0)
      if(nonzero.group>0){
        rnames.groups <- c(rnames.groups, paste("Pair",nrow.groups,"_nonzero",sep=""))	
      } else{
        rnames.groups <- c(rnames.groups, paste("Pair",nrow.groups,"_zero",sep=""))	
        X.list.zeros[[nrow.groups]] <- j:(j+1)
      }
      X.list[[nrow.groups]] <- j:(j+1)
    }
  } else {
    p.subgroup.vector <- p.subgroup	
    
    M <- length(p.subgroup.vector)
    
    nrow.groups <- 0
    rnames.groups <- NULL
    X.list <- vector("list",2*M)		## There can be at most 2*M subgroups of zero/nonzero betas.
    X.list.zeros <- vector("list",2*M)	
    X.list.nonzeros <- vector("list",2*M)
    
    for(j in 1:nrow(beta.coef)){
      ##print(j)
      non.na <- !is.na(beta.coef[j,])
      if( sum(beta.coef[j,non.na]!=0)==p.subgroup.vector[j] ){
        ## ALL betas are non-zero
        
        nrow.groups   <- nrow.groups + 1
        rnames.groups <- c(rnames.groups, paste("Subgroup",j,"_nonzero",sep=""))	
        if(j==1){
          X.list[[nrow.groups]]   <- 1:p.subgroup.vector[j] 
        } else {
          X.list[[nrow.groups]]   <- 1:p.subgroup.vector[j] + sum(p.subgroup.vector[(j-1):1])
        }  
        X.list.nonzeros[[nrow.groups]] <- X.list[[nrow.groups]]
      } else if( sum(beta.coef[j,non.na]==0)==p.subgroup.vector[j] ){
        ## ALL betas are zero
        
        nrow.groups   <- nrow.groups + 1
        rnames.groups <- c(rnames.groups, paste("Subgroup",j,"_zero",sep=""))	
        if(j==1){
          X.list[[nrow.groups]]   <- 1:p.subgroup.vector[j] 
        } else {
          X.list[[nrow.groups]]   <- 1:p.subgroup.vector[j] + sum(p.subgroup.vector[(j-1):1])
        }  
        X.list.zeros[[nrow.groups]] <- X.list[[nrow.groups]]
      } else {
        ## some betas are zero and some are non-zero
        
        nrow.groups <- nrow.groups + 2
        if(j==1){
          X.list[[nrow.groups-1]]	<- which(beta.coef[j,]!=0)
          X.list[[nrow.groups]]	<- which(beta.coef[j,]==0)
        } else {
          X.list[[nrow.groups-1]]	<- which(beta.coef[j,]!=0) + sum(p.subgroup.vector[(j-1):1])
          X.list[[nrow.groups]]	<- which(beta.coef[j,]==0) + sum(p.subgroup.vector[(j-1):1])
        }
        X.list.nonzeros[[nrow.groups]] <- X.list[[nrow.groups-1]]
        
        X.list.zeros[[nrow.groups]] <- X.list[[nrow.groups]]
        rnames.groups <- c(rnames.groups, paste("Subgroup",j,"_nonzero",sep=""))
        rnames.groups <- c(rnames.groups, paste("Subgroup",j,"_zero",sep=""))
      }
    }
  }
  out <- matrix(0,nrow = nrow.groups + 12, ncol=ncol(out.simu))
  out <- as.data.frame(out)
  colnames(out) <- colnames(out.simu)
  rownames(out) <- c(rnames.groups,"FDR","specificity","sensitivity","gscore",
                     "FDR_123","specificity_123","sensitivity_123","gscore_123",
                     "FDR_23","specificity_23","sensitivity_23","gscore_23")

  if(beta.set!="set3b" & beta.set!="set3b_bigger"){
    rownames(out)[1:7] <- c("G1_nozero","G1_nonzero",
                       "G2_nonzero","G2_zero",
                       "G3_nonzero","G3_zero",
                       "Rest_zero")
  } else {
    rownames(out)[1:11] <- c("G1_nozero","G1_nonzero",
                            "G2_nonzero","G2_zero",
                            "G3_nonzero","G3_zero",
                            "G4_nonzero","G4_zero",
                            "G5_nonzero","G5_zero",
                            "Rest_zero")
  }
  

  ## NOTE: calculations with 123 mean that we compute these values only for groups 1,2,3.
  out.zeros <- out
  out.nonzeros <- out
  
  
  R <- 0
  F <- 0
  spec.num <- 0
  sens.num <- 0
  spec.den <- 0
  sens.den <- 0

  R.23 <-0
  F.23 <-0
  spec.num.23 <- 0
  sens.num.23 <- 0
  spec.den.23 <- 0
  sens.den.23 <- 0
  

  out.simu.zeros <- nsimu-out.simu
  out.simu.zeros[,c("mult.cv.sgl.all.1")] <- 0
  out.simu.zeros[,c("mult.cv.group.sgl.lasso.all.1")] <-0
  out.simu.zeros[,c("mult.cv.sparse.gp.subgp.lasso.all.1")] <-0
  
  ## Original output, all subgroups shown
  
  ##  for(k in 1:nrow.groups){
  ##    out[k,] <- apply(out.simu[X.list[[k]],],2,mean)
  ##    R <- R + length(X.list[[k]]) * out[k,]
  ##    F <- F + length(X.list.zeros[[k]]) * out[k,]
  ##  }
  
  
  ## 1-3-2013: Output for paper, version 10, will need to change once we find a good setup
  if(beta.set!="set3b" & beta.set!="set3b_bigger"){
    for(k in 1:nrow.groups){
      if(k<=5){
        out[k,] <- apply(out.simu[X.list[[k]],],2,mean)
        out.zeros[k,] <- apply(out.simu.zeros[X.list[[k]],],2,mean)
        
        R <- R + length(X.list[[k]]) * out[k,]
        F <- F + length(X.list.zeros[[k]]) * out[k,]

        ## Sensitivity and Specificity
        spec.num <- spec.num + length(X.list.zeros[[k]]) * out.zeros[k,]
        spec.den <- spec.den + length(X.list.zeros[[k]]) * out.zeros[k,] +
          length(X.list.zeros[[k]]) * out[k,]
        
        sens.num <- sens.num + length(X.list.nonzeros[[k]]) * out[k,]
        sens.den <- sens.den + length(X.list.nonzeros[[k]]) * out[k,] +
          length(X.list.nonzeros[[k]]) * out.zeros[k,]

        if(k!=1 & k!=2){
          spec.num.23 <- spec.num.23 + length(X.list.zeros[[k]]) * out.zeros[k,]
          spec.den.23 <- spec.den.23 +  length(X.list.zeros[[k]]) * out.zeros[k,] +
                      length(X.list.zeros[[k]]) * out[k,]
          sens.num.23 <- sens.num.23 + length(X.list.nonzeros[[k]]) * out[k,]
          sens.den.23 <- sens.den.23 + length(X.list.nonzeros[[k]]) * out[k,] +
                      length(X.list.nonzeros[[k]]) * out.zeros[k,]
          R.23 <- R.23 + length(X.list[[k]]) * out[k,]
          F.23 <- F.23 + length(X.list.zeros[[k]]) * out[k,]
        }
      }
    }
    
    ## Combining zero parts of Group 3
    group3 <- unlist(X.list[6:7])
    out[6,] <-  apply(out.simu[group3,],2,mean)
    out.zeros[6,] <- apply(out.simu.zeros[group3,],2,mean)
    
    spec.num <- spec.num + length(group3) * out.zeros[6,]
    spec.den <- spec.den + length(group3) * out.zeros[6,] +
      length(group3) * out[6,]
    
    R <- R + length(group3) * out[6,]
    F <- F + length(group3) * out[6,]
    
    spec.num.23 <- spec.num.23 + length(group3) * out.zeros[6,]
    spec.den.23 <- spec.den.23 + length(group3) * out.zeros[6,] +
      length(group3) * out[6,]
    R.23 <- R.23 +  length(group3) * out[6,]
    F.23 <- F.23 +  length(group3) * out[6,]
    
    
    ## Up to here we have done computations for groups 1,2,3:
    FDR.123 <- F/R
    specificity.123 <- spec.num/spec.den
    sensitivity.123 <- sens.num/sens.den
    g.123 <- sqrt(specificity.123 * sensitivity.123)
    
    ## Up to here we have computations for groups 2,3
    FDR.23 <- F.23/R.23
    specificity.23 <- spec.num.23/spec.den.23
    sensitivity.23 <- sens.num.23/sens.den.23
    g.23 <- sqrt(specificity.23 * sensitivity.23)
    
    
    ## Combining Groups 4-10
    rest.groups <- unlist(X.list[8:nrow.groups])
    out[7,] <-  apply(out.simu[rest.groups,],2,mean)
    out.zeros[7,] <- apply(out.simu.zeros[rest.groups,],2,mean)
    R <- R + length(rest.groups) * out[7,]
    F <- F + length(rest.groups) * out[7,]
    
    spec.num <- spec.num + length(rest.groups) * out.zeros[7,]
    spec.den <- spec.den + length(rest.groups) * out.zeros[7,] +
      length(rest.groups) * out[7,]
  } else {
    for(k in 1:nrow.groups){
      if(k<=5){
        out[k,] <- apply(out.simu[X.list[[k]],],2,mean)
        out.zeros[k,] <- apply(out.simu.zeros[X.list[[k]],],2,mean)
        
        R <- R + length(X.list[[k]]) * out[k,]
        F <- F + length(X.list.zeros[[k]]) * out[k,]

        ## Sensitivity and Specificity
        spec.num <- spec.num + length(X.list.zeros[[k]]) * out.zeros[k,]
        spec.den <- spec.den + length(X.list.zeros[[k]]) * out.zeros[k,] +
          length(X.list.zeros[[k]]) * out[k,]
        
        sens.num <- sens.num + length(X.list.nonzeros[[k]]) * out[k,]
        sens.den <- sens.den + length(X.list.nonzeros[[k]]) * out[k,] +
          length(X.list.nonzeros[[k]]) * out.zeros[k,]

        if(k!=1 & k!=2){
          spec.num.23 <- spec.num.23 + length(X.list.zeros[[k]]) * out.zeros[k,]
          spec.den.23 <- spec.den.23 +  length(X.list.zeros[[k]]) * out.zeros[k,] +
                      length(X.list.zeros[[k]]) * out[k,]
          sens.num.23 <- sens.num.23 + length(X.list.nonzeros[[k]]) * out[k,]
          sens.den.23 <- sens.den.23 + length(X.list.nonzeros[[k]]) * out[k,] +
                      length(X.list.nonzeros[[k]]) * out.zeros[k,]
          R.23 <- R.23 + length(X.list[[k]]) * out[k,]
          F.23 <- F.23 + length(X.list.zeros[[k]]) * out[k,]
        }
      }
    }
    
    ## Combining zero parts of Group 3
    group3 <- unlist(X.list[6:7])
    out[6,] <-  apply(out.simu[group3,],2,mean)
    out.zeros[6,] <- apply(out.simu.zeros[group3,],2,mean)
    
    spec.num <- spec.num + length(group3) * out.zeros[6,]
    spec.den <- spec.den + length(group3) * out.zeros[6,] +
      length(group3) * out[6,]
    
    R <- R + length(group3) * out[6,]
    F <- F + length(group3) * out[6,]
    
    spec.num.23 <- spec.num.23 + length(group3) * out.zeros[6,]
    spec.den.23 <- spec.den.23 + length(group3) * out.zeros[6,] +
      length(group3) * out[6,]
    R.23 <- R.23 +  length(group3) * out[6,]
    F.23 <- F.23 +  length(group3) * out[6,]


    ## Adding parts for duplicated "group 2 and group 3" which are now group 4 and group 5, respect.
    index.tmp <- 7

    for(k in 8:10){
      out[index.tmp,] <- apply(out.simu[X.list[[k]],],2,mean)
      out.zeros[index.tmp,] <- apply(out.simu.zeros[X.list[[k]],],2,mean)
      
      R <- R + length(X.list[[k]]) * out[index.tmp,]
      F <- F + length(X.list.zeros[[k]]) * out[index.tmp,]
      
      ## Sensitivity and Specificity
      spec.num <- spec.num + length(X.list.zeros[[k]]) * out.zeros[index.tmp,]
      spec.den <- spec.den + length(X.list.zeros[[k]]) * out.zeros[index.tmp,] +
        length(X.list.zeros[[k]]) * out[index.tmp,]
      
      sens.num <- sens.num + length(X.list.nonzeros[[k]]) * out[index.tmp,]
      sens.den <- sens.den + length(X.list.nonzeros[[k]]) * out[index.tmp,] +
        length(X.list.nonzeros[[k]]) * out.zeros[index.tmp,]
      
      spec.num.23 <- spec.num.23 + length(X.list.zeros[[k]]) * out.zeros[index.tmp,]
      spec.den.23 <- spec.den.23 +  length(X.list.zeros[[k]]) * out.zeros[index.tmp,] +
        length(X.list.zeros[[k]]) * out[index.tmp,]
      sens.num.23 <- sens.num.23 + length(X.list.nonzeros[[k]]) * out[index.tmp,]
      sens.den.23 <- sens.den.23 + length(X.list.nonzeros[[k]]) * out[index.tmp,] +
        length(X.list.nonzeros[[k]]) * out.zeros[index.tmp,]
      R.23 <- R.23 + length(X.list[[k]]) * out[index.tmp,]
      F.23 <- F.23 + length(X.list.zeros[[k]]) * out[index.tmp,]
      index.tmp <- index.tmp + 1
    }

    ## Combining zero parts of Group 5
    group5 <- unlist(X.list[11:12])
    out[index.tmp,] <-  apply(out.simu[group5,],2,mean)
    out.zeros[index.tmp,] <- apply(out.simu.zeros[group5,],2,mean)
    
    spec.num <- spec.num + length(group5) * out.zeros[index.tmp,]
    spec.den <- spec.den + length(group5) * out.zeros[index.tmp,] +
      length(group5) * out[index.tmp,]
    
    R <- R + length(group5) * out[index.tmp,]
    F <- F + length(group5) * out[index.tmp,]
    
    spec.num.23 <- spec.num.23 + length(group5) * out.zeros[index.tmp,]
    spec.den.23 <- spec.den.23 + length(group5) * out.zeros[index.tmp,] +
      length(group5) * out[index.tmp,]
    R.23 <- R.23 +  length(group5) * out[index.tmp,]
    F.23 <- F.23 +  length(group5) * out[index.tmp,]

    index.tmp <- index.tmp +1
    
    ## Up to here we have done computations for groups 1,2,3,4,5:
    FDR.123 <- F/R
    specificity.123 <- spec.num/spec.den
    sensitivity.123 <- sens.num/sens.den
    g.123 <- sqrt(specificity.123 * sensitivity.123)
    
    ## Up to here we have computations for groups 2,3,4,5
    FDR.23 <- F.23/R.23
    specificity.23 <- spec.num.23/spec.den.23
    sensitivity.23 <- sens.num.23/sens.den.23
    g.23 <- sqrt(specificity.23 * sensitivity.23)
    
    
    ## Combining Groups 6-10
    rest.groups <- unlist(X.list[13:nrow.groups])
    out[index.tmp,] <-  apply(out.simu[rest.groups,],2,mean)
    out.zeros[index.tmp,] <- apply(out.simu.zeros[rest.groups,],2,mean)
    R <- R + length(rest.groups) * out[index.tmp,]
    F <- F + length(rest.groups) * out[index.tmp,]
    
    spec.num <- spec.num + length(rest.groups) * out.zeros[index.tmp,]
    spec.den <- spec.den + length(rest.groups) * out.zeros[index.tmp,] +
      length(rest.groups) * out[index.tmp,]
  }
  

  out <- out * 100/nsimu
  
  out["FDR",] <- F/R
  FDR <- out["FDR",]

  specificity <- spec.num/spec.den
  sensitivity <- sens.num/sens.den
  g.all <- sqrt(specificity * sensitivity)
  out["specificity",] <- specificity
  out["sensitivity",] <- sensitivity
  out["gscore",] <- g.all

  out["FDR_123",] <- FDR.123
  out["specificity_123",] <- specificity.123
  out["sensitivity_123",] <- sensitivity.123
  out["gscore_123",] <- g.123

  out["FDR_23",] <- FDR.23
  out["specificity_23",] <- specificity.23
  out["sensitivity_23",] <- sensitivity.23
  out["gscore_23",] <- g.23

  
  ## Computation for sensitivity, specificity and geometric mean
  beta <- as.vector(t(beta.coef))	## Make into a vector
  beta <- beta[!is.na(beta)]		## Remove NA values
  beta.nonzero <- which(beta!=0)
  beta.zero <- which(beta==0)

  specificity.calc <- function(out.tmp){
    my.specificity <- sum(abs(out.tmp[beta.zero])<1e-5)/length(beta.zero)
    return(my.specificity)
  }

  sensitivity.calc <- function(out.tmp){
    my.sensitivity <- sum(abs(out.tmp[beta.nonzero])>1e-5)/length(beta.nonzero)
    return(my.sensitivity)
  }

  g.calc <- function(out.tmp){
    my.sensitivity <- sensitivity.calc(out.tmp)
    my.specificity <- specificity.calc(out.tmp)
    return(sqrt(my.sensitivity * my.specificity))
  }

  ##specificity <- apply(out.simu,2,specificity.calc)
  ##sensitivity <- apply(out.simu,2,sensitivity.calc)
  ##g.all <- apply(out.simu,1,g.calc)

  
  
  list(out=out,FDR=FDR)
}


