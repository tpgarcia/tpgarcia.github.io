############################
## Common parameters used ##
############################

## number of simulations
nsimu <- 1

## number of repeated K-fold cross-validations
ncv <- 2 ## for manuscript, we set this to 100


## programs to run
run.Lasso <- TRUE;
run.Group.Lasso <- TRUE;
run.Group.Lasso.Group.Lasso <- TRUE;
run.Group.Lasso.Group.Lasso.Lasso <- TRUE;

if(!exists(as.character(substitute(run.SGL)))){
  run.SGL <- FALSE
}

if(!exists(as.character(substitute(run.subgroup.SGL)))){
  run.subgroup.SGL <- FALSE
}

if(!exists(as.character(substitute(run.Group.Lasso.SGL)))){
  run.Group.Lasso.SGL <- FALSE
}

## seed for generating data
seed <- 1110 

## delta value
delta <- 2
delta.sub <- delta;
delta.ind <- delta;

## tau value
tau <- 0.94

## lambda values
lambda.accuracy <- 1e-4;
lambdas <- NULL         
nlam <- 100  # maybe change to 100?

## how data set is generated
run.simon <- FALSE

## for LASSO algorithm
use.Gram <-  TRUE

## run a range of alpha values?
if(!exists(as.character(substitute(run.alphas.range)))){
  run.alphas.range <- FALSE
}

## standardize for group Lasso?
if(!exists(as.character(substitute(group.standardize)))){
  group.standardize <- TRUE; 
}

## run repeated cross-validations?
if(!exists(as.character(substitute(SGL.cv)))){
  SGL.cv  <- FALSE;
}

if(!exists(as.character(substitute(Group.Lasso.SGL.cv)))){
  Group.Lasso.SGL.cv  <- FALSE;
}

if(!exists(as.character(substitute(subgroup.SGL.cv)))){
  subgroup.SGL.cv  <- FALSE;
}




## If we run multiple cv, we only run 1 simulation at a time
if(SGL.cv == TRUE | Group.Lasso.SGL.cv == TRUE | subgroup.SGL.cv == TRUE){
  nsimu <- 1

  run.Lasso <- FALSE
  run.Group.Lasso <- FALSE
  run.SGL <- FALSE
  run.subgroup.SGL <- FALSE
  run.Group.Lasso.Group.Lasso <- FALSE
  run.Group.Lasso.SGL <- FALSE
  run.Group.Lasso.Group.Lasso.Lasso <- FALSE

}



## percents.range
percents.range <- seq(50,100,by=10)

## number of folds in cross-validation
nfold <- 10

## alphas.cv.range
alphas.cv.range <- c(seq(0.01,0.1,by=0.01),seq(0.15,0.95,by=0.05))

if(subgroup.SGL.cv == TRUE){
  alphas.cv.range <- c(seq(0.01,0.1,by=0.03),seq(0.15,0.95,by=0.1))
}


## alpha values
alpha1 <- 0.05;
alpha2 <- 0.2;
alpha3 <- 0.1
alpha <- alpha3;
alpha.SGL <- alpha3;
two.alphas <- FALSE;


if(run.alphas.range==TRUE){
  ##Programs run
  run.Lasso=FALSE;
  run.Group.Lasso=FALSE;
  run.SGL=FALSE;
  run.subgroup.SGL=TRUE;
  run.Group.Lasso.Group.Lasso=FALSE;
  run.Group.Lasso.SGL=FALSE;
  run.Group.Lasso.Group.Lasso.Lasso=FALSE;
  alpha1 <- c(0.01,0.05,0.1,0.2)#,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
  alpha2 <- c(0.01,0.05,0.1,0.2)#,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
  alpha3 <- c(0.01,0.05,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
  alpha <- 0.95
} 

## Form beta coefficients for each group
N=30;	
L=10;

if(beta.set=="set1"){
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4)

} else if(beta.set=="set11"){
  p.in.group =6;
  p=L * p.in.group;
  sigma <- sqrt(2);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.2,0.3,0.4)
  beta.coef[2,] <- c(0.2,0.3,0.4)
  
} else if(beta.set=="set2"){
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[3,] <- c(0.1,0.2,0.3,0.4)
  
} else if(beta.set=="set22"){
  p.in.group =6;
  p=L * p.in.group;
  sigma <- sqrt(2);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.2,0.3,0.4)
  beta.coef[2,] <- c(0.2,0.3,0.4)
  beta.coef[3,] <- c(0.2,0.3,0.4)

} else if(beta.set=="set3"){
  ## 1-3-2013: Right now, this is the setting we like for paper version 10. But it needs to be updated.
  
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[3,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[5,] <- c(0.5,0.5,0,0)
  ##beta.coef[5,] <- c(0.25,0.25,0,0)

} else if(beta.set=="set33"){
  p.in.group =6;
  p=L * p.in.group;
  sigma <- sqrt(2);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.2,0.3,0.4)
  beta.coef[2,] <- c(0.2,0.3,0.4)
  beta.coef[3,] <- c(0.2,0.3,0.4)
  beta.coef[5,] <- c(0.5,0.5,0)
  ##beta.coef[5,] <- c(0.25,0.25,0)
} else if(beta.set=="set4"){
  ## 1/14/2013: This setting for sub_sgl did not lead to good results. The elements were not picked up
  ## frequently enough.
  
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[3,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[5,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[7,] <- c(0.5,0.5,0.5,0)
  beta.coef[9,] <- c(0.5,0.5,0.5,0)
  beta.coef[11,] <- c(0.5,0.5,0,0)
  beta.coef[12,] <- c(0,0,0.5,0.5)
  beta.coef[13,] <- c(0.5,0.5,0,0)
  beta.coef[14,] <- c(0,0,0.5,0.5)
} else if(beta.set=="set5"){
  ## 1/16/2013: This setting also did not give good results. Lasso outperformed ours.
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[3,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[4,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[5,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[7,] <- c(0.1,0.2,0.3,0.4)
  beta.coef[9,] <- c(0.5,0.5,0,0)
  beta.coef[11,] <- c(0.5,0.5,0,0)
  ##beta.coef[5,] <- c(0.25,0.25,0,0)
  
} else if(beta.set=="set6"){
  ## 1/19/2013: results are okay.
  
  p.in.group =10;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4,0.5)
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4,0.5)
  beta.coef[3,] <- c(0.1,0.2,0.3,0.4,0.5)
  beta.coef[5,] <- c(0.5,0.5,0.5,0,0)
} else if(beta.set=="set7"){
  ## 1/22/2013: Results not good.
  
  p.in.group =10;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4,0.5)
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4,0.5)
  beta.coef[3,] <- c(0.3,0.4,0.5,0.6,0.7)
  beta.coef[5,] <- c(0.3,0.4,0.5,0.6,0.7)
  beta.coef[7,] <- c(0.5,0.5,0.5,0,0)
  beta.coef[9,] <- c(0.5,0.5,0,0,0)
} else if(beta.set=="set3_big"){
  ## 1-22-2013: This is analogous to "set3" but with bigger coefficients
  ## 1-24-2013: Checked the results, they are looking good, but we need bigger coefficients.
  
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  #beta.coef[1,] <- c(2,2.4,2.6,3)/2
  #beta.coef[2,] <- c(2,2.4,2.6,3)/2
  #beta.coef[3,] <- c(2,2.4,2.6,3)/2
  #beta.coef[5,] <- c(3,3,0,0)/2

  beta.coef[1,] <- c(4,4.4,4.6,5)/2
  beta.coef[2,] <- c(4,4.4,4.6,5)/2
  beta.coef[3,] <- c(4,4.4,4.6,5)/2
  beta.coef[5,] <- c(5,5,0,0)/2
  ##beta.coef[5,] <- c(0.25,0.25,0,0)
  
} else if(beta.set=="set6_big"){
  ## 1/22/2013: This is analogous to "set6" but with bigger coefficients.
  
  p.in.group =10;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(4.5,4.5,4.5,4.5,5)/2
  beta.coef[2,] <- c(4.5,4.5,4.5,4.5,5)/2
  beta.coef[3,] <- c(4.5,4.5,4.5,4.5,5)/2
  beta.coef[5,] <- c(5,5,5,0,0)/2

  #beta.coef[1,] <- c(1,2,2,3,4)/2
  #beta.coef[2,] <- c(1,2,2,3,4)/2
  #beta.coef[3,] <- c(1,2,2,3,4)/2
  #beta.coef[5,] <- c(4,4,4,0,0)/2
}  else if(beta.set=="set3_bigger"){
  ## 1-24-2013: This is analogous to set3 but with even bigger coefficients.
  
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);

  ## 1/25/2013: This setting gives good results, but beta.coef[5,] may be too strong.
  ## beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  ## beta.coef[1,] <- c(6,6.4,6.6,8)/2
  ## beta.coef[2,] <- c(6,6.4,6.6,8)/2
  ## beta.coef[3,] <- c(6,6.6,6.6,8)/2
  ## beta.coef[5,] <- c(15,15,0,0)/2

  ## 1/25/2013: This gives good results.
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(6,6.4,6.6,8)/2
  beta.coef[2,] <- c(6,6.4,6.6,8)/2
  beta.coef[3,] <- c(6,6.6,6.6,8)/2
  beta.coef[5,] <- c(12.5,12.5,0,0)/2

} else if(beta.set=="set6_bigger"){
  ## 1/24/2013: This is analogous to "set6" but with even bigger coefficients.

  p.in.group =10;
  p=L * p.in.group;
  sigma <- sqrt(1);

  ## 1/25/2013: This setting gives good results, but maybe we need a bit stronger.
  ## beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  ## beta.coef[1,] <- c(8.5,8.5,8.5,9,9)/2
  ## beta.coef[2,] <- c(8.5,8.5,8.5,9,9)/2
  ## beta.coef[3,] <- c(8.5,8.5,8.5,8.5,9)/2
  ## beta.coef[5,] <- c(12,12,12,0,0)/2

  ## 1/25/2013: This does not give good results.
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(8.5,8.5,8.5,9,9)/2
  beta.coef[2,] <- c(8.5,8.5,8.5,9,9)/2
  beta.coef[3,] <- c(8.5,8.5,8.5,8.5,9)/2
  beta.coef[5,] <- c(14,14,14,0,0)/2
} else if(beta.set=="set3a"){
  ## 1-27-2013: This is the setting we are working with.
  
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4)*10
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4)*10
  beta.coef[3,] <- c(0.1,0.2,0.3,0.4)*10
  beta.coef[5,] <- c(0.5,0.5,0,0)*10
  ##beta.coef[5,] <- c(0.25,0.25,0,0)
} else if(beta.set=="set3b"){
  ## 5-22-2013: This is analogous to set3a but with another Group2/Group3 to the mix.
  
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);
  
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(0.1,0.2,0.3,0.4)*20
  beta.coef[2,] <- c(0.1,0.2,0.3,0.4)*20
  beta.coef[3,] <- c(0.1,0.2,0.3,0.4)*20
  beta.coef[5,] <- c(0.5,0.5,0,0)*20
  beta.coef[7,] <- c(0.1,0.2,0.3,0.4)*20
  beta.coef[9,] <- c(0.5,0.5,0,0)*20
  ##beta.coef[5,] <- c(0.25,0.25,0,0)
} else if(beta.set=="set3b_bigger"){
  ## 1-24-2013: This is analogous to set3 but with even bigger coefficients.
  
  p.in.group =8;
  p=L * p.in.group;
  sigma <- sqrt(1);

  ## 1/25/2013: This setting gives good results, but beta.coef[5,] may be too strong.
  ## beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  ## beta.coef[1,] <- c(6,6.4,6.6,8)/2
  ## beta.coef[2,] <- c(6,6.4,6.6,8)/2
  ## beta.coef[3,] <- c(6,6.6,6.6,8)/2
  ## beta.coef[5,] <- c(15,15,0,0)/2

  ## 5/22/2013: This is analogous to set3_bigger but with another Group2/Group3 to the mix.
  beta.coef <- matrix(0,nrow=2*L,ncol=(p/L)/2)
  beta.coef[1,] <- c(6,6.4,6.6,8)
  beta.coef[2,] <- c(6,6.4,6.6,8)
  beta.coef[3,] <- c(6,6.6,6.6,8)
  beta.coef[5,] <- c(12.5,12.5,0,0)
  beta.coef[7,] <- c(6,6.6,6.6,8)
  beta.coef[9,] <- c(12.5,12.5,0,0)
}

beta.coef <- beta.coef *2


## index for sub-groups, subgroup labels are unique!
p.group <- rep(p/L,L)
index.subgroup <- matrix(NA,nrow=L,ncol=p)
tmp <- 0
for(k in 1:L){
  if(k==1){
    index.subgroup[k,1:p.group[k]] <- c(rep(1,(p/L)/2),rep(2,(p/L)/2))
  } else {
    ind <- 1:p.group[k] + sum(p.group[(k-1):1])
    index.subgroup[k,ind] <- c(rep(k+tmp,(p/L)/2),rep(k+tmp+1,(p/L)/2))
  }
  tmp <- tmp + 1
}

##################
## Name of file ##
##################
file <- paste("setting_",beta.set,"_gp_std_",group.standardize,
              "_SGL_cv_",SGL.cv,
              "_Group_Lasso_SGL_cv_",Group.Lasso.SGL.cv,
              "_subgroup_SGL_cv_",subgroup.SGL.cv,
              "_N",N,".csv",sep="")

