
#################
## Source code ##
#################

source("../main/simulation_study_main_sub_group.R")

########################
## Parameter Settings ##
########################

beta.set <- "set3a"
subgroup.SGL.cv <- TRUE


## Set parameters
source("../main/simulation_study_common_parameters.R")



seed <- 1110

file <- paste("seed_",seed,"_",file,sep="")


######################
## Simulation Study ##
######################

source("../main/call_simulation_study.R")

source("../main/simulation_study_table_results.R")
