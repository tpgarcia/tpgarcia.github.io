###############
# Source code #
###############

source("../../main_R_code/simulation_study_main.R")


###############
# For testing #
###############

##q.old=FALSE;
##pi0.true=FALSE;
##pi0.val=0.9;
##std.y=TRUE;
##est.MSE=c("TRUE","est.var","step")[2]
##j <- 1


########################
## Parameter settings ##
########################

source("main_file.R")


## Set parameters
source("../../main_R_code/simulation_study_common_parameters.R")


####################
# Simulation study #
####################

##source("../../main_R_code/call_simulation_study.R")



source("../../main_R_code/simulation_study_table_results.R")
