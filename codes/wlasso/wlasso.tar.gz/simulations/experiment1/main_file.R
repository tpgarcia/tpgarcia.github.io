m <- 40
coef.set <- "set1"

x.star.correlated <- FALSE      # we run without adding X_1.star
