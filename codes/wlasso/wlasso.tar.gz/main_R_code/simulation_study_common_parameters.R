############################
## Common parameters used ##
############################

## number of simulations
nsimu <- 1000

## Check if lasso.mincp exists
if(!exists(as.character(substitute(lasso.mincp)))){
  lasso.mincp <- TRUE
}

## use true  pi0 in q-values? NO
pi0.true <- FALSE


## value of pi0.val
if(x.star.correlated==TRUE){
  pi0.val <-  (((m/4*3+1)-5+1) + ( m - (m/4*3+2)+1 ) + 1)/(m +1)
} else {
  pi0.val <-  (((m/4*3+1)-5+1) + ( m - (m/4*3+2)+1 ) )/m
}

## method for estimating pi, either smoother or bootstrap
method <- "smoother"

## thresholding alpha
alpha <- 0.15

## M_n(delta,p) criterion
delta <- 2


## range of delta values in M_n(delta,p) criterion
delta.range <- c(1)
##delta.range <- c(.25,.4,.5,.75,1,1.5,2)

## t-test used to compute p-values
ttest <- TRUE

## number of mice in each diet group
n.i <- 20

## number of diet groups
g <- 2

## seed for random simulations
seed <- 1110

## weight on diet variable
diet.wt <- 1000

## we cut off small weight values so we avoid division by 0
##thresh.q <- TRUE
thresh.q <- FALSE

## correlation between x1 and x1^* for Samuel setting
rho <- 0.8

## when FALSE, we are computing FDR
robust <- FALSE         

## sets for coefficients
if(coef.set=="set1"){
  coef <- c(4.5,3,-3,-3,3)
}else if(coef.set=="set2"){
  coef<- c(2.5,1.5,-1.5,-1.5,1.5)
  diet.wt <- 10000
} else if(coef.set=="set3"){
  coef <- c(4.5,3,0,-3,3)
} else{
  coef <- c(1.5,1,0,-1,1) 
}


## standardize y?
std.y <- TRUE

## probabilities to calculate quantiles of weights
quant.prob <- c(0.25,0.5,0.75)

## divide by median for boxplot?
divide.med <- TRUE

##############################
## File for storing results ##
##############################
file.name <- paste("coef_",coef.set,
                   "_pi0_",pi0.true,
                   "_m_",m,
                   "_lasso_mincp_",lasso.mincp,
                   "_seed_",seed,sep="")

