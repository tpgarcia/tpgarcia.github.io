############################
# Read  tables for storing #
############################

###########################
## number of sig. digits ##
###########################
sig.digits <- 2




        #######################
        #  out2 : FDR results #
        #######################


# Load Table for Analysis
file <- paste("coef_",coef.set,
              "_pi0_",pi0.true,
              "_m_",m,
              "_lasso_mincp_",lasso.mincp,
              "_seed_",seed,sep="")

file.plot <- paste("coef_",coef.set,"_cor_",x.star.correlated,"_",sep="")

out <- read.csv(paste("simu2_wlasso_results_",file,".csv",sep=""),
                header=TRUE)[,-1]
tvalue <- read.csv(paste("simu2_tvalue_",file,".csv",sep=""),header=TRUE,
                   row.names=1)
parcor.value <- read.csv(paste("simu2_parcor_value_",file,".csv",sep=""),
                         header=TRUE,row.names=1)
pvalue.noadj <- read.csv(paste("simu2_pvalue_noadj_",file,".csv",sep=""),
                         header=TRUE,row.names=1)
pvalue.benhoch <- read.csv(paste("simu2_pvalue_benhoch_",file,".csv",sep=""),
                           header=TRUE,row.names=1)
qvalue <- read.csv(paste("simu2_qvalue_",file,".csv",sep=""),
                   header=TRUE,row.names=1)


out2.FDR.org <- org.simu(m,out,nsimu,forpaper=FALSE,x.star.correlated=x.star.correlated,coef=coef)


## Weighted Lasso

cat("\n \n ##Weighted Lasso\n\n")
out.lasso <- out2.FDR.org$out[,c("w.parcor.1",
                                 "w.tvalue.1",
                                 "w.pvalue.noadj.1",
                                 "w.pvalue.bh.1",
                                 "w.qvalue.1")]
print(xtable(out.lasso,sig.digits=sig.digits))

## Table of weights

g1 <- function(x){
  return(x)
}

g3 <- function(x){
  return(1/abs(x))
}

t.summary <- summary.weights(g3,tvalue,m,x.star.correlated=x.star.correlated,coef=coef,
                             quant.prob=quant.prob,name="t",file.name=paste(file.plot,"_t",sep=""),
                             main.title="Inverted Absolute t-Statistics",divide.med=divide.med,ylim=c(0,10))

parcor.summary <- summary.weights(g3,parcor.value,m,x.star.correlated=x.star.correlated,coef=coef,
                                  quant.prob=quant.prob,name="parcor",file.name=paste(file.plot,"_parcor",sep=""),
                                  main.title="Inverted Absolute Partial Correlations",divide.med=divide.med,ylim=c(0,10))
pvalue.noadj.summary <- summary.weights(g1,pvalue.noadj,m,x.star.correlated=x.star.correlated,coef=coef,
                                        quant.prob=quant.prob,name="pval_noadj",
                                        file.name=paste(file.plot,"_pval_noadj",sep=""),
                                        main.title="p-Values",divide.med=divide.med,ylim=c(0,5))
pvalue.benhoch.summary <- summary.weights(g1,pvalue.benhoch,m,x.star.correlated=x.star.correlated,coef=coef,
                                          quant.prob=quant.prob,name="pval_bh",
                                          file.name=paste(file.plot,"_pvalbh",sep=""),
                                          main.title="Benjamini-Hochberg p-Values",divide.med=divide.med,ylim=c(0,5))
qvalue.summary <- summary.weights(g1,qvalue,m,x.star.correlated=x.star.correlated,coef=coef,
                                  quant.prob=quant.prob,name="q",file.name=paste(file.plot,"_q",sep=""),
                                  main.title="q-Values", divide.med=divide.med,ylim=c(0,5))

cat("\n \n ##Weight Summary\n\n")
out.weights<-cbind(parcor.summary,t.summary,pvalue.noadj.summary,pvalue.benhoch.summary,qvalue.summary)
             
print(xtable(t(out.weights),
             digits=sig.digits))


##cat("\n\n ## Selection and Weights Together\n\n")
##print(xtable(cbind(out.lasso,out.weights),
##             digits=sig.digits))



## Plots
# t-value vs. pvalue.noadj
##myplot.xy(tvalue,pvalue.noadj,xlab="t-statistic", ylab="p-value (no adjustment)",
##          fileplot=paste(file.plot,"tvalue_pvalue_noadj.eps",sep=""))

# t-value vs. pvalue BenHoch
##myplot.xy(tvalue,pvalue.benhoch,xlab="t-statistic", ylab="BH p-value",
##          fileplot=paste(file.plot,"tvalue_pvalue_benhoch.eps",sep=""))

# t-value vs. parcor
myplot.xy(tvalue,parcor.value,xlab="Inverted absolute t-statistic", ylab="Inverted absolute partial correlation",
          fileplot=paste(file.plot,"tvalue_parcor.eps",sep=""))

# t-value vs. q value
##myplot.xy(tvalue,qvalue,xlab="t-statistic", ylab="q-value",
##          fileplot=paste(file.plot,"tvalue_qvalue.eps",sep=""))

# pvalue.noadj vs pvalue.benhoch
##myplot.xy(pvalue.noadj,pvalue.benhoch,xlab="p-value (no adjustment)", ylab="BH p-value",
##          fileplot=paste(file.plot,"pvalue_noadj_pvalue_benhoch.eps",sep=""))

# pvalue.noadj vs parcor.value
##myplot.xy(pvalue.noadj,parcor.value,xlab="p-value (no adjustment)", ylab="partial correlation",
##          fileplot=paste(file.plot,"pvalue_noadj_parcor.eps",sep=""))

# pvalue.noadj vs q-value
##myplot.xy(pvalue.noadj,qvalue,xlab="p-value (no adjustment)", ylab="q-value",
##          fileplot=paste(file.plot,"pvalue_noadj_qvalue.eps",sep=""))


# pvalue.benhoch vs parcor
##myplot.xy(pvalue.benhoch,parcor.value,xlab="BH p-value",ylab="partial correlation",
##          fileplot=paste(file.plot,"pvalue_benhoch_parcor.eps",sep=""))


# pvalue.benhoch vs qvlaue
##myplot.xy(pvalue.benhoch,qvalue,xlab="BH p-value",ylab="qvalue",
##          fileplot=paste(file.plot,"pvalue_benhoch_qvalue.eps",sep=""))

# parcor vs qvlaue
##myplot.xy(parcor.value,qvalue,xlab="partial correlation",ylab="qvalue",
##          fileplot=paste(file.plot,"parcor_qvalue.eps",sep=""))

