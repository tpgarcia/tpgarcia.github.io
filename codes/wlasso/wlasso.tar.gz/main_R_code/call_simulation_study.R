## Function to call simulation study
out2.FDR <-  simu.study(rho = rho,
                        coef = coef,
                        nsimu = nsimu,
                        alpha = alpha,
                        delta = delta,
                        delta.range=delta.range,
                        ttest = ttest,
                        method = method,
                        m = m ,
                        n.i = n.i,
                        g = g,
                        seed = seed,
                        diet.wt = diet.wt,
                        thresh.q=thresh.q,
                        robust=robust,
                        pi0.val = pi0.val,
                        pi0.true = pi0.true,
                        std.y=std.y,
                        x.star.correlated = x.star.correlated,
                        lasso.mincp = lasso.mincp)

############################
# Write tables for storing #
############################

write.csv(out2.FDR$wlasso.results,paste("simu2_wlasso_results_",file.name,
                                        ".csv",sep=""))
write.csv(out2.FDR$out.tvalue, paste("simu2_tvalue_",file.name,".csv",
                                     sep=""))
write.csv(out2.FDR$out.pvalue.noadj, paste("simu2_pvalue_noadj_",
                                           file.name,".csv",sep=""))
write.csv(out2.FDR$out.pvalue.benhoch, paste("simu2_pvalue_benhoch_",
                                             file.name,".csv",sep=""))
write.csv(out2.FDR$out.parcor.value, paste("simu2_parcor_value_",
                                           file.name,".csv",sep=""))
write.csv(out2.FDR$out.qvalue, paste("simu2_qvalue_",file.name,
                                     ".csv",sep=""))
