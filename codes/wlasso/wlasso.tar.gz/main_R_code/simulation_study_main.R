#######################
## Clean out objects ##
#######################
rm(list=ls(all=TRUE))

#################
## Source code ##
#################

source("../../main_R_code/microbe_ana.R")
#source("microbe_ana.R")

####################################################
## Function to generate a variable x.star that is ##
## correlated with x and has correlation rho      ##
####################################################

## x : original variable that x.star will be correlated with
## rho : correlation between x.star and x

x.correlated <- function(x,rho){
  ## standardize x
  x.std <- ( x - mean(x) ) / sd(x)
  
  ## coefficient needed to make x.star and x correlated
  a <- sqrt ( rho^2 / ( 1 - rho^2 ) )
  
  ## generate x.star
  x.star <- a * x.std +  rnorm(length(x),sd=1)
  
  return(x.star)
}


## for testing
##cor.out <- rep(0,1000)
##for(i in 1:1000){
##	cor.out[i] <- cor(x.correlated(x,rho),x)
##}
##mean(cor.out)

###############################
## Function to simulate data ##
###############################

## coef  : true coefficient values
## m     : numer of microbes
## n.i   : number of observations per diet group
## g     : number of diet groups
## x.star.correlated : indicator that we generate an extra variable that is correlated with
##   another x, but does not act on y
## rho : correlation between X[,1] and X[,1].star

data.generated <- function(coef,g,n.i,m,rho=0.8,x.star.correlated=FALSE){
  ## Total sample size
  N <- g * n.i	
  
  diet    <-  rep(c(-1,1),each=n.i)
  d.on.X  <-  c(runif(m/4*3,0.25,0.5),rep(0,m/4))
  X       <-  matrix(runif(N*m),ncol=m) 
  for (i in 1:m){
    X[,i] = X[,i] + matrix(diet*d.on.X[i],ncol=1)
  }
  
  ## Generate X[,1]^* that is correlated with X[,1] ? 
  if(x.star.correlated ==TRUE){
    X.star <- x.correlated(X[,1],rho)
  }
  
  y <- coef[1] * diet + coef[2] * X[,1] + coef[3] * X[,2] + coef[4] * X[,3] + coef[5]* X[,m] + rnorm(N,sd=1/sqrt(2))
  
  ## raw design matrix X
  if(x.star.correlated==TRUE){
    X  <-  cbind(diet,X,X.star)	
    colnames(X) <- c("Diet",paste("X_",seq(1,m),sep=""),"X_1.star")
  } else {
    X  <-  cbind(diet,X)	
    colnames(X) <- c("Diet",paste("X_",seq(1,m),sep=""))	
  }
  
  microbes <- t(X)
  phenotypes <- as.data.frame(t(y))
  rownames(phenotypes) <- "phenotype"
  
  list(microbes=microbes,phenotypes=phenotypes)
}




# For Testing!!!
#nsimu=10;alpha=0.15;ttest=TRUE;method=c("bootstrap","smoother")[2]
#m=40;n.i=20;g=2;seed=1110;diet.wt=100
#coef<- c(4.5,3,-3,-3,3); rho =0.8

#####################################
## Function to do simulation study ##
#####################################

## nsimu : number of simulations
## coef  : true coefficient values
## alpha : cut-off for q-values
## m     : numer of microbes
## n.i   : number of observations per diet group
## g     : number of diet groups
## seed  : seed used for simulations
## ttest : T/F for using ttest in computing p-values for correlations
##         and partial correlations
## method : either bootstrap or smoother for computing q-values
## diet.wt : weight on diet variable
## x.star.correlated : indicator that we generate an extra variable that is correlated with
##   another x, but does not act on y

## lasso.mincp: if TRUE, we run Lasso with criterion of Mn(delta,p)
## lasso.cv : if TRUE, we run LASSO with cv-criterion
## lasso.delta.cv.mult : If TRUE, we run LASSO with delta-cv criterion multiple times (ncv times)

simu.study<- function(rho=0.8,coef=c(4.5,3,-3,-3,3),nsimu=1000,alpha=0.15,delta=2,
                      delta.range=c(1),
                      ttest=TRUE,method=c("bootstrap","smoother")[1],
                      m=40,n.i=20,g=2,seed=1110,diet.wt=100,thresh.q=FALSE,robust=TRUE,q.old=FALSE,
                      pi0.true=FALSE,pi0.val=0.9,std.y=TRUE,est.MSE=c("TRUE","est.var","step")[2],
                      x.star.correlated=FALSE, lasso.mincp=TRUE)
{
  
######################################
  ## Form matrices for storing output ##
######################################
  
  ## To get dimensions and rownames for output, we run a simulated data set
  data <- data.generated(coef,g,n.i,m,rho,x.star.correlated)
  microbes <- data$microbes
  
  out.nrow <- nrow(microbes)
  out.rownames <- rownames(microbes)	

###################################
  ## Output from Weights ##
###################################
  ## stores t-value statistics
  out.tvalue <-  as.data.frame(matrix(0, nrow = (out.nrow-1), ncol = nsimu,
                                      dimnames = list(out.rownames[-1],
                                        seq(1,nsimu))))

  ## stores original p-values
  out.pvalue.noadj <-  as.data.frame(matrix(0, nrow = (out.nrow-1), ncol = nsimu,
                                      dimnames = list(out.rownames[-1], seq(1,nsimu))))

  ## stores Benjamini-Hochberg p-values
  out.pvalue.benhoch <-  as.data.frame(matrix(0, nrow = (out.nrow-1), ncol = nsimu,
                                      dimnames = list(out.rownames[-1], seq(1,nsimu))))
  
  ## stores partial correlations
  out.parcor.value <-  as.data.frame(matrix(0, nrow = (out.nrow-1), ncol = nsimu,
                                      dimnames = list(out.rownames[-1], seq(1,nsimu))))

  ## stores q-values
  out.qvalue <-  as.data.frame(matrix(0, nrow = (out.nrow-1), ncol = nsimu,
                                            dimnames = list(out.rownames[-1], seq(1,nsimu))))
  
##########################################################
  ## Output for weighted Lasso with Mn(delta,p) criterion ##
##########################################################
  
  ## Weight functions
  g1 <- function(x){
    return(x)
  }
  
  g2 <- function(x){
    return(sqrt(x))
  }
  
  g3 <- function(x){
    return(1/abs(x))
  }
  
  g4 <- function(x){
    return(x^2)
  }
  
  ## stores results from weighted lasso when weights are set to t-values AFTER taking into account
  ## diet,
  ##           and weight function g3
  
  w.tvalue <- as.data.frame(matrix(0,nrow=out.nrow,ncol=length(delta.range),
                                 dimnames = list(out.rownames,paste("w.tvalue.",delta.range,sep=""))))

  ## stores results from weighted lasso when weights are set to original p-values AFTER taking into account diet,
  ##           and weight function g1
  
  w.pvalue.noadj <- as.data.frame(matrix(0,nrow=out.nrow,ncol=length(delta.range),
                                 dimnames = list(out.rownames,paste("w.pvalue.noadj.",delta.range,
                                   sep=""))))

  
  ## stores results from weighted lasso when weights are set to original p-values AFTER taking into account diet,
  ##           and weight function g1
  
  w.pvalue.benhoch <- as.data.frame(matrix(0,nrow=out.nrow,ncol=length(delta.range),
                                         dimnames = list(out.rownames,paste("w.pvalue.bh.",
                                           delta.range,sep=""))))
  
  ## stores results from weighted lasso when weights are set to partial correlations AFTER taking into account diet,
  ##           and weight function g3
  
  w.parcor <- as.data.frame(matrix(0,nrow=out.nrow,ncol=length(delta.range),
                                   dimnames = list(out.rownames,paste("w.parcor.",
                                     delta.range,sep=""))))
  
  ## stores results from weighted lasso when weights are set to q-values AFTER taking into account diet,
  ##           and weight function g1
  
  w.qvalue <- as.data.frame(matrix(0,nrow=out.nrow,ncol=length(delta.range),
                                   dimnames = list(out.rownames,
                                     paste("w.qvalue.",delta.range,sep=""))))
  
  
#######################
  ## Start Simulations ##
#######################
  
  
  ## set seed
  set.seed(seed)
  
  for(j in 1:nsimu){
#################
    ## Generate data #
#################	
    ##print(j)
    data <- data.generated(coef,g,n.i,m,rho,x.star.correlated)
    microbes <- data$microbes
    phenotypes <- data$phenotypes
    
    
###########################################
    ## Get correlation and partial correlation #
############################################
    parcor.out <- correlations(microbes,phenotypes,partial=TRUE,ttest=ttest,format.data=FALSE)
    cor.out <- correlations(microbes,phenotypes,partial=FALSE,ttest=ttest,format.data=FALSE)
    fstat.out <- ftests(microbes)
    
#####################
    ## Get Weights: t-statistic, p-values, Benjamin-Hochberg p-values, q-values, partial correlations ##
#####################
    
    ## t-values with \beta_k in y=diet + \beta_k * microbe_k
    weight.tvalue <- parcor.out$tvalues
    out.tvalue[,j] <- parcor.out$tvalues
    
    ## p-values with \beta_k in y=diet + \beta_k * microbe_k
    weight.pvalue.noadj <- parcor.out$pvalues
    out.pvalue.noadj[,j] <- parcor.out$pvalues 

    ## Benjamini-Hochberg adjusted p-values from y=diet + \beta_k * microbe_k
    benhoch.results <- ben.hoch.interest(parcor.out$pvalues,alpha=0.05)
    weight.pvalue.benhoch <- benhoch.results$pval.adjust
    out.pvalue.benhoch[,j] <- benhoch.results$pval.adjust
    
    ## partial correlations
    weight.parcor <- parcor.out$estimate
    out.parcor.value[,j] <- parcor.out$estimate

    ## q-values from  y=diet + \beta_k * microbe_k
    ## Results for testing if a microbe has an effect on phenotype, but AFTER
    ##            accounting for diet
    ## That is, we test : H_0 : \beta_{x_j|z}=0
    
    microbe.parcor.out.qvalues <- q.computations(parcor.out,method=method,
                                                 plots=FALSE,file="parcor",robust=robust,q.old=q.old,
                                                 pi0.true=pi0.true,pi0.val=pi0.val)

    weight.qvalue <- microbe.parcor.out.qvalues$qval.mat
    out.qvalue[,j] <- microbe.parcor.out.qvalues$qval.mat
    
    
###############################################
    ## Weighted Lasso with Mn(delta,p) criterion ##
###############################################	
    
    if(lasso.mincp==TRUE){	
###################################################
      ## Lasso calculations: With Diet forced in model ##
###################################################
      
      ##		g1 <- function(x){
      ##			return(x)
      ##		}
      
      ##		g2 <- function(x){
      ##			return(sqrt(x))
      ##		}
      
      ##		g3 <- function(x){
      ##			return(1/abs(x))
      ##		}
      
      ##		g4 <- function(x){
      ##			return(x^2)
      ##		}
      
      include.diet <- "TRUE"
      
      for(d in 1:length(delta.range)){
        ## weights are t-values
        weights <- weight.tvalue         
        lasso.tvalue <- lasso.computations(weights,microbes,phenotypes,g3,plots=FALSE,
                                           file="weight_tval_",
                                           include.diet=include.diet,format.data=FALSE,diet.wt=diet.wt,
                                           corr.g=TRUE,
                                           delta=delta.range[d],
                                           std.y=std.y,est.MSE=est.MSE)
        w.tvalue[,d] <- w.tvalue[,d] + lasso.tvalue$interest

        ## weights are partial correlations
        weights <- weight.parcor
        lasso.parcor <- lasso.computations(weights,microbes,phenotypes,g3,plots=FALSE,
                                           file="weight_parcor_",
                                           include.diet=include.diet,format.data=FALSE,
                                           diet.wt=diet.wt,corr.g=TRUE,
                                           delta=delta.range[d],
                                           std.y=std.y,est.MSE=est.MSE)
        w.parcor[,d] <- w.parcor[,d] + lasso.parcor$interest
        
        ## weights are original p-values
        weights <- weight.pvalue.noadj
        lasso.pvalue.noadj <- lasso.computations(weights,microbes,phenotypes,g1,plots=FALSE,
                                                 file="weight_pval_noadj_",
                                                 include.diet=include.diet,format.data=FALSE,
                                                 diet.wt=diet.wt,
                                                 thresh.q=thresh.q,delta=delta.range[d],
                                                 std.y=std.y,est.MSE=est.MSE)
        w.pvalue.noadj[,d] <- w.pvalue.noadj[,d] + lasso.pvalue.noadj$interest

        
        ## weights are BenHoch p-values
        weights <- weight.pvalue.benhoch
        lasso.pvalue.benhoch <- lasso.computations(weights,microbes,phenotypes,g1,plots=FALSE,
                                                   file="weight_pval_benhoch_",
                                                   include.diet=include.diet,format.data=FALSE,
                                                   diet.wt=diet.wt,
                                                   thresh.q=thresh.q,delta=delta.range[d],
                                                   std.y=std.y,est.MSE=est.MSE)
        w.pvalue.benhoch[,d] <- w.pvalue.benhoch[,d] + lasso.pvalue.benhoch$interest

        ## weights are q-values
        weights <- weight.qvalue
        lasso.qvalue <- lasso.computations(weights,microbes,phenotypes,g1,plots=FALSE,
                                           file="weight_pval_qval_",
                                           include.diet=include.diet,format.data=FALSE,
                                           diet.wt=diet.wt,
                                           thresh.q=thresh.q,delta=delta.range[d],
                                           std.y=std.y,est.MSE=est.MSE)
        w.qvalue[,d] <- w.qvalue[,d] + lasso.qvalue$interest
      }
    }
  }
    
######################
  ## Organize results ##
######################
  wlasso.results <- cbind(w.tvalue,
                          w.pvalue.noadj,
                          w.pvalue.benhoch,
                          w.qvalue,
                          w.parcor)
                      
  out <- list(out.tvalue=out.tvalue,
              out.pvalue.noadj=out.pvalue.noadj,
              out.pvalue.benhoch=out.pvalue.benhoch,
              out.parcor.value=out.parcor.value,
              out.qvalue=out.qvalue,
              wlasso.results=wlasso.results)
              
}
  

## function to organize output from multiple cv-delta process
org.mult.cv.delta <- function(mult.cv.delta.output,percent,ncv){
  make.criteria <- function(ncv,percent){
    function(x){
      return(x >= ncv * percent/100)
    }
  }

  criteria <- make.criteria(ncv,percent)
  
  check.criteria <- apply(mult.cv.delta.output,c(1,2),criteria)
  
  output <- apply(check.criteria,1,sum) 
  return(output)
}


## function to plot x and y
myplot.xy <- function(x,y,xlab=NULL,ylab=NULL,fileplot="myplot.eps"){
  x.avg <- apply(abs(x),1,mean)
  y.avg <- apply(abs(y),1,mean)

  postscript(fileplot)
  plot(x.avg,y.avg,main="",xlab=xlab,ylab=ylab)
  lines(lowess(x.avg,y.avg),col="red") ## lowess curve
  dev.off()
}
  

## function to see summary of weights
summary.weights <- function(g,weights,m,x.star.correlated,coef,quant.prob=c(0.25,0.5,0.75),name="new",
                            file.name=NULL,main.title,divide.med=TRUE,cex.main=2,cex.axis=2,ylim=c(0,5)){
##  weights.avg <- apply(g(weights),1,mean)
  weights.avg <- g(weights)
  weights.avg <- rbind(rep(0,ncol(weights.avg)),weights.avg)
  
  if(x.star.correlated==TRUE){
    num.row = 7
  } else {
    num.row=6
  }
  out <- matrix(0,nrow = num.row, ncol=(1+length(quant.prob)))
  out <- as.data.frame(out)
  colnames(out) <- c("Avg_Weight",paste(name,"_Quantile_",quant.prob,sep=""))
  
  if(x.star.correlated==TRUE){
    rownames(out) <- c("Diet","Group 1","Group 2","Group 3","Group 4","Group 5","FDR")	
  } else {
    rownames(out) <- c("Diet","Group 1","Group 2","Group 3","Group 4","FDR")	
  }

  diet.group <-weights.avg[1,]
  if(coef[3]==0){
    group1 <- weights.avg[c(2,4),]
    group2 <- weights.avg[c(3,5:(m/4*3+1)),]
  } else {
    group1 <- weights.avg[c(2,3,4),]
    group2 <- weights.avg[5:(m/4*3+1),]
  }
  group3 <- weights.avg[(m/4*3+2):m,]
  group4 <- weights.avg[m+1,]

  if(divide.med==TRUE){
    all.groups <- rbind(group1,group2,group3,group4)
    median.value <- apply(all.groups,2,median)
    ##median.value <- mean(median.value)
    ##median.value <- median(c(group1,group2,group3,group4))
  } else {
    median.value <- rep(1,nsimu)
  }

  get.min <- function(group){
    min.value <- mean(apply(group,2,min))
    return(min.value)
  }

  get.max <- function(group){
    max.value <- mean(apply(group,2,max))
    return(max.value)
  }  
  
  get.mean <- function(group){
    mean.value <- mean(apply(group,2,mean))
    return(mean.value)
  }

  get.quantiles <- function(group){
    quantiles.value <- apply(apply(group,2,quantile,probs=quant.prob),1,mean)
    return(quantiles.value)
  }

  get.mean.quantiles <- function(group){
    mean.value <- get.mean(group)
    quantiles.value <- get.quantiles(group)
    return(c(mean.value,quantiles.value))
  }

  get.boxplot.values <- function(group,median.value){
    group <- t(apply(group,1,"/",median.value))
        
    ##min.value <- get.min(group)
    ##max.value <- get.max(group)
    ##quantiles.value <- get.quantiles(group)
    ##return(c(min.value,quantiles.value,max.value))
    return(c(group))

  }
  
  
  out["Group 1",] <- get.mean.quantiles(group1)
  out["Group 2",] <- get.mean.quantiles(group2)
  out["Group 3",] <- get.mean.quantiles(group3)
  out["Group 4",] <- get.mean.quantiles(group4)

  weights.list <- list(get.boxplot.values(group1,median.value),
                       get.boxplot.values(group2,median.value),
                       get.boxplot.values(group3,median.value),
                       get.boxplot.values(group4,median.value))
  weights.names <- c("Group 1", "Group 2", "Group 3",
                     "Group 4")
  
  if(x.star.correlated==TRUE){
    ## for X_1.star
    group5 <- weights.avg[m+2,]
    out["Group 5",] <- get.mean.quantiles(group5)

    weights.list <- list(get.boxplot.values(group1,median.value),
                         get.boxplot.values(group2,median.value),
                         get.boxplot.values(group3,median.value),
                         get.boxplot.values(group4,median.value),
                         get.boxplot.values(group5,median.value))
    
    weights.names <- c("Group 1", "Group 2", "Group 3",
                       "Group 4", "Group 5")
  }

  postscript(paste(file.name,"_boxplot.eps",sep=""))
  boxplot(weights.list,names=weights.names,main=main.title,cex.axis=cex.axis,cex.main=cex.main,ylim=ylim)
  dev.off()

  return(out)
}


## function to compute mean and alpha and (1-alpha) quantiles
	
summarize.function <- function(x){
  nsimu <- ncol(x)	
  
  lower.bound <- function(y){
    alpha <- 0.05
    sort.y <- sort(y)
    lo.bound <- sort.y[ceiling(length(y) * alpha/2)]
    return(lo.bound)
  }
  
  upper.bound <- function(y){
    alpha <- 0.05
    sort.y <- sort(y)
    hi.bound <- sort.y[ceiling(length(y) * (1-alpha/2))]
    return(hi.bound)
  }
  
  
  mean.x <- apply(x,1,mean)
  low.x <- apply(x,1,lower.bound)
  hi.x <- apply(x,1,upper.bound)
  
  sd.x <- apply(x,1,sd)
  qnorm.lo <- mean.x - qnorm(1-alpha/2) * sd.x / sqrt(nsimu)
  qnorm.hi <- mean.x + qnorm(1-alpha/2) * sd.x / sqrt(nsimu)
  
  out.summary <- data.frame(cbind(mean.x,low.x,hi.x,sd.x,qnorm.lo,qnorm.hi))
  colnames(out.summary) <- c("mean","lo_CI","hi_CI","sd","qnorm_lo_CI","qnorm_hi_CI")
  rownames(out.summary) <- rownames(x)	
  
  return(out.summary)
  
}


# function to get mean, sd, and 95% CI of estimated pi0
org.estimate.pi0 <- function(x,a=0.05){
	table <- matrix(0,nrow=1,ncol=4)
	colnames(table) <- c("mean","sd","CI lo","CI hi")
	table[,"mean"] <- mean(x)
	table[,"sd"]  <- sd(x)
	table[,c("CI lo", "CI hi")] <- mean(x) + c(-1,1) * qnorm(1-a/2) * sqrt(var(x)/length(x))
       	return(table)
}





# function to analyze correlation matrix of p-values
cormat.pvalues <- function(out.pvalues){
	#cor.mat <- cor(t(out.pvalues$pvalues.mat))
	cor.mat <- cor(t(out.pvalues))
	cor.out <- matrix(0,nrow=nrow(cor.mat),ncol=2)
	for(i in 1:nrow(cor.out)){
		cor.out[i,1] <- apply(matrix(abs(cor.mat[i,-i]),nrow=length(cor.mat[i,-i])),2,max)
		cor.out[i,2] <- which(abs(cor.mat[i,])==cor.out[i,1])
	}
	return(cor.out)
}



# function to organize data into grouped averages

org.simu <- function(m,out.simu,nsimu,forpaper=TRUE,x.star.correlated=FALSE,coef){
  if(x.star.correlated==TRUE){
    num.row  <- 7
  } else {
    num.row <- 6 
  }
  out <- matrix(0,nrow = num.row, ncol=ncol(out.simu))
  out <- as.data.frame(out)
  colnames(out) <- colnames(out.simu)


  
  if(x.star.correlated==TRUE){
    rownames(out) <- c("Diet","Group 1","Group 2","Group 3","Group 4","Group 5","FDR")
  } else {
    rownames(out) <- c("Diet","Group 1","Group 2","Group 3","Group 4","FDR")
  }

  ## out.zeros: calculates how many zeros there are
  out.zeros <- out
  out.nonzeros <- out

  out.simu.zeros <- nsimu-out.simu
  spec.num <- 0
  sens.num <- 0
  spec.den <- 0
  sens.den <- 0
  

  if(coef[3]==0){
    out["Diet",] <- out.simu[1,]
    out["Group 1",] <- apply(out.simu[c(2,4),],2,mean)
    out["Group 2",] <- apply(out.simu[c(3,5:(m/4*3+1)),],2,mean)
    out["Group 3",] <- apply(out.simu[(m/4*3+2):m,],2,mean)
    out["Group 4",] <- apply(out.simu[m+1,],2,mean)

    out.zeros["Diet",] <- out.simu.zeros[1,]
    out.zeros["Group 1",] <- apply(out.simu.zeros[c(2,4),],2,mean)
    out.zeros["Group 2",] <- apply(out.simu.zeros[c(3,5:(m/4*3+1)),],2,mean)
    out.zeros["Group 3",] <- apply(out.simu.zeros[(m/4*3+2):m,],2,mean)
    out.zeros["Group 4",] <- apply(out.simu.zeros[m+1,],2,mean)

    
    if(x.star.correlated==TRUE){
      out["Group 5",] <- apply(out.simu[m+2,],2,mean)		# for X_1.star
      out.zeros["Group 5",] <- apply(out.simu.zeros[m+2,],2,mean)		# for X_1.star
    }
    
    out <- out * 100/nsimu
    
    R <- #1 * out["Diet",] + 
      2 * out["Group 1",] + (1+(m/4*3+1)-5+1) * out["Group 2",] + ( m - (m/4*3+2)+1 ) * out["Group 3",] + 1 * out["Group 4",] 
    
    
    F <- (1+(m/4*3+1)-5+1) * out["Group 2",] + ( m - (m/4*3+2)+1 ) * out["Group 3",] 

    
  } else {
    out["Diet",] <- out.simu[1,]
    out["Group 1",] <- apply(out.simu[c(2,3,4),],2,mean)
    out["Group 2",] <- apply(out.simu[5:(m/4*3+1),],2,mean)
    out["Group 3",] <- apply(out.simu[(m/4*3+2):m,],2,mean)
    out["Group 4",] <- apply(out.simu[m+1,],2,mean)

    out.zeros["Diet",] <- out.simu.zeros[1,]
    out.zeros["Group 1",] <- apply(out.simu.zeros[c(2,3,4),],2,mean)
    out.zeros["Group 2",] <- apply(out.simu.zeros[5:(m/4*3+1),],2,mean)
    out.zeros["Group 3",] <- apply(out.simu.zeros[(m/4*3+2):m,],2,mean)
    out.zeros["Group 4",] <- apply(out.simu.zeros[m+1,],2,mean)
    
    if(x.star.correlated==TRUE){
      out["Group 5",] <- apply(out.simu[m+2,],2,mean)		# for X_1.star
      out.zeros["Group 5",] <- apply(out.simu.zeros[m+2,],2,mean)		# for X_1.star
    }
    
    out <- out * 100/nsimu
    
    R <- #1 * out["Diet",] + 
      3 * out["Group 1",] + ((m/4*3+1)-5+1) * out["Group 2",] + ( m - (m/4*3+2)+1 ) * out["Group 3",] + 1 * out["Group 4",] 
    
    
    F <- ((m/4*3+1)-5+1) * out["Group 2",] + ( m - (m/4*3+2)+1 ) * out["Group 3",] 
    
    
  }
    
    
  if(x.star.correlated==TRUE){
    R <- R + 1 * out["Group 5",]
    F <- F + 1 * out["Group 5",]

  }

  
  
  out["FDR",] <- F/R

  
  if(forpaper==TRUE){
    out <- out[,c(1:10,16:ncol(out))]
    ##out <- out[,c(1:8,13:16,20:ncol(out))]
  } 
  FDR <- out["FDR",]
  
  list(out=out,FDR=FDR)
  
}

