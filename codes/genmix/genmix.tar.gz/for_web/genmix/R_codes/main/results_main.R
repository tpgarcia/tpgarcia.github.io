#############
## Library ##
#############

##library("hydroGOF") ## compute mse
library("survival") ## for KM estimator

#############################
## Function to adjust Fest ##
#############################

getF <- function(Ft,num.est.all,p){
  n <- dim(Ft)[1]
  F <- Ft
  for(j in 1:num.est.all){
    for(i in 1:p){
      tmp <- min(F[2:n,i,j]-F[1:(n-1),i,j])
      k <- match(tmp,F[2:n,i,j]-F[1:(n-1),i,j])
      while(tmp<0){
        F[k,i,j]=(F[k+1,i,j]+F[k,i,j])/2
        F[k+1,i,j]=F[k,i,j]	 
        tmp <- min(F[2:n,i,j]-F[1:(n-1),i,j])
        k <- match(tmp,(F[2:n,i,j]-F[1:(n-1),i,j]))
      }
    }
  }
  return(F)
}



##################################################################
## Compute area under the curve and bias, and mean square error ##
##################################################################


typeIerror.results <- function(pvalues,alpha.values=c(0.01,0.05,0.1,0.2)){
  num.est <- ncol(pvalues)

  results <- array(0,dim=c(num.est,length(alpha.values)),
                   dimnames=list(estimator.names[1:num.est],paste("alpha_",alpha.values,sep="")))

  for(a in 1:length(alpha.values)){
    for (j in 1:num.est){
      results[j,a] <- mean(pvalues[,j] <=alpha.values[a])
    }
  }

  list(results=results)
}

## summarize results
summary.results.restrict <- function(statistic,data.type,timeval){
  eps <- 0.00001
  if(data.type=="cox"){
    lim1.lo <- 1
    lim2.lo <- 1
    
    lim1 <- which(timeval<= 10.0 + eps & timeval >=10.0 -eps)
    lim2 <- which(timeval<= 5.0 + eps & timeval >=5.0 -eps)
  } else if(data.type=="newcox"){
    lim1.lo <- 1
    lim2.lo <- 1
    
    lim1 <- which(timeval<= 4.0 + eps & timeval >=4.0 -eps)
    lim2 <- which(timeval<= 9.0 + eps & timeval >=9.0 -eps)
  }else {
    lim1.lo <- which(timeval<= 48.0 + eps & timeval >=48.0 -eps)
    lim2.lo <- lim1.lo
    
    lim1 <- length(timeval)
    lim2 <- length(timeval)
  }

  stat1 <- t(apply(statistic[lim1.lo:lim1,,],c(2,3),mean,na.rm=TRUE))
  stat2 <- t(apply(statistic[lim2.lo:lim2,,],c(2,3),mean,na.rm=TRUE))
  stat <- cbind(stat1[,1], stat2[,2])

  return(stat)
}

summary.results <- function(statistic,data.type,timeval){
  eps <- 0.00001
  if(data.type=="cox"){
    lim1.lo <- 1
    lim2.lo <- 1
    
    lim1 <- which(timeval<= 10.0 + eps & timeval >=10.0 -eps)
    lim2 <- which(timeval<= 5.0 + eps & timeval >=5.0 -eps)
  } else if(data.type=="newcox"){
    lim1.lo <- 1
    lim2.lo <- 1
    
    lim1 <- length(timeval)
    lim2 <- length(timeval)
  }else {
    lim1.lo <- 1
    lim2.lo <- 1
    
    lim1 <- length(timeval)
    lim2 <- length(timeval)
  }
  stat1 <- t(apply(statistic,c(2,3),mean,na.rm=TRUE))
  stat2 <- t(apply(statistic,c(2,3),mean,na.rm=TRUE))
  stat <- cbind(stat1[,1], stat2[,2])

  return(stat)
}


## summary function when hyptest==FALSE and power.compute ==FALSE

bias.curve <- function(data.all,p,num.est.all,estimator.names,
                       data.type,filename="cox_",H0,realdata=FALSE){
  ## Timeval points
  timeval <- unique(data.all[,1,1])
  print(timeval)
  
  ## Array to store biases
  Ft <- array(0,dim=c(length(timeval),p,num.est.all),
              dimnames=list(paste("t",timeval,sep=""),
                paste("p",1:p,sep=""),
                estimator.names))
  
  ## Array to store estimated variances
  var.est <- Ft

  ## Var.est quantiles
  Ft.hi <- Ft
  Ft.lo <- Ft
  
  ## Mean squared error
  mse.out <- Ft

  ## coverage probabilities
  cov.prob <- Ft
  
  for(j in 1:num.est.all){
    data <- data.all[,,j]
    if(realdata==TRUE){
      Ft[,,j] <- data[,c(2,1+p)]
      ##var.est[,,j] <- data[,c(p+2,p+5)]

      ##Ft.hi[,,j] <- Ft[,,j] + qnorm(0.975) * sqrt(var.est[,,j])
      ##Ft.lo[,,j] <- Ft[,,j] + qnorm(0.025) * sqrt(var.est[,,j])
      Ft.lo[,,j] <- data[,c(p+2,p+3)]
      Ft.hi[,,j] <- data[,c(p+4,p+5)]
      
    } else{
      
      for(i in 1:length(timeval)){
        ind.tmp <- which(data[,1]==timeval[i])
        mat.tmp <- as.data.frame(data[ind.tmp,])
        Ft[i,,j]<- apply(mat.tmp,2,mean,na.rm=TRUE)[2:(1+p)]
        var.est[i,,j] <- apply(mat.tmp,2,var,na.rm=TRUE)[2:(1+p)]
        Ft.hi[i,,j] <- apply(mat.tmp,2,myquantiles.hi)[2:(1+p)]
        Ft.lo[i,,j] <- apply(mat.tmp,2,myquantiles.lo)[2:(1+p)]
        
        myvar.mat <- matrix(rep(var.est[i,,j],nrow(mat.tmp)),nrow=nrow(mat.tmp),byrow=TRUE)
        mycov.tmp <- t(apply(abs(mat.tmp[,2:(1+p)]-data.all[ind.tmp,2:(1+p),13])/sqrt(myvar.mat),1,pnorm) < 0.975)
        ##mycov.tmp <- pnorm(abs(mat.tmp[,2:(1+p)]-data.all[ind.tmp,2:(1+p),13])/sqrt(myvar.mat))<0.975
        cov.prob[i,,j] <- apply(mycov.tmp,2,sum)/nrow(mat.tmp)
        
       ## mse.out[i,,j] <- mse(sim=mat.tmp,obs=data.all[ind.tmp,,13])[2:(1+p)]
        
      }
    }
  }
  
  ## Adjusted F-values for all except GENMIX and TRUTH estimator
  F <- Ft
  index.genmix.truth <- c(which(estimator.names=="GENMIX"),which(estimator.names=="TRUTH"))
  F.out <- F[,,-index.genmix.truth]
  F[,,-index.genmix.truth] <- getF(F.out,dim(F.out)[3],p)

  if(realdata==TRUE){
    for(j in 1:num.est.all){
      data <- data.all[,,j]
      ##var.est[,,j] <- data[,c(p+2,p+5)]
      ##Ft.hi[,,j] <- F[,,j] + 1.96 * sqrt(var.est[,,j])
      ##Ft.lo[,,j] <- F[,,j] -1.96 * sqrt(var.est[,,j])      
      Ft.lo[,,j] <- data[,c(p+2,p+3)]
      Ft.hi[,,j] <- data[,c(p+4,p+5)]
    }
  }
  
  
  ## Delta values
  timeval2 <- c(0,timeval[1:(length(timeval)-1)])
  Delta <- timeval-timeval2
  
  ## Mean pointwise bias
  bias.ptwise <- array(0,dim=c(length(timeval),p,num.est.all),
                       dimnames=list(paste("t",timeval,sep=""),
                         paste("p",1:p,sep=""),
                         estimator.names))

  if(realdata==FALSE){
    for (i in 1:p){
      bias.ptwise[,i,] <- F[,i,]-true.values.range(timeval,data.type,H0=H0)[,i]	
    }		
    
    
    
############################
    ## Average 95\% coverages ##
############################
    avg.coverage <- summary.results.restrict(cov.prob,data.type,timeval)
    
######################
    ## Average variance ##
######################
    avg.var <- summary.results(var.est,data.type,timeval)
    
    
#####################################
    ## Average absolute pointwise bias ##
#####################################
    avg.abs.ptwise.bias <- summary.results(bias.ptwise,data.type,timeval)
    
    
########################
    ## Mean Squared Error ##
########################
    mse.mine <- var.est + bias.ptwise^2
    mse.avg <- summary.results(mse.mine,data.type,timeval)
    
    
################################
    ## Area under the curve (auc) ##
################################
    
    auc <- matrix(0,nrow=num.est.all,ncol=p)
    rownames(auc) <- estimator.names
    
####################################
    ## integrated absolute bias (iab) ##
####################################
    
    iab <- matrix(0,nrow=num.est.all,ncol=p)
    rownames(iab) <- estimator.names
    
    eps <- 0.00001
    
    for(j in 1:num.est.all){
      for(i in 1:p){
        if(data.type=="cox"){
          if(i==1){
            lim <- which(timeval<= 10.0 + eps & timeval >=10.0 -eps)
          } else {
            lim <- which(timeval<= 5.0 + eps & timeval >=5.0 -eps)
          }
        } else {
          lim <- length(timeval)
        }
        
        auc[j,i] <- sum(Delta[1:lim] * F[1:lim,i,j])
        iab[j,i] <- sum(Delta[1:lim] * abs(bias.ptwise[1:lim,i,j]))
        ##/ lim
      }
    }
    
    ## bias of Area under curve (AUC) and true integrated value
    bias <- auc - matrix(rep(true.values(data.type,H0=H0),num.est.all),nrow=num.est.all,ncol=p,byrow=TRUE)
    
    
    ## absolute bias of Area under curve (AUC) and true integrated value
    ## We remove plotting
    
    ##  for(j in 1:num.est.all){
    ##	postscript(paste(filename,j,".eps",sep="")) 
    ##	par(mfrow=c(2,1))
    ##	if(realdata){
    ##		plot(timeval,bias.ptwise[,1,j],type="l",ylab="Bias",xlab="t",main="F1(t)")
    ##		plot(timeval,bias.ptwise[,2,j],type="l",ylab="Bias",xlab="t",main="F2(t)")
    ##
    ##	} else {
    ##		plot(timeval,bias.ptwise[1:100,1,j],type="l",ylab="Bias",xlab="t",main="F1(t)")
    ##		plot(timeval[1:50],bias.ptwise[1:50,2,j],type="l",ylab="Bias",xlab="t",main="F2(t)")
    ##	dev.off()
    ##	} 
    ##}
  } else {
    auc <- NULL
    bias <- NULL
    iab <- NULL
    mse <- NULL
    mse.mine <- NULL
    mse.avg <- NULL
    avg.var <- NULL
    avg.abs.ptwise.bias <- NULL
    avg.coverage <- NULL
  }
  
  list(timeval=timeval,F=F,var.est=var.est,Ft.hi=Ft.hi,Ft.lo=Ft.lo,
       auc=auc,bias=bias,iab=iab,mse=mse.mine,mse.avg=mse.avg,
       avg.var=avg.var,avg.abs.ptwise.bias=avg.abs.ptwise.bias,avg.coverage=avg.coverage)
}




############################
## Functions for plotting ##
############################
##  for paper, cex.main=1.75,lwd=1.75,cex.lab=1.75,cex.axis=1.75,cex.legend=1.75
##   ylab="Probability"
## for presentation, cex.main=2.8,lwd=3.5,cex.lab=2.8,cex.axis=2.8, cex.legend=2.8
##    except for real data hetboth, (which has 2.2) ylab=""
myplot <- function(data.type,F,var.est,Ft.lo,Ft.hi,
                   timeval,est.name="EFFAIPW",censorrate=0,plot.ci=TRUE,plot.cdf=TRUE,
                   ylab="",xlab="Time",cex.main=1.75,lwd=1.75,cex.lab=1.75, cex.legend=1.75,
                   cex.axis=1.75,realdata=FALSE,NameF=NULL,
                   NameG=NULL,time.restrict=NULL,other.data=NULL,
                   col1="red",col2="blue",hetcar=TRUE,hetboth=FALSE,NameA=NULL){

  main.title=est.name
  ## if(data.type=="realcarrier" | data.type=="realdeletion" | data.type=="realAB" | data.type=="misscarrier"){
  ##   main.title=est.name
  ## } else {
  ##   main.title=paste(est.name,", censor rate = ",censorrate,"%",sep="")
  ## }
  
  if(!is.null(other.data)){
    KM <- survfit(Surv(other.data[,"x"],other.data[,"delta"])~1,type="kaplan-meier")
  }
  
  if(is.null(time.restrict)){
    times <- 1:length(timeval)
  } else {
    times.tmp <- match(time.restrict,timeval)
    times <- times.tmp[1]:times.tmp[2]
  }
  
  if(plot.cdf==TRUE){
    ## we plot CDF
    F.plot <- F
    ci.lo <- Ft.lo
    ci.hi <- Ft.hi
    
    if(data.type=="cox"| data.type=="newcox"){
      legend.position <- "bottomright"
    } else {
      legend.position <- "topleft"
    }
  } else {
    ## we plot survival curve
    F.plot <- 1-F
    ci.lo <- 1-Ft.hi
    ci.hi <- 1-Ft.lo
    if(data.type=="cox"| data.type=="newcox"){
      legend.position <- "topright"
    } else {
      legend.position <- "bottomleft"
    }
  }
  
  
  
  ## we plot F_true and F_est
  if(realdata==FALSE){
    par(mar=c(4, 4, 4, 2))
    plot(timeval, F.plot[,1,"TRUTH"],
         type="l",col="black",
         main=main.title,
         ylim=c(-0.2,1.2),yaxt="n",ylab=ylab,xlab=xlab,cex.main=cex.main,lwd=lwd,cex.lab=cex.lab,cex.axis=cex.axis,
         xlim=c(min(timeval),max(timeval)))
    
    lines(timeval,F.plot[,2,"TRUTH"],lty=1,col="black",lwd=lwd)
  } else {
    if(plot.cdf==TRUE){
      if(is.null(other.data)){
        ylim  <- c(-0.2,0.7)
      } else {
        ylim <- c(-0.2,1.2)
      }
    } else {
      if(is.null(other.data)){
        ylim <- c(0.5,1.2)
      } else {
        ylim <- c(-0.2,1.2)
      }
    }
    if(is.null(other.data)){
      par(mar=c(4, 4, 4, 2))
      plot(1,type="n",main=main.title,
           ylim=ylim,yaxt="n",ylab=ylab,xlab=xlab,cex.main=cex.main,lwd=lwd,cex.lab=cex.lab,cex.axis=cex.axis,
           ##xlim=c(min(timeval),max(timeval)))
           xlim=time.restrict)
    } else {
      ## we plot Kaplan-Meier estimator
      if(hetboth==TRUE){
        colkm="black"
      } else {
        colkm=col1
      }
      
      if(plot.cdf==TRUE){
        par(mar=c(4, 4, 4, 2))
        plot(KM,col=colkm,fun="event",lty=c(1,3,4),conf.int=plot.ci,
             main=main.title,
             ylim=ylim,yaxt="n",ylab=ylab,xlab=xlab,cex.main=cex.main,lwd=lwd,cex.lab=cex.lab,cex.axis=cex.axis,
             xlim=time.restrict)             
      } else {
        par(mar=c(4, 4, 4, 2))
        plot(KM,col=colkm,conf.int=plot.ci,lty=c(1,3,4),conf.int=plot.ci,
             main=main.title,
             ylim=ylim,yaxt="n",ylab=ylab,xlab=xlab,cex.main=cex.main,lwd=lwd,cex.lab=cex.lab,cex.axis=cex.axis,
             xlim=time.restrict)             
      }
    }
  }
  axis(2,at=seq(-0.2,1.2,by=0.2),las=1,labels=seq(-0.2,1.2,by=0.2),cex.axis=cex.axis)

  if(is.null(other.data)){
    for(i in 1:p){
      if(i==1){
        lines(timeval[times],F.plot[times,i,est.name],lty=2,col=col1,lwd=lwd)
        if(plot.ci==TRUE){
          lines(timeval[times],ci.lo[times,i,est.name],lty=4,col=col1,lwd=lwd)
          lines(timeval[times],ci.hi[times,i,est.name],lty=3,col=col1,lwd=lwd)
        }
      } else {
        lines(timeval[times],F.plot[times,i,est.name],lty=5,col=col2,lwd=lwd)
        if(plot.ci==TRUE){
          ## for lo, lty=4
          lines(timeval[times],ci.lo[times,i,est.name],lty=4,col=col2,lwd=lwd)
          lines(timeval[times],ci.hi[times,i,est.name],lty=3,col=col2,lwd=lwd)
        }
      }
    }
  } else {
    if(hetcar==TRUE){
      i<-1
    } else {
      i <- 2
    }
    lines(timeval[times],F.plot[times,i,est.name],lty=5,col=col2,lwd=lwd)
    if(plot.ci==TRUE){
      ## for lo, lty=4
      lines(timeval[times],ci.lo[times,i,est.name],lty=4,col=col2,lwd=lwd)
      lines(timeval[times],ci.hi[times,i,est.name],lty=3,col=col2,lwd=lwd)
    }
    
    if(hetboth==TRUE){
      for(i in 1:p){
        if(i==1){
          lines(timeval[times],F.plot[times,i,est.name],lty=2,col=col1,lwd=lwd)
          if(plot.ci==TRUE){
            lines(timeval[times],ci.lo[times,i,est.name],lty=4,col=col1,lwd=lwd)
            lines(timeval[times],ci.hi[times,i,est.name],lty=3,col=col1,lwd=lwd)
          }
        } else {
          lines(timeval[times],F.plot[times,i,est.name],lty=5,col=col2,lwd=lwd)
          if(plot.ci==TRUE){
            ## for lo, lty=4
            lines(timeval[times],ci.lo[times,i,est.name],lty=4,col=col2,lwd=lwd)
            lines(timeval[times],ci.hi[times,i,est.name],lty=3,col=col2,lwd=lwd)
          }
        }
      } 
    }
  }
  if(plot.ci==TRUE){
    ##legend("bottomright",c("Truth",expression(paste(F[1])),expression(paste(F[2])),"95% CI (upper)", "95% CI (lower)"),
    ##       col=c("black",col1,col2,"black","black"),
    ##       lty=c(1,2,5,3,4),lwd=rep(lwd,5),bty="n",cex=cex.main)
    
    if(realdata==FALSE){
      legend(legend.position,c("Truth",expression(paste(F[1])),expression(paste(F[2])),"95% CI (upper)", "95% CI (lower)"),
             col=c("black",col1,col2,"black", "black"),
             lty=c(1,2,5,3,4),lwd=rep(lwd,5),bty="n",cex=cex.legend)
    } else {
      if(hetboth==FALSE){
        legend(legend.position,c(NameF,NameG,"95% CI (upper)",
                                 "95% CI (lower)"),
               col=c(col1,col2,"black","black"),
               lty=c(1,5,3,4),
               lwd=rep(lwd,4),bty="n",cex=cex.legend)
      } else {
        legend(legend.position,c(NameA,NameF,NameG,"95% CI (upper)",
                                 "95% CI (lower)"),
               col=c("black",col1,col2,"black","black"),
               lty=c(1,2,5,3,4),
               lwd=rep(lwd,5),bty="n",cex=cex.legend)
               
        
      }
    }
  } else {
    if(realdata==FALSE){
      legend(legend.position,c("Truth",expression(paste(F[1])),expression(paste(F[2]))),
             col=c("black",col1,col2),
             lty=c(1,2,5),lwd=rep(lwd,3),bty="n",cex=cex.legend)

    } else {
      if(hetboth==FALSE){
        legend(legend.position,c(NameF,NameG),
               col=c(col1,col2),
               lty=c(2,5),lwd=rep(lwd,2),bty="n",cex=cex.legend)
               
      } else {
        legend(legend.position,c(NameA,NameF,NameG),
               col=c("black",col1,col2),
               lty=c(1,2,5),lwd=rep(lwd,3),bty="n",cex=cex.legend)
        
      }
    }
  }
}


myplot2 <- function(data.type,F,var.est,Ft.lo,Ft.hi,
                    F2,var.est2,Ft.lo2,Ft.hi2,
                    timeval,est.name="EFFAIPW",censorrate=0,plot.ci=TRUE,
                    plot.cdf=TRUE,
                    ylab="",xlab="Time", cex.legend=1.75,cex.main=1.75,lwd=1.75,
                    cex.lab=1.75,cex.axis=1.75,realdata=FALSE,NameF=NULL,
                    NameG=NULL,NameF2=NULL, NameG2=NULL,time.restrict=NULL,
                    col1="red",col2="blue",col3="green",col4="black",
                    other.data=NULL){

  main.title=est.name
  ##  if(data.type=="realcarrier" | data.type=="realdeletion" | data.type=="realAB" | data.type=="misscarrier"){
  ##    main.title=est.name
  ##  } else {
  ##    main.title=paste(est.name,", censor rate = ",censorrate,"%",sep="")
  ##  }

  
  if(is.null(time.restrict)){
    times <- 1:length(timeval)
  } else {
    times.tmp <- match(time.restrict,timeval)
    times <- times.tmp[1]:times.tmp[2]
  }
  
  if(plot.cdf==TRUE){
    ## we plot CDF
    F.plot <- F
    ci.lo <- Ft.lo
    ci.hi <- Ft.hi

    F.plot2 <- F2
    ci.lo2 <- Ft.lo2
    ci.hi2 <- Ft.hi2
    
    if(data.type=="cox"| data.type=="newcox"){
      legend.position <- "bottomright"
    } else {
      legend.position <- "topleft"
    }
  } else {
    ## we plot survival curve
    F.plot <- 1-F
    ci.lo <- 1-Ft.hi
    ci.hi <- 1-Ft.lo

    F.plot2 <- 1-F2
    ci.lo2 <- 1-Ft.hi2
    ci.hi2 <- 1-Ft.lo2

    
    if(data.type=="cox"| data.type=="newcox"){
      legend.position <- "topright"
    } else {
      legend.position <- "bottomleft"
    }
  }
  
  
  ## ci.lo <- F.plot + qnorm(0.025)*sqrt(var.est)
  ## ci.hi <- F.plot + qnorm(0.975)*sqrt(var.est)
  
  
  ## we plot F_true and F_est
  if(plot.cdf==TRUE){
    if(is.null(other.data)){
      ylim  <- c(-0.2,0.7)
    } else {
      ylim <- c(-0.2,1.2)
    }
  } else {
    if(is.null(other.data)){
        ylim <- c(0.5,1.2)
      } else {
        ylim <- c(-0.2,1.2)
      }
  }

  par(mar=c(4, 4, 4, 2))
  plot(1,type="n",main=main.title,
           ylim=ylim,yaxt="n",ylab=ylab,xlab=xlab,cex.main=cex.main,lwd=lwd,cex.lab=cex.lab,cex.axis=cex.axis,
           ##xlim=c(min(timeval),max(timeval)))
           xlim=time.restrict)
  
  axis(2,at=seq(-0.2,1.2,by=0.2),las=1,labels=seq(-0.2,1.2,by=0.2),cex.axis=cex.axis)

  for(i in 1:p){
    if(i==1){
      lines(timeval[times],F.plot[times,i,est.name],lty=2,col=col1,lwd=lwd)

      lines(timeval[times],F.plot2[times,i,est.name],lty=1,col=col3,lwd=lwd)

      if(plot.ci==TRUE){
        lines(timeval[times],ci.lo[times,i,est.name],lty=4,col=col1,lwd=lwd)
        lines(timeval[times],ci.hi[times,i,est.name],lty=3,col=col1,lwd=lwd)
        
        lines(timeval[times],ci.lo2[times,i,est.name],lty=4,col=col3,lwd=lwd)
        lines(timeval[times],ci.hi2[times,i,est.name],lty=3,col=col3,lwd=lwd)
      }
      
    } else {
      lines(timeval[times],F.plot[times,i,est.name],lty=5,col=col2,lwd=lwd)
      lines(timeval[times],F.plot2[times,i,est.name],lty=6,col=col4,lwd=lwd)
      if(plot.ci==TRUE){
        ## for lo, lty=4
        lines(timeval[times],ci.lo[times,i,est.name],lty=4,col=col2,lwd=lwd)
        lines(timeval[times],ci.hi[times,i,est.name],lty=3,col=col2,lwd=lwd)

        lines(timeval[times],ci.lo2[times,i,est.name],lty=4,col=col4,lwd=lwd)
        lines(timeval[times],ci.hi2[times,i,est.name],lty=3,col=col4,lwd=lwd)
      }
    }
  }

  if(plot.ci==TRUE){
    ##legend("bottomright",c("Truth",expression(paste(F[1])),expression(paste(F[2])),"95% CI (upper)", "95% CI (lower)"),
    ##       col=c("black",col1,col2,"black","black"),
    ##       lty=c(1,2,5,3,4),lwd=rep(lwd,5),bty="n",cex.main=cex.main)

    legend(legend.position,c(NameF,NameG,NameF2,NameG2,"95% CI (upper)",
                             "95% CI (lower)"),
           col=c(col1,col2,col3,col4,"black","black"),
           lty=c(2,5,1,6,3,4),
           lwd=rep(lwd,6),bty="n",cex=cex.legend)
           
  } else {
    legend(legend.position,c(NameF,NameG,NameF2,NameG2),
           col=c(col1,col2,col3,col4),
           lty=c(2,5,1,6),
           lwd=rep(lwd,4),bty="n",cex=cex.legend)
        
  }
}



point.estimates <- function(F,var.est,Ft.lo,Ft.hi,timeval,est.interest="EFFAIPW",ages.interest,cdf=TRUE,
                            other.data=NULL,hetcar=TRUE){
  times <- match(ages.interest,timeval)
  F1.summary <- NULL
  F2.summary <- NULL

  if(cdf==FALSE){
    F.plot <- 1-F
    ci.lo <- 1-Ft.hi
    ci.hi <- 1-Ft.lo
  } else {
    F.plot <- F
    ci.lo <- Ft.lo
    ci.hi <- Ft.hi
  }

  if(!is.null(other.data)){
    if(hetcar==TRUE){
      k <-1
    } else {
      k<-2 
    }
    
    F.plot.new <- F.plot
    ci.lo.new <- ci.lo
    ci.hi.new <- ci.hi
    
    KM <- survfit(Surv(other.data[,"x"],other.data[,"delta"])~1,type="kaplan-meier")
    tmp.rep <- diff(c(1,KM$time,max(timeval)+1))
    KM.estimator <- rep(c(1,KM$surv),times=tmp.rep)
    KM.estimator <- KM.estimator[timeval]

    KM.hi <- rep(c(1,KM$upper),times=tmp.rep)
    KM.hi <- KM.hi[timeval]
    
    KM.lo <- rep(c(1,KM$lower),times=tmp.rep)
    KM.lo <- KM.lo[timeval]

    if(cdf==FALSE){
      F.plot.new[,1,] <- KM.estimator
      F.plot.new[,2,] <- 1-F[,k,]

      ci.lo.new[,1,] <- KM.lo
      ci.lo.new[,2,] <- 1-Ft.hi[,k,]

      ci.hi.new[,1,] <- KM.hi
      ci.hi.new[,2,] <- 1-Ft.lo[,k,]
    } else {
      F.plot.new[,1,] <- 1-KM.estimator
      F.plot.new[,2,] <- F[,k,]

      ci.lo.new[,1,] <- 1-KM.hi
      ci.lo.new[,2,] <- Ft.lo[,k,]

      ci.hi.new[,1,] <- 1-KM.lo
      ci.hi.new[,2,] <- Ft.hi[,k,]      
    }

    F.plot <- F.plot.new
    ci.lo <- ci.lo.new
    ci.hi <- ci.hi.new
  }
  
  
  for(i in 1:length(est.interest)){
    F1.summary <- cbind(F1.summary,
                        F.plot[times,1,est.interest[i]],ci.lo[times,1,est.interest[i]],
                        ci.hi[times,1,est.interest[i]])
    F2.summary <- cbind(F2.summary,
                        F.plot[times,2,est.interest[i]],ci.lo[times,2,est.interest[i]],
                        ci.hi[times,2,est.interest[i]])
  } 

  colnames(F1.summary) <- rep(est.interest,each=3)
  colnames(F2.summary) <- rep(est.interest,each=3)


  
  list(F1.summary=F1.summary,F2.summary=F2.summary)
}

##################################
## Residual Life estimates table #
##################################

residual.life.est <- function(ages=seq(30,60,by=5),interest=seq(5,20,by=5),
                              p,num.est.all,timeval,F,estimator.names,
                              survival=FALSE,other.data=NULL){


  
  if(!is.null(other.data)){
    estimator.names[length(estimator.names)] <- "KM"

    
    KM <- survfit(Surv(other.data[,"x"],other.data[,"delta"])~1,type="kaplan-meier")
    tmp.rep <- diff(c(1,KM$time,max(timeval)+1))
    KM.estimator <- rep(c(1,KM$surv),times=tmp.rep)
    KM.estimator <- KM.estimator[timeval]

    KM.hi <- rep(c(1,KM$upper),times=tmp.rep)
    KM.hi <- KM.hi[timeval]
    
    KM.lo <- rep(c(1,KM$lower),times=tmp.rep)
    KM.lo <- KM.lo[timeval]

    F[,,length(estimator.names)] <- 1-KM.estimator
  }

  out <- array(0,dim=c(length(ages),length(interest),p,num.est.all),
               dimnames=list(paste("age",ages,sep=""),
                 paste("int",interest,sep=""),
                 paste("p",1:p,sep=""),
                 estimator.names))
  
  
  for(i in 1:num.est.all){
    for(j in 1:length(ages)){
      age.ind <- which(timeval==ages[j])
      for(k in 1:length(interest)){
        interest.ind <- which(timeval==(ages[j]+interest[k]))
        out[j,k,,i] <- ( F[interest.ind,,i]- F[age.ind,,i] ) / ( 1- F[age.ind,,i])
        if(survival==TRUE){
          out[j,k,,i] <- 1-out[j,k,,i]
        }
      }
    }
  }
  return(out)
}


residual.life.est.organize <- function(out,ages,interest,
                                       est.interest){
  ## p=1 : Carrier
  ## p=2 : Non-carrier

  table.out <- cbind(out[,,1,est.interest],out[,,2,est.interest])
  cnames <- c(paste(est.interest,"Carr",interest,sep=" "),
              paste(est.interest,"Non-Carr",interest,sep=" "))
  rnames <- ages
  colnames(table.out) <- cnames
  rownames(table.out) <- rnames
  list(table.out=table.out)
}







###################################
## Functions to compute integral ##
###################################
## for checking
##t <- seq(0,10,by=0.1)
##t2 <- seq(0,5,by=0.1)

##tval <- c(0.75,2,3)

##cox
##plot(t,cox.F1(t),ylim=c(0,1),type="l")
##lines(t2,cox.F2(t2),col=col2)
##abline(v=tval)

##cox.cure
##plot(t,cox.F1.cure(t),ylim=c(0,1),type="l")
##lines(t2,cox.F2.cure(t2),col=col2)
##abline(v=tval)



## noncox
##plot(t,noncox.F1(t),ylim=c(0,1),type="l")
##lines(t2,noncox.F2(t2),col=col2)
##abline(v=tval)

##noncox.cure
##plot(t,noncox.F1.cure(t),ylim=c(0,1),type="l")
##lines(t2,noncox.F2.cure(t2),col=col2)
##abline(v=tval)



cox.F1.cure <- function(t){
  theta <- 2
  1-exp(-theta * cox.F1(t))
}

cox.F2.cure <- function(t){
  theta <- 3
 ## 1-exp(-theta * cox.F1(t)^0.98)
  1-exp(-theta * cox.F2(t))
}


##test.cox.F1 <- function(t){
##  a <- 1.
##  b <-1
##  s <-1
##  a/(1+b*exp(-(t-3)/s))
##}


new.cox.F2 <-function(t){
  a <- 2.5
  ( 1-exp(-t/a))/(1-exp(-10/a)) 
}

new.cox.F1 <-function(t){
  ( 1-exp(-t))/(1-exp(-10)) 
}



cox.F1 <- function(t){
  (1-exp(-t/4)) /(1-exp(-2.5)) 
}

cox.F2 <- function(t){
  ##cox.F1(t)^0.98
  noncox.F2(t)
}

noncox.F1.cure <- function(t){
  theta <- 2
  1-exp(-theta * noncox.F1(t))
}

noncox.F2.cure <- function(t){
  theta <- 3
  1-exp(-theta * noncox.F2(t))
}

noncox.F1 <- function(t){
  ( ( 1-exp(-t/4)) / (1-exp(-2.5)) ) ^ 0.5
}

noncox.F2 <- function(t){
  ( 1-exp(-t/2)) / (1-exp(-2.5))
}


realdata.F1.orig <- function(t){
  a <- 0.8
  b <- 1
  mu <- 80
  s <- 5
  d <- 0

  if(t >=0 & t <=100){
    out <- a/ ( 1+ b*exp(-(t-mu)/s)) +d
  } else if (t>=100){
    gamma <-a/ ( 1+ b*exp(-(100-mu)/s)) +d
    beta <- (1-gamma)/200
    alpha <- 1-300*beta
         out <- alpha + beta *t
  }
  return(out)
}

realdata.F2.orig <- function(t){
  a <- 0.2
  b <- 1
  mu <- 80
  s <- 5
  d <- 0

  if(t >=0 & t <=100){
    out <- a/ ( 1+ b*exp(-(t-mu)/s)) +d
  } else if (t>=100){
    gamma <-a/ ( 1+ b*exp(-(100-mu)/s)) +d
    beta <- (1-gamma)/200
    alpha <- 1-300*beta
         out <- alpha + beta *t
  }
  return(out)
}



realdata.F1 <- function(t){
  if(length(t)==1){
    return(realdata.F1.orig(t))
  } else {
    return(apply(as.matrix(t),1,realdata.F1.orig))
  }
}

realdata.F2 <- function(t){
  if(length(t)==1){
    return(realdata.F2.orig(t))
  } else {
    return(apply(as.matrix(t),1,realdata.F2.orig))
  }
}


## functions for power calculations for Grant
grant.lowF.original <- function(t){
  if(t >= 0 & t <=50){
    out <-0.0004*t
  } else if( t >=50 & t <=80){
    out <- -0.38 + 0.008*t
  } else if(t >=80 & t<=300){
    out <- 1-300/220*0.74 + 0.74/220*t
  }
  return(out)
}


grant.lowF <- function(t){
  if(length(t)==1){
    return(grant.lowF.original(t))
  } else {
    return(apply(as.matrix(t),1,grant.lowF.original))
  }
}



grant.medF.original <- function(t){
  if(t >= 0 & t <=50){
    out <-0.002*t
  } else if( t >=50 & t <=60){
    out <- -0.9 + 0.02*t
  } else if(t >=60 & t <=70){
    out <- -0.18 + 0.008*t
  } else if(t >=70 & t <=80){
    out <- -0.81 + 0.017 * t
  } else if(t >=80 & t<=300){
    out <- 1-300/220*0.45 + 0.45/220*t
  }
  return(out)
}

grant.medF <- function(t){
  if(length(t)==1){
    return(grant.medF.original(t))
  } else {
    return(apply(as.matrix(t),1,grant.medF.original))
  }
}


grant.highF.original <- function(t){
  if(t >= 0 & t <=60){
    out <-0.32/60*t
  } else if( t >=60 & t <=80){
    out <- -1.72 + 0.034*t
  } else if(t >=80 & t<=300){
    out <- 1
  }
  return(out)
}

grant.highF <- function(t){
  if(length(t)==1){
    return(grant.highF.original(t))
  } else {
    return(apply(as.matrix(t),1,grant.highF.original))
  }
}


## plots
## high and low
## t <- seq(0,100,by=1)
##plot(t,grant.highF(t),ylim=c(0,1),type="l",col="black")
##lines(t,grant.lowF(t),col=col2)

## middle and low
## t <-seq(0,100,by=1)
##plot(t,grant.lowF(t),ylim=c(0,1),type="l",col=col2)
##lines(t,grant.medF(t),col=col1)





## True integrated values
true.values <- function(data.type,H0){
  if(data.type=="newcure"){
    F1.true <- integrate(realdata.F1, lower=0,upper=100,subdivisions=10000)$value
    F2.true <- integrate(realdata.F2, lower=0,upper=100,subdivisions=10000)$value
  } else if(data.type=="pene"){
    if(H0==TRUE){
      F1.true <- integrate(grant.highF, lower=0,upper=100,subdivisions=10000)$value
      F2.true <- integrate(grant.lowF, lower=0,upper=100,subdivisions=10000)$value
    } else{
      F1.true <- integrate(grant.medF, lower=0,upper=100,subdivisions=10000)$value
      F2.true <- integrate(grant.lowF, lower=0,upper=100,subdivisions=10000)$value
    }
  } else if(data.type=="newcox"){
    F1.true <- integrate(new.cox.F1, lower=0,upper=10,subdivisions=10000)$value
    F2.true <- integrate(new.cox.F2, lower=0,upper=10,subdivisions=10000)$value
  } else if(data.type=="cox"){
    F1.true <- integrate(cox.F1, lower=0,upper=10,subdivisions=10000)$value
    F2.true <- integrate(cox.F2, lower=0,upper=5,subdivisions=10000)$value
  } else if(data.type=="noncox"){
    F1.true <- integrate(noncox.F1, lower=0,upper=10,subdivisions=10000)$value
    F2.true <- integrate(noncox.F2, lower=0,upper=5,subdivisions=10000)$value
  } else if(data.type=="coxcure"){
    F1.true <- integrate(cox.F1.cure, lower=0,upper=10,subdivisions=10000)$value
    F2.true <- integrate(cox.F2.cure, lower=0,upper=5,subdivisions=10000)$value
  } else if(data.type=="noncoxcure"){
    F1.true <- integrate(noncox.F1.cure, lower=0,upper=10,subdivisions=10000)$value
    F2.true <- integrate(noncox.F2.cure, lower=0,upper=5,subdivisions=10000)$value
  }
  return(c(F1.true,F2.true))
}

## True functions evaluated at timeval points (timeval)
true.values.range <- function(timeval,data.type,H0=FALSE){
  if(data.type=="newcure"){
    F1.true <- realdata.F1(timeval)
    F2.true <- realdata.F2(timeval) 
  } else if(data.type=="newcox"){
    F1.true <- new.cox.F1(timeval)
    F2.true <- new.cox.F2(timeval) 

  } else if(data.type=="cox"){
    F1.true <- cox.F1(timeval)
    F2.true <- cox.F2(timeval)
    F2.true[timeval>=5] <- cox.F2(5)

  } else if(data.type=="noncox"){
    F1.true <- noncox.F1(timeval)
    F2.true <- noncox.F2(timeval)
    F2.true[timeval>=5] <- noncox.F2(5)

  } else if(data.type=="coxcure"){
    F1.true <- cox.F1.cure(timeval)
    F2.true <- cox.F2.cure(timeval)
    F2.true[timeval>=5] <- cox.F2.cure(5)

  } else if(data.type=="noncox"){
    F1.true <- noncox.F1.cure(timeval)
    F2.true <- noncox.F2.cure(timeval)
    F2.true[timeval>=5] <- noncox.F2.cure(5)
  } else if(data.type=="pene"){
    if(H0==TRUE){
      F1.true <- grant.highF(timeval)
      F2.true <- grant.lowF(timeval)
    } else{
      F1.true <- grant.medF(timeval)
      F2.true <- grant.lowF(timeval)
    }
  }

  
  return(cbind(F1.true,F2.true))
}





