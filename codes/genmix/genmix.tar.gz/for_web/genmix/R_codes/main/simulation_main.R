######################
## Clear out history ##
#######################
rm(list=ls(all=TRUE))


###############
## Libraries ##
###############
library(survival)

#################
## Source code ##
#################
source("../../../main/genetic-mixture.R")

if(!is.loaded("kincohort_estimators")){
    dyn.load("../../../../kincohort_simu/src/kincohortsimu.so") }



##################################################
## Set values for simulation based on data.type ##
##################################################

simu.setting <- function(iseed,n,p,m,setting,data=NULL,realdata=FALSE){

  ###############
  ## Setvalues ##
  ###############
  ## storage for Fortran
  storage.mode(setting) <- "character"
  storage.mode(p) <- "integer"
  storage.mode(m) <- "integer"
  storage.mode(n) <- "integer"
  storage.mode(iseed) <- "integer"


  
  ## output from setvalues
  qvs <- matrix(0,nrow=p,ncol=m)
  storage.mode(qvs) <- "double"
  
  lim <- as.double(0)
  rat <- as.double(0)

  if(realdata==FALSE){
    ## sets values for qvs, lim, rat, and t.pt depending on data.type
    values <- .Fortran("Rsetvalues",setting,p,m,qvs=qvs,lim=lim,rat=rat)
    
    lim <- values$lim
    rat <- values$rat
    qvs <- values$qvs
  } else {
    # real data
    lim <- 100
    rat <- 10
    qvs[1,] <- as.numeric(names(table(data[,"q0"])))
    qvs[2,] <- 1-qvs[1,]
  }
    
  ##########################
  ## Get rc and rt values ##
  ##########################

  ## output from rcrctvalues
  rt <- rep(0,m)
  storage.mode(rt) <- "integer"

  rc <- rep(0,m+1)
  storage.mode(rc) <- "integer"

  if(realdata==FALSE){
    ## get rc and rt values
    rcrt <- .Fortran("rcrtvalues",iseed,n,m,rc=rc,rt=rt)
    
    rt <- rcrt$rt
    rc <- rcrt$rc
  } else {
    rt <- as.vector(table(data[,"q0"]))
    rc <- rt
  }

  list(qvs=qvs,rt=rt,rc=rc,lim=lim,rat=rat)
}


## Function to get simulated data
simu.data <- function(n,p,m,setting,d=1,H0=FALSE,
                      censorrate,qvs,rc,rt,lim,rat){
  
#######################
  ## Generate data set ##
#######################
  ## storage for Fortran
  storage.mode(n) <- "integer"
  storage.mode(m) <- "integer"
  storage.mode(p) <- "integer"
  storage.mode(rc) <- "integer"
  storage.mode(qvs) <- "double"
  storage.mode(d) <- "double"
  storage.mode(lim) <- "double"
  storage.mode(rat) <- "double"
  storage.mode(setting) <- "character"
  storage.mode(d) <- "double"
  storage.mode(H0) <- "logical"
  storage.mode(censorrate) <- "integer"

  
  ## output from gendata
  q <- matrix(0,nrow=p,ncol=n)
  storage.mode(q) <- "double"
  
  x <- rep(0,n)
  storage.mode(x) <- "double"
  
  delta <- rep(0,n)
  storage.mode(delta) <- "double"
  
  r <- rep(0,m)
  storage.mode(r) <- "integer"

  
  good.data <- FALSE
  
  while(good.data==FALSE){
    data <- .Fortran("gendata",n,p,m,rc=rc,qvs=qvs,
                     q=q,x=x,delta=delta,
                     r=r,lim=lim,rat=rat,
                     setting,d,H0,censorrate)
    q <- data$q
    x <- data$x
    delta <- data$delta
    r <- data$r
    
    if(min(r)<1){
      ## we need to generate another data set
      good.data <- FALSE

    } else {
      good.data <- TRUE
    }
  }
  list(x=x,delta=delta,q=q,r=r)
}


## function to find upper and lower quantiles
myquantiles.lo <-function(x){
  alpha <- 0.05
  B <- length(x)
  lo <- sort(x)[B*alpha/2]
  return(lo)
}

myquantiles.hi <-function(x){
  alpha <- 0.05
  B <- length(x)
  up <- sort(x)[B*(1-alpha/2)]
  return(up)
}


## Function to get bootstrap data
get.boot.data <- function(n,p,m,q,x,delta){
  ## get bootstrap data
  storage.mode(n) <- "integer"
  storage.mode(p) <- "integer"
  storage.mode(m) <- "integer"
  
  storage.mode(q) <- "double"
  storage.mode(x) <- "double"
  storage.mode(delta) <- "double"

  ## output
  qb <- matrix(0,nrow=p,ncol=n)
  xb <- rep(0,n)
  deltab <- rep(0,n)
  r1 <- rep(0,m)
  m1 <- 0
  qvs1 <- matrix(0,nrow=p,ncol=m)

  storage.mode(qb) <- "double"
  storage.mode(xb) <- "double"
  storage.mode(deltab) <- "double"
  
  storage.mode(r1) <- "integer"
  storage.mode(m1) <- "integer"
  storage.mode(qvs1) <- "double"

  ## data is sorted in genbootdata function
  boot.data <- .Fortran("genbootdata",n,p,m,q,x,delta,
                        qb=qb,xb=xb,deltab=deltab,r1=r1,m1=m1,qvs1=qvs1)
  qb <- boot.data$qb
  xb <- boot.data$xb
  deltab <- boot.data$deltab
  rb <- boot.data$r1
  mb <- boot.data$m1
  qvsb <- boot.data$qvs1
  
  list(qb=qb,xb=xb,deltab=deltab,rb=rb,mb=mb,qvsb=qvsb)
}




## Function to call kincohort_estimators (for one time point)

kincohort.estimators <- function(n,q,x,delta,t0,qvs,p,m,r,lim,rat,setting,d=1,H0=FALSE,
                                 num.est,boot,bootvar,usetruth,useOLS,useWLS,useEFF,useNPMLEs){

  ## storage for Fortran 90
  storage.mode(n) <- "integer"
  storage.mode(q) <- "double"
  storage.mode(x) <- "double"
  storage.mode(delta) <- "double"
  storage.mode(t0) <- "double"
  storage.mode(qvs) <- "double"
  storage.mode(p) <- "integer"
  storage.mode(m) <- "integer"
  storage.mode(r) <- "integer"
  storage.mode(lim) <- "double"
  storage.mode(rat) <- "double"
  storage.mode(setting) <- "character"
  storage.mode(d) <- "double"
  storage.mode(H0) <- "logical"
  storage.mode(num.est) <- "integer"
  storage.mode(boot) <- "integer"
  storage.mode(bootvar) <- "logical"
  storage.mode(usetruth) <- "logical"
  storage.mode(useOLS) <- "logical"
  storage.mode(useWLS) <- "logical"
  storage.mode(useEFF) <- "logical"
  storage.mode(useNPMLEs) <- "logical"

  
  ## output
  Fest <- matrix(0,nrow=p,ncol=num.est)
  storage.mode(Fest) <- "double"

  var_est <- array(0,dim=c(p,p,num.est))
  storage.mode(var_est) <- "double"

  eflag <- as.integer(0)

  ## call kincohort_estimators
  kincohort.results <- .Fortran("kincohort_estimators",n,q,x,
                                delta,t0,qvs,p,m,r,lim,rat,setting,d,H0,
                                num.est,boot,bootvar,usetruth,useOLS,useWLS,useEFF,useNPMLEs,
                                Fest=Fest,
                                var_est=var_est,
                                eflag=eflag)

  Fest <- kincohort.results$Fest
  vest <- kincohort.results$var_est
  eflag <- kincohort.results$eflag

  list(Fest=Fest,vest=vest,eflag=eflag)  
}


## Function to run simulation study
simulation.study <- function(nsimu,iseed,num.est=12,n,p,m,setting,d=1,H0=FALSE,timeval,
                             censorrate,boot,bootvar,usetruth=usetruth,
                             useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                             useGENMIX=useGENMIX,
                             estimator.names=estimator.names,
                             tol.level=0.00001,count.max=100,data=NULL,realdata=FALSE,
                             other.data=NULL){

  ## storage for fortran
  storage.mode(p) <- "integer"
  storage.mode(n) <- "integer"
  storage.mode(setting) <- "character"
  storage.mode(d) <- "double"
  storage.mode(H0) <- "logical"
  
  ## Set parameter values based on data.type
  par.values <- simu.setting(iseed,n,p,m,setting,data,realdata=realdata)
  lim <- par.values$lim
  qvs <- par.values$qvs
  rt <- par.values$rt
  rc <- par.values$rc
  rat <- par.values$rat
  
  storage.mode(lim) <- "double"
  storage.mode(qvs) <- "double"
  storage.mode(rt) <- "integer"
  storage.mode(rc) <- "integer"
  storage.mode(rat) <- "double"
  storage.mode(timeval) <- "double"
  
 
  ## number of estimators
  num.est.orig <- num.est-1 ##(we had 11 original estimators)
  truth.index <- length(estimator.names)

  ## number of time points
  numt <- length(timeval)


  ## Arrays to store results, we append the truth
  Fest <- array(0,dim=c(p,numt,length(estimator.names),nsimu))
  vest <- array(0,dim=c(p,p,numt,length(estimator.names),nsimu))
  
  zeros <- rep(0,(length(estimator.names)-1)*p+(length(estimator.names)-1))

  
  for(i in 1:nsimu){
   # print(i)
    results <- kh.estimators(lim=lim,qvs=qvs,rt=rt,rc=rc,rat=rat,num.est=num.est,
                             num.est.orig=num.est.orig,
                             n,p,m,setting=setting,d=d,H0=H0,timeval,
                             censorrate,boot,bootvar,usetruth=usetruth,
                             useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                             useGENMIX=useGENMIX,
                             estimator.names=estimator.names,
                             tol.level=tol.level,count.max=count.max,
                             xb=NULL,qb=NULL,deltab=NULL,rb=NULL,permute.data=FALSE,
                             realdata=realdata,
                             data=data,other.data=other.data)
    
    Fest[,,1:(length(estimator.names)-1),i] <- results$Fest
    vest[,,,1:(length(estimator.names)-1),i] <- results$vest
  }

  if(realdata==FALSE){
    ## Storing results for truth
    for(j in 1:numt){
      Ft <- rep(0,p)
      storage.mode(Ft) <- "double"
      
      t0 <- timeval[j]
      storage.mode(t0) <- "double"
      
      Ft.true <- .Fortran("trueFt",p,t0,Ft=Ft,lim,rat,n,setting,d,H0)
      
      store.true <- c(p,nsimu,num.est,Ft.true$Ft,n,
                      zeros[1:(num.est*p+num.est-4-p)])
      
      Fest[,j,truth.index,] <- Ft.true$Ft
    }
  } else {
    ## No truth for real data
    store.true <- 1
  }

  ## testing
  ## Fest[,,13,]
  
  dimnames(Fest)<- list(paste("p.",1:p,sep=""),
                        paste("t",timeval,sep=""),
                        estimator.names,
                        paste("simu",1:nsimu,sep=""))
  dimnames(vest) <- list(paste("p.",1:p,sep=""),
                      paste("p.",1:p,sep=""),
                      paste("t",timeval,sep=""),
                      estimator.names,
                      paste("simu",1:nsimu,sep=""))

  list(Fest=Fest,vest=vest,store.true=store.true,timeval=timeval)       

}




## function to compute 95% CI based on bootstrap
boot.CI <- function(boot=100,nsimu,iseed,num.est=12,n,p,m,setting,d=1,H0=FALSE,timeval,
                    censorrate,bootvar=FALSE,usetruth=usetruth,
                    useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                    useGENMIX=useGENMIX,
                    estimator.names=estimator.names,
                    tol.level=0.00001,count.max=100,data=NULL,realdata=FALSE,
                    other.data=NULL){

  ## Set parameter values based on data.type
  par.values <- simu.setting(iseed,n,p,m,setting,data,realdata=realdata)
  lim <- par.values$lim
  qvs <- par.values$qvs
  rt <- par.values$rt
  rc <- par.values$rc
  rat <- par.values$rat
  
  storage.mode(lim) <- "double"
  storage.mode(qvs) <- "double"
  storage.mode(rt) <- "integer"
  storage.mode(rc) <- "integer"
  storage.mode(rat) <- "double"
  storage.mode(timeval) <- "double"

  ## number of time points
  numt <- length(timeval)
  
  ## number of estimators
  num.est.orig <- num.est-1 ##(we had 11 original estimators)
  truth.index <- length(estimator.names)

  ## Arrays to store results
  Fest <- array(0,dim=c(p,numt,length(estimator.names),nsimu))
  dimnames(Fest)<- list(paste("p.",1:p,sep=""),
                        paste("t",timeval,sep=""),
                        estimator.names,
                        paste("simu",1:nsimu,sep=""))
  

  ci.lo <- array(0,dim=c(p,numt,length(estimator.names),nsimu))
  dimnames(ci.lo) <- list(paste("p.",1:p,sep=""),
                          paste("t",timeval,sep=""),
                          estimator.names,
                          paste("simu",1:nsimu,sep=""))
  ci.hi <- ci.lo
  
  for(i in 1:nsimu){
    results0 <- kh.estimators(lim=lim,qvs=qvs,rt=rt,rc=rc,rat=rat,num.est=num.est,
                              num.est.orig=num.est.orig,
                              n,p,m,setting,d=d,H0=H0,timeval,
                              censorrate,boot,bootvar,usetruth=usetruth,
                              useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                              useGENMIX=useGENMIX,
                              estimator.names=estimator.names,
                              tol.level=tol.level,count.max=count.max,
                              xb=NULL,qb=NULL,deltab=NULL,rb=NULL,
                              realdata=realdata,data=data,other.data=other.data,
                              boot.data=FALSE)
    
    ## data from initial simulation
    xb <- results0$x
    qb <- results0$q
    deltab <- results0$delta
    rb <- results0$r
    
    ## results from initial simulation
    Fest[,,1:(length(estimator.names)-1),i] <- results0$Fest
    
    ## vector to store results
    Fest.boot <- array(0,dim=c(boot,p,numt,length(estimator.names)))
    dimnames(Fest.boot) <- list(paste("boot",1:boot,sep=""),
                                paste("p.",1:p,sep=""),
                                paste("t",timeval,sep=""),
                                estimator.names)
    
    for(b in 1:boot){
      print(b)
      results <- kh.estimators(lim=lim,qvs=qvs,rt=rt,rc=rc,rat=rat,num.est=num.est,
                               num.est.orig=num.est.orig,
                               n,p,m,setting,d=d,H0=H0,timeval,
                               censorrate,boot,bootvar,usetruth=usetruth,
                               useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                               useGENMIX=useGENMIX,
                               estimator.names=estimator.names,
                               tol.level=tol.level,count.max=count.max,
                               xb=xb,qb=qb,deltab=deltab,rb=rb,
                               realdata=realdata,data=data,other.data=other.data,
                               boot.data=TRUE)
      
      ## results from simulation
      Fest.boot[b,,,1:(length(estimator.names)-1)] <- results$Fest
    }

    ## get quantiles
    for(j in 1:num.est){
      for(k in 1:numt){
        tmp <- Fest.boot[,,k,j]
        ci.lo[,k,j,i] <- apply(tmp,2,myquantiles.lo)
        ci.hi[,k,j,i] <- apply(tmp,2,myquantiles.hi)
      }
    }
  }
  list(Fest=Fest,ci.lo=ci.lo,ci.hi=ci.hi)
}

## function to compute test statistic 
test.statistic <- function(Fest){
  difference <- data.frame(apply(Fest,3,diff))
  if(dim(Fest)[2]==1){
    ## single point
    out <- apply(abs(difference),1,max)
  } else {
    out <- apply(abs(difference),2,max)
  }
  return(out)
}

## functions to compute type I errors
typeIerror <- function(nperm=50,nsimu,iseed,num.est=12,n,p,m,setting,d=1,H0=FALSE,timeval,
                       censorrate,boot,bootvar=FALSE,usetruth=usetruth,
                       useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                       useGENMIX=useGENMIX,
                       estimator.names=estimator.names,
                       tol.level=0.00001,count.max=100,data=NULL,realdata=FALSE,
                       other.data=NULL){
  
  ## Set parameter values based on data.type
  par.values <- simu.setting(iseed,n,p,m,setting,data,realdata=realdata)
  lim <- par.values$lim
  qvs <- par.values$qvs
  rt <- par.values$rt
  rc <- par.values$rc
  rat <- par.values$rat
  
  storage.mode(lim) <- "double"
  storage.mode(qvs) <- "double"
  storage.mode(rt) <- "integer"
  storage.mode(rc) <- "integer"
  storage.mode(rat) <- "double"
  storage.mode(timeval) <- "double"
  
  
  ## number of estimators
  num.est.orig <- num.est-1 ##(we had 11 original estimators)
  truth.index <- length(estimator.names)
  
  
  ## Arrays to store results
  pvalues <- as.data.frame(array(0,dim=c(nsimu,(length(estimator.names)-1)),
                   dimnames=list(NULL,estimator.names[1:(length(estimator.names)-1)])))

  pvalues.hetcar <- pvalues
  pvalues.nonhetcar <- pvalues

  ## For testing with KM estimator
  Fest0.hetcar <- array(0,dim=c(p,numt,num.est))
  Fest0.nonhetcar <- array(0,dim=c(p,numt,num.est))
  Fest.hetcar <- array(0,dim=c(p,numt,num.est))
  Fest.nonhetcar <- array(0,dim=c(p,numt,num.est))
        

  
  for(i in 1:nsimu){
    results0 <- kh.estimators(lim=lim,qvs=qvs,rt=rt,rc=rc,rat=rat,num.est=num.est,
                              num.est.orig=num.est.orig,
                              n,p,m,setting,d=d,H0=H0,timeval,
                              censorrate,boot,bootvar,usetruth=usetruth,
                              useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                              useGENMIX=useGENMIX,
                              estimator.names=estimator.names,
                              tol.level=tol.level,count.max=count.max,
                              xb=NULL,qb=NULL,deltab=NULL,rb=NULL,permute.data=FALSE,
                              realdata=realdata,data=data,other.data=other.data)
    
    ## data from initial simulation
    xb <- results0$x
    qb <- results0$q
    deltab <- results0$delta
    rb <- results0$r
    
    ## results from initial simulation
    Fest0 <- results0$Fest
    s0 <- test.statistic(Fest0)


    if(!is.null(other.data)){
      Fest0.hetcar[1,,] <- results0$KM.estimator
      Fest0.hetcar[2,,] <- results0$Fest[1,,]
      s0.hetcar <- test.statistic(Fest0.hetcar)
      
      Fest0.nonhetcar[1,,] <- results0$KM.estimator
      Fest0.nonhetcar[2,,] <- results0$Fest[2,,]
      s0.nonhetcar <- test.statistic(Fest0.nonhetcar)
    } 
      
    ## vector to store results
    sval <- array(0,dim=c(nperm,num.est),
                  dimnames=list(paste("nperm",1:nperm,sep=""),estimator.names[1:num.est]))

    sval.hetcar <- sval
    sval.nonhetcar <- sval
    
    for(b in 1:nperm){
      results <- kh.estimators(lim=lim,qvs=qvs,rt=rt,rc=rc,rat=rat,num.est=num.est,num.est.orig=num.est.orig,
                               n,p,m,setting,d=d,H0=H0,timeval,
                               censorrate,boot,bootvar,usetruth=usetruth,
                               useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                               useGENMIX=useGENMIX,
                               estimator.names=estimator.names,
                               tol.level=tol.level,count.max=count.max,
                               xb=xb,qb=qb,deltab=deltab,rb=rb,permute.data=TRUE,
                               realdata=realdata,data=data,other.data=other.data)
      
      ## results from simulation
      Fest <- results$Fest
      sval[b,] <- test.statistic(Fest)
      if(!is.null(other.data)){
        Fest.hetcar[1,,] <- results$KM.estimator
        Fest.hetcar[2,,] <- results$Fest[1,,]
        sval.hetcar[b,] <- test.statistic(Fest.hetcar)
        
        Fest.nonhetcar[1,,] <- results$KM.estimator
        Fest.nonhetcar[2,,] <- results$Fest[2,,]
        sval.nonhetcar[b,] <- test.statistic(Fest.nonhetcar)
      }
    }
    
    ## form p-value
    for(j in 1:num.est){
        pvalues[i,j] <- sum(sval[,j] >=s0[j])/nperm
      if(!is.null(other.data)){
        pvalues.hetcar[i,j] <- sum(sval.hetcar[,j] >=s0.hetcar[j])/nperm
        pvalues.nonhetcar[i,j] <- sum(sval.nonhetcar[,j] >=s0.nonhetcar[j])/nperm
        
      }
    }
    
  }
  list(pvalues=pvalues,pvalues.hetcar=pvalues.hetcar,pvalues.nonhetcar=pvalues.nonhetcar)
}

## function to do power calculations

power.calculation <- function(npow=100,nsimu=100,alpha.values=c(0.01,0.05,0.1,0.2),
                              dval=seq(1,2,by=0.1),
                              iseed,num.est=12,n,p,m,setting,d=1,H0=FALSE,timeval,
                              censorrate,boot,bootvar=FALSE,usetruth=usetruth,
                              useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                              useGENMIX=useGENMIX,
                              estimator.names=estimator.names,
                              tol.level=0.00001,count.max=100){
  
  ## Set parameter values based on data.type
  par.values <- simu.setting(iseed,n,p,m,setting)
  lim <- par.values$lim
  qvs <- par.values$qvs
  rt <- par.values$rt
  rc <- par.values$rc
  rat <- par.values$rat
  
  storage.mode(lim) <- "double"
  storage.mode(qvs) <- "double"
  storage.mode(rt) <- "integer"
  storage.mode(rc) <- "integer"
  storage.mode(rat) <- "double"
  storage.mode(timeval) <- "double"
  
  
  ## number of estimators
  num.est.orig <- num.est-1 ##(we had 11 original estimators)
  
  ## number of time points
  numt <- length(timeval)

  
  ## Arrays to store results, we append the truth
  power.values <- array(0,dim=c(length(alpha.values),length(dval),
                            npow,num.est),
                        dimnames=list(paste("alpha_",alpha.values,sep=""),
                          paste("d_",dval,sep=""),
                          NULL,estimator.names[1:num.est]))

  ## vector to store results
  sval0 <- array(0,dim=c(nsimu,num.est),
                 dimnames=list(paste("nsimu",1:nsimu,sep=""),estimator.names[1:num.est]))
  

  ## Form distribution under the null
  
  for(i in 1:nsimu){
    H0 <- TRUE
    d <- 1
    
    results0 <- kh.estimators(lim=lim,qvs=qvs,rt=rt,rc=rc,rat=rat,num.est=num.est,num.est.orig=num.est.orig,
                              n,p,m,setting,d=d,H0=H0,timeval,
                              censorrate,boot,bootvar,usetruth=usetruth,
                              useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                              useGENMIX=useGENMIX,
                              estimator.names=estimator.names,
                              tol.level=tol.level,count.max=count.max,
                              xb=NULL,qb=NULL,deltab=NULL,rb=NULL,permute.data=FALSE)
    
    ## results from initial simulation
    Fest <- results0$Fest
    sval0[i,] <- test.statistic(Fest)
  }

  ## Form critical values
  make.find.critical.value <- function(alpha){
    function(sval){
      B.sval <- length(sval)
      sval.sort <- sort(sval)
      critical.value <- sval.sort[floor(B.sval * (1-alpha))]
      return(critical.value)
    }
  }

  critical.values <- array(0,dim=c(length(alpha.values),num.est),
                           dimnames=list(paste("alpha_",alpha.values,sep=""),
                             estimator.names[1:num.est]))
  
  for(a in 1:length(alpha.values)){
    alpha.critical.value <- make.find.critical.value(alpha.values[a])
    critical.values[a,] <- apply(sval0,2,alpha.critical.value)
  }

  ## find distributions under H1
  for(d.index in 1:length(dval)){
    d <- dval[d.index]
    H0 <- FALSE

    for(b in 1:npow){
      ## vector to store results
      sval <- array(0,dim=c(nsimu,num.est),
                    dimnames=list(paste("nsimu",1:nsimu,sep=""),estimator.names[1:num.est]))
      
      for(i in 1:nsimu){
        results <- kh.estimators(lim=lim,qvs=qvs,rt=rt,rc=rc,rat=rat,num.est=num.est,num.est.orig=num.est.orig,
                                 n,p,m,setting,d=d,H0=H0,timeval,
                                 censorrate,boot,bootvar,usetruth=usetruth,
                                 useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                                 useGENMIX=useGENMIX,
                                 estimator.names=estimator.names,
                                 tol.level=tol.level,count.max=count.max,
                                 xb=NULL,qb=NULL,deltab=NULL,rb=NULL,permute.data=FALSE)
        
        ## results from simulation
        Fest <- results$Fest
        sval[i,] <- test.statistic(Fest)
      }

      ## form power
      for(j in 1:num.est){
        for(a in 1:length(alpha.values)){
          power.values[a,d.index,b,j] <- sum(sval[,j] >=critical.values[a,j])/nsimu
        }
      }
    }
  }
  list(power.values=power.values)
} 





## main function to call estimators
kh.estimators <- function(lim,qvs,rt=rt,rc=rc,rat=rat,
                          num.est=12,num.est.orig=11,n,p,m,setting,d=1,H0=FALSE,timeval,
                          censorrate,boot,bootvar,usetruth=usetruth,
                          useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                          useGENMIX=useGENMIX,
                          estimator.names=estimator.names,
                          tol.level=0.00001,count.max=100,
                          xb=NULL,qb=NULL,deltab=NULL,rb=NULL,permute.data=FALSE,
                          realdata=FALSE,data=NULL,other.data=NULL,
                          boot.data=FALSE){
  
  ## number of time points
  numt <- length(timeval)
  
  ## Arrays to store results, we append the truth
  Fest <- array(0,dim=c(p,numt,num.est))
  vest <- array(0,dim=c(p,p,numt,num.est))

  storage.mode(Fest) <- "double"
  storage.mode(vest) <- "double"
  

  ## we keep repeating this process until bad.data==FALSE
  ## we would have errors only if we run useEFF and we get eflag!=1
  
  bad.data <- TRUE  
    
  while(bad.data == TRUE){
    ## for testing
    ##for(i in 1:220){
    ##  data <- simu.data(n,p,m,setting,d,H0,
    ##               censorrate,qvs,rc,rt,lim,rat)
    ##}

    ##dyn.unload("../../../../kincohort_simu/src/kincohortsimu.so")
    ##dyn.load("../../../../kincohort_simu/src/kincohortsimu.so")

    ## generate data
    if( realdata==TRUE & permute.data==FALSE & boot.data==FALSE){
      ## We use the real data and we do not permute it NOR bootstrap it.
      
      ## order the data
      data.tmp <- data
      x <- data[,"x"]

      data.tmp <- data.tmp[order(x),]
      x <- data.tmp[,"x"]
      delta <-data.tmp[,"delta"]
      q <- t(data.tmp[,c("q0","q1")])
      r <- as.vector(table(data[,"q0"]))
      
    } else if(realdata==FALSE & permute.data==FALSE & boot.data==FALSE){
      ## We generate new data for simulation study,
      ##   and we do not permute it, NOR bootstrap it.
      
      data <- simu.data(n,p,m,setting,d,H0,
                        censorrate,qvs,rc,rt,lim,rat)
      x <- data$x
      delta <- data$delta
      q <- data$q
      r <- data$r
      ## testing
      ##sum(delta)/n
      ##sum(delta[x<=100])/sum(x<=100)
    }
    
    if(permute.data==TRUE){
      ## We permute data for type I error testing.
      
      if(is.null(other.data)){
        ## Used for the case where we don't have Compound Heterozygote data.
        
        index.random <- sample(1:n,replace=FALSE)
        x <- xb[index.random]
        delta <- deltab[index.random]
        q <- qb
        r <- rb
        
        ## order the data
        data.tmp <- cbind(x,delta,t(q))
        data.tmp <- data.tmp[order(x),]
        x <- data.tmp[,1]
        delta <-data.tmp[,2]
        q <- t(data.tmp[,c(3,4)])
      } else {
        ## Used for the case when we do have Compound Heterozygote data.
        ## We concatenate because we want to compare against Compound Heterozygote.
        
        dataA <- other.data
        dataB <- data

        dataA <- cbind(dataA,rep("Compound Heterozygous",nrow(dataA)))
        dataB <- cbind(dataB,rep("Other",nrow(dataB)))
        colnames(dataA)[ncol(dataA)] <- "Type"
        colnames(dataB)[ncol(dataB)] <- "Type"

        data.all <- rbind(dataA,dataB)
        xb <- data.all[,"x"]
        deltab <- data.all[,"delta"]
        
        index.random <- sample(1:nrow(data.all),replace=FALSE)
        x <- xb[index.random]
        delta <- deltab[index.random]
        
        ## order the data
        data.tmp <- cbind(x,delta,data.all[,c("q0","q1","Type")])
        data.tmp <- data.tmp[order(x),]

        new.data.index <- which(data.tmp[,"Type"]=="Compound Heterozygous")
        new.data <- data.tmp[new.data.index,]

        data.tmp <- data.tmp[-new.data.index,]
        x <- data.tmp[,1]
        delta <-data.tmp[,2]
        q <- t(data.tmp[,c(3,4)])
        r <- rb
        
      }
    }

    if(boot.data==TRUE){
      my.boot.data <- get.boot.data(n,p,m,qb,xb,deltab)
      x <- my.boot.data$xb
      q <- my.boot.data$qb
      delta <- my.boot.data$deltab
      r <- my.boot.data$rb
      m <- my.boot.data$mb
      qvs <- my.boot.data$qvsb
      
      ## Used when we want to compute 95% CI based on bootstrapping each data set.
      ##index.random <- sample(1:n,replace=TRUE)
      ##x <- xb[index.random]
      ##delta <- deltab[index.random]
      ##q <- qb
      ##r <- rb
      
      ## order the data
      ##data.tmp <- cbind(x,delta,t(q))
      ##data.tmp <- data.tmp[order(x),]
      ##x <- data.tmp[,1]
      ##delta <-data.tmp[,2]
      ##q <- t(data.tmp[,c(3,4)])
      
    }
    
    storage.mode(x) <- "double"
    storage.mode(delta) <- "double"
    storage.mode(q) <- "double"
    storage.mode(r) <- "integer"

    

    eflag <-0
    
    if(useOLS==TRUE | useWLS == TRUE | useEFF == TRUE | useNPMLEs==TRUE){
      for(j in 1:numt){
        t0 <- timeval[j]
        ##print(t0)
        
        ## Run simulation study
        
        results <- kincohort.estimators(n,q,x,delta,t0,qvs,p,m,r,lim,rat,setting,d,H0,
                                        num.est.orig,boot,bootvar,usetruth,useOLS,useWLS,
                                        useEFF,useNPMLEs)
        eflag <- results$eflag
        
        if(useEFF==TRUE){
          if(eflag==1){
            Fest[,j,1:num.est.orig] <- results$Fest
            vest[,,j,1:num.est.orig] <- results$vest
          } else {
            break
          }
        } else if(useOLS==TRUE | useWLS == TRUE | useNPMLEs==TRUE){
          Fest[,j,1:num.est.orig] <- results$Fest
          vest[,,j,1:num.est.orig] <- results$vest
        }
      }
    }
    
    if((useEFF==TRUE & eflag==1) | useEFF==FALSE){
      if(useGENMIX==TRUE){
        ## we evaluate genmix at all time points
        genmix.results <- genetic.mix(n,p,m,q,x,delta,timeval,boot,bootvar,
                                      tol.level,count.max)
        Fest[,,num.est] <- genmix.results$Fest
        vest[,,,num.est] <- genmix.results$var.out
      }
    }

    if(!is.null(other.data)){
      if(permute.data==FALSE){
        new.data <- other.data
      }
         
      KM <- survfit(Surv(new.data[,"x"],new.data[,"delta"])~1,type="kaplan-meier")
      ## adjust survival times to match timeval
      tmp.rep <- diff(c(1,KM$time,101))
      KM.estimator <- rep(c(1,KM$surv),times=tmp.rep)
      KM.estimator <- 1-KM.estimator
      KM.estimator <- KM.estimator[timeval]
      

    } else {
      KM.estimator <- NULL
      KM.var <- NULL
    }
    
    if(useEFF==TRUE & eflag!=1){
      bad.data <- TRUE
      print("bad.data")
    } else if((useEFF==TRUE & eflag==1) | useEFF==FALSE){
      bad.data <- FALSE
    }
  }
  
  dimnames(Fest)<- list(paste("p.",1:p,sep=""),
                        paste("t",timeval,sep=""),
                        estimator.names[1:num.est])

  dimnames(vest) <- list(paste("p.",1:p,sep=""),
                      paste("p.",1:p,sep=""),
                         paste("t",timeval,sep=""),
                         estimator.names[1:num.est])
  

  list(Fest=Fest,vest=vest,x=x,delta=delta,q=q,r=r,
       KM.estimator=KM.estimator)
}   




