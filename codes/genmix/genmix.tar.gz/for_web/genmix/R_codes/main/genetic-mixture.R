###################################################################
## Note: Our code combines timeval and x points                  ##
##          for evaluating Fest.                                 ##
###################################################################

### genetic mixture with known proportion

######################
## Libraries needed ##
######################
library(Iso)   ## for pava
library(zoo)   ## to handle NA values


## n : the sample size
## p : the dimension of Ft (i.e., number of distributions in mixture)
## q : mixture proportions
## x : observed time points
## delta : censoring indicator, delta=1 means death
## timeval : time points where Ft is evaluated at
## tol.level : tolerance level for algorithm
## count.max : maximum number of counts

## for testing:
#n <- 400
#p <- 2
#q <- matrix(0,nrow=p,ncol=n)
#q[1,] <-lam
#q[2,] <- (1-lam)
#x <- t
#timeval <- t
#delta <- d
#numt <- n


genetic.mix.fest <- function(n,q,x,delta,timeval,p,tol.level=0.00001, count.max = 100){

  ## timeval.new contains the points timeval and x together
  timeval.new <- c(timeval,x)
  timeval.new <- sort(timeval.new)  ## sorting all time points
  timeval.indices <- match(timeval,timeval.new)  ## indices of timeval points
  events.indices <- match(x,timeval.new)  ## indices of event times x
  
  ## number of time points for evaluation
  numt.new <- length(timeval.new)

  ## Fest: function for storing results
  ## Fest0 : initial estimate of Fest, and used in loop
  Fest <- matrix(0,nrow=p,ncol=numt.new)
  Fest0 <- Fest
  

  ## initial estimate Fest0
  for(l in 1:p){
    Fest0[l,] <- pnorm(timeval.new,mean=mean(timeval.new))
  }

  ## We set Fest to its initial estimate, Fest0
  Fest <- Fest0

  ## setting tolerance count for loop
  tol <- 1
  count <- 0

  ## all.deaths?
  ## if all.deaths==TRUE, then we have the complete data case;
  ## otherwise, we have censoring.
  all.deaths <- (sum(delta)==n)
  
  ## Loop for estimating Ft
  while(tol>tol.level & count<count.max){
    count <- count+1    

    ## u,v are P(D_i=1|X_i<=t_j) and P(D_i=1|X_i>t_j)  
    u <- matrix(0,nrow=n,ncol=numt.new)
    v <- u
    
    for(i in 1:n){
      ## Compute u_ij. for t_j very small, u_ij could be 0/0
      ## In this case we, set u_ij to be the next largest value.
      
      u.numerator <- q[1,i]*Fest0[1,]
      u.denominator <- q[1,i]*Fest0[1,]+q[2,i]*Fest0[2,]
      
      u[i,] <-  u.numerator/u.denominator
      u[i,] <- na.approx(u[i,],na.rm=FALSE,rule=2)
      
      ##u.index00 <- intersect(which(abs(u.numerator)<1e-10),
      ##                       which(abs(u.denominator)<1e-10))
      
      ##if(length(u.index00)>0){
      ##  u[i,u.index00] <- u[i,(max(u.index00)+1)]
      ##}

      ## Compute v_ij. for t_j very small, v_ij could be 0/0
      ## In this case we, set v_ij to be the last value before we got 0/0

      v.numerator <- q[1,i]*(1-Fest0[1,])
      v.denominator <- (q[1,i]*(1-Fest0[1,])+
                      q[2,i]*(1-Fest0[2,]))

      v[i,] <- v.numerator / v.denominator

      ## if all temp values are NaN, replace all of them with 0
      ##if(sum(is.na(v[i,]))==length(v[i,])){
      ##  v[i,] <- rep(0,length(v[i,]))
      ##}
      
      ## if only one value is non-zero, and the rest are NaN
      ##if(sum(is.na(v[i,]))==(length(v[i,])-1)){
      ##  v[i,] <- na.locf(v[i,],na.rm=FALSE)
      ##}
      
      v[i,] <- na.approx(v[i,],na.rm=FALSE,rule=2)
      
      ##v.index00 <- intersect(which(abs(v.numerator)<1e-10),
      ##                     which(abs(v.denominator)<1e-10))
      
      ##if(length(v.index00)>0){
      ##  v[i,v.index00] <- v[i,(min(v.index00)-1)]
      ##}
    }
    
    ## Fest is the unrestricted estimate of Ft
    ## s are the weights
    s <- matrix(0,nrow=p,ncol=numt.new)

    if(all.deaths==FALSE){
      ## censored case
      w.tmp <- matrix(0,nrow=n,ncol=numt.new)
      for(j in 1:numt.new){
        ##print(j)
        indicator <- rep(0,n)
        indicator[x>timeval.new[j]] <- 1
        
        ## denominator
        bottom <- q[1,]*(1-Fest0[1,events.indices])+q[2,]*(1-Fest0[2,events.indices])

        ## numerator
        top <- q[1,]*(1-Fest0[1,j])+q[2,]*(1-Fest0[2,j])
        temp <- (1-delta)*top/bottom

        ######################
        ## make adjustments ##
        ######################

        ## replace Inf with 0's
        temp[temp==Inf] <- 0

        ## if all temp values are NaN, replace all of them with 0
        if(sum(is.na(temp))==length(temp)){
          temp <- rep(0,length(temp))
        }

        ## if only one value is non-zero, and the rest are NaN
        if(sum(is.na(temp))==(length(temp)-1)){
          temp <- na.locf(temp,na.rm=FALSE)
        }
         
        temp <- na.approx(temp,na.rm=FALSE,rule=2)
        
        indicator[x<=timeval.new[j]] <- temp[x<=timeval.new[j]]

        ## we compute 1-w_ij
        w.tmp[,j] <- 1-indicator
      }

      for(j in 1:numt.new){
        s[1,j] <- sum(u[,j]*w.tmp[,j])+sum(v[,j]*(1-w.tmp[,j]))      
        s[2,j] <- sum((1-u[,j])*w.tmp[,j])+sum((1-v[,j])*(1-w.tmp[,j]))
        Fest[1,j] <- sum(u[,j]*w.tmp[,j])/s[1,j]
        Fest[2,j] <- sum((1-u[,j])*w.tmp[,j])/s[2,j]
      }
      
    } else {
      ## non-censored case
      for(j in 1:numt.new){
        tem <- rep(0,n)
        tem[x<=timeval.new[j]] <- 1
        s[1,j] <- sum(u[,j]*tem)+sum(v[,j]*(1-tem))      
        s[2,j] <- sum((1-u[,j])*tem)+sum((1-v[,j])*(1-tem))
        Fest[1,j] <- sum(u[,j]*tem)/s[1,j]
        Fest[2,j] <- sum((1-u[,j])*tem)/s[2,j]
      }    

    }
    

    for(l in 1:p){
      Fest[l,] <- pava(Fest[l,],s[l,])
    }
    
    tol <- data.frame(apply(Fest-Fest0,1,abs))
    tol <- apply(tol,2,mean)
    tol <- sum(tol)

    ## reset initial estimate
    Fest0 <- Fest
  }

  ## We output Fest only evaluated at time points of interest (i.e., timeval)
  Fest.all <- Fest
  Fest <- Fest[,timeval.indices]
  
  list(Fest=Fest,Fest.all=Fest.all)
}


genetic.mix.boot <- function(n,p,m,q,x,delta,timeval,boot=100,tol.level=0.00001,
                             count.max = 100){
  ## matrix for storing estimates
  numt <- length(timeval)
  Fest.boot <- array(0,dim=c(p,numt,boot))

  for(b in 1:boot){

    boot.data <- get.boot.data(n,p,m,q,x,delta)
    qb <- boot.data$qb
    xb <- boot.data$xb
    deltab <- boot.data$deltab

    Fest.boot[,,b] <- genetic.mix.fest(n,qb,xb,deltab,timeval,p,
                                       tol.level=tol.level, count.max = count.max)$Fest
  }
  ## compute bootstrap variance for each time point
  var.boot <- array(0,dim=c(p,p,numt))
  for(k in 1:numt){
    tmp <- Fest.boot[,k,]
    var.boot[,,k] <- var(t(tmp))
  }
  
  list(var.boot=var.boot)
}

## function to get 95% CI by bootstrap
genetic.mix.ci <- function(n,p,m,q,x,delta,timeval,boot=100,tol.level=0.00001,
                             count.max = 100,alpha=0.05){
  ## matrix for storing estimates
  numt <- length(timeval)
  Fest.boot <- array(0,dim=c(p,numt,boot))
  dimnames(Fest.boot) <- list(paste("p.",1:p,sep=""),
                              paste("t",timeval,sep=""),
                              paste("boot",1:boot,sep=""))

  for(b in 1:boot){

    boot.data <- get.boot.data(n,p,m,q,x,delta)
    qb <- boot.data$qb
    xb <- boot.data$xb
    deltab <- boot.data$deltab

    Fest.boot[,,b] <- genetic.mix.fest(n,qb,xb,deltab,timeval,p,
                                       tol.level=tol.level, count.max = count.max)$Fest
  }
  ## compute 95% CI for each timepoint
  ci.boot.lo <- array(0,dim=c(p,numt))
  ci.boot.hi <- array(0,dim=c(p,numt))
  
  for(k in 1:numt){
    tmp <- Fest.boot[,k,]
    ci.boot.lo[,k] <- apply(tmp,1,myquantiles.lo)
    ci.boot.hi[,k] <- apply(tmp,1,myquantiles.hi)
  }
  
  list(ci.boot.lo=ci.boot.lo,ci.boot.hi=ci.boot.hi)
}

## main function for genetic.mix

genetic.mix <- function(n,p,m,q,x,delta,timeval,boot=100,bootvar=TRUE,tol.level=0.00001,
                        count.max = 100){
  numt <- length(timeval)
  
  Fest.out <- genetic.mix.fest(n,q,x,delta,timeval,p,tol.level,
                               count.max)
  if(bootvar==TRUE){
    var.out <- genetic.mix.boot(n,p,m,q,x,delta,timeval,boot,tol.level,count.max)$var.boot
  } else {
    var.out <- array(0,dim=c(p,p,numt))
  }

  list(Fest=Fest.out$Fest,var.out=var.out)
}
