##########################
## Run simulation study ##
##########################

if(hyptest == FALSE & power.compute == FALSE & boot.ci==FALSE){
  ## normal simulation study
  simu.out <- simulation.study(nsimu,iseed,num.est,n,p,m,
                               setting,d=1,H0=H0,
                               timeval,
                               censorrate,boot,bootvar,usetruth,
                               useOLS,useWLS,useEFF,useNPMLEs,useGENMIX,
                               estimator.names,tol.level,count.max,data=data,
                               realdata=realdata,other.data=other.data)
} else if (hyptest== TRUE){
  ## hypothesis testing
  hyptest.out <- typeIerror(nperm=nperm,nsimu=nsimu,iseed,num.est,n,p,m,
                            setting,d=1,H0,timeval,
                            censorrate,boot,bootvar=FALSE,usetruth=usetruth,
                            useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,
                            useNPMLEs=useNPMLEs,
                            useGENMIX=useGENMIX,
                            estimator.names=estimator.names,
                            tol.level,count.max,data=data,realdata=realdata,other.data=other.data)

} else if (power.compute==TRUE){
  ## power calculations (not used)
  power.out <- power.calculation(npow,nsimu,alpha.values,
                                 dval=seq(1,2,by=0.1),
                                 iseed,num.est,n,p,m,setting,
                                 d,H0,timeval,
                                 censorrate,boot,bootvar=FALSE,
                                 usetruth=usetruth,
                                 useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,
                                 useNPMLEs=useNPMLEs,
                                 useGENMIX=useGENMIX,
                                 estimator.names=estimator.names,
                                 tol.level,count.max)
} else if(boot.ci==TRUE){
  ## This is used only for real data to compute 95% CI using bootstrap.
  boot.out <- boot.CI(boot=boot,
                      nsimu=nsimu,
                      iseed,
                      num.est=num.est,n,p,m,setting,d,
                      H0,timeval,
                      censorrate,bootvar=FALSE,
                      usetruth=usetruth,
                      useOLS=useOLS,useWLS=useWLS,useEFF=useEFF,useNPMLEs=useNPMLEs,
                      useGENMIX=useGENMIX,
                      estimator.names=estimator.names,
                      tol.level,count.max,data=data,realdata=realdata,
                      other.data=other.data)
}

##################
## Write output ##
##################

if(hyptest==FALSE & power.compute == FALSE & boot.ci==FALSE){
  
  if(fullrange==FALSE){
    Fest.out <- apply(simu.out$Fest[,1,1:num.est,],2,rbind)
      
    if(nsimu==1){
      vest.out <- apply(simu.out$vest[,,1,1:num.est,],c(1,3),rbind)
    }  else {
      vest.out <- apply(simu.out$vest[,,1,1:num.est,],c(1,4),rbind)
    }
    vest.out <- apply(vest.out,1,cbind)
    
    if(nsimu==1){
      vest.out <- t(vest.out)
    }
    out <- cbind(Fest.out,vest.out)
    
    if(realdata==FALSE){
      if(iseed==1234){
        out <- rbind(simu.out$store.true,out)
      }
    }
    
    write.table(out,file_name,col.names=FALSE,row.names=FALSE)
  } else {
    ## We print out the truth as well, that's why we have num.est+1
    final.output <- array(0,dim=c(nsimu * length(simu.out$timeval),
                              p*3+1,num.est+1))

    
    for(e in 1:(num.est+1)){
      Fest.out <- simu.out$Fest
      Fest.out <- Fest.out[,,e,]
      Fest.out <- apply(Fest.out,1,rbind)

      
      vest.out <- simu.out$vest
      vest.out <- vest.out[,,,e,]

      
      if(nsimu==1){
        vest.out <- apply(vest.out,3,rbind)
      } else {
        vest.out <- apply(vest.out,c(3,4),rbind)
      }
      vest.out <- apply(vest.out,1,rbind)
      
      ##out <- cbind(rep(simu.out$timeval,nsimu),Fest.out,vest.out)
      final.output[,,e] <- cbind(rep(simu.out$timeval,nsimu),
                                 Fest.out,vest.out)

    }
    
    write.table(data.frame(final.output[,,1]),
                file=paste("full_",file_name,sep=""),
                col.names=FALSE,row.names=FALSE)

    
    for(e in 2:(num.est+1)){
      write.table(final.output[,,e],
                  file=paste("full_",file_name,sep=""),
                  append=TRUE,col.names=FALSE,row.names=FALSE)
    }
  }
} else if(hyptest==TRUE){
  write.table(hyptest.out$pvalues,file=paste("hyptest_",file_name,sep=""),
              col.names=FALSE,row.names=FALSE)

  if(!is.null(other.data)){
    write.table(hyptest.out$pvalues.hetcar,file=paste("hyptest_hetcar_",file_name,sep=""),
                col.names=FALSE,row.names=FALSE)

    write.table(hyptest.out$pvalues.nonhetcar,file=paste("hyptest_nonhetcar_",file_name,sep=""),
                col.names=FALSE,row.names=FALSE)
  }
} else if(power.compute==TRUE){
  final.output <- NULL

  for(e in 1:num.est){
    est.tmp <- power.out$power.values[,,,e]
    for(a in 1:length(alpha.values)){
      tmp.alpha <- rep(alpha.values[a],npow)
      final.output <- rbind(final.output,cbind(tmp.alpha,t(est.tmp[a,,])))
    }
  }

  write.table(data.frame(final.output),
              file=paste("power_",file_name,sep=""),
              col.names=FALSE,row.names=FALSE)
} else if(boot.ci==TRUE){
  ## We compute 95% CI using bootstrap
  ## We print out the truth as well, that's why we have num.est+1
  final.output <- array(0,dim=c(nsimu * length(timeval),
                            p*3+1,num.est+1))
  for(e in 1:(num.est+1)){
    Fest.out <- boot.out$Fest
    Fest.out <- Fest.out[,,e,]
    Fest.out <- apply(Fest.out,1,rbind)

    ci.lo <- boot.out$ci.lo
    ci.lo <- ci.lo[,,e,]
    ci.lo <- apply(ci.lo,1,rbind)

    ci.hi <- boot.out$ci.hi
    ci.hi <- ci.hi[,,e,]
    ci.hi <- apply(ci.hi,1,rbind)

    ##out <- cbind(rep(simu.out$timeval,nsimu),Fest.out,vest.out)
    final.output[,,e] <- cbind(rep(timeval,nsimu),
                               Fest.out,ci.lo,ci.hi)
  }

  write.table(data.frame(final.output[,,1]),
              file=paste("bootci_full_",file_name,sep=""),
              col.names=FALSE,row.names=FALSE)
  
  
  for(e in 2:(num.est+1)){
    write.table(final.output[,,e],
                file=paste("bootci_full_",file_name,sep=""),
                append=TRUE,col.names=FALSE,row.names=FALSE)
  }

}





if(is.loaded("apply_kincohort_estimators")){
    dyn.unload("../../../../kincohort_simu/src/kincohortsimu.so") }
