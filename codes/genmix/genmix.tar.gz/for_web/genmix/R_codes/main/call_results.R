############
## Source ##
############
source("../../../main/results_main.R")


###############
## Libraries ##
###############
library(xtable)

##################################
## Number of significant digits ##
##################################
sig.digits <- 4

if(hyptest==FALSE & power.compute==FALSE & boot.ci==FALSE){
####################
  ## Read data file ##
####################
  
  mydata <- as.matrix(read.table(file=paste("full_",file_name,sep="")))
  ##mydata <- as.matrix(read.table("myresults.dat"))
  mydata.tmp <- mydata

  
###############################
  ## We put data into an array ##
###############################
  
  data.all <- array(0,dim=c(nsimu * numt,
                        p*3+1,num.est+1))

  
  for(e in 1:(num.est+1)){
    data.all[,,e] <- (mydata.tmp[1:(nsimu*numt),])
    mydata.tmp <- mydata.tmp[-(1:(nsimu*numt)),]
  }
  
  num.est.all <- num.est + 1
  
} else if(hyptest==TRUE){
  data.all <-  as.matrix(read.table(file="mydata.dat"))
  
} else if(power.compute==TRUE){

  mydata <- as.matrix(read.table(file=paste("power_",file_name,sep="")))
  ##mydata <- as.matrix(read.table("myresults.dat"))
  
  mydata.tmp <- mydata
  
###############################
  ## We put data into an array ##
###############################
  
  data.all <- array(0,dim=c(npow * length(alpha.values),
                        length(dval)+1,num.est),
                    dimnames=list(NULL,c("alpha",paste("d_",dval,sep="")),
                      estimator.names[1:num.est]))

  for(e in 1:(num.est)){
    data.all[,,e] <- (mydata.tmp[1:(npow*length(alpha.values)),])
    mydata.tmp <- mydata.tmp[-(1:(npow*length(alpha.values))),]
  }
  
  num.est.all <- num.est 
  
} else if(boot.ci==TRUE){
  
  mydata <- as.matrix(read.table(file=paste("bootci_full_",file_name,sep="")))
  ##mydata <- as.matrix(read.table("myresults.dat"))
  mydata.tmp <- mydata

  
###############################
  ## We put data into an array ##
###############################
  
  data.all <- array(0,dim=c(nsimu * numt,
                        p*3+1,num.est+1))

  
  for(e in 1:(num.est+1)){
    data.all[,,e] <- (mydata.tmp[1:(nsimu*numt),])
    mydata.tmp <- mydata.tmp[-(1:(nsimu*numt)),]
  }
  
  num.est.all <- num.est + 1
  
}




if((hyptest==FALSE & power.compute==FALSE & boot.ci==FALSE) | boot.ci==TRUE){ 
#######################
  ## Summarize Results ##
#######################
  
  output <- bias.curve(data.all,p,num.est.all,estimator.names,
                       data.type,filename="plot",H0,realdata)
  
  
  if(realdata==FALSE){
##################
    ## LaTeX Tables ##
##################
    
######################
    ## Average variance ##
######################
    cat("\n\n  Average variance \n\n")
    
    print(xtable(output$avg.var,digits=sig.digits))
    
    
#########
    ## IAB ##
#########
    cat("\n\n  Integrated absolute bias (IAB) \n\n")
    
    print(xtable(output$iab,digits=sig.digits))
    
    
    
    
###########################
  ## Average 95\% coverage ##
###########################
    
    cat("\n\n  Average 95 coverage \n\n")
    
    print(xtable(output$avg.coverage,digits=sig.digits))
    
    
    
#############
    ## Avg MSE ##
#############
    cat("\n\n Average Mean squared error (MSE) \n\n")
    print(xtable(output$mse.avg,digits=sig.digits))
    
    
#####################################
    ## Average absolute pointwise bias ##
#####################################
    cat("\n\n  Average absolute pointwise bias \n\n")
    
    print(xtable(output$avg.abs.ptwise.bias,digits=sig.digits))
    
    
  
    
  
    
    
##########
    ## Bias ##
##########
    cat("\n\n  Bias of Area under curve (AUC) and true integrated value \n\n")
    
    print(xtable(output$bias,digits=sig.digits))
    
  }
  
  if(fullrange==TRUE){
###########
      ## Plots ##
###########
    timeval <- output$timeval

    F <- output$F
    var.est <- output$var.est
    Ft.lo <- output$Ft.lo
    Ft.hi <- output$Ft.hi

    if(realdata==FALSE){
      plot.ci <- TRUE
      plot.cdf <- TRUE
      cdf <- TRUE
    } else {
      plot.ci <- TRUE
      plot.cdf <- TRUE
      cdf <- TRUE
    }

    if(realdata==TRUE){
      ## show table of estimates and results
      out.point <- point.estimates(F,var.est,Ft.lo,Ft.hi,
                                   timeval,est.interest=est.interest,
                                   ages.interest=ages.interest,cdf=cdf)

      cat("\n\n  F1: Point estimates and 95% CI \n\n")
      print(xtable(out.point$F1.summary,digits=3))

      cat("\n\n  F2: Point estimates and 95% CI \n\n")
      print(xtable(out.point$F2.summary,digits=3))

      cat("\n\n  F1 and F2: Point estimates and 95% CI \n\n")
      print(xtable(cbind(out.point$F1.summary,out.point$F2.summary),digits=3))

      ## show residual life table
      resid.life <- residual.life.est(ages=ages,interest=future.ages,
                                      p,num.est.all,timeval,F,
                                      estimator.names,
                                      survival=survival,
                                      other.data=other.data)

      cat("\n\n Residual Life Table: EM-PAVA \n\n")
      est.interest <- "EMPAVA"
      print(residual.life.est.organize(resid.life,ages,
                                       interest=future.ages,
                                       est.interest=est.interest))
      
      
      if(!is.null(other.data)){
        hetcar <- TRUE
        out.point.hetcar <- point.estimates(F,var.est,Ft.lo,Ft.hi,
                                     timeval,est.interest=est.interest,
                                     ages.interest=ages.interest,cdf=cdf,
                                         other.data=other.data,hetcar=hetcar)

        hetcar <- FALSE
        out.point.nonhetcar <- point.estimates(F,var.est,Ft.lo,Ft.hi,
                                     timeval,est.interest=est.interest,
                                     ages.interest=ages.interest,cdf=cdf,
                                         other.data=other.data,hetcar=hetcar)

        cat("\n\n F1 and F2: Point estimates and 95% CI for het and hetnon (Kaplan-Meier)\n\n")
        print(xtable(cbind(out.point.hetcar$F1.summary[,1:3],out.point.hetcar$F2.summary,
                           out.point.nonhetcar$F2.summary),
                     digits=3))

        cat("\n\n Residual Life Table: KM estimator")
        est.interest <- "KM"
        print(residual.life.est.organize(resid.life,ages,
                                         interest=future.ages,
                                         est.interest=est.interest))
        
        
          
      }
      
      
    }
    
    
    ## EFFAIPW
    est.name <- "EFFAIPW"
    postscript(paste(est.name,setting,censorrate,".eps",sep=""))
    myplot(data.type,F,var.est,Ft.lo,Ft.hi,timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2)
    dev.off()
    
    ## NPMLE1
    est.name <- "type I NPMLE"
    postscript(paste("NPMLE1",setting,censorrate,".eps",sep=""))
    myplot(data.type,F,var.est,Ft.lo,Ft.hi,timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2)

    dev.off()
    
##    ## NPMLE2
    est.name <- "type II NPMLE"
    postscript(paste("NPMLE2",setting,censorrate,".eps",sep=""))
    myplot(data.type,F,var.est,Ft.lo,Ft.hi,timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2)
    dev.off()
    
    ## GENMIX
    est.name <- "EMPAVA"
    postscript(paste(est.name,setting,censorrate,".eps",sep=""))
    myplot(data.type,F,var.est,Ft.lo,Ft.hi,timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2)

    dev.off()



    if(!is.null(other.data)){
      NameF <- "Compound Heterozygous or Homozygous Carrier"
      NameG <- "Heterozygous Carrier"
      hetcar <- TRUE
      
##      ## EFFAIPW
##      est.name <- "EFFAIPW"
##      postscript(paste(est.name,setting,censorrate,"hetcar.eps",sep=""))
##      myplot(data.type,F,var.est,Ft.lo,
##             Ft.hi,
##             timeval,est.name=est.name,censorrate=censorrate,
##             plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG,
##             time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2,hetcar=hetcar)
##      dev.off()
    
      ## NPMLE1
      est.name <- "type I NPMLE"
      postscript(paste("NPMLE1",setting,censorrate,"hetcar.eps",sep=""))
      myplot(data.type,F,var.est,Ft.lo,Ft.hi,
             timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2,hetcar=hetcar)
      dev.off()
      
##      ## NPMLE2
##      est.name <- "type II NPMLE"
##      postscript(paste("NPMLE2",setting,censorrate,"hetcar.eps",sep=""))
##      myplot(data.type,F,var.est,Ft.lo,
##             Ft.hi,
##             timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,
##      NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2,hetcar=hetcar)
##      dev.off()
      
      ## GENMIX
      est.name <- "EMPAVA"
      postscript(paste(est.name,setting,censorrate,"hetcar.eps",sep=""))
      myplot(data.type,F,var.est,Ft.lo,Ft.hi,timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,
             realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,
             col1=col1,col2=col2,hetcar=hetcar)
      dev.off()

      
      


      ## Non-Carrier
      NameG <- "Non-Carrier"
      hetcar <- FALSE

##      ## EFFAIPW
##      est.name <- "EFFAIPW"
##      postscript(paste(est.name,setting,censorrate,"nonhetcar.eps",sep=""))
##      myplot(data.type,F,var.est,Ft.lo,
##             Ft.hi,
##             timeval,est.name=est.name,censorrate=censorrate,
##             plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG,
##             time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2,
##      hetcar=hetcar)
##      dev.off()
    
      ## NPMLE1
      est.name <- "type I NPMLE"
      postscript(paste("NPMLE1",setting,censorrate,"nonhetcar.eps",sep=""))
      myplot(data.type,F,var.est,Ft.lo,Ft.hi,
             timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2,hetcar=hetcar)
    dev.off()
      
##      ## NPMLE2
##      est.name <- "type II NPMLE"
##      postscript(paste("NPMLE2",setting,censorrate,"nonhetcar.eps",sep=""))
##      myplot(data.type,F,var.est,Ft.lo,
##             Ft.hi,
##             timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2,hetcar=hetcar)
##      dev.off()
      
      ## GENMIX
      est.name <- "EMPAVA"
      postscript(paste(est.name,setting,censorrate,"nonhetcar.eps",sep=""))
      myplot(data.type,F,var.est,Ft.lo,Ft.hi,timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,
             realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,
             col1=col1,col2=col2,hetcar=hetcar)
      dev.off()

      ## For both Hetcar and HetNoncar
      NameA <- "Compound Heterozygous or Homozygous Carrier"
      NameF <- "Heterozygous Carrier"
      NameG <- "Non-Carrier"
      
      ## NPMLE1
      est.name <- "type I NPMLE"
      postscript(paste("NPMLE1",setting,censorrate,"hetboth.eps",sep=""))
      myplot(data.type,F,var.est,Ft.lo,Ft.hi,
             timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,realdata=realdata,NameF=NameF,
             NameG=NameG, time.restrict=time.restrict,other.data=other.data,col1=col1,col2=col2,hetcar=hetcar,
             hetboth=TRUE,NameA=NameA)
      dev.off()

      ## GENMIX
      est.name <- "EMPAVA"
      postscript(paste(est.name,setting,censorrate,"hetboth.eps",sep=""))
      myplot(data.type,F,var.est,Ft.lo,Ft.hi,timeval,est.name=est.name,censorrate=censorrate,plot.ci,plot.cdf,
             realdata=realdata,NameF=NameF,NameG=NameG, time.restrict=time.restrict,other.data=other.data,
             col1=col1,col2=col2,
             hetcar=hetcar,hetboth=TRUE,NameA=NameA)
      dev.off()
      
    }
  }
} else if(hyptest==TRUE){
  output <- typeIerror.results(data.all,alpha.values)


######################
  ## Rejection rates ##
######################
  cat("\n\n  Rejection rates \n\n")
  
  print(xtable(output$results,digits=sig.digits))
  

}
  


