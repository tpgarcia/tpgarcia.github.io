##################################################################
## Warning: Ft must always be p=2,                               ##
## because genetic-mixture.R is not flexible to handle general p.##
###################################################################

#########################
## Missing variables ? ##
#########################

## iseed
if(!exists(as.character(substitute(iseed)))){
  iseed <- 1234
}

## realdata
if(!exists(as.character(substitute(realdata)))){
  realdata <- FALSE
}

## boot.ci
if(!exists(as.character(substitute(boot.ci)))){
  boot.ci <- FALSE
}

## boot
if(!exists(as.character(substitute(boot)))){
  boot <- 100
}

## nperm
if(!exists(as.character(substitute(nperm)))){
  nperm <- 100
}

## npow
if(!exists(as.character(substitute(npow)))){
  npow <- 100
}





## other.data
if(!exists(as.character(substitute(other.data)))){
  other.data <- NULL
}

## hetcar
if(!exists(as.character(substitute(hetcar)))){
  hetcar <- TRUE
}


## H0
if(!exists(as.character(substitute(H0)))){
  H0 <- FALSE
}

## NameF
if(!exists(as.character(substitute(NameF)))){
  NameF <- NULL
}

## NameG
if(!exists(as.character(substitute(NameG)))){
  NameG <- NULL
}

## NameG
if(!exists(as.character(substitute(time.restrict)))){
  time.restrict <- NULL
}



## d
if(!exists(as.character(substitute(d)))){
  d <- 1
}

## fullrange
if(!exists(as.character(substitute(fullrange)))){
  fullrange <- FALSE
}

## do we have real data?
if(!exists(as.character(substitute(fullrange)))){
  realdata <- FALSE
}

## singlet
if(!exists(as.character(substitute(singlet)))){
  singlet <- "none"
}

## hyptest
if(!exists(as.character(substitute(hyptest)))){
  hyptest <- FALSE
}

## power.compute
if(!exists(as.character(substitute(power.compute)))){
  power.compute <- FALSE
}


####################
## Set parameters ##
####################

## types of estimators used
useOLS <- FALSE
useWLS <- FALSE
useEFF <- TRUE
useNPMLEs <- TRUE
useGENMIX <- TRUE

## For TESTING!!
##useOLS <- TRUE
##useWLS <- TRUE
##useEFF <- FALSE
##useNPMLEs <- FALSE
##useGENMIX <- FALSE

if(data.type=="cox"){
  setting <- "regcoxcase"
} else if(data.type=="newcox"){
  setting <- "newcoxcase"
} else if(data.type=="newcure"){
  setting <- "newmodcure"
} else if(data.type=="coxcure"){
  setting <- "regcoxcure"
} else if(data.type=="noncox"){
  setting <- "noncoxcase"
} else if(data.type=="noncoxcure"){
  setting <- "noncoxcure"
} else if(data.type=="power"){
  setting <- "regpowcase"
} else if(data.type=="powercure"){
  setting <- "regpowcure"
} else if(data.type=="realcarrier"){
  setting <- "myrealcarr"
} else if(data.type=="misscarrier"){
  setting <- "mymisscarr"
} else if(data.type=="realdeletion"){
  setting <-"myrealdele"
} else if(data.type=="realAB"){
  setting <- "myrealbgrp"
} else if(data.type=="pene"){
  setting <- "mypenedata"
}


if(data.type=="coxcure" | data.type=="noncoxcure" | data.type=="powercure"){
  useEFF <- FALSE ## we cannot run this, otherwise we will get errors!
}

if(data.type=="realcarrier"){
  ## Real data (mimics HD data set)
  n <- 355
  m <- 3
  censorrate <- 93.8
} else if(data.type=="realdeletion"){
  n <-300
  m <- 3
  censorrate <- 94.3
} else if(data.type=="realAB"){
  n<- 338
  m <- 3
  censorrate <- 97
} else if(data.type=="misscarrier"){
  n<- 341
  m <- 2
  censorrate <- 93.5
} else if(data.type=="pene"){
  n <- 747
  m <- 3
} else {
  ##n <- 10  ## FOR TESTING!!!!!!!!!!
  n <- 500 
  m <- 4  
}

## use true estimator teffest?
if(realdata==FALSE){
  usetruth <- TRUE
} else {
  usetruth <- FALSE
}

## alpha values
alpha.values <- c(0.01,0.05,0.1,0.2)

## dval
dval <- seq(1,2,by=0.2)

## number of estimators (11 original + genetic mixture)
num.est <- 12

## tolerance level and count.max for genetic.mixture function
tol.level <- 0.00001
count.max <- 100

## dimension of F(t)
p <- 2


## For simulations at a single time point
if(singlet=="t1"){
  if(data.type=="newcure"){
    timeval <- 85
  } else if(data.type=="newcox") {
    timeval <- 1.3
  } else if(data.type=="cox"){
    timeval <- 2
  }
} else if(singlet=="t2"){
  timeval <- 2
} else if(singlet=="t3"){
  timeval <-3
} else if(singlet=="multiple"){
  if(data.type=="newcure"){
    timeval <- c(65,75,85)
  } else{
    timeval <- c(1.5,2.5,3.5)
  }
}
  

if(hyptest==FALSE & power.compute==FALSE){
  ## standard simulation study
  if(realdata==FALSE){
    ## simulated data

    ## Types of estimators used
    useOLS <- FALSE
    useWLS <- FALSE
    useEFF <- TRUE
    useNPMLEs <- TRUE
    useGENMIX <- TRUE
    
    ##useEFF <- FALSE
    ##useNPMLEs <- FALSE
    ##useGENMIX <- TRUE

    ## Number of simulations
    nsimu <- 500
    ##nsimu <- 2  ## for testing!!
  } else {
    ## real data

    ## Types of estimators used
    useOLS <- FALSE
    useWLS <- FALSE
    useEFF <- FALSE
    useNPMLEs <- TRUE
    useGENMIX <- TRUE
    ##useGENMIX <- FALSE

    ## Number of simulations
    nsimu <- 1
  }
    
  if(fullrange==FALSE){
    ## Evaluate at a single point
    bootvar <- TRUE  ## do bootstrap variance
    boot <- 100
  }
  
  if(fullrange==TRUE){
    ## Evaluate over a range of time points
    bootvar <- FALSE
    
    if(realdata==TRUE){
      ## Change 11/27/2013
      boot.ci <- TRUE
      boot <- 100
      ##boot <- 10
    }

    if(data.type=="newcure" | data.type=="pene"){
      timeval <- seq(2,100,by=2)
    } else if(data.type=="realcarrier" | data.type=="realdeletion" | data.type=="realAB" |
              data.type=="misscarrier"){
      timeval <- seq(1,100,by=1)
      ##timeval <- c(50,51) ## For testing
    } else {
      timeval <- seq(0.2,10,by=0.2)
      ##timeval <- seq(0.5,10,by=0.5) ## for testing!!
    }
  } 
  
} else if(hyptest==TRUE){
  ## Hypothesis testing
  
  if(realdata==FALSE){
    ## Simulated data

    ## Types of estimator used
    useOLS <- FALSE
    useWLS <- FALSE
    useEFF <- TRUE
    useNPMLEs <- TRUE
    useGENMIX <- TRU
    nsimu <- 200
  } else {
    ## Real data

    ## Types of estimator used
    useOLS <- FALSE
    useWLS <- FALSE
    useEFF <- FALSE
    useNPMLEs <- TRUE
    useGENMIX <- TRUE
    ##useGENMIX <- FALSE
    nsimu <- 1
  }

  bootvar <- FALSE
  

  ## number of permuations
  if(data.type=="pene"){
    nperm <- 500
    ##nperm <-2  ## testing
  } else {
    nperm <- 1000
    ##nperm <-2  ## testing
  }
  
  if(fullrange==TRUE){
    if(data.type=="newcure" | data.type=="pene"){
      timeval <- seq(5,100,by=5)
    } else if(data.type=="realcarrier"| data.type=="realdeletion" | data.type=="realAB" | data.type=="misscarrier"){
      ##timeval <- seq(20,80,by=2)
      timeval <- seq(20,70,by=2)
    } else {
      timeval <- seq(0.5,10,by=0.5)
      ##timeval <- seq(0.5,10,by=0.5) ## for testing!!
    }
  }

} else if (power.compute==TRUE){
  bootvar <- FALSE
  ##nsimu <- 250
  nsimu <-2

  ## number of replicates for power
  ##npow <- 100
  npow <-2  ## testing
}


## number of time points
numt <- length(timeval)

## data
if(realdata==FALSE){
  data <- NULL
}

## estimators to show point estimates and 95\% CI
est.interest <- c("type I NPMLE","EMPAVA")
##ages.interest <- seq(20,80,by=5)
ages.interest <- seq(20,70,by=5)


## set up parameters for fortran 90 program
storage.mode(iseed) <- "integer"
storage.mode(n) <- "integer"
storage.mode(p) <- "integer"
storage.mode(m) <- "integer"
storage.mode(bootvar) <- "logical"
storage.mode(boot) <- "integer"
storage.mode(fullrange) <- "logical"
storage.mode(numt) <- "integer"
storage.mode(timeval) <- "double"
storage.mode(censorrate) <- "integer"
storage.mode(usetruth) <- "logical"
storage.mode(useOLS) <- "logical"
storage.mode(useWLS) <- "logical"
storage.mode(useEFF) <- "logical"
storage.mode(useNPMLEs) <- "logical"
storage.mode(H0) <- "logical"
storage.mode(d) <- "double"
storage.mode(alpha.values) <- "double"
storage.mode(dval) <- "double"
storage.mode(setting) <- "character"

## name of file for storing
file_name <- paste("results_",setting,"_censor_",censorrate,"_fullrange_",
                   fullrange,"_singlet_",singlet,"_H0_",H0,".dat",
                   sep="")



##file_name <- "mytest"

## names of estimators
estimator.names <- c("OLSIPW","OLSAIPW","OLSIMP",
                     "WLSIPW","WLSAIPW","WLSIMP",
                     "EFFIPW","EFFAIPW","EFFIMP",
                     "type I NPMLE","type II NPMLE","EMPAVA",
                     "TRUTH")


## ages of interest for Residual Life Table
ages <- c(40,50,60)
future.ages <- c(10,20,30,35)
survival <- FALSE
   
## colors
col1 <- "red"
col2 <- "blue"
##col1 <- "black"
##col2 <- "black"
