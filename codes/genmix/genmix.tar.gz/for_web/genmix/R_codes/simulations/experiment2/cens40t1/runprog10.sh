#!/bin/bash 

for i in {46..50}
do
    Rscript play $i > 'out'$i.'Rout'&
done
