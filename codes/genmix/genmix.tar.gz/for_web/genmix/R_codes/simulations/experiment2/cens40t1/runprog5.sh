#!/bin/bash 

for i in {21..25}
do
    Rscript play $i > 'out'$i.'Rout'&
done
