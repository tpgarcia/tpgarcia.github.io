#!/bin/bash 

for i in {38..40}
do
    Rscript play $i > 'out'$i.'Rout'&
done
