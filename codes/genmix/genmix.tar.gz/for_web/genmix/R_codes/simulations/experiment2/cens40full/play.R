## Important!!: must load and unload kincohortsimu.so, otherwise
##   code doesn't run.
## We have *.so file just for testing .f90 code. Eventually, we will put it in a library.


#################
## Source file ##
#################

source("../../../main/simulation_main.R")
source("../main_settings.R")

####################
## Set parameters ##
####################

censorrate <- 40
fullrange <- TRUE



source("../../../main/simu_settings.R")


##########################
## Run simulation study ##
##########################
source("../../../main/call_simulation.R")


