#!/bin/bash 

for i in {30..33}
do
    Rscript play $i > 'out'$i.'Rout'&
done
