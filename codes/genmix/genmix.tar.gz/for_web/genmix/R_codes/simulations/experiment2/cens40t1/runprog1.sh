#!/bin/bash 

for i in {1..5}
do
    Rscript play $i > 'out'$i.'Rout'&
done
