#!/bin/bash 

for i in {41..45}
do
    Rscript play $i > 'out'$i.'Rout'&
done
