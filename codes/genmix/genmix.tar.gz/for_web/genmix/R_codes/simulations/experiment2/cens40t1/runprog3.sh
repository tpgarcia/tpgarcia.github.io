#!/bin/bash 

for i in {11..15}
do
    Rscript play $i > 'out'$i.'Rout'&
done
