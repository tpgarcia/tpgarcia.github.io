#!/bin/bash 

for i in {31..35}
do
    Rscript play $i > 'out'$i.'Rout'&
done
