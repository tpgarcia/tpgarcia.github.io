% Load data set
load mydata.dat; a1=mydata;


% Get true Ft values and number of estimators
trueFt1=a1(1,4);
trueFt2=a1(1,5);
num=a1(1,3);

% Organize data so that we only take from entries 2 on
a1=a1(2:end,:);


% Put all simulation sets together
a=a1;


% Remove NANs
a(any(isnan(a),2),:) = [];

% Get estimatesd Ft(1) and Ft(2)
Ft1=a(1:2:end,1:num);
Ft2=a(2:2:end,1:num);
%ind=(Ft2(:,5)>-50);
%Ft1=Ft1(ind,:);
%  Ft2=Ft2(ind,:);
Ft=[Ft1 Ft2];

% Repeat true Ft(1) and Ft(2) num many times
Ft10=repmat(trueFt1,1,num);
Ft20=repmat(trueFt2,1,num);
Ft0=[Ft10 Ft20];

% Get variances
vFt1=a(1:2:end,(num+1):2:end);
vFt2=a(2:2:end,(num+2):2:end);
%%vFt1=vFt1(ind,:);
%%vFt2=vFt2(ind,:);
v=[vFt1 vFt2];

n=length(Ft)
format short 
D=[
mean(Ft)-Ft0
 %   median(Ft)-Ft0
    std(Ft)
    mean(sqrt(v))
%    median(sqrt(v))
 sum(normcdf(abs(Ft-ones(n,1)*Ft0)./sqrt(v))<0.975)/n
 
   ];

transpose(D)
trueFt1
trueFt2
