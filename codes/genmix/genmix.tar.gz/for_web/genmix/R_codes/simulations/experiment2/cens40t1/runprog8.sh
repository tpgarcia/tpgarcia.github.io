#!/bin/bash 

for i in {36..40}
do
    Rscript play $i > 'out'$i.'Rout'&
done
