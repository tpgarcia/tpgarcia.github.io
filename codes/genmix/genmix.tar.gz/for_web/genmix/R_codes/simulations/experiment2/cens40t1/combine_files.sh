#!/bin/bash 

##rm -r *.Rout

cat *seed*.dat > mydata.dat

##cat *seed_1234* > mydata.dat

##for i in {2..36}
##do
##    cat *seed_$i*>> mydata.dat
##done
