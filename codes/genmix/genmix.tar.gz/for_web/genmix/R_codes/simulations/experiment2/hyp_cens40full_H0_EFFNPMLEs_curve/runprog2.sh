#!/bin/bash 

for i in {26..29}
do
    Rscript play $i > 'out'$i.'Rout'&
done
