#!/bin/bash 

for i in {34..37}
do
    Rscript play $i > 'out'$i.'Rout'&
done
