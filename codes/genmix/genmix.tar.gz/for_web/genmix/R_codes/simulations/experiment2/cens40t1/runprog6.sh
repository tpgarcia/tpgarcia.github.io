#!/bin/bash 

for i in {26..30}
do
    Rscript play $i > 'out'$i.'Rout'&
done
