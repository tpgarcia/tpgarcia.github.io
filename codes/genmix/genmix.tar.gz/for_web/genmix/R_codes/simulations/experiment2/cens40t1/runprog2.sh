#!/bin/bash 

for i in {6..10}
do
    Rscript play $i > 'out'$i.'Rout'&
done
