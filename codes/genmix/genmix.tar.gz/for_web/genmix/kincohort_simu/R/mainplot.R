mainplot <- function(F,se.est,est.index,title,plot.ci=TRUE,plot.cdf=TRUE,
                     ylab="F(t)",xlab="time"){
  p <-  dim(F)[2]
  
  if(plot.cdf==TRUE){
    F.plot <- F
    S.lo<- F+qnorm(0.025)*se.est
    S.hi <- F+qnorm(0.975)*se.est
    ylab="F(t)"
          }else{
            F.plot <- 1-F
            S.lo<- (1-F)+qnorm(0.025)*se.est
            S.hi <- (1-F)+qnorm(0.975)*se.est
            ylab="S(t)"
          }
  
  
  time <- as.numeric(dimnames(F)[[1]])
  y <- c(-0.2,1.2)
  plot(range(time),y,type="n",xlab=xlab,ylab=ylab,main=title)
  
  
  for(i in 1:p){
    lines(time,F.plot[,i,est.index],lty=1,col=i)
    if(plot.ci==TRUE){
      lines(time,S.lo[,i,est.index],lty=2,col=i)
      lines(time,S.hi[,i,est.index],lty=2,col=i)
    }
  }
  legend("bottomleft",paste("F",1:p,sep=""),lty=rep(1,p),col=1:p,
         bty="n")
}

