.First.lib <- function(lib,pkg)
  {
       library.dynam("kincohortsimu",pkg,lib)
          cat("kinchortsimu 0.1-1 loaded\n")
     }

