adjustfest <- function(f.est){
  F <- f.est
  p <- dim(F)[2]
  num_est <- dim(F)[3] # number of estimators
  num_time <- dim(F)[1]   # number of time points
  
  for(j in 1:num_est){
    for(i in 1:p){
      tmp <- min(F[2:num_time,i,j]-F[1:(num_time-1),i,j])
      k <- match(tmp,F[2:num_time,i,j]-F[1:(num_time-1),i,j])
      while(tmp<0){
        F[k,i,j]=(F[k+1,i,j]+F[k,i,j])/2
        F[k+1,i,j]=F[k,i,j]
        tmp <- min(F[2:num_time,i,j]-F[1:(num_time-1),i,j])
        k <- match(tmp,(F[2:num_time,i,j]-F[1:(num_time-1),i,j]))
      }
    }
  }
  return(F)
}

