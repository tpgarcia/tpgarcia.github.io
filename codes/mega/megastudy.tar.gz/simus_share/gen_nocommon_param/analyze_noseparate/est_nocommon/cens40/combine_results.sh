#!/bin/bash

cat out_truth*iseed_1.dat > out_truth.dat
cat out_count*iseed* > out_count.dat
cat out_alphasest*iseed* > out_alphasest.dat
cat out_alphasvar*iseed* > out_alphasest_var.dat
cat out_alphasdiff*iseed* > out_alphasest_diff.dat
cat out_Ftest*iseed* > out_Ftest.dat
cat out_Ftvar*iseed* > out_Ftest_var.dat
cat out_Ftdiff*iseed* > out_Ftest_diff.dat
cat out_betaest*iseed* > out_betaest.dat
cat out_betavar*iseed* > out_betaest_var.dat
cat out_betadiff*iseed* > out_betaest_diff.dat

cat out_gammaest*iseed* > out_gammaest.dat
cat out_gammavar*iseed* > out_gammaest_var.dat
cat out_gammadiff*iseed* > out_gammaest_diff.dat

cat out_omegaest*iseed* > out_omegaest.dat
cat out_omegavar*iseed* > out_omegaest_var.dat
cat out_omegadiff*iseed* > out_omegaest_diff.dat

cat printout*.Rout > out_print.dat


#cat out_alphasijest*iseed* > out_alphasijest.dat
#cat out_alphasijvar*iseed* > out_alphasijest_var.dat
#cat out_Ftijest*iseed* > out_Ftijest.dat
#cat out_Ftijvar*iseed* > out_Ftijest_var.dat

rm -rf *iseed*.dat 
rm -rf printout*.Rout
