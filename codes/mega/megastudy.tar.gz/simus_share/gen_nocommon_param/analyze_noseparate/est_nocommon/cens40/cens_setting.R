censorrate <- rep(30,num_study)  ## actually it is 40, check output
