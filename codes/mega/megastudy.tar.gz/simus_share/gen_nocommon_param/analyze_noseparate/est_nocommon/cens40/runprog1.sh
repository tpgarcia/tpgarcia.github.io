#!/bin/bash 

for i in {1..1}
do
    Rscript runsimu $i > 'printout'$i.'Rout'&
done
