##################
## Source codes ##
##################
source("../../../../../codes/R_codes/simulation_main.R")
source("../../../../../codes/R_codes/main.R")
dyn.load("../../../../../codes/f90_codes/cohortmix.so")


###############################
## get particular parameters ##
###############################
source("../../../../method_setting.R")
source("../../../data_setting.R")
source("../../estimation_setting.R")
source("../analyze_setting.R")
source("cens_setting.R")



##########################
## Set other parameters ##
##########################
source("../../../../../codes/R_codes/simu_settings.R")


###########################
## call simulation study ##
###########################
##source("../../../../../codes/R_codes/call_simulation.R")

##################
## call results ##
##################
source("../../../../../codes/R_codes/call_results.R")
source("../../../../../codes/R_codes/get_results.R")



#########################
## unload cohortmix.so ##
#########################
dyn.unload("../../../../../codes/f90_codes/cohortmix.so")
