common.param.estimation <- FALSE
