#!/bin/bash 

for i in {1..2}
do
    Rscript runsimu $i > 'printout'$i.'Rout'&
done
