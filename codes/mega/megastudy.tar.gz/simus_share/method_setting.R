method <- "gamm4"
real_data <- FALSE
num_study <- 2
frform <- "norm"
