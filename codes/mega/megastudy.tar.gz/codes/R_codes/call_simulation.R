simu.out <- simulation.study(method=method,
			     a0=a0,
			     iseed=iseed,
                             simus=simus,
                             m0_qvs=m0_qvs,
                             xks=xks,
                             frform=frform,
                             fzrform=fzrform,
                             fxform=fxform,
			     type_fr=type_fr,
			     type_fzr=type_fzr,
			     type_fx=type_fx,
			     par1_fr=par1_fr,
			     par2_fr=par2_fr,
			     par_fu=par_fu,
			     par1_fr2=par1_fr2,
			     par2_fr2=par2_fr2,
                             mix_n=mix_n,
			     par1_fzr=par1_fzr,
			     par2_fzr=par2_fzr,
			     par1_fx=par1_fx,
			     par2_fx=par2_fx,
                             axmod=axmod,
                             num_time=num_time,
                             censorrate=censorrate,
                             p=p,
			     beta0int=beta0int,
                             beta0=beta0,
			     gamma.param=gamma.param,
			     omega.param=omega.param,
                             n=n,
                             m=m,
                             la=la,
                             real_data=real_data,
                             boot=boot,
			     z_tmp.list=z_tmp.list,
                             x_tmp.list=x_tmp.list,
                             delta_tmp.list=delta_tmp.list,
                             s_tmp.list=s_tmp.list,
			     knot.length=knot.length,
			     randomeffects.covariates.dependent=randomeffects.covariates.dependent,
			     family.data=family.data,
			     num_study=num_study,
			     np=np,
			     lb=lb,
			     lb.max=lb.max,
			     zeval=zeval,
			     z.choice=z.choice,
			     spline.constrain=spline.constrain,
			     gtmod=gtmod,
			     use.random.effects=use.random.effects,
			     analyze.separately=analyze.separately,
			     check.study.equality=check.study.equality,
			     common.param.estimation=common.param.estimation,
			     param.label=param.label
)

##################
## Write output ##
##################
write.table(simu.out$truth.out,paste("out_truth_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$beta.out,
     paste("out_betaest_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$beta.var.out,
     paste("out_betavar_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$beta.diff.out,
     paste("out_betadiff_",filename,sep=""),col.names=FALSE,row.names=FALSE)


write.table(simu.out$gamma.out,
     paste("out_gammaest_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$gamma.var.out,
     paste("out_gammavar_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$gamma.diff.out,
     paste("out_gammadiff_",filename,sep=""),col.names=FALSE,row.names=FALSE)


write.table(simu.out$omega.out,
     paste("out_omegaest_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$omega.var.out,
     paste("out_omegavar_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$omega.diff.out,
     paste("out_omegadiff_",filename,sep=""),col.names=FALSE,row.names=FALSE)


write.table(simu.out$alphas.out,
     paste("out_alphasest_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$alphas.var.out,
     paste("out_alphasvar_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$alphas.diff.out,
     paste("out_alphasdiff_",filename,sep=""),col.names=FALSE,row.names=FALSE)

write.table(simu.out$Ft.out,
     paste("out_Ftest_",filename,sep=""),col.names=FALSE,row.names=FALSE,na="0")

write.table(simu.out$Ft.var.out,
     paste("out_Ftvar_",filename,sep=""),col.names=FALSE,row.names=FALSE,na="0")

write.table(simu.out$Ft.diff.out,
     paste("out_Ftdiff_",filename,sep=""),col.names=FALSE,row.names=FALSE,na="0")


write.table(simu.out$count.store,
   paste("out_count_",filename,sep=""),col.names=FALSE,row.names=FALSE,na="0")


## for testing
##real_data <- TRUE
##if(real_data==TRUE){

if(1==0){
  write.table(simu.out$alphasij.out,
     paste("out_alphasijest_",filename,sep=""),col.names=FALSE,row.names=FALSE)

  write.table(simu.out$alphasij.var.out,
     paste("out_alphasijvar_",filename,sep=""),col.names=FALSE,row.names=FALSE)

  write.table(simu.out$Ftij.out,
     paste("out_Ftijest_",filename,sep=""),col.names=FALSE,row.names=FALSE,na="0")

  write.table(simu.out$Ftij.var.out,
     paste("out_Ftijvar_",filename,sep=""),col.names=FALSE,row.names=FALSE,na="0")
}


#########################
## unload cohortmix.so ##
#########################
##dyn.unload("../../../../../codes/f90_codes/cohortmix.so")
