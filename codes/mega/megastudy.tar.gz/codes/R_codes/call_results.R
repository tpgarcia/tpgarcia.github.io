################
## File names ##
################

filename_beta <- paste("beta",sep="")
filename_gamma <- paste("gamma",sep="")
filename_omega <- paste("omega",sep="")
filename_alpha <- paste("alpha",sep="")
filename_Ft <- paste("Ft",sep="")
filename_alphaij <- paste("alphaij",sep="")
filename_Ftij <- paste("Ftij",sep="")

if(common.param.estimation==TRUE){
  filename_beta <- paste("j",filename_beta,sep="")
  filename_gamma <- paste("j",filename_gamma,sep="")
  filename_omega <- paste("j",filename_omega,sep="")
  filename_alpha <- paste("j",filename_alpha,sep="")
  filename_Ft <- paste("j",filename_Ft,sep="")
  filename_alphaij <- paste("j",filename_alphaij,sep="")
  filename_Ftij <- paste("j",filename_Ftij,sep="")
}

#if(analyze.separately==TRUE){
#  filename_beta <- paste("n",filename_beta,sep="")
#  filename_gamma <- paste("n",filename_gamma,sep="")
#  filename_omega <- paste("n",filename_omega,sep="")
#  filename_alpha <- paste("n",filename_alpha,sep="")
#  filename_Ft <- paste("n",filename_Ft,sep="")
#  filename_alphaij <- paste("n",filename_alphaij,sep="")
#  filename_Ftij <- paste("n",filename_Ftij,sep="")
#}

if(real_data==FALSE){
 if(randomeffects.covariates.dependent==TRUE){
   filename_beta <- paste("dep_",filename_beta,sep="")
   filename_gamma <- paste("dep_",filename_gamma,sep="")
   filename_omega <- paste("dep_",filename_omega,sep="")
   filename_alpha <- paste("dep_",filename_alpha,sep="")
   filename_Ft <- paste("dep_",filename_Ft,sep="")
 }

 if(family.data==TRUE){
   filename_beta <- paste("fam_",filename_beta,sep="")
   filename_gamma <- paste("fam_",filename_gamma,sep="")
   filename_omega <- paste("fam_",filename_omega,sep="")
   filename_alpha <- paste("fam_",filename_alpha,sep="")
   filename_Ft <- paste("fam_",filename_Ft,sep="")
 }
}
  
###############
## Load data ##
###############
data.truth <- read.table("out_truth.dat",header=FALSE)

data.alpha <- read.table("out_alphasest.dat",header=FALSE)
data.alpha.varboot <- read.table("out_alphasest_var.dat",header=FALSE)

if(num_study > 1){
  data.alpha.diff <- read.table("out_alphasest_diff.dat",header=FALSE)
} else {
  data.alpha.diff <- NULL
}


data.beta <- read.table("out_betaest.dat",header=FALSE)
data.beta.varboot <- read.table("out_betaest_var.dat",header=FALSE)

if(num_study > 1){
  data.beta.diff <- read.table("out_betaest_diff.dat",header=FALSE)
} else {
  data.beta.diff <- NULL
} 

if(!is.null(gamma.param)){
  data.gamma <- read.table("out_gammaest.dat",header=FALSE)
  data.gamma.varboot <- read.table("out_gammaest_var.dat",header=FALSE)

  if(num_study > 1){
    data.gamma.diff <- read.table("out_gammaest_diff.dat",header=FALSE)
  } else {
    data.gamma.diff <- NULL
  }
} else{
  data.gamma <- NULL
  data.gamma.varboot <- NULL
  data.gamma.diff <- NULL
}

if(!is.null(omega.param)){
  data.omega <- read.table("out_omegaest.dat",header=FALSE)
  data.omega.varboot <- read.table("out_omegaest_var.dat",header=FALSE)

  if(num_study > 1){
    data.omega.diff <- read.table("out_omegaest_diff.dat",header=FALSE)
  } else {
    data.omega.diff <- NULL
  }
} else {
  data.omega <- NULL
  data.omega.varboot <- NULL
  data.omega.diff <- NULL
}

data.Ft <- read.table("out_Ftest.dat",header=FALSE)
data.Ft.varboot <- read.table("out_Ftest_var.dat",header=FALSE)

if(num_study > 1){
  data.Ft.diff <- read.table("out_Ftest_diff.dat",header=FALSE)
} else {
  data.Ft.diff <- NULL
}


## for testing
##real_data <- TRUE
#if(real_data==TRUE){
if(1==0){
  data.alphaij <- read.table("out_alphasijest.dat",header=FALSE)
  data.alphaij.varboot <- read.table("out_alphasijest_var.dat",header=FALSE)

  data.Ftij <- read.table("out_Ftijest.dat",header=FALSE)
  data.Ftij.varboot <- read.table("out_Ftijest_var.dat",header=FALSE)
} else {
  data.alphaij <- NULL
  data.alphaij.varboot <- NULL
  data.Ftij <- NULL
  data.Ftij.varboot <- NULL
}


##if(1==0){ ## for testing
data.count <- read.table("out_count.dat",header=FALSE)
#}

#################
## get results ##
#################
##source("../../../../../codes/R_codes/get_results.R")
