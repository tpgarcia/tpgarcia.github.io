########################
## Clear out history ##
#######################
rm(list=ls(all=TRUE))

###########################
## main simulation study ##
###########################
simulation.study <- function(method=c("gamm4","new")[1],
			     a0,	
			     iseed,
			     simus,
			     m0_qvs,
			     xks,
			     frform,
			     fzrform,
			     fxform,
			     type_fr,
			     type_fzr,
			     type_fx,
			     par1_fr,
			     par2_fr,
			     par_fu,
			     par1_fr2,
			     par2_fr2,
			     mix_n,
			     par1_fzr,
			     par2_fzr,
			     par1_fx,
			     par2_fx,
			     axmod,
			     num_time,
			     censorrate,
			     p,
			     beta0int,
			     beta0,
			     gamma.param,	
			     omega.param,
			     n,
			     m,
			     la,
			     real_data,
			     time_val_final,
			     boot,
			     z_tmp.list,
			     x_tmp.list,
			     delta_tmp.list,
			     s_tmp.list,
			     knot.length,
			     randomeffects.covariates.dependent,
			     family.data,
			     num_study=num_study,
			     np=np,
			     lb=lb,
			     lb.max=lb.max,
			     zeval=zeval,
			     z.choice=z.choice,
			     spline.constrain=spline.constrain,
			     gtmod=gtmod,
			     use.random.effects=use.random.effects,
			     analyze.separately=analyze.separately,
			     check.study.equality=check.study.equality,
			     common.param.estimation=common.param.estimation,
			     param.label
			     ){
			     
  ###############
  ## set terms ##
  ###############
  num_time <- length(time_val)
  num_xx <- max(unlist(lapply(xks,length.apply)))
  maxm <- max(m)
  nmax <- max(n)
  
  if(num_study > 1){
    ## used to get all combinations to compare equality of studies.
    combi.study <- factorial(num_study) / 
  	      	 		(factorial(num_study-2)*factorial(2))
    combi.choice <- combn(1:num_study,2)
    combi.names <- apply(combi.choice,2,
  	      function(x) paste(x,collapse=""))
  } else {
    ## no comparisons between studies made if num_study=1
    combi.study <- NULL
    combi.choice <- NULL
    combi.names <- NULL
  }

  betaest.store <- array(0,dim=c(simus,num_study,np,length(time_val),
  		length(param.label)),
                         dimnames=list(paste("iter",1:simus,sep=""),
			   paste("ss",1:num_study,sep=""),
                           paste("np",1:np,sep=""),
			   paste("t",time_val,sep=""),
                           param.label))
  betaest.var.store <- betaest.store


  if(num_study > 1){
    betabootci.store <- array(0,dim=c(simus,combi.study,np,
  		   length(time_val),length(param.label),3),
                         dimnames=list(paste("iter",1:simus,sep=""),
		   combi.names,
		   paste("np",1:np,sep=""),
                   paste("t",time_val,sep=""),
                   param.label,c("est","lo","hi")))
  } else {
    betabootci.store <- NULL
  }
   
  alphasest.store <- array(0,dim=c(simus,num_study,np,num_xx,
  		  length(time_val),la),
                           dimnames=list(paste("iter",1:simus,sep=""),
			     paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
			     paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             paste("la",1:la,sep="")))
  alphasest.var.store <- alphasest.store

  if(num_study > 1){
    alphasbootci.store <- array(0,dim=c(simus,combi.study,np,num_xx,
  		     length(time_val),la,3),
                           dimnames=list(paste("iter",1:simus,sep=""),
			     combi.names,
                             paste("np",1:np,sep=""),
			     paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             paste("la",1:la,sep=""),c("est","lo","hi")))
  } else {
    alphasbootci.store <- NULL
  }

  Ftest.store <- array(0,dim=c(simus,num_study,np,z.choice,num_xx,
  	      length(time_val)),
                           dimnames=list(paste("iter",1:simus,sep=""),
       			     paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
			     paste("zz",1:z.choice),
			     paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep="")))

  Ftest.var.store <- Ftest.store

  if(num_study > 1){
    Ftbootci.store <- array(0,dim=c(simus,combi.study,np,z.choice,
  		 num_xx,length(time_val),3),
                           dimnames=list(paste("iter",1:simus,sep=""),
			     combi.names,
                             paste("np",1:np,sep=""),
			     paste("zz",1:z.choice),
			     paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             c("est","lo","hi")))
  } else {
    Ftbootci.store <- NULL
  }

  alphasijest.store <- NULL
#  alphasijest.store <- array(0,dim=c(num_study,np,nmax,length(time_val),la),
#                           dimnames=list(
#    			     paste("ss",1:num_study,sep=""),
#                             paste("np",1:np,sep=""),
#			     paste("nn",1:nmax,sep=""),
#                             paste("t",time_val,sep=""),
#                             paste("la",1:la,sep="")))

  alphasijest.var.store <- NULL
#  alphasijest.var.store <- alphasijest.store

   alphasijbootci.store <- NULL
#  alphasijbootci.store <- array(0,dim=c(num_study,np,nmax,length(time_val),la,2),
#                           dimnames=list(
#  			     paste("ss",1:num_study,sep=""),
#                             paste("np",1:np,sep=""),
#			     paste("nn",1:nmax,sep=""),
#			     paste("t",time_val,sep=""),
#                             paste("la",1:la,sep=""),c("lo","hi")))
#
  Ftijest.store <- NULL
#  Ftijest.store <- array(0,dim=c(num_study,np,nmax,length(time_val)),
#                           dimnames=list(
#			     paste("ss",1:num_study,sep=""),
#                             paste("np",1:np,sep=""),
#			     paste("nn",1:nmax,sep=""),
#                             paste("t",time_val,sep="")))
#

  Ftijest.var.store <- NULL
#  Ftijest.var.store <- Ftijest.store

  Ftijbootci.store <- NULL
#  Ftijbootci.store <- array(0,dim=c(num_study,np,nmax,length(time_val),2),
#                           dimnames=list(
#			     paste("ss",1:num_study,sep=""),
#                             paste("np",1:np,sep=""),
#			     paste("nn",1:nmax,sep=""),
#			     paste("t",time_val,sep=""),
#                             c("lo","hi")))

  count.store <- NULL

  #####################
  ## get true values ##
  #####################
  ## sigmar may need EDITING if I change the way par2_fr,par_fu is formed.
  truth <- get.truth(combi.study,combi.choice,combi.names,
        real_data,num_study,np,lb,num_time,
        param.label,beta0int,beta0,gamma.param,omega.param,time_val,num_xx,a0,axmod,
        la,xks,zeval,z.choice,sigmar=par2_fr[1],sigmau=par_fu["sd"],
        gtmod,
        use.random.effects)

  betadiff.store <- truth$beta.diff
  alphasdiff.store <- truth$alphas.diff
  Ftdiff.store <- truth$Ft.diff


  ##############
  ## set seed ##
  ##############
  set.seed(iseed)
  print(paste("iseed=",iseed,sep=""))


  iters <-1
  ##iters <-10  ## for testing   
  while(iters <= simus){
    ########################
    ## get simulated data ##
    ########################
    data <- simu.data(randomeffects.covariates.dependent,z_tmp.list,x_tmp.list,
		      delta_tmp.list,s_tmp.list,
                      a0,axmod,num_time,censorrate,
		      frform,fzrform,fxform,
		      type_fr,type_fzr,type_fx,
		      par1_fr,par2_fr,
		      par_fu,
		      par1_fr2,par2_fr2,mix_n,
		      par1_fx,par2_fx,
		      par1_fzr,par2_fzr,
                      real_data,time_val,
                      p,beta0int,beta0,gamma.param,omega.param,
		      n,nmax,m,maxm,la,lb,num_study,
		      np,gtmod,use.random.effects)
   #}		      

    ## for testing
    ##real_data <- TRUE  

    if(method=="gamm4"){
	gamm4.est <- gamm4.estimates(num_study,np,
			count.store,data,num_time,
			time_val,p,n,nmax,m,maxm,
			la,lb,lb.max,xks,truth,m0_qvs,
			num_xx,knot.length,real_data,
			family.data,
			zeval,z.choice,
			param.label,beta0int,gamma.param,omega.param,
			spline.constrain,
			common.param.estimation,par_fu,analyze.separately)
	eflag <- gamm4.est$eflag

	if(eflag!=-1){
  	  ###################
     	  ## store results ##
      	  ###################
     	  betaest.store[iters,,,,] <- gamm4.est$betaest
      	  betaest.var.store[iters,,,,] <- gamm4.est$betavar
      	  alphasest.store[iters,,,,,] <- gamm4.est$alphasest
      	  alphasest.var.store[iters,,,,,] <- gamm4.est$alphasvar
	  Ftest.store[iters,,,,,] <- gamm4.est$Ftest
	  Ftest.var.store[iters,,,,,] <- gamm4.est$Ftvar

	  #if(1==0){  ## for testing only!
	  if(common.param.estimation==FALSE & check.study.equality==TRUE & num_study>1){ ## assumes no common alpha, beta across studies in estimation
  	    my.boot <- boot.compare.studies(combi.study,combi.choice,combi.names,
		num_study,boot,np,data,num_xx,num_time,time_val,
		xks,p,n,nmax,m,
		maxm,la,lb,lb.max,a0,axmod,axmod2,truth,real_data,m0_qvs,
		knot.length,
		family.data,zeval,z.choice,
		param.label,beta0int,gamma.param,omega.param,
		spline.constrain,common.param.estimation,par_fu,analyze.separately)

	    betabootci.store[iters,,,,,] <- my.boot$betabootci
	    alphasbootci.store[iters,,,,,,] <- my.boot$alphasbootci
	    Ftbootci.store[iters,,,,,,] <- my.boot$Ftbootci
	  }

	  count.store <- gamm4.est$count.store
	  iters <- iters + 1
	}
    } 
  }

#############################
  ## write data for output ##
###########################
  num_b0 <- 0
  num_bgamma <- 0
  num_bomega <- 0
  if(!is.null(beta0int)){
    num_b0 <- num_b0 + 1
  }

  if(!is.null(gamma.param)){
    num_bgamma <- num_bgamma + 1
  }

  if(!is.null(omega.param)){
    num_bomega <- num_bomega + 1
  }

  truth.out <- array(0,dim=c(1 + 
  	    num_study*np*(num_b0+num_bgamma+num_bomega+lb.max+num_xx+z.choice*num_xx),
					5+length(time_val)))
	
  beta.out <- array(0,dim=c(num_study*np*((num_b0+lb.max)*simus),
  	   4+length(time_val)))

  gamma.out <- array(0,dim=c(num_study*np*((num_bgamma)*simus),
  	   4+length(time_val)))

  omega.out <- array(0,dim=c(num_study*np*((num_bomega)*simus),
  	   4+length(time_val)))

  alphas.out <- array(0,dim=c(num_study*np*(num_xx*(simus)),
  	     4+length(time_val)))
  Ft.out <- array(0,dim=c(num_study*np*(z.choice*num_xx*(simus)),
  	 5+length(time_val)))
  
  if(num_study>1){
    beta.diff.out <- array(0,dim=c(combi.study*np*((num_b0+lb.max)*(4*simus)),4+length(time_val)))
    gamma.diff.out <- array(0,dim=c(combi.study*np*((num_bgamma)*(4*simus)),4+length(time_val)))
    omega.diff.out <- array(0,dim=c(combi.study*np*((num_bomega)*(4*simus)),4+length(time_val)))
    alphas.diff.out <- array(0,dim=c(combi.study*np*(num_xx*(4*simus)),4+length(time_val))) 
    Ft.diff.out <- array(0,dim=c(combi.study*np*(z.choice*num_xx*(4*simus)),5+length(time_val)))
  } else {
    beta.diff.out <- NULL
    gamma.diff.out <- NULL
    omega.diff.out <- NULL
    alphas.diff.out <- NULL
    Ft.diff.out <- NULL
  }
  
  beta.var.out <- array(0,dim=c(num_study*np*((num_b0+lb.max)*
  	       (3*simus)),4+length(time_val)))
  gamma.var.out <- array(0,dim=c(num_study*np*((num_bgamma)*
  	       (3*simus)),4+length(time_val)))
  omega.var.out <- array(0,dim=c(num_study*np*((num_bomega)*
  	       (3*simus)),4+length(time_val)))
  alphas.var.out <- array(0,dim=c(num_study*np*num_xx*(3*simus),
  		 4+length(time_val)))
  Ft.var.out <- array(0,dim=c(num_study*np*z.choice*num_xx*(3*simus),
  	     5+length(time_val)))

  tmp <- 1
  truth.out[tmp,] <- c(0,0,"truet",0,lb.max,time_val)

  for(ss in 1:num_study){
    for (nn in 1:np){
      if(!is.null(beta0int)){
        tmp <- tmp+1
	truth.out[tmp,] <- c(ss,nn,"beta",0,0,
                        truth$beta.true[ss,nn,,"beta0"])
      }

      if(!is.null(gamma.param)){
        tmp <- tmp+1
	truth.out[tmp,] <- c(ss,nn,"gamma",0,0,
                        truth$beta.true[ss,nn,,"gamma"])
      }

      if(!is.null(omega.param)){
        tmp <- tmp+1
	truth.out[tmp,] <- c(ss,nn,"omega",0,0,
                        truth$beta.true[ss,nn,,"omega"])
      }

      beta_index <- lb[[ss]][[nn]]
      for(ll in 1:beta_index){
        tmp <- tmp+1
        truth.out[tmp,] <-c(ss,nn,"beta",0,ll, 
			truth$beta.true[ss,nn,,paste("beta",ll,sep="")])
      }

      for(xx in 1:length(xks[[ss]])){
        tmp <- tmp+1
        truth.out[tmp,] <- c(ss,nn,"alpha",0,xks[[ss]][xx],
			truth$alphas.true[ss,nn,xx,,])
      }

      for(zz in 1:z.choice){
        for(xx in 1:length(xks[[ss]])){
          tmp <- tmp + 1
	  truth.out[tmp,] <- c(ss,nn,"Ft",zz,xks[[ss]][xx],
	  		  truth$Ft.true[ss,nn,zz,xx,])
        }
      }
    }
  }

  tmp <-0
  tmp_var <- 0

  tmpg <- 0
  tmpg_var <- 0

  tmpo <- 0
  tmpo_var <- 0

  tmpa <- 0
  tmpa_var <-0
  tmpF <- 0
  tmpF_var <-0

  for(ss in 1:num_study){
    for(nn in 1:np){
      beta_index <- 1:lb[[ss]][[nn]]
      if(!is.null(beta0int)){
        beta_index <- c(0,beta_index)
      }
      for(ll in 1:length(beta_index)){
        for(iters in 1:simus){
          tmp <- tmp+1
      	  tmp_var <- tmp_var+1

      	  beta.out[tmp,] <- c(ss,nn,iters,ll,
	  		 betaest.store[iters,ss,nn,,paste("beta",beta_index[ll],sep="")])
      	  beta.var.out[tmp_var,] <- c(ss,nn,iters,ll,
	  			 betaest.var.store[iters,ss,nn,,paste("beta",beta_index[ll],sep="")])
      	  tmp_var <- tmp_var+1     
      	  beta.var.out[tmp_var,] <- c(ss,nn,iters,ll,
	  			 rep(0,ncol(beta.var.out)-4))
      	  tmp_var <- tmp_var+1     
      	  beta.var.out[tmp_var,] <- c(ss,nn,iters,ll,
	  			 rep(0,ncol(beta.var.out)-4))
        }
      }

      if(!is.null(gamma.param)){
        for(ll in 1:num_bgamma){
          for(iters in 1:simus){
            tmpg <- tmpg+1
            tmpg_var <- tmpg_var+1

      	    gamma.out[tmpg,] <- c(ss,nn,iters,ll,
	  		 betaest.store[iters,ss,nn,,"gamma"])
      	    gamma.var.out[tmpg_var,] <- c(ss,nn,iters,ll,
	  			 betaest.var.store[iters,ss,nn,,"gamma"])
      	    tmpg_var <- tmpg_var+1     
      	    gamma.var.out[tmpg_var,] <- c(ss,nn,iters,ll,
	  			 rep(0,ncol(beta.var.out)-4))
      	    tmpg_var <- tmpg_var+1     
      	    gamma.var.out[tmpg_var,] <- c(ss,nn,iters,ll,
	  			 rep(0,ncol(beta.var.out)-4))
          }
        }
      }

      if(!is.null(omega.param)){
        for(ll in 1:num_bomega){
          for(iters in 1:simus){
            tmpo <- tmpo+1
            tmpo_var <- tmpo_var+1

      	    omega.out[tmpo,] <- c(ss,nn,iters,ll,
	  		 betaest.store[iters,ss,nn,,"omega"])
      	    omega.var.out[tmpo_var,] <- c(ss,nn,iters,ll,
	  			 betaest.var.store[iters,ss,nn,,"omega"])
      	    tmpo_var <- tmpo_var+1     
      	    omega.var.out[tmpo_var,] <- c(ss,nn,iters,ll,
	  			 rep(0,ncol(beta.var.out)-4))
      	    tmpo_var <- tmpo_var+1     
      	    omega.var.out[tmpo_var,] <- c(ss,nn,iters,ll,
	  			 rep(0,ncol(beta.var.out)-4))
          }
        }
      }
  
      for(xx in 1:length(xks[[ss]])){
        for(iters in 1:simus){
          tmpa <- tmpa+1
      	  tmpa_var <-tmpa_var+1
      	  alphas.out[tmpa,] <- c(ss,nn,iters,xks[[ss]][xx],
	  		    alphasest.store[iters,ss,nn,xx,,])
      	  alphas.var.out[tmpa_var,] <- c(ss,nn,iters,xks[[ss]][xx],
	  			alphasest.var.store[iters,ss,nn,xx,,])
      	  tmpa_var <- tmpa_var+1
      	  alphas.var.out[tmpa_var,] <- c(ss,nn,iters,xks[[ss]][xx],
	  			    rep(0,ncol(alphas.var.out)-4))
       	  tmpa_var <- tmpa_var+1
       	  alphas.var.out[tmpa_var,] <- c(ss,nn,iters,xks[[ss]][xx],
	  			    rep(0,ncol(alphas.var.out)-4))
        }
      }

      for(zz in 1:z.choice){
        for(xx in 1:length(xks[[ss]])){
          for(iters in 1:simus){
	    tmpF <- tmpF+1
	    tmpF_var <- tmpF_var + 1
	    Ft.out[tmpF,] <- c(ss,nn,iters,zz,xks[[ss]][xx],
	    		  Ftest.store[iters,ss,nn,zz,xx,])
	    Ft.var.out[tmpF_var,] <- c(ss,nn,iters,zz,xks[[ss]][xx],
	    			  Ftest.var.store[iters,ss,nn,zz,xx,])
            tmpF_var <- tmpF_var+1
      	    Ft.var.out[tmpF_var,] <- c(ss,nn,iters,zz,xks[[ss]][xx],
	    			  rep(0,ncol(Ft.var.out)-5))
       	    tmpF_var <- tmpF_var+1
       	    Ft.var.out[tmpF_var,] <- c(ss,nn,iters,zz,xks[[ss]][xx],
	    			  rep(0,ncol(Ft.var.out)-5))
	  }
        }
      }
    }
  }

  if(num_study > 1){
    ## differences bootstrap
    tmp_var <- 0
    tmpg_var <- 0
    tmpo_var <- 0
    tmpa_var <-0
    tmpF_var <-0

    for(ss in 1:combi.study){
      for(nn in 1:np){
        beta_index <- 1:lb[[ss]][[nn]]
        if(!is.null(beta0int)){
          beta_index <- c(0,beta_index)
        }
        for(ll in 1:length(beta_index)){
          for(iters in 1:simus){
      	    tmp_var <- tmp_var+1
      	    beta.diff.out[tmp_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betadiff.store[ss,nn,,paste("beta",beta_index[ll],sep="")])

      	    tmp_var <- tmp_var+1     
      	    beta.diff.out[tmp_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,paste("beta",beta_index[ll],sep=""),
					"est"])
      	    tmp_var <- tmp_var+1     
      	    beta.diff.out[tmp_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,paste("beta",beta_index[ll],sep=""),
					"lo"])

      	    tmp_var <- tmp_var+1     
      	    beta.diff.out[tmp_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,paste("beta",beta_index[ll],sep=""),
					"hi"])
          }
        }

        if(!is.null(gamma.param)){
          for(ll in 1:num_bgamma){
            for(iters in 1:simus){
              tmpg_var <- tmpg_var+1
      	      gamma.diff.out[tmpg_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betadiff.store[ss,nn,,"gamma"])

      	      tmpg_var <- tmpg_var+1     
      	      gamma.diff.out[tmpg_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,"gamma",
					"est"])
      	      tmpg_var <- tmpg_var+1     
      	      gamma.diff.out[tmpg_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,"gamma",
					"lo"])

      	      tmpg_var <- tmpg_var+1     
      	      gamma.diff.out[tmpg_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,"gamma",
					"hi"])
            }
          }
        }

        if(!is.null(omega.param)){
          for(ll in 1:num_bomega){
            for(iters in 1:simus){
              tmpo_var <- tmpo_var+1
      	      omega.diff.out[tmpo_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betadiff.store[ss,nn,,"omega"])

      	      tmpo_var <- tmpo_var+1     
      	      omega.diff.out[tmpo_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,"omega",
					"est"])
      	      tmpo_var <- tmpo_var+1     
      	      omega.diff.out[tmpo_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,"omega",
					"lo"])

      	      tmpo_var <- tmpo_var+1     
      	      omega.diff.out[tmpo_var,] <- c(combi.names[ss],nn,iters,ll,
	  			  betabootci.store[iters,ss,nn,,"omega",
					"hi"])
            }
          }
        }
        
        for(xx in 1:length(xks[[ss]])){
          for(iters in 1:simus){
	    ##print(tmpa_var)
      	    tmpa_var <-tmpa_var+1
      	    alphas.diff.out[tmpa_var,] <- c(combi.names[ss],nn,iters,
	    xks[[ss]][xx],alphasdiff.store[ss,nn,xx,,])

      	    tmpa_var <- tmpa_var+1
      	    alphas.diff.out[tmpa_var,] <- c(combi.names[ss],nn,iters,
	      xks[[ss]][xx],alphasbootci.store[iters,ss,nn,xx,,,"est"])

       	    tmpa_var <- tmpa_var+1
      	    alphas.diff.out[tmpa_var,] <- c(combi.names[ss],nn,iters,
	      xks[[ss]][xx],alphasbootci.store[iters,ss,nn,xx,,,"lo"])

       	    tmpa_var <- tmpa_var+1
       	    alphas.diff.out[tmpa_var,] <- c(combi.names[ss],nn,iters,
	  	xks[[ss]][xx],alphasbootci.store[iters,ss,nn,xx,,,"hi"])
          }
        }

        for(zz in 1:z.choice){
          for(xx in 1:length(xks[[ss]])){
            for(iters in 1:simus){
	      tmpF_var <- tmpF_var + 1
	      Ft.diff.out[tmpF_var,] <- c(combi.names[ss],nn,iters,zz,
	        xks[[ss]][xx],Ftdiff.store[ss,nn,zz,xx,])

              tmpF_var <- tmpF_var+1
      	      Ft.diff.out[tmpF_var,] <- c(combi.names[ss],nn,iters,zz,
	        xks[[ss]][xx],Ftbootci.store[iters,ss,nn,zz,xx,,"est"])

       	      tmpF_var <- tmpF_var+1
      	      Ft.diff.out[tmpF_var,] <- c(combi.names[ss],nn,iters,zz,
	        xks[[ss]][xx],Ftbootci.store[iters,ss,nn,zz,xx,,"lo"])

       	      tmpF_var <- tmpF_var+1
       	      Ft.diff.out[tmpF_var,] <- c(combi.names[ss],nn,iters,zz,
	        xks[[ss]][xx],Ftbootci.store[iters,ss,nn,zz,xx,,"hi"])
	    }
          }
        }
      }
    }  
  }
  
#  if(real_data==TRUE){
   ## don't want this to run!!
   if(1==0){
    tmpaij <- 0
    tmpaij_var <-0
    tmpFij <- 0
    tmpFij_var <-0

    for(ss in 1:num_study){
      for(nn in 1:np){
        for(ii in 1:n[ss]){
          for(iters in 1:simus){
            tmpaij <- tmpaij + 1
	    tmpFij <- tmpFij + 1
            tmpaij_var <-tmpaij_var+1
            tmpFij_var <-tmpFij_var+1

      	    alphasij.out[tmpaij,] <- c(ss,nn,iters,ii,alphasijest.store[ss,nn,ii,,])
      	    alphasij.var.out[tmpaij_var,] <- c(ss,nn,iters,ii,alphasijest.var.store[ss,nn,ii,,])

      	    Ftij.out[tmpFij,] <- c(ss,nn,iters,ii,Ftijest.store[ss,nn,ii,])
      	    Ftij.var.out[tmpFij_var,] <- c(ss,nn,iters,ii,Ftijest.var.store[ss,nn,ii,])

      	    tmpaij_var <- tmpaij_var+1
      	    tmpFij_var <- tmpFij_var+1

      	    alphasij.var.out[tmpaij_var,] <- c(ss,nn,iters,ii,alphasijbootci.store[ss,nn,ii,,,1])
      	    Ftij.var.out[tmpFij_var,] <- c(ss,nn,iters,ii,Ftijbootci.store[ss,nn,ii,,1])

      	    tmpaij_var <- tmpaij_var+1
      	    tmpFij_var <- tmpFij_var+1
      	    alphasij.var.out[tmpaij_var,] <- c(ss,nn,iters,ii,alphasijbootci.store[ss,nn,ii,,,2])
      	    Ftij.var.out[tmpFij_var,] <- c(ss,nn,iters,ii,Ftijbootci.store[ss,nn,ii,,2])
         }
        }
      }
    }
  } 

  list(truth.out=truth.out,
       beta.out=beta.out,beta.var.out=beta.var.out,
       gamma.out=gamma.out,gamma.var.out=gamma.var.out,
       omega.out=omega.out,omega.var.out=omega.var.out,
       alphas.out=alphas.out,alphas.var.out=alphas.var.out, 
       Ft.out=Ft.out,Ft.var.out=Ft.var.out,
       count.store=count.store,
       beta.diff.out=beta.diff.out,
       gamma.diff.out=gamma.diff.out,
       omega.diff.out=omega.diff.out,
       alphas.diff.out=alphas.diff.out,
       Ft.diff.out=Ft.diff.out)#,
       #alphasij.out=alphasij.out,alphasij.var.out=alphasij.var.out, 
       #Ftij.out=Ftij.out,Ftij.var.out=Ftij.var.out)
    
}
