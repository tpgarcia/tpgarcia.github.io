#############################################
## R code to read in data and show results ##
#############################################


  ################
  ## combi info ##
  ################
if(num_study >1 ){
  combi.study <- factorial(num_study) /
                               (factorial(num_study-2)*factorial(2))
  combi.choice <- combn(1:num_study,2)
  combi.names <- apply(combi.choice,2,
              function(x) paste(x,collapse=""))
} else {
  combin.study <- NULL
  combi.choice <- NULL
  combi.names <- NULL
}




###########################################
## number of digits for printing results ##
###########################################
digits.tmp <- 3
digits.tmp.short <- 2

##################################
## beta and alpha estimate info ##
##################################

## time points
time_val <- data.truth[which(data.truth[,3]=="truet"),6:ncol(data.truth)]

## number of time points
num_time <- length(time_val)


## xx points
tmp.list <- get.empty.list(study.names)
xx_val <- tmp.list
for(ss in 1:num_study){
  xx_val[[ss]] <- unique(data.truth[which(data.truth[,1]==ss & data.truth[,3]=="alpha"),5])
}

## number of xx points
num_xx <- max(unlist(lapply(xx_val,length.apply)))


## nsimu
num_beta <- lb.max
if(!is.null(beta0int)){
  num_beta <- num_beta+1
}
nsimu <- nrow(data.beta)/(num_study*np*num_beta)

############
## counts ##
############

#if(1==0){ ## for testing
colnames(data.count) <- c("study","time","y1","y0_nocens","y0_cens","yother")
counts.array <- array(0,dim=c(nsimu,num_study,num_time,4),
                      dimnames=list(
		        paste("iter",1:nsimu,sep=""),
			paste("ss",1:num_study,sep=""),
                        paste("t",time_val,sep=""),
                        c("y1","y0_nocens","y0_cens","yother")))                

for(ss in 1:num_study){
  for(t in 1:num_time){
    index <- intersect(which(data.count$study==ss),which(data.count$time==as.numeric(time_val[t])))
    counts.array[,ss,t,] <- as.matrix(data.count[index,c("y1","y0_nocens","y0_cens","yother")])
  }
}
#}


#########################
## get needed matrices ##
#########################
my.out <- sort.results(
             num_xx=num_xx,
             num_study=num_study,
	     n=n,
	     nmax=nmax,
       	     np=np,
             lb.max=lb.max,
	     time_val=time_val,
	     xx_val=xx_val,
	     nsimu=nsimu,
             plot.nw=plot.nw,
             num_time=num_time,
             var.est= var.est,
             data.truth=data.truth,
             data.beta=data.beta,
             data.beta.varboot=data.beta.varboot,
             data.beta.diff=data.beta.diff,
	     #
             data.gamma=data.gamma,
             data.gamma.varboot=data.gamma.varboot,
             data.gamma.diff=data.gamma.diff,
	     #
             data.omega=data.omega,
             data.omega.varboot=data.omega.varboot,
             data.omega.diff=data.omega.diff,
	     #
             data.alpha=data.alpha,
             data.alpha.varboot=data.alpha.varboot,
             data.alpha.diff=data.alpha.diff,
	     data.Ft=data.Ft,
	     data.Ft.varboot=data.Ft.varboot,
	     data.Ft.diff=data.Ft.diff,
	     alpha.cut=alpha.cut,
	     beta.cut=beta.cut,
	     z.choice=z.choice,
	     z_lab=z_lab,
	     s.names=s.names,
	     beta0int=beta0int,
	     gamma.param=gamma.param,
	     omega.param=omega.param,
	     boot.ci=boot.ci,
             combi.study=combi.study,
             combi.choice=combi.choice,
             combi.names=combi.names
)

betat <- my.out$betat
gammat <- my.out$gammat
omegat <- my.out$omegat

alphat <- my.out$alphat
Ft <- my.out$Ft

#
beta.array <- my.out$beta.array
data.beta.var <- my.out$data.beta.var
data.beta.ci.lo=my.out$data.beta.ci.lo
data.beta.ci.hi=my.out$data.beta.ci.hi
beta.var.array=my.out$beta.var.array
beta.ci.lo.array=my.out$beta.ci.lo.array
beta.ci.hi.array=my.out$beta.ci.hi.array

beta.diff.array <- my.out$beta.diff.array
beta.diff.estdiff.array=my.out$beta.diff.estdiff.array
beta.diff.ci.lo.array=my.out$beta.diff.ci.lo.array
beta.diff.ci.hi.array=my.out$beta.diff.ci.hi.array

#
gamma.array <- my.out$gamma.array
data.gamma.var <- my.out$data.gamma.var
data.gamma.ci.lo=my.out$data.gamma.ci.lo
data.gamma.ci.hi=my.out$data.gamma.ci.hi
gamma.var.array=my.out$gamma.var.array
gamma.ci.lo.array=my.out$gamma.ci.lo.array
gamma.ci.hi.array=my.out$gamma.ci.hi.array

gamma.diff.array <- my.out$gamma.diff.array
gamma.diff.estdiff.array=my.out$gamma.diff.estdiff.array
gamma.diff.ci.lo.array=my.out$gamma.diff.ci.lo.array
gamma.diff.ci.hi.array=my.out$gamma.diff.ci.hi.array


#
omega.array <- my.out$omega.array
data.omega.var <- my.out$data.omega.var
data.omega.ci.lo=my.out$data.omega.ci.lo
data.omega.ci.hi=my.out$data.omega.ci.hi
omega.var.array=my.out$omega.var.array
omega.ci.lo.array=my.out$omega.ci.lo.array
omega.ci.hi.array=my.out$omega.ci.hi.array

omega.diff.array <- my.out$omega.diff.array
omega.diff.estdiff.array=my.out$omega.diff.estdiff.array
omega.diff.ci.lo.array=my.out$omega.diff.ci.lo.array
omega.diff.ci.hi.array=my.out$omega.diff.ci.hi.array

#
alpha.array=my.out$alpha.array
data.alpha.var=my.out$data.alpha.var
data.alpha.ci.lo=my.out$data.alpha.ci.lo
data.alpha.ci.hi=my.out$data.alpha.ci.hi
alpha.var.array=my.out$alpha.var.array
alpha.ci.lo.array=my.out$alpha.ci.lo.array
alpha.ci.hi.array=my.out$alpha.ci.hi.array

alpha.diff.array <- my.out$alpha.diff.array
alpha.diff.estdiff.array=my.out$alpha.diff.estdiff.array
alpha.diff.ci.lo.array=my.out$alpha.diff.ci.lo.array
alpha.diff.ci.hi.array=my.out$alpha.diff.ci.hi.array

#
Ft.array=my.out$Ft.array
data.Ft.var=my.out$data.Ft.var
data.Ft.ci.lo=my.out$data.Ft.ci.lo
data.Ft.ci.hi=my.out$data.Ft.ci.hi
Ft.var.array=my.out$Ft.var.array
Ft.ci.lo.array=my.out$Ft.ci.lo.array
Ft.ci.hi.array=my.out$Ft.ci.hi.array

Ft.diff.array <- my.out$Ft.diff.array
Ft.diff.estdiff.array=my.out$Ft.diff.estdiff.array
Ft.diff.ci.lo.array=my.out$Ft.diff.ci.lo.array
Ft.diff.ci.hi.array=my.out$Ft.diff.ci.hi.array


#
alpha.array.new=my.out$alpha.array.new
alphat.new=my.out$alphat.new
alpha.var.array.new =my.out$alpha.var.array.new
alpha.ci.lo.array.new=my.out$alpha.ci.lo.array.new
alpha.ci.hi.array.new=my.out$alpha.ci.hi.array.new



###############
## Get plots ##
###############
if(do.plots==TRUE){
    xx_val2 <- xx_val

    if(real_data==TRUE){
      extra <- paste("_comp_",comp,sep="")
    } else {
      extra <- NULL
    }   

    for(ss in 1:num_study){
      for(nn in 1:np){

        ##########
	## beta ##
	##########
        beta_index <- 1:lb[[ss]][[nn]]
        xx_lab_new <- beta_lab[[ss]][[nn]]
        if(!is.null(beta0int)){
          beta_index <- 0:lb[[ss]][[nn]]
          xx_lab_new <- c("0",beta_lab[[ss]][[nn]])
        }

        estimate.plot(paste("ss_",study.names[ss],"_",s.names[nn],extra,"_",filename_beta,sep=""),
	      xx_choose=beta_index,xx_val=beta_index,xx_lab=xx_lab_new,
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="beta",
	      tt_val=time_val,
	      thetat=adrop(betat[ss,nn,,,drop=FALSE],drop=1),
	      theta.array=adrop(beta.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(beta.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(beta.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=ylim.set,
	      xaxis.cut=time.cut)

        ###########
	## gamma ##
	###########
	if(!is.null(gamma.param)){
	  num_bgamma <- 1
          gamma_index <- 1:num_bgamma
          xx_lab_new <- num_bgamma

          estimate.plot(paste("ss_",study.names[ss],"_",s.names[nn],extra,"_",filename_gamma,sep=""),
	      xx_choose=gamma_index,xx_val=gamma_index,xx_lab=xx_lab_new,
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="beta",
	      tt_val=time_val,
	      thetat=adrop(gammat[ss,nn,,,drop=FALSE],drop=1),
	      theta.array=adrop(gamma.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(gamma.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(gamma.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=ylim.set,
	      xaxis.cut=time.cut)
	}


        ###########
	## omega ##
	###########
	if(!is.null(omega.param)){
	  num_bomega <- 1
          omega_index <- 1:num_bomega
          xx_lab_new <- num_bomega

          estimate.plot(paste("ss_",study.names[ss],"_",s.names[nn],extra,"_",filename_omega,sep=""),
	      xx_choose=omega_index,xx_val=omega_index,xx_lab=xx_lab_new,
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="beta",
	      tt_val=time_val,
	      thetat=adrop(omegat[ss,nn,,,drop=FALSE],drop=1),
	      theta.array=adrop(omega.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(omega.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(omega.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=ylim.set,
	      xaxis.cut=time.cut)
	}

        ##########################
        ## alpha(x,t) vs. t     ##
        ## xlab="t"	        ##
        ## parameter ="alpha"   ##
        ##########################

        estimate.plot(paste("ss_",study.names[ss],
			"_",s.names[nn],extra,"_",filename_alpha,"_x",sep=""),
              xx_choose=xx_choice[[ss]],xx_val=xx_val[[ss]],xx_lab=alphax_lab[[ss]],
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="alpha",
	      tt_val=time_val,
	      thetat=adrop(alphat[ss,nn,,,drop=FALSE],drop=1),
	      theta.array=adrop(alpha.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(alpha.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(alpha.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=ylim.set,
	      xaxis.cut=time.cut)

       ##########################
       ## alpha(x,t) vs. x     ##
       ## xlab="x"	       ##
       ## parameter ="alpha"   ##
       ##########################

       estimate.plot(paste("ss_",study.names[ss],
		"_",s.names[nn],extra,"_",filename_alpha,"_t",sep=""),
              xx_choose=time_choice[[ss]],xx_val=time_val,xx_lab=alphat_lab[[ss]],
	      plot.nw=FALSE,add.legend=FALSE,xlab="",ylab="",
	      parameter="alpha",
              tt_val=xx_val2[[ss]],
	      thetat=adrop(alphat.new[ss,nn,,,drop=FALSE],drop=1),
	      theta.array=adrop(alpha.array.new[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(alpha.ci.lo.array.new[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(alpha.ci.hi.array.new[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,	      
	      real_data=real_data,
	      convert=TRUE,
	      #convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=ylim.set,xaxis.cut=NULL)


	#############
   	## Ft plot ##
   	#############
  
	for(zz in 1:z.choice){
     	  estimate.plot(paste("ss_",study.names[ss],"_",s.names[nn],extra,"_",
				filename_Ft,"_z",zz,"_x",sep=""),
              xx_choose=xx_choice[[ss]],xx_val=xx_val[[ss]],xx_lab=alphax_lab[[ss]],
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="Ft",
	      tt_val=time_val,
	      thetat=adrop(Ft[ss,nn,zz,,,drop=FALSE],drop=c(1,3)),
	      theta.array=adrop(Ft.array[ss,nn,zz,,,,drop=FALSE],drop=c(1,3)),
	      theta.ci.lo.array=adrop(Ft.ci.lo.array[ss,nn,zz,,,,drop=FALSE],drop=c(1,3)),
	      theta.ci.hi.array=adrop(Ft.ci.hi.array[ss,nn,zz,,,,drop=FALSE],drop=c(1,3)),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=c(0,1),
	      xaxis.cut=time.cut)   
     	}
      }
    }
  ##}

  if(real_data==TRUE & check.study.equality==TRUE){
   for(ss in 1:combi.study){
      for(nn in 1:np){
        ##########
	## beta ##
	##########
        beta_index <- 1:lb[[ss]][[nn]]
        xx_lab_new <- beta_lab[[ss]][[nn]]
        if(!is.null(beta0int)){
          beta_index <- 0:lb[[ss]][[nn]]
          xx_lab_new <- c("0",beta_lab[[ss]][[nn]])
        }

        estimate.plot(paste("cc_",combi.names[ss],"_",s.names[nn],extra,"_",filename_beta,sep=""),
	      xx_choose=beta_index,xx_val=beta_index,xx_lab=xx_lab_new,
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="beta",
	      tt_val=time_val,
	      thetat=NULL,
	      theta.array=adrop(beta.diff.estdiff.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(beta.diff.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(beta.diff.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=c(-10,10),#ylim.set=ylim.set,
	      xaxis.cut=time.cut)

        ###########
	## gamma ##
	###########
	if(!is.null(gamma.param)){
	  num_bgamma <- 1
          gamma_index <- 1:num_bgamma
          xx_lab_new <- num_bgamma

          estimate.plot(paste("cc_",combi.names[ss],"_",s.names[nn],extra,"_",filename_gamma,sep=""),
	      xx_choose=gamma_index,xx_val=gamma_index,xx_lab=xx_lab_new,
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="beta",
	      tt_val=time_val,
	      thetat=NULL,
	      theta.array=adrop(gamma.diff.estdiff.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(gamma.diff.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(gamma.diff.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=c(-10,10),#ylim.set=ylim.set,
	      xaxis.cut=time.cut)
	}



        ###########
	## omega ##
	###########
	if(!is.null(omega.param)){
	  num_bomega <- 1
          omega_index <- 1:num_bomega
          xx_lab_new <- num_bomega

          estimate.plot(paste("cc_",combi.names[ss],"_",s.names[nn],extra,"_",filename_omega,sep=""),
	      xx_choose=omega_index,xx_val=omega_index,xx_lab=xx_lab_new,
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="beta",
	      tt_val=time_val,
	      thetat=NULL,
	      theta.array=adrop(omega.diff.estdiff.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(omega.diff.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(omega.diff.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=c(-10,10),#ylim.set=ylim.set,
	      xaxis.cut=time.cut)
	}

        ##########################
        ## alpha(x,t) vs. t     ##
        ## xlab="t"	        ##
        ## parameter ="alpha"   ##
        ##########################

        estimate.plot(paste("cc_",combi.names[ss],
			"_",s.names[nn],extra,"_",filename_alpha,"_x",sep=""),
              xx_choose=xx_choice[[ss]],xx_val=xx_val[[ss]],xx_lab=alphax_lab[[ss]],
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="alpha",
	      tt_val=time_val,
	      thetat=NULL,
	      theta.array=adrop(alpha.diff.estdiff.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.lo.array=adrop(alpha.diff.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1),
	      theta.ci.hi.array=adrop(alpha.diff.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=c(-10,10),#ylim.set=ylim.set,
	      xaxis.cut=time.cut)


	#############
   	## Ft plot ##
   	#############
  
	for(zz in 1:z.choice){
     	  estimate.plot(paste("cc_",combi.names[ss],"_",s.names[nn],extra,"_",
				filename_Ft,"_z",zz,"_x",sep=""),
              xx_choose=xx_choice[[ss]],xx_val=xx_val[[ss]],xx_lab=alphax_lab[[ss]],
	      plot.nw=plot.nw,add.legend=FALSE,xlab="",ylab="",
              parameter="Ft",
	      tt_val=time_val,
	      thetat=NULL,
	      theta.array=adrop(Ft.diff.estdiff.array[ss,nn,zz,,,,drop=FALSE],drop=c(1,3)),
	      theta.ci.lo.array=adrop(Ft.diff.ci.lo.array[ss,nn,zz,,,,drop=FALSE],drop=c(1,3)),
	      theta.ci.hi.array=adrop(Ft.diff.ci.hi.array[ss,nn,zz,,,,drop=FALSE],drop=c(1,3)),
	      var.est=var.est,
	      real_data=real_data,
	      convert=FALSE,
	      xmin=xmin[[ss]],xmax=xmax[[ss]],ylim.set=c(-10,10),#ylim.set=c(0,1),
	      xaxis.cut=time.cut)   
     	}
      }
    }
  }
}

if(real_data==TRUE){		
  for(ss in 1:num_study){
    for(nn in 1:np){
      #####################################
      ## perspective plots of alpha(x,t) ##
      #####################################

      alpha.array.tmp <- adrop(alpha.array[ss,nn,,,,drop=FALSE],drop=1)
      alpha.ci.lo.array.tmp <- adrop(alpha.ci.lo.array[ss,nn,,,,drop=FALSE],drop=1)
      alpha.ci.hi.array.tmp <- adrop(alpha.ci.hi.array[ss,nn,,,,drop=FALSE],drop=1)
  
      beta.array.tmp <- adrop(beta.array[ss,nn,,,,drop=FALSE],drop=1)

      ## plot over time at different x
      plot.3d.time(paste("ss_",study.names[ss],"_",s.names[nn],"_",filename_alpha,sep=""),
		xx_choice[[ss]],xx_val[[ss]],time_choice[[ss]],time_val,
		estimate=alpha.array[ss,nn,,nsimu,],
		theta.array.lo=alpha.ci.lo.array[ss,nn,,nsimu,],
		theta.array.hi=alpha.ci.hi.array[ss,nn,,nsimu,],
        	index_xx=which(round(xx_val[[ss]],3)%in%round(xx_choice[[ss]],3)),
        	real_data=real_data,
		name.diff=paste("_diff_x_comp_",comp,sep=""),
		conf.int=TRUE,xmin=xmin[[ss]],xmax=xmax[[ss]],xaxis.cut=time.cut,
		ylim=ylim.time)

      ## plot over x at different t
      plot.3d.x(filename=paste("ss_",study.names[ss],"_",s.names[nn],"_",filename_alpha,sep=""),
		xx_choice=xx_choice[[ss]],xx_val=xx_val[[ss]],time_choice=time_choice[[ss]],
		time_val,	
		estimate=alpha.array[ss,nn,,nsimu,],
		theta.array.lo=alpha.ci.lo.array[ss,nn,,nsimu,],
		theta.array.hi=alpha.ci.hi.array[ss,nn,,nsimu,],
		real_data=real_data,
		conf.int=TRUE,xmin=xmin[[ss]],xmax=xmax[[ss]],
		ylim=ylim.x,name.diff=paste("_diff_t_comp_",comp,sep=""))

    }
  }

  ##########################
  ## monotone Ft estimate ##
  ##########################
  Ft.mono.out <- get.monotone(theta.array=Ft.array,
	      theta.ci.lo.array=Ft.ci.lo.array,
	      theta.ci.hi.array=Ft.ci.hi.array,z.choice,num_study,np)
  
  Ft.mono <- Ft.mono.out$theta.array.new
  Ft.ci.hi.mono <- Ft.mono.out$theta.ci.hi.array.new
  Ft.ci.lo.mono <- Ft.mono.out$theta.ci.lo.array.new


  ## plot over time at different z
  index_xx_use<- which(round(xx_val[[ss]],3)%in%round(xx_choice[[ss]],3))
  for(ss in 1:num_study){
    if(study.names[ss]=="pharos" & (common.param.estimation==TRUE  || analyze.separately!="none")){ 
      legend.position <-"topright"
    } else {
      legend.position <- NULL
    }

    for(zcomp in 1:length(zz_comp)){
      for(nn in 1:np){
      tmp <- 0
        for(xx in index_xx_use){
          tmp <- tmp + 1
          plot.3d.time(paste("ss_",study.names[ss],"_",s.names[nn],
			"_xx_",alphax_lab[[ss]][tmp],"_",filename_Ft,sep=""),
		xx_choice=zz_comp[[zcomp]],xx_val=zz_comp[[zcomp]],
			time_choice[[ss]],time_val,
		estimate=Ft.mono[ss,nn,,xx,],
  	  theta.array.lo=Ft.ci.lo.mono[ss,nn,,xx,],
	  theta.array.hi=Ft.ci.hi.mono[ss,nn,,xx,],
          index_xx=zz_comp[[zcomp]],
          real_data=real_data,
	  conf.int=TRUE,xmin=xmin[[ss]],xmax=xmax[[ss]],xaxis.cut=time.cut,
	  ylim=c(0,1.2),name.diff=paste("_diff_z_comp",letters[zcomp],"_comp_",comp,sep=""),
	  convert.x=FALSE,label.names=z_lab_names[zz_comp[[zcomp]]],
	  legend.position=legend.position)
       }
     }
    }
  }				
  
  for(ss in 1:num_study){
    ##legend.position <-"topright"

    if(study.names[ss]=="pharos" & (common.param.estimation==TRUE  || analyze.separately!="none")){ 
      legend.position <-"topright"
    } else {
      legend.position <- NULL
    }

    for(nn_comp in 1:length(nn.comparison)){
      for(zz in 1:z.choice){
        plot.3d.compare(filename=paste(filename_Ft,"_ss_",study.names[ss],"_nn_comp_",comp,
		"_zeval_",z_lab[zz],"_compare_x",sep=""),
                xx_choice[[ss]],xx_val[[ss]],time_choice[[ss]],time_val,alphax_lab[[ss]],
		s.names.short,s.names,
		index_xx=index_xx_use,
		estimate=Ft.mono[ss,,zz,,],
		estimate.ci.lo=Ft.ci.lo.mono[ss,,zz,,],
		estimate.ci.hi=Ft.ci.hi.mono[ss,,zz,,],
                real_data=real_data,ylim=c(0.,1.2),xmin=xmin[[ss]],xmax=xmax[[ss]],conf.int=TRUE,
		nn.choice=nn.comparison[[nn_comp]],colors.use=colors.use,
		legend.position=legend.position)
      }
   
      plot.3d.compare(filename=paste(filename_alpha,"_ss_",study.names[ss],
		"_nn_comp_",comp,"_compare_x",sep=""),
		xx_choice[[ss]],xx_val[[ss]],time_choice[[ss]],time_val,alphax_lab[[ss]],
		s.names.short,s.names,
		index_xx=index_xx_use,
                estimate=alpha.array[ss,,,nsimu,],
                estimate.ci.lo=alpha.ci.lo.array[ss,,,nsimu,],
                estimate.ci.hi=alpha.ci.hi.array[ss,,,nsimu,],
                real_data=real_data,ylim=ylim.x,xmin=xmin[[ss]],xmax=xmax[[ss]],conf.int=TRUE,
                nn.choice=nn.comparison[[nn_comp]],colors.use=colors.use,
		legend.position=legend.position)

	 ## plot over x at different t		

      plot.3d.compare(filename=paste(filename_alpha,"_ss_",study.names[ss],
		"_nn_comp_",comp,"_compare_t",sep=""),
		time_choice[[ss]],time_val,xx_choice[[ss]],
		convert.cag(xx_val[[ss]],xmin=xmin[[ss]],xmax=xmax[[ss]]),
		alphat_lab[[ss]],
		s.names.short,s.names,
		index_xx=index_tt_use,
                estimate=alpha.array.new[ss,,,nsimu,],
                estimate.ci.lo=alpha.ci.lo.array.new[ss,,,nsimu,],
                estimate.ci.hi=alpha.ci.hi.array.new[ss,,,nsimu,],
                real_data=real_data,ylim=ylim.x,xmin=xmin[[ss]],xmax=xmax[[ss]],conf.int=TRUE,
                nn.choice=nn.comparison[[nn_comp]],colors.use=colors.use,
		legend.position=legend.position)




      beta_index <- 1:max(unlist(lb[[ss]]))
      beta_lab.new <- beta_lab[[ss]][[nn_comp]]
      if(!is.null(beta0int)){
        ## for intercept
        beta_index <- 1:(max(unlist(lb[[ss]])) + 1)
	beta_lab.new <- c(0,beta_lab.new)
      }
      
      plot.3d.compare(filename=paste(filename_beta,"_ss_",study.names[ss],
		"_nn_comp_",comp,"_compare_lb",sep=""),
		xx_choice=beta_index,
		xx_val=beta_index,
		time_choice[[ss]],time_val,beta_lab.new,s.names.short,s.names,
                index_xx=beta_index,
		estimate=adrop(beta.array[ss,,,nsimu,,drop=FALSE],drop=c(1,4)),
                estimate.ci.lo=adrop(beta.ci.lo.array[ss,,,nsimu,,drop=FALSE],drop=c(1,4)),
                estimate.ci.hi=adrop(beta.ci.hi.array[ss,,,nsimu,,drop=FALSE],drop=c(1,4)),
                real_data=real_data,ylim=ylim.beta,xmin=xmin[[ss]],xmax=xmax[[ss]],conf.int=TRUE,
                nn.choice=nn.comparison[[nn_comp]],colors.use=colors.use,
		legend.position=legend.position)
    }
  }

  ##############################
  ## individual predictions ? ##
  ## not used!		      ##
  ##############################
  if(sum(!unlist(lapply(ii.choose,double.null)))>0){

    Ftij.mono.out <- get.monotone.ij(theta.array=Ftij.array,
			theta.ci.lo.array=Ftij.ci.lo.array,
			theta.ci.hi.array=Ftij.ci.hi.array,
			num_study,
			np,ii.choose=ii.choose,time_val=time_val,nsimu)
   

    Ftij.mono <- Ftij.mono.out$theta.array.new
    Ftij.ci.hi.mono <- Ftij.mono.out$theta.ci.hi.array.new
    Ftij.ci.lo.mono <- Ftij.mono.out$theta.ci.lo.array.new
    
    for(ss in 1:num_study){
      for(nn_comp in 1:length(nn.comparison)){
        plot.3d.compare(filename=paste(filename_alphaij,"_ss_",study.names[ss],
		"_nn_comp_",comp,"_ii_",sep=""),
                xx_choice=ii.choose[[ss]],xx_val=1:n[ss],
		time_choice[[ss]],time_val,alphax_lab=ii.choose[[ss]],s.names.short,
		s.names,
		index_xx=index_xx,
		estimate=adrop(alphaij.array[ss,,,,,drop=FALSE],drop=c(1,4)),
		estimate.ci.lo=adrop(alphaij.ci.lo.array[ss,,,,,drop=FALSE],drop=c(1,4)),
		estimate.ci.hi=adrop(alphaij.ci.hi.array[ss,,,,,drop=FALSE],drop=c(1,4)),
                real_data=real_data,ylim=c(0.,1.2),xmin=xmin[[ss]],xmax=xmax[[ss]],conf.int=TRUE,
		nn.choice=nn.comparison[[nn_comp]],colors.use=colors.use)


        plot.3d.compare(filename=paste(filename_Ftij,"_ss_",study.names[ss],
		"_nn_comp_",comp,"_ii_",sep=""),
                xx_choice=1:length(ii.choose[[ss]]),xx_val=1:length(ii.choose[[ss]]),
		time_choice[[ss]],time_val,alphax_lab=ii.choose[[ss]],s.names.short,s.names,
		index_xx=index_xx,
		estimate=adrop(Ftij.mono[ss,,,,,drop=FALSE],drop=c(1,4)),
		estimate.ci.lo=adrop(Ftij.ci.lo.mono[ss,,,,,drop=FALSE],drop=c(1,4)),
		estimate.ci.hi=adrop(Ftij.ci.hi.mono[ss,,,,,drop=FALSE],drop=c(1,4)),
                real_data=real_data,ylim=c(0.,1.2),xmin=xmin[[ss]],xmax=xmax[[ss]],conf.int=TRUE,
		nn.choice=nn.comparison[[nn_comp]],colors.use=colors.use)
       }
    } 
  }
}



#####################
## plot the counts ##
#####################
#if(1==0){ ## for testing
for(ss in 1:num_study){
  plot.counts(paste("ss_",study.names[ss],"_",filename_beta,sep=""),time_val,
		adrop(counts.array[,ss,,,drop=FALSE],drop=2))
}
#}

#########################
## plot expit function ##
#########################

###################
## Print results ##
###################

###################
## count results ##
###################
#if(1==0){ ## for testing
cat("\n\n ## Counting results \n\n")
for(ss in 1:num_study){	      
  cat("\n\n ## Study ",study.names[ss],"## \n\n")
  print(apply(adrop(counts.array[,ss,,,drop=FALSE],drop=2),c(2,3),mean))
}
#}

if(real_data==FALSE){

  all.results.names <- paste("ss_",1:num_study,sep="")
  all.results.out <- get.empty.list(all.results.names)

  for(ss in 1:num_study){
    ##################
    ## beta results ## 
    ##################
    max_beta <- max(unlist(lb[[ss]]))
    if(!is.null(beta0int)){
      ## for intercept
      max_lab <- 0:max_beta
    } else {
      max_lab <- 1:max_beta
    }
  
    beta.results <- parameter.results(thetat=adrop(betat[ss,,,,drop=FALSE],drop=1),
  	       theta.array=adrop(beta.array[ss,,,,,drop=FALSE],drop=1),
	       theta.var.array=adrop(beta.var.array[ss,,,,,drop=FALSE],drop=1),
	       tt_val=time_val,xx_choose=1:length(max_lab),
	       tt_choose=time_choice[[ss]],nsimu,var.est=var.est,
	       np=np,xx_lab=max_lab,xx_lab_name="beta",
	       s.names=s.names)

    org.beta.results <- organize.data(avg.results=beta.results$avg.results,
				pt.results=beta.results$pt.results,
				np=np,
				tt_choose=time_choice[[ss]],
				xx_choose=NULL,zz_choose=NULL,param="beta",
				xx_lab=max_lab,study=ss,
				analyze.separately=analyze.separately,
				common.param.estimation=common.param.estimation)


    ###################
    ## gamma results ## 
    ###################
    if(!is.null(gamma.param)){  
      max_gamma <- 1
      max_lab <- 1:max_gamma
  
      gamma.results <- parameter.results(thetat=adrop(gammat[ss,,,,drop=FALSE],drop=1),
  	       theta.array=adrop(gamma.array[ss,,,,,drop=FALSE],drop=1),
	       theta.var.array=adrop(gamma.var.array[ss,,,,,drop=FALSE],drop=1),
	       tt_val=time_val,xx_choose=1:length(max_lab),
	       tt_choose=time_choice[[ss]],nsimu,var.est=var.est,
	       np=np,xx_lab=max_lab,xx_lab_name="gamma",
	       s.names=s.names)

      org.gamma.results <- organize.data(avg.results=gamma.results$avg.results,
				pt.results=gamma.results$pt.results,
				np=np,
				tt_choose=time_choice[[ss]],
				xx_choose=NULL,zz_choose=NULL,param="gamma",
				xx_lab=max_lab,study=ss,analyze.separately=analyze.separately,
				common.param.estimation=common.param.estimation)
    } else {
      gamma.results <- NULL
      org.gamma.results <- NULL      
    } 


    ###################
    ## omega results ## 
    ###################
    if(!is.null(omega.param)){  
      max_omega <- 1
      max_lab <- 1:max_omega
  
      omega.results <- parameter.results(thetat=adrop(omegat[ss,,,,drop=FALSE],drop=1),
  	       theta.array=adrop(omega.array[ss,,,,,drop=FALSE],drop=1),
	       theta.var.array=adrop(omega.var.array[ss,,,,,drop=FALSE],drop=1),
	       tt_val=time_val,xx_choose=1:length(max_lab),
	       tt_choose=time_choice[[ss]],nsimu,var.est=var.est,
	       np=np,xx_lab=max_lab,xx_lab_name="omega",
	       s.names=s.names)

      org.omega.results <- organize.data(avg.results=omega.results$avg.results,
				pt.results=omega.results$pt.results,
				np=np,
				tt_choose=time_choice[[ss]],
				xx_choose=NULL,zz_choose=NULL,param="omega",
				xx_lab=max_lab,study=ss,
				analyze.separately=analyze.separately,
				common.param.estimation=common.param.estimation)
    } else {
      omega.results <- NULL
      org.omega.results <- NULL      
    } 

    ############################
    ## alpha results  across t##
    ############################

    alpha.time.results <- parameter.results(thetat=adrop(alphat[ss,,,,drop=FALSE],drop=1),
  		     theta.array=adrop(alpha.array[ss,,,,,drop=FALSE],drop=1),
		     theta.var.array=adrop(alpha.var.array[ss,,,,,drop=FALSE],drop=1),
		     tt_val=time_val,
                     xx_choose=which(round(xx_val[[ss]],2)%in%xx_choice[[ss]]),
		     tt_choose=time_choice[[ss]],
		     nsimu,
		     var.est=var.est,np=np,xx_lab=alphax_lab[[ss]],xx_lab_name="xx",
		     s.names=s.names)

    org.alpha.time.results <- organize.data(avg.results=alpha.time.results$avg.results,
				pt.results=alpha.time.results$pt.results,
				np=np,
				tt_choose=time_choice[[ss]],
				xx_choose=xx_choice[[ss]],
				zz_choose=NULL,param="alpha",xx_lab=NULL,study=ss,
				analyze.separately=analyze.separately,
				common.param.estimation=common.param.estimation)

    ############################
    ## alpha results  across x##
    ############################
    alpha.xx.results <- parameter.results(thetat=adrop(alphat.new[ss,,,,drop=FALSE],drop=1),
  		      theta.array=adrop(alpha.array.new[ss,,,,,drop=FALSE],drop=1),
		      theta.var.array=adrop(alpha.var.array.new[ss,,,,,drop=FALSE],drop=1),
		      tt_val=round(xx_val[[ss]],2),
                      xx_choose=which(time_val%in%time_choice[[ss]]),tt_choose=xx_choice[[ss]],nsimu,
		      var.est=var.est,np=np,xx_lab=alphat_lab[[ss]],xx_lab_name="tt",
		      s.names=s.names,use.xx=TRUE)

    org.alpha.xx.results <- organize.data(avg.results=alpha.xx.results$avg.results,
				pt.results=alpha.xx.results$pt.results,
				np=np,
				tt_choose=xx_choice[[ss]],
				xx_choose=time_choice[[ss]],
				zz_choose=NULL,param="alpha",xx_lab=NULL,study=ss,use.xx=TRUE,
				analyze.separately=analyze.separately,
				common.param.estimation=common.param.estimation)

    ################
    ## Ft results ##	
    ################
    mynames <- paste("zz_",z_lab,sep="")
    Ft.results <- get.empty.list(mynames)
    org.Ft.results <- get.empty.list(mynames)

    for(zz in 1:z.choice){
      Ft.results[[zz]] <-  parameter.results(thetat=adrop(Ft[ss,,zz,,,drop=FALSE],drop=c(1,3)),
                     theta.array=adrop(Ft.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
                     theta.var.array=adrop(Ft.var.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
                     tt_val=time_val,
                     xx_choose=which(round(xx_val[[ss]],2)%in%xx_choice[[ss]]),
		     tt_choose=time_choice[[ss]],
		     nsimu,
                     var.est=var.est,np=np,xx_lab=alphax_lab[[ss]],xx_lab_name="xx",
		     s.names=s.names)

      org.Ft.results[[zz]] <- organize.data(avg.results=Ft.results[[zz]]$avg.results,
                                pt.results=Ft.results[[zz]]$pt.results,
                                np=np,
                                tt_choose=time_choice[[ss]],
				xx_choose=xx_choice[[ss]],zz_choose=zeval[ss,zz,,],
				param="F",xx_lab=NULL,study=ss,
				analyze.separately=analyze.separately,
				common.param.estimation=common.param.estimation)
				
    }
    
    ## put results together
    all.results <- combine.organize.results(org.beta.results,
					org.gamma.results,
					org.omega.results,
					org.alpha.time.results,
					org.alpha.xx.results,
					org.Ft.results,np,z.choice)

    all.results.out[[ss]] <- all.results

  #######################################
  cat("\n\n ## Study",study.names[ss],"##\n\n")
  #######################################

  ########################################
  cat("\n\n ##Average  results##\n\n")
  #########################################
  foo <-  all.results$full.avg[,c("abs bias", "emp var", "est var", "95% cov")]
  rownames(foo) <- all.results$latex.study.names.full
 
  print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)

  ########################################
  cat("\n\n ##Pointwise  results##\n\n")
  #########################################
  foo <- all.results$full.pt[,c("bias", "emp var", "est var", "95% cov")]
  rownames(foo) <- all.results$latex.study.names.pt

  print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)



  }

  #########################################
  cat("\n\n ##ALL Average  results##\n\n")
  #########################################
  myall.avg.tmp <- NULL
  myall.pt.tmp <- NULL

  if(common.param.data==FALSE){ # no common beta, alpha
    for (ss in 1:num_study){
      myall.avg.tmp <- cbind(myall.avg.tmp,
			all.results.out[[ss]]$full.avg[,c("abs bias", "emp var", "est var",
    	      	 							 "95% cov")])

      myall.pt.tmp <- cbind(myall.pt.tmp,
    		    all.results.out[[ss]]$full.pt[,c("bias", "emp var", "est var",
    	      	 							 "95% cov")])
    }  
  } else { # common beta, alpha
    ##for (ss in 1:1){
    for (ss in 1:num_study){
      myall.avg.tmp <- cbind(myall.avg.tmp,
			all.results.out[[ss]]$full.avg[,c("abs bias", "emp var", "est var",
    	      	 							 "95% cov")])

      myall.pt.tmp <- cbind(myall.pt.tmp,
    		    all.results.out[[ss]]$full.pt[,c("bias", "emp var", "est var",
    	      	 							 "95% cov")])
    }    
  }


  foo <- myall.avg.tmp
  rownames(foo) <- all.results$latex.names.full
  print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)
  

  #########################################
  cat("\n\n ##ALL Pointwise  results##\n\n")
  #########################################
  foo <- myall.pt.tmp
  rownames(foo) <- all.results$latex.names.pt
  print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)

  if(num_study > 1){
    ########################
    ## difference results ##
    ########################

    ##########
    ## beta ##
    ##########
    max_beta <- max(unlist(lb[[1]]))
    if(!is.null(beta0int)){
      ## for intercept
      max_lab <- 0:max_beta
    } else {
      max_lab <- 1:max_beta
    }

    beta.diff.results <- iac.results(theta.array=beta.diff.array,
				theta.ci.lo.array=beta.diff.ci.lo.array,
				theta.ci.hi.array=beta.diff.ci.hi.array,time_val,
                        time.index=5,iter.index=4)

    org.beta.diff.results <- organize.data.diff(beta.diff.results,np,xx_choose=NULL,
  			   zz_choose=NULL,param="beta",xx_lab=max_lab)

    ###########
    ## gamma ##
    ###########
    if(!is.null(gamma.param)){
      max_lab <- 1
      gamma.diff.results <- iac.results(theta.array=gamma.diff.array,
				theta.ci.lo.array=gamma.diff.ci.lo.array,
				theta.ci.hi.array=gamma.diff.ci.hi.array,time_val,
                        time.index=5,iter.index=4)

      org.gamma.diff.results <- organize.data.diff(gamma.diff.results,np,xx_choose=NULL,
  			   zz_choose=NULL,param="gamma",xx_lab=max_lab)
    } else {
      gamma.diff.results <- NULL
      org.gamma.diff.results <- NULL
    }

    ###########
    ## omega ##
    ###########
    if(!is.null(omega.param)){
      max_lab <- 1
      omega.diff.results <- iac.results(theta.array=omega.diff.array,
				theta.ci.lo.array=omega.diff.ci.lo.array,
				theta.ci.hi.array=omega.diff.ci.hi.array,time_val,
                        time.index=5,iter.index=4)

      org.omega.diff.results <- organize.data.diff(omega.diff.results,np,xx_choose=NULL,
  			   zz_choose=NULL,param="omega",xx_lab=max_lab)
    } else {
      omega.diff.results <- NULL
      org.omega.diff.results <- NULL
    }			   
 
    ###########
    ## alpha ##
    ###########

    alpha.diff.results <- iac.results(theta.array=alpha.diff.array,
				theta.ci.lo.array=alpha.diff.ci.lo.array,
				theta.ci.hi.array=alpha.diff.ci.hi.array,time_val,
                        time.index=5,iter.index=4,
			xx_choose=which(round(xx_val[[1]],2)%in%xx_choice[[1]])) 
			## xx_choose is valid because it is the same for all studies!!

    org.alpha.diff.results <- organize.data.diff(alpha.diff.results,np,
  			   zz_choose=NULL,param="alpha",xx_lab=NULL,xx_choose=xx_choice[[1]])

    ########
    ## Ft ##
    ########

    Ft.diff.results <- iac.results(theta.array=Ft.diff.array,
				theta.ci.lo.array=Ft.diff.ci.lo.array,
				theta.ci.hi.array=Ft.diff.ci.hi.array,time_val,
                        time.index=6,iter.index=5,
			xx_choose=which(round(xx_val[[1]],2)%in%xx_choice[[1]]),useFt=TRUE)
			 ## xx_choose is valid because it is the same for all studies!!


    mynames <- paste("zz_",z_lab,sep="")
    org.Ft.diff.results <- get.empty.list(mynames)

    for(zz in 1:z.choice){
      org.Ft.diff.results[[zz]] <- organize.data.diff(
    			      avg.results=adrop(Ft.diff.results[,,1,,drop=FALSE],drop=3),np,
				xx_choose=xx_choice[[1]],zz_choose=zeval[1,zz,,],
				param="F",xx_lab=NULL)
    }

    ## put results together
    all.diff.results <- combine.organize.diff.results(org.beta.diff.results,
					org.gamma.diff.results,
					org.omega.diff.results,
					org.alpha.diff.results,
					org.Ft.diff.results,np,z.choice)

    ########################################
    cat("\n\n ##IAC results##\n\n")
    #########################################
    foo <-  all.diff.results$full.avg
    rownames(foo) <- all.diff.results$latex.names.full
 
    print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)
  }
}



## print 95\% CI's
if(real_data==TRUE){
  for(ss in 1:num_study){

    #######################################
    cat("\n\n ## Study",study.names[ss],"##\n\n")
    #######################################

    ###########
    ## alpha ##
    ###########

    alpha.cis <- get.cis(adrop(alpha.array[ss,,,,,drop=FALSE],drop=1),
    	      	   adrop(alpha.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
		   adrop(alpha.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                   xx_val=xx_val[[ss]],xx_choose=xx_choice.ci[[ss]],
                   tt_val=time_val,time_choice=time_choice.ci[[ss]],
		   convert=TRUE,xmin[[ss]],xmax[[ss]],np,nsimu)

    alpha.cis.org <- org.get.cis(alpha.cis,round.set=round.set)

    ##########
    ## beta ##
    ##########
    if(!is.null(beta0int)){
      ## for intercept
      beta.index <- 0:max(unlist(lb[[ss]]))
    } else {
      beta.index <- 1:max(unlist(lb[[ss]]))
    }
    
    beta.cis <- get.cis(theta.array=adrop(beta.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.lo.array=adrop(beta.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.hi.array=adrop(beta.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                	xx_val=beta.index,
			xx_choose=beta.index,
                	tt_val=time_val,time_choice=time_choice.ci[[ss]],
			convert=FALSE,xmin=xmin[[ss]],xmax=xmax[[ss]],np,nsimu)

    beta.cis.org <- org.get.cis(beta.cis,round.set=round.set)	

    ###########
    ## gamma ##
    ###########
    if(!is.null(gamma.param)){
      gamma.index <- 1
      gamma.cis <- get.cis(theta.array=adrop(gamma.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.lo.array=adrop(gamma.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.hi.array=adrop(gamma.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                	xx_val=gamma.index,
			xx_choose=gamma.index,
                	tt_val=time_val,time_choice=time_choice.ci[[ss]],
			convert=FALSE,xmin=xmin[[ss]],xmax=xmax[[ss]],np,nsimu)

      gamma.cis.org <- org.get.cis(gamma.cis,round.set=round.set)	
    } else {
      gamma.cis <- NULL
      gamma.cis.org <- NULL
    }


    ###########
    ## omega ##
    ###########
    if(!is.null(omega.param)){
      omega.index <- 1
      omega.cis <- get.cis(theta.array=adrop(omega.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.lo.array=adrop(omega.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.hi.array=adrop(omega.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                	xx_val=omega.index,
			xx_choose=omega.index,
                	tt_val=time_val,time_choice=time_choice.ci[[ss]],
			convert=FALSE,xmin=xmin[[ss]],xmax=xmax[[ss]],np,nsimu)

      omega.cis.org <- org.get.cis(omega.cis,round.set=round.set)	
    } else {
      omega.cis <- NULL
      omega.cis.org <- NULL
    }

    ########
    ## Ft ##
    ########
    mynames <- paste("zz_",z_lab,sep="")
    Ft.cis <- get.empty.list(mynames)
    Ft.cis.org <- get.empty.list(mynames)
  
    for(zz in 1:z.choice){

      Ft.cis[[zz]] <- get.cis(adrop(Ft.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
    		  adrop(Ft.ci.lo.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
		adrop(Ft.ci.hi.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
                xx_val=xx_val[[ss]],xx_choose=xx_choice.ci[[ss]],
                tt_val=time_val,time_choice=time_choice.ci[[ss]],
                convert=TRUE,xmin[[ss]],xmax[[ss]],np,nsimu)

      Ft.cis.org[[zz]] <- org.get.cis(Ft.cis[[zz]],round.set=round.set)
    }


    if(!is.null(unlist(ii.choose[[ss]]))){
      alphaij.cis <- get.cis(adrop(alphaij.array[ss,,,,,drop=FALSE],drop=1),
			adrop(alphaij.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
			adrop(alphaij.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                     	xx_val=1:n[ss],xx_choose=ii.choose[[ss]],
                     	tt_val=time_val,time_choice=time_choice.ci[[ss]],
		     	convert=FALSE,xmin[[ss]],xmax[[ss]],np,nsimu)

      alphaij.cis.org <- org.get.cis(alphaij.cis,round.set=round.set)

      Ftij.cis <- get.cis(adrop(Ftij.mono[ss,,,,,drop=FALSE],drop=1),
			adrop(Ftij.ci.lo.mono[ss,,,,,drop=FALSE],drop=1),
			adrop(Ftij.ci.hi.mono[ss,,,,,drop=FALSE],drop=1),
                	xx_val=1:length(ii.choose[[ss]]),xx_choose=1:length(ii.choose[[ss]]),
                	tt_val=time_val,time_choice=time_choice.ci[[ss]],
			convert=FALSE,xmin[[ss]],xmax[[ss]],np,nsimu)

      Ftij.cis.org <- org.get.cis(Ftij.cis,round.set=round.set)
    }

    ##################
    ## for printing ##
    ##################

    ##########
    ## beta ##
    ##########
    #if(!is.null(beta0int)){
    #  ## for intercept
    #  beta.cis.null <- beta.cis.org[1,1:length(time_val),c("tt","est")]
    #  beta.index.use <- 1:nrow(beta.cis.org[1,,])
    #  beta.index.use <- beta.index.use[-(1:length(time_val))]
    #} else{
      beta.index.use <- 1:nrow(beta.cis.org[1,,])
    #}

    beta.cis.print <- beta.cis.org[1,beta.index.use,c("tt","est")]


    ###########
    ## gamma ##
    ###########
    if(!is.null(gamma.param)){
      gamma.cis.print <- gamma.cis.org[1,,c("tt","est")]
    }

    ###########
    ## omega ##
    ###########
    if(!is.null(omega.param)){
      omega.cis.print <- omega.cis.org[1,,c("tt","est")]
    }

    ###########
    ## alpha ##
    ###########
    alpha.cis.print <- alpha.cis.org[1,,]
  
    if(!is.null(unlist(ii.choose[[ss]]))){
      alphaij.cis.print <- alphaij.cis.org[1,,]
      Ftij.cis.print <- Ftij.cis.org[1,,]
    }

    Ft.cis.print <- NULL
    zz.length <- nrow(Ft.cis.org[[zz]][1,,])
    for(zz in 1:z.choice){
      zz.val.tmp <- rep(zz,zz.length)
      Ft.cis.print <- rbind(Ft.cis.print,cbind(zz.val.tmp,Ft.cis.org[[zz]][1,,]))
    }
		
    for(nn in 2:np){
      beta.cis.print <- cbind(beta.cis.print,beta.cis.org[nn,beta.index.use,"est"])

      if(!is.null(gamma.param)){
        gamma.cis.print <- cbind(gamma.cis.print,gamma.cis.org[nn,,"est"])
      }

      if(!is.null(omega.param)){
        omega.cis.print <- cbind(omega.cis.print,omega.cis.org[nn,,"est"])
      }

      alpha.cis.print <- cbind(alpha.cis.print,alpha.cis.org[nn,,"est"])

      if(!is.null(unlist(ii.choose[[ss]]))){
        alphaij.cis.print <-  cbind(alphaij.cis.print,alphaij.cis.org[nn,,"est"])   
        Ftij.cis.print <-  cbind(Ftij.cis.print,Ftij.cis.org[nn,,"est"])   
      }

      Ft.cis.print.tmp <- NULL
      for(zz in 1:z.choice){
        Ft.cis.print.tmp <- rbind(Ft.cis.print.tmp,as.matrix(Ft.cis.org[[zz]][nn,,"est"]))
      } 
      Ft.cis.print <- cbind(Ft.cis.print,Ft.cis.print.tmp)
    }


    
    colnames(beta.cis.print) <- c("tt",s.names)
    
    if(!is.null(gamma.param)){
      colnames(gamma.cis.print) <- c("tt",s.names)
    }

    if(!is.null(omega.param)){
      colnames(omega.cis.print) <- c("tt",s.names)
    }

    colnames(alpha.cis.print) <- c("xx","tt",s.names)
    colnames(Ft.cis.print) <- c("zz","xx","tt",s.names)

    if(!is.null(unlist(ii.choose[[ss]]))){
      colnames(alphaij.cis.print) <- c("ii","tt",s.names)
      colnames(Ftij.cis.print) <- c("ii","tt",s.names)
    }

    for(nn_comp in 1:length(nn.comparison.table)){
      cat("###################################")
      cat("\n\n ## Ft CIs ",s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
      cat("###################################")

      foo <- Ft.cis.print[,c("xx","tt",s.names[nn.comparison.table[[nn_comp]]])]
      rownames(foo) <- Ft.cis.print[,"zz"]

      print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)

    }

   # if(!is.null(beta0int)){
   #   cat("###################################")
   #   cat("\n\n ## beta CIs for beta0 ##\n\n")
   #   cat("###################################")
# 
#      foo <- beta.cis.null[,c("tt","est")]
#      rownames(foo) <- rep("",nrow(foo))
#
#      print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
#                                sanitize.text.function=function(x){x},
# 				include.rownames = FALSE)
#    }

    for(nn_comp in 1:length(nn.comparison.table)){
      cat("###################################")
      cat("\n\n ## beta CIs for ",s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
      cat("###################################")
 
      foo <- beta.cis.print[,c("tt",s.names[nn.comparison.table[[nn_comp]]])]
      rownames(foo) <- rep("",nrow(foo))

      print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)


      if(!is.null(gamma.param)){
        cat("###################################")
        cat("\n\n ## gamma CIs for ",s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
        cat("###################################")
 
        foo <- gamma.cis.print[,c("tt",s.names[nn.comparison.table[[nn_comp]]])]
        rownames(foo) <- rep("",nrow(foo))

        print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)
      }


      if(!is.null(omega.param)){
        cat("###################################")
        cat("\n\n ## omega CIs for ",s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
        cat("###################################")
 
        foo <- omega.cis.print[,c("tt",s.names[nn.comparison.table[[nn_comp]]])]
        rownames(foo) <- rep("",nrow(foo))

        print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)
      }
     
      cat("###################################")
      cat("\n\n ## alpha CIs ",s.names[nn.comparison.table[[nn_comp]]] ,"##\n\n")
      cat("###################################")

      foo <- alpha.cis.print[,c("tt",s.names[nn.comparison.table[[nn_comp]]])]
      rownames(foo) <- alpha.cis.print[,c("xx")]

      print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)

    }

    if(!is.null(unlist(ii.choose[[ss]]))){
      cat("###################################")
      cat("\n\n ## alphaij CIs ##\n\n")
      cat("###################################")

      print(xtable(alphaij.cis.print,digits=digits.tmp.short))

      cat("###################################")
      cat("\n\n ## Ftij CIs ##\n\n")
      cat("###################################")

      print(xtable(Ftij.cis.print,digits=digits.tmp.short))
    }
  }


  if(num_study > 1){
    ##########################
    ## difference estiamtes ##
    ##########################
    for(ss in 1:combi.study){

      #######################################
      cat("\n\n ## Study comparison",combi.names[ss],"##\n\n")
      #######################################


      ###########
      ## alpha ##
      ###########
      alpha.diff.cis <- get.cis(adrop(
    		   alpha.diff.estdiff.array[ss,,,,,drop=FALSE],drop=1),
    	      	   adrop(alpha.diff.ci.lo.array[ss,,,,,drop=FALSE],
			drop=1),
		   adrop(alpha.diff.ci.hi.array[ss,,,,,drop=FALSE],
			drop=1),
                   xx_val=xx_val[[ss]],xx_choose=xx_choice.ci[[ss]],
                   tt_val=time_val,time_choice=time_choice.ci[[ss]],
		   convert=TRUE,xmin[[ss]],xmax[[ss]],np,nsimu)

      alpha.diff.cis.org <- org.get.cis.track(alpha.diff.cis,
    		       	  round.set=round.set)

      ##########
      ## beta ##
      ##########

      if(!is.null(beta0int)){
        ## for intercept
        beta.index <- 0:max(unlist(lb[[ss]]))
      } else {
        beta.index <- 1:max(unlist(lb[[ss]]))
      }
    
      beta.diff.cis <- get.cis(theta.array=adrop(
    		  beta.diff.estdiff.array[ss,,,,,drop=FALSE],drop=1),
    			theta.ci.lo.array=
		adrop(beta.diff.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.hi.array=
		adrop(beta.diff.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                	xx_val=beta.index,
			xx_choose=beta.index,
                	tt_val=time_val,time_choice=time_choice.ci[[ss]],
			convert=FALSE,xmin=xmin[[ss]],
			xmax=xmax[[ss]],np,nsimu)

      beta.diff.cis.org <- org.get.cis.track(beta.diff.cis,round.set=
    		      round.set)	

      ###########
      ## gamma ##
      ###########
      if(!is.null(gamma.param)){
        gamma.index <- 1
        gamma.diff.cis <- get.cis(theta.array=adrop(
    		  gamma.diff.estdiff.array[ss,,,,,drop=FALSE],drop=1),
    			theta.ci.lo.array=
		adrop(gamma.diff.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.hi.array=
		adrop(gamma.diff.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                	xx_val=gamma.index,
			xx_choose=gamma.index,
                	tt_val=time_val,time_choice=time_choice.ci[[ss]],
			convert=FALSE,xmin=xmin[[ss]],
			xmax=xmax[[ss]],np,nsimu)

        gamma.diff.cis.org <- org.get.cis.track(gamma.diff.cis,round.set=
    		      round.set)	
      } else {
        gamma.diff.cis <- NULL
	gamma.diff.cis.org <- NULL
      }


      ###########
      ## omega ##
      ###########
      if(!is.null(omega.param)){
        omega.index <- 1
        omega.diff.cis <- get.cis(theta.array=adrop(
    		  omega.diff.estdiff.array[ss,,,,,drop=FALSE],drop=1),
    			theta.ci.lo.array=
		adrop(omega.diff.ci.lo.array[ss,,,,,drop=FALSE],drop=1),
			theta.ci.hi.array=
		adrop(omega.diff.ci.hi.array[ss,,,,,drop=FALSE],drop=1),
                	xx_val=omega.index,
			xx_choose=omega.index,
                	tt_val=time_val,time_choice=time_choice.ci[[ss]],
			convert=FALSE,xmin=xmin[[ss]],
			xmax=xmax[[ss]],np,nsimu)

        omega.diff.cis.org <- org.get.cis.track(omega.diff.cis,round.set=
    		      round.set)	
      } else {
        omega.diff.cis <- NULL
	omega.diff.cis.org <- NULL
      }

      ########
      ## Ft ##
      ########

      mynames <- paste("zz_",z_lab,sep="")
      Ft.diff.cis <- get.empty.list(mynames)
      Ft.diff.cis.org <- get.empty.list(mynames)
  
      for(zz in 1:z.choice){

        Ft.diff.cis[[zz]] <- get.cis(adrop(Ft.diff.estdiff.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
    		  adrop(Ft.diff.ci.lo.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
		adrop(Ft.diff.ci.hi.array[ss,,zz,,,,drop=FALSE],drop=c(1,3)),
                xx_val=xx_val[[ss]],xx_choose=xx_choice.ci[[ss]],
                tt_val=time_val,time_choice=time_choice.ci[[ss]],
                convert=TRUE,xmin[[ss]],xmax[[ss]],np,nsimu)

        Ft.diff.cis.org[[zz]] <- org.get.cis.track(Ft.diff.cis[[zz]],round.set=round.set)
      }

      ##################
      ## for printing ##
      ##################

      ##########
      ## beta ##
      ##########

      #if(!is.null(beta0int)){
      #  ## for intercept
      #  beta.diff.cis.null <- beta.diff.cis.org[1,1:length(time_val),c("change","tt","est")]
      #  beta.diff.index.use <- 1:nrow(beta.diff.cis.org[1,,])
      #  beta.diff.index.use <- beta.diff.index.use[-(1:length(time_val))]
      #} else{
        beta.diff.index.use <- 1:nrow(beta.diff.cis.org[1,,])
      #}

      beta.diff.cis.print <- beta.diff.cis.org[1,beta.diff.index.use,c("change","tt","est")]

      ###########
      ## gamma ##
      ###########
      if(!is.null(gamma.param)){
        gamma.diff.cis.print <- gamma.diff.cis.org[1,,c("change","tt","est")]      
      }

      ###########
      ## omega ##
      ###########
      if(!is.null(omega.param)){
        omega.diff.cis.print <- omega.diff.cis.org[1,,c("change","tt","est")]      
      }

      alpha.diff.cis.print <- alpha.diff.cis.org[1,,]
  
      Ft.diff.cis.print <- NULL
      zz.length <- nrow(Ft.diff.cis.org[[zz]][1,,])
      for(zz in 1:z.choice){
        zz.val.tmp <- rep(zz,zz.length)
        Ft.diff.cis.print <- rbind(Ft.diff.cis.print,cbind(zz.val.tmp,Ft.diff.cis.org[[zz]][1,,]))
      }
		
      for(nn in 2:np){
        beta.diff.cis.print <- cbind(beta.diff.cis.print,beta.diff.cis.org[nn,beta.index.use,"est"])

	if(!is.null(gamma.param)){
          gamma.diff.cis.print <- cbind(gamma.diff.cis.print,gamma.diff.cis.org[nn,,"est"])
        }

	if(!is.null(omega.param)){
          omega.diff.cis.print <- cbind(omega.diff.cis.print,omega.diff.cis.org[nn,,"est"])
        }

        alpha.diff.cis.print <- cbind(alpha.diff.cis.print,alpha.diff.cis.org[nn,,"est"])

        Ft.diff.cis.print.tmp <- NULL
        for(zz in 1:z.choice){
          Ft.diff.cis.print.tmp <- rbind(Ft.diff.cis.print.tmp,
			      	 as.matrix(Ft.diff.cis.org[[zz]][nn,,"est"]))
        } 
        Ft.diff.cis.print <- cbind(Ft.diff.cis.print,Ft.diff.cis.print.tmp)
      }

      colnames(beta.diff.cis.print) <- c("change","tt",s.names)
      rownames(beta.diff.cis.print) <- 1:nrow(beta.diff.cis.print)

      if(!is.null(gamma.param)){
        colnames(gamma.diff.cis.print) <- c("change","tt",s.names)
        rownames(gamma.diff.cis.print) <- 1:nrow(gamma.diff.cis.print)
      }

      if(!is.null(omega.param)){
        colnames(omega.diff.cis.print) <- c("change","tt",s.names)
        rownames(omega.diff.cis.print) <- 1:nrow(omega.diff.cis.print)
      }

      colnames(alpha.diff.cis.print) <- c("change","xx","tt",s.names)
      rownames(alpha.diff.cis.print) <- 1:nrow(alpha.diff.cis.print)

      colnames(Ft.diff.cis.print) <- c("zz","change","xx","tt",s.names)
      rownames(Ft.diff.cis.print) <- 1:nrow(Ft.diff.cis.print)

      for(nn_comp in 1:length(nn.comparison.table)){
        cat("###################################")
        cat("\n\n ## Ft diff CIs ",
      		s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
        cat("###################################")

        change.check <- which(Ft.diff.cis.print[,"change"]==1)

        if(length(change.check)>0){
          foo <- Ft.diff.cis.print[change.check,
      	    c("xx","tt",s.names[nn.comparison.table[[nn_comp]]])]
	  if(is.null(dim(foo))){
	    print(foo)
	  } else {
            rownames(foo) <- Ft.diff.cis.print[change.check,"zz"]

            print(xtable(data.frame(row = rownames(foo),data.frame(foo)),
       				  digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)
	  }
        }
      }

#      if(!is.null(beta0int)){
#        cat("###################################")
#        cat("\n\n ## beta diff CIs for beta0 ##\n\n")
#        cat("###################################")
# 
#        change.check <- which(beta.diff.cis.null[,"change"]==1)
#
#        if(length(change.check)>0){
#          foo <- beta.diff.cis.null[change.check,c("tt","est")]
#	  if(is.null(dim(foo))){
#	    print(foo)
#	  } else {
#            rownames(foo) <- rep("",nrow(foo))
#
#            print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
#                                sanitize.text.function=function(x){x},
# 				include.rownames = FALSE)
#          }
#        }
#      }

      for(nn_comp in 1:length(nn.comparison.table)){

        cat("###################################")
        cat("\n\n ## beta diff CIs for ",s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
        cat("###################################")
 
        change.check <- which(beta.diff.cis.print[,"change"]==1)
      
        if(length(change.check)>0){
          foo <- beta.diff.cis.print[change.check,c("tt",s.names[nn.comparison.table[[nn_comp]]])]
	  if(is.null(dim(foo))){
	    print(foo)
	  } else {
            rownames(foo) <- rep("",nrow(foo))

            print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
 				  include.rownames = FALSE)
          }
        }

	if(!is.null(gamma.param)){
          cat("###################################")
          cat("\n\n ## gamma diff CIs for ",s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
          cat("###################################")
 
          change.check <- which(gamma.diff.cis.print[,"change"]==1)
      
          if(length(change.check)>0){
            foo <- gamma.diff.cis.print[change.check,c("tt",s.names[nn.comparison.table[[nn_comp]]])]
	    if(is.null(dim(foo))){
	      print(foo)
	    } else {
              rownames(foo) <- rep("",nrow(foo))

              print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
 				  include.rownames = FALSE)
            }
          }
        }


	if(!is.null(omega.param)){
          cat("###################################")
          cat("\n\n ## omega diff CIs for ",s.names[nn.comparison.table[[nn_comp]]],"##\n\n")
          cat("###################################")
 
          change.check <- which(omega.diff.cis.print[,"change"]==1)
      
          if(length(change.check)>0){
            foo <- omega.diff.cis.print[change.check,c("tt",s.names[nn.comparison.table[[nn_comp]]])]
	    if(is.null(dim(foo))){
	      print(foo)
	    } else {
              rownames(foo) <- rep("",nrow(foo))

              print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
 				  include.rownames = FALSE)
            }
          }
        }

        cat("###################################")
        cat("\n\n ## alpha diff CIs ",s.names[nn.comparison.table[[nn_comp]]] ,"##\n\n")
        cat("###################################")

        change.check <- which(alpha.diff.cis.print[,"change"]==1)

        if(length(change.check)>0){
          foo <- alpha.diff.cis.print[change.check,c("tt",
	    s.names[nn.comparison.table[[nn_comp]]])]
	  if(is.null(dim(foo))){
	    print(alpha.diff.cis.print[change.check,c("xx","tt",
              s.names[nn.comparison.table[[nn_comp]]])])
	  } else {

            rownames(foo) <- alpha.diff.cis.print[change.check,c("xx")]

            print(xtable(data.frame(row = rownames(foo),data.frame(foo)),digits=digits.tmp.short),
                                  sanitize.text.function=function(x){x},
				  include.rownames = FALSE)

	  }
        }
      }
    }
  }
}




