###############################################
## Main functions used to organize real data ##
###############################################

################################
## function to summarize data ##
################################
summarize.symp.onset <- function(onset.age.use,data,names){

  onset.delta.use <- paste("delta.",onset.age.use,sep="")


  data.out <- array(0,dim=c(length(onset.age.use),3),
			dimnames=list(names,c("\\% Rater","\\% Family","\\% Subject")))

  for(i in 1:length(onset.age.use)){
    data.new <- cbind(data[,c(onset.age.use[i],onset.delta.use[i],"who")])
    data.new <- data.new[complete.cases(data.new),]

    data.out[names[i],"\\% Rater"] <-  mean(data.new$who=="RATER")*100
    data.out[names[i],"\\% Family"] <-  mean(data.new$who=="FAMILY")*100
    data.out[names[i],"\\% Subject"] <-  mean(data.new$who=="SUBJECT")*100
  }

  return(data.out)
}


summarize.onset <- function(onset.age.use,data,names){

  onset.delta.use <- paste("delta.",onset.age.use,sep="")


  data.out <- array(0,dim=c(length(onset.age.use),2),
			dimnames=list(names,c("Sample size","% Censoring")))

  for(i in 1:length(onset.age.use)){
    data.new <- cbind(data[,c(onset.age.use[i],onset.delta.use[i])])
    data.new <- data.new[complete.cases(data.new),]

    data.out[names[i],"Sample size"] <- nrow(data.new)
    data.out[names[i],"% Censoring"] <- (1-mean(data.new[,onset.delta.use[i]]))*100

  }

  return(data.out)
}


get.mean.sd <- function(x,digits=1){
  tmp.out <- c(mean(x,na.rm=TRUE),sd(x,na.rm=TRUE))
  tmp.out <- round(tmp.out,digits)
  out <- paste(tmp.out[1]," (",tmp.out[2],")",sep="")
  return(out)
}

 

   get.summary <- function(x){
      return(c(sum(x==1,na.rm=TRUE),sum(x==0,na.rm=TRUE),sum(is.na(x))))
   }

  

## post baseline summary
summarize.covariates.motor <- function(onset.age.use,data,use.feature=c("motor","mci","beh")[1],
				use.pharos=FALSE,
				gene.know=c("gene.site.investigator",
					"gene.indep.rater","gene.study.coord",
					"gene.study.subj"),
				gene.know.names=c("Site.Investigator",
					"Independent.Rater",
					"Study.Coordinator",
					"Subject")){

   onset.delta.use <- paste("delta.",onset.age.use,sep="")
   onset.followup.use <- paste("followup.",onset.age.use,sep="")

   if(use.feature=="motor.onset"){
 	features.interest <- c("DCL.","motor.")
	features.names <- c("DCL","TMS")
   } else if(use.feature=="mci.onset"){
	features.interest <- c("score.")
	features.names <- c("Cog Score")
   } else if(use.feature=="beh.onset"){
	features.interest <- c("score.")
	features.names <- c("Severity")
   }

   features.use <- paste(features.interest,onset.age.use,sep="")
	
   if(use.pharos==TRUE & use.feature=="motor.onset"){
     know.use <- paste(gene.know,".",onset.age.use,sep="")
   }

   get.measures <- function(data.out,index.use,data.use,use.pharos){

     data.out[index.use,"Sample size"] <- nrow(data.use)
     data.out[index.use,"Age"] <- get.mean.sd(data.use[,onset.age.use])

     for(ll in 1:length(features.use)){
       data.out[index.use,features.names[ll]] <- get.mean.sd(data.use[,features.use[ll]])
     }
     data.out[index.use,"Follow-up"] <- get.mean.sd(data.use[,onset.followup.use])     

     if(use.pharos==TRUE & use.feature=="motor.onset"){
       for(k in 1:length(gene.know)){
         tmp <- paste(gene.know.names[k],c("Yes","No","NR"),sep=".")
         index.tmp <- which(colnames(data.out) %in% tmp)
         data.out[index.use,index.tmp] <- get.summary(data.use[,know.use[k]])
       }
     }
     return(data.out)
   }

   if(use.pharos==FALSE || use.pharos==TRUE & use.feature!="motor.onset"){
     data.out <- array(0,dim=c(2,3+length(features.names)),
				dimnames=list(c(paste(onset.age.use,c("Diagnosed","Non-diagnosed"),sep=".")),
		c("Sample size","Age",
		features.names,"Follow-up")))

     ## get subjects 
     data.tmp <- data[,c(onset.age.use,onset.delta.use,onset.followup.use,features.use)]
     data.tmp <- data.tmp[complete.cases(data.tmp[,c(onset.age.use,onset.delta.use)]),]  

   } else {
     data.out <- array(0,dim=c(2,3+length(features.names)+3*length(gene.know)),
				dimnames=list(c(paste(onset.age.use,c("Diagnosed","Non-diagnosed"),sep=".")),
		c("Sample size","Age",
		features.names,"Follow-up",
		as.vector(t(outer(gene.know.names, c("Yes","No","NR"), paste, sep="."))) )))


     ## get subjects 
     data.tmp <- data[,c(onset.age.use,onset.delta.use,onset.followup.use,features.use,know.use)]
     data.tmp <- data.tmp[complete.cases(data.tmp[,onset.age.use]),]  
   }

   ############################
   ## get subjects censored  ##
   ############################
   index.censored <- which(data.tmp[,onset.delta.use]==0)
   censored.data <- data.tmp[index.censored,]

   index.use <- paste(onset.age.use,"Non-diagnosed",sep=".")
   data.use <- censored.data

   data.out <- get.measures(data.out,index.use=index.use,data.use=data.use,use.pharos=use.pharos)

   ############################
   ## get subjects observed  ##
   ############################
   non.censored.data <- data.tmp[-index.censored,]

   index.use <- paste(onset.age.use,"Diagnosed",sep=".")
   data.use <- non.censored.data

   data.out <- get.measures(data.out,index.use=index.use,data.use=data.use,use.pharos=use.pharos)

   return(data.out)
}




multi.onset <- function(onset.age.use,data){

  onset.delta.use <- paste("delta.",onset.age.use,sep="")

  data.out <- array(0,dim=c(1,2),
			dimnames=list("Multi",c("Sample size","% Cens")))

  data.new <- cbind(data[,onset.delta.use])
 
  data.tmp <- aggregate(list(numdup=rep(1,nrow(data.new))), data.new, length)
  tmp.index <- which(apply(data.tmp[,-ncol(data.tmp)],1,sum)==length(onset.age.use))

  if(length(tmp.index)>1e-6){
    data.out["Multi","Sample size"] <- data.tmp[tmp.index,"numdup"]
    data.out["Multi","% Cens"] <- ""
  }

  return(data.out)
}

summarize.covariate <- function(var,data,names){

  data.out <- array(0,dim=c(length(var),5),
			dimnames=list(names,c("Sample size","Mean (SD)","Min","Median","Max")))

  for(i in 1:length(var)){
    data.new <- cbind(data[,c(var[i])])
    data.new <- data.new[complete.cases(data.new),]

    data.out[names[i],"Sample size"] <- length(data.new)
    data.out[names[i],"Mean (SD)"] <-    get.mean.sd(data.new)
    data.out[names[i],c("Min","Median","Max")] <- round(quantile(data.new,prob=c(0,0.5,1)),digits=1)
  }
  return(data.out)
}


summarize.indicator.covariate <- function(var,data,names){
  data.out <- array(0,dim=c(length(var),1),
			dimnames=list(names,c("%")))

  for(i in 1:length(var)){
    data.new <- cbind(data[,c(var[i])])
    data.new <- data.new[complete.cases(data.new),]

    #data.out[names[i],"Sample size"] <- length(data.new)
    data.out[names[i],"%"] <-    mean(data.new)*100
  }

  data.out <- round(data.out,digits=1)
  return(data.out)
}

get.empty.list <- function(names){
  out <-  vector("list",length(names))
  names(out) <- names
  return(out)
}


summarize.data.sets.covariates <- function(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=NULL,
				onset.names=NULL,
				use.pharos=FALSE,
				function.use=c("continuous","discrete",
					"onset","motor.onset","mci.onset")[1],table.name="CAG",
				digits.set=1,filler="none",show.gene.know=TRUE){
  names.new <- names(data.sets)
  data.sets.new <- get.empty.list(names.new)

  for(i in 1:length(data.sets)){
  	##print(i)
	data <- data.sets[[i]]
	if(function.use=="continuous"){
	  data.sets.new[[i]] <- summarize.covariate(covariates.interest,data,covariates.names) 
        } else if(function.use=="discrete") {
	  data.sets.new[[i]] <- summarize.indicator.covariate(covariates.interest,
	  		     data,covariates.names) 

        } else if(function.use=="symp.onset"){
	  data.sets.new[[i]] <- summarize.symp.onset(onset.age.use,data,onset.names)
	} else if(function.use=="onset"){
	  data.sets.new[[i]] <- summarize.onset(onset.age.use,data,onset.names)
	} else if(function.use=="multi.onset"){
	  data.sets.new[[i]] <- multi.onset(onset.age.use,data)
	} else {
	  data.sets.new[[i]] <- summarize.covariates.motor(onset.age.use,data,
					use.feature=function.use,use.pharos=use.pharos)
	} 
  }

  data.sets.out <- NULL
  for(i in 1:length(data.sets)){
	if(function.use=="onset" | function.use=="multi.onset" ){
 	  data.sets.out <- cbind(data.sets.out,data.sets.new[[i]])
      } else {
 	  data.sets.out <- rbind(data.sets.out,data.sets.new[[i]])
      }
  }

  if(function.use=="motor.onset"){
    data.sets.out <- t(data.sets.out)

    if(show.gene.know==TRUE){
      ## fix rownames
      index.gene <- which(grepl("*Yes*|*No*|*NR*",rownames(data.sets.out))==TRUE)
      yes.nos <- rep(c("Yes","No","NR"),length(index.gene)/3)
      new.tmp <- c(rownames(data.sets.out)[-index.gene],yes.nos)    
    
      data.sets.out <- cbind(new.tmp,data.sets.out)
      rownames(data.sets.out) <- c(rep("",length(rownames(data.sets.out)[-index.gene])),
    			       "\\multirow{3}{*}{\\parbox{2cm}{Site Investigator}}",
			       rep("",2),
			       "\\multirow{3}{*}{\\parbox{2cm}{Independent Rater}}",
			       rep("",2),
			       "\\multirow{3}{*}{\\parbox{2cm}{Study Coordinator}}",
			       rep("",2),
			       "\\multirow{3}{*}{\\parbox{2cm}{Subject}}",
			       			       rep("",2))
     }
  }

  if(function.use=="mci.onset" | function.use=="beh.onset"){
    data.sets.out <- t(data.sets.out)
   
    ## fix rownames
    data.sets.out <- cbind(rownames(data.sets.out),data.sets.out)
    rownames(data.sets.out) <- rep("",nrow(data.sets.out))
  }

  if(filler!="none"){
    if(function.use!="motor.onset" & function.use!="mci.onset" & function.use!="beh.onset"){
      data.sets.out <- rbind(c(rep("",ncol(data.sets.out))),round(data.sets.out,1))
      ##data.sets.out <- cbind(c(rep("",nrow(data.sets.out))),round(data.sets.out,1))
    } else {
      data.sets.out <- rbind(c(rep("",ncol(data.sets.out))),data.sets.out)
      ##data.sets.out <- cbind(c(rep("",ncol(data.sets.out))),data.sets.out)
    }     
    rownames(data.sets.out)[1] <- filler
    ##data.sets.out <- rbind(paste("\\multicolumn{",ncol(data.sets.out)-1,"}{l}{",filler,"}",sep=""),
    ##		     data.sets.out)
  } else {
    if(function.use!="multi.onset" & function.use!="continuous" & function.use!="symp.onset"){
      data.sets.out <- round(data.sets.out,1)
    }
    
    if(function.use=="symp.onset"){
      data.sets.out <- round(data.sets.out,3)
    }
    
  }

  if(function.use=="continuous" | function.use=="discrete" | function.use=="symp.onset"){
    data.sets.out <- cbind(c("All","\\atrisk", "\\norisk"),data.sets.out)
    rownames(data.sets.out) <- c(paste("\\multirow{3}{*}{",table.name,"}",sep=""),"","")
  }

  return(data.sets.out)
}

################################
## function to display tables ##
################################

get.my.tables <- function(all.data,cutoff=50,data.name="cohort"){

  use.pharos <- TRUE
  #use.pharos <- FALSE
  use.predict <- FALSE

  #if(data.name=="pharos"){
  #  use.pharos <- TRUE
  #} 

  if(data.name=="predict"){
    use.predict <- TRUE
  }

  all.data <- all.data[which(all.data$base_age>=18),]  ## take people who are 18+ at BL

  ###################
  ## get one event ##
  ###################
  ## mci
  mci.ages <- c("sdmt",
			"strcol",
			"strwrd",
			"strint")

  one.mci <- get.one.event(all.data,onset.ages=mci.ages,name="mcione")
  all.data <- cbind(all.data,one.mci)

  if(use.predict==FALSE){
    ## behavior
    beh.ages <- c("apt2",
			"irb2",
			"dep2")

    one.beh <- get.one.event(all.data,onset.ages=beh.ages,name="behone")

    ## add two components to data set
    all.data <- cbind(all.data,one.mci,one.beh)
  } 

  ######################
  ## subjects at risk ##
  ######################
  at.risk <- which(all.data$CAG>=36)
  data.at.risk <- all.data[at.risk,]

  ##########################
  ## subjects not at risk ##
  ##########################
  data.not.at.risk <- all.data[-at.risk,]

  ###############
  ## Data sets ##
  ###############
  data.sets<- list(data.all=all.data,
	data.at.risk=data.at.risk,
	data.not.at.risk=data.not.at.risk)

  ########################
  ## General covariates ##
  ########################
  function.use <- "continuous"

  interest <- c("CAG")
  interest.names <- interest
  covariates.cag <- summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="CAG")

  interest <- c("base_age")
  interest.names <- interest
  covariates.baseage <-  summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="BL Age")

  function.use <- "discrete"
  interest <- "gender"
  interest.names <- "male"
  covariates.gender <-  summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="\\% Males")


  interest <- c("educ_cat")
  interest.names <- interest
  covariates.educ <- summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="\\% Higher Educ")

  cat("\n\n##  CAG ##\n\n")
  foo <- covariates.cag
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

  ## Age at baseline
  cat("\n\n##  AGE AT BL ##\n\n")
  foo <- covariates.baseage
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

 
  ## Gender
  cat("\n\n##  GENDER ##\n\n")
  foo <- covariates.gender
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)



  ## Education
  cat("\n\n##  EDUCATION ##\n\n")
  foo <- covariates.educ
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)


  ###################		  
  ## motor symptom ##
  ###################
  if(use.predict==FALSE){
    onset.ages <- "symp"
    onset.names <- c("Age at first motor symptom")
    filler.names <- "none"

    function.use <- "symp.onset"
    onset.out <- NULL

    for(kk in 1:length(onset.ages)){
  
      onset.out.tmp <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages[kk],
				onset.names=onset.names[kk],
				function.use=function.use,filler=filler.names[kk],
				table.name="Motor Symptom")
      onset.out <- rbind(onset.out,onset.out.tmp)
      ##cat("\n\n## ", onset.names[kk],"##\n\n")
      ##print(xtable(onset.out,digits=1))
    }

    cat("\n\n## Motor symptom times ##\n\n")
    foo <- onset.out
    print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)    
    
  }


  ###################
  ## overall onset ##
  ###################

  if(use.predict==FALSE){
    onset.ages <- c("symp",
			"hdage_base",
			"hdage_nobase",
			#"hdage_new_base",
			"hdage_new_nobase",
			"sdmt",
			"strcol",
			"strwrd",
			"strint",
			"mcione",
			#"cog",
			"apt2",
			"irb2",
			"dep2",
			"behone")

    onset.names <- c("Age at first motor symptom",
		"~~~~~At Baseline",
		"~~~~~When DCL=4 post-BL",
		#"Age at first motor diagnosis (at BL)",
		"~~~~~When DCL=3 or 4 post-BL",
		"~~~~~SDMT score",
		"~~~~~Stroop color naming score",
		"~~~~~Stroop word reading score",
		"~~~~~Stroop inferference score",
		"~~~~~\\# Who Experience All 4",
		#"Age at first cognitive impairment first impacted daily life",
		"~~~~~Apathy",
		"~~~~~Irritability",
		"~~~~~Depression",
		"~~~~~\\# Who Experience All 3")

    filler.names <- c("none",
    		    "Age at first motor-diagnosis",
		    "none",
		    "none",
		    "Age at first MCI based on",
		    "none",
		    "none",
		    "none",
		    "none",
		    "Age at which behavior severity $\\geq$ 3",
		    "none",
		    "none",
		    "none"
		    )
  } else {
    onset.ages <- c(	"hdage_base",
			"hdage_nobase",
			"hdage_new_base",
			"hdage_new_nobase",
			"sdmt",
			"strcol",
			"strwrd",
			"strint",
			"mcione")

    onset.names <- c(
		"~~~~~At Baseline (DCL=4)",
		"~~~~~When DCL=4 post-BL",
		"~~~~~At Baseline (DCL=3 or 4)",
		"~~~~~When DCL=3 or 4 post-BL",
		"~~~~~SDMT score",
		"~~~~~Stroop color naming score",
		"~~~~~Stroop word reading score",
		"~~~~~Stroop inferference score",
		"~~~~~\\# Who Experience All 4")

    filler.names <- c(
    		    "Age at first motor-diagnosis",
		    "none",
		    "none",
		    "none",
		    "none",
		    "Age at first MCI based on",
		    "none",
		    "none",
		    "none",
		    "none",
		    "none"
		    )
  }

  function.use <- "onset"
  onset.out <- NULL
  for(kk in 1:length(onset.ages)){
  
    onset.out.tmp <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages[kk],
				onset.names=onset.names[kk],
				function.use=function.use,filler=filler.names[kk])
    onset.out <- rbind(onset.out,onset.out.tmp)
    ##cat("\n\n## ", onset.names[kk],"##\n\n")
    ##print(xtable(onset.out,digits=1))
  }

  cat("\n\n## Onset times ##\n\n")
  foo <- onset.out
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

  #################
  ## motor onset ##
  #################
  onset.ages <- c(
			"hdage_nobase",
			"hdage_new_nobase")

  onset.names <- c(
		"When DCL=4 post-BL",
		#"Age at first motor diagnosis (at BL)",
		"When DCL=3 or 4 post-BL")

  function.use <- "motor.onset"
  motor.onset.out <- NULL
  for(kk in 1:length(onset.ages)){
 
     motor.onset.out.tmp <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages[kk],
				onset.names=onset.names[kk],
				function.use=function.use,
				use.pharos=use.pharos,filler=onset.names[kk])
    motor.onset.out <- rbind(motor.onset.out,motor.onset.out.tmp)

    ##cat("\n\n## ", onset.names[kk],"##\n\n")
    ##print(xtable(t(onset.out)))
  }

  cat("\n\n## Onset/Gene knowledge ##\n\n")
  foo <- motor.onset.out
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)


####################
## MCI covariates ##
####################
  onset.ages <- c("sdmt",
			"strcol",
			"strwrd",
			"strint",
			"mcione")

  onset.names <- c(		"SDMT score",
		"Stroop color naming score",
		"Stroop word reading score",
		"Stroop inferference score",
		"One MCI event score")

  filler.names <- c("When MCI occurs based on SDMT",
  	       	  "When MCI occurs based on Stroop color naming",
		  "When MCI occurs based on Stroop word reading",
		  "When MCI occurs based on Stroop interference",
		  "When MCI occurs based on any cognitive test")

  function.use <- "mci.onset"
  mci.onset.out <- NULL
  for(kk in 1:length(onset.ages)){
  
    mci.onset.out.tmp <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages[kk],
				onset.names=onset.names[kk],
				function.use=function.use,
				use.pharos=use.pharos, filler=filler.names[kk])
    mci.onset.out <- rbind(mci.onset.out,mci.onset.out.tmp)
    ##cat("\n\n## ", onset.names[kk],"##\n\n")
    ##print(xtable(t(onset.out)))
  }

  cat("\n\n## MCI Onset ##\n\n")
  foo <- mci.onset.out
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)  

  ## simultaneous experience?

  onset.ages <- c("sdmt",
			"strcol",
			"strwrd",
			"strint")

  onset.names <- c(		"SDMT score",
		"Stroop color naming score",
		"Stroop word reading score",
		"Stroop inferference score")

  function.use <- "multi.onset"
  multi.out <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages,
				onset.names=onset.names,
				function.use=function.use, 
				use.pharos=use.pharos)


  cat("\n\n##  Multi MCI onset##\n\n")
  print(xtable(multi.out,digits=1))


  ####################
  ## BEH covariates ##
  ####################
  if(use.predict==FALSE){
  onset.ages <- c("apt2",
			"irb2",
			"dep2",
			"behone")


  onset.names <- c(	"Apathy",
		"Irritability",
		"Depression",
		"At least one BEH")

  filler.names <- c(	"When Apathy severity $\\geq$ 3",
		"When Irritability severity $\\geq$ 3",
		"When Depression severity $\\geq$ 3",
		"When at least one BEH severity $\\geq$ 3")


  function.use <- "beh.onset"
  beh.onset.out <- NULL
  for(kk in 1:length(onset.ages)){
  
    beh.onset.out.tmp <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages[kk],
				onset.names=onset.names[kk],
				function.use=function.use,
				use.pharos=use.pharos,filler=filler.names[kk])
    ##cat("\n\n## ", onset.names[kk],"##\n\n")
    ##print(xtable(t(onset.out)))
    beh.onset.out <- rbind(beh.onset.out,beh.onset.out.tmp)
  }

  cat("\n\n## Beh onset ##\n\n")
  foo <- beh.onset.out
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)  


    ## simultaneous experience?
    onset.ages <- c("apt2",
			"irb2",
			"dep2")


    onset.names <- c(	"Apathy",
		"Irritability",
		"Depression")

    function.use <- "multi.onset"
    multi.out <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages,
				onset.names=onset.names,
				function.use=function.use, 
				use.pharos=use.pharos)


    cat("\n\n## Multi BEH onset ##\n\n")
    print(xtable(multi.out,digits=1))
  }

  ##################
  ## for analysis ##
  ##################

  cat("\n\n## DATA FOR ANALYSIS ## \n\n")

  data.for.use <- data.at.risk

  cat("\n\n## check CAG repeats ## \n\n")
  print(table(data.for.use$CAG))

  ## only use data for CAG < cutoff
  index.cag <- which(data.for.use$CAG <=cutoff)
  data.for.use <- data.for.use[index.cag,]

  ## cag limits
  cag.limit <- c(min(data.for.use$CAG),max(data.for.use$CAG))  
  print(cag.limit)

  ## standardize cag variable to be in [0,1]
  ##data.for.use$CAG <- (data.for.use$CAG-min(data.for.use$CAG))/(max(data.for.use$CAG)-min(data.for.use$CAG))
  data.for.use$CAG <- reverse.cag(data.for.use$CAG,xmin=36,xmax=cutoff)

  cat("\n\n## unique CAG repeats ## \n\n")
  print(sort(unique(data.for.use$CAG)))

  print(table(data.for.use$CAG))

  #######################
  ## write data output ##
  #######################
  write.table(data.for.use,paste("clean_",data.name,".dat",sep=""),row.names=FALSE,col.names=TRUE)
  write.table(cag.limit,paste(data.name,"_cag_limits.dat",sep=""),row.names=FALSE,col.names=FALSE)

  return(data.sets)

}



#####################################
## function for tables: stat paper ##
#####################################
get.my.tables.stat.old <- function(all.data,cutoff=50,data.name="cohort"){

  #use.pharos <- TRUE
  use.pharos <- FALSE
  use.predict <- FALSE

  #if(data.name=="pharos"){
  #  use.pharos <- TRUE
  #} 

  if(data.name=="predict"){
    use.predict <- TRUE
  }

  ########################################
  ## convert uniform CAG to regular CAG ##
  ########################################
  all.data$CAG <- convert.cag(all.data$CAG,xmin=36,xmax=cutoff)

  ######################
  ## subjects at risk ##
  ######################
  at.risk <- which(all.data$CAG>=36)
  data.at.risk <- all.data[at.risk,]

  ##########################
  ## subjects not at risk ##
  ##########################
  data.not.at.risk <- all.data[-at.risk,]

  ###############
  ## Data sets ##
  ###############
  data.sets<- list(data.all=all.data,
	data.at.risk=data.at.risk,
	data.not.at.risk=data.not.at.risk)

  ########################
  ## General covariates ##
  ########################
  function.use <- "continuous"

  interest <- c("CAG")
  interest.names <- interest
  covariates.cag <- summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="CAG")

  interest <- c("base_age")
  interest.names <- interest
  covariates.baseage <-  summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="BL Age")

  function.use <- "discrete"
  interest <- "gender"
  interest.names <- "male"
  covariates.gender <-  summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="\\% Males")


  interest <- c("educ_cat")
  interest.names <- interest
  covariates.educ <- summarize.data.sets.covariates(data.sets,
				covariates.interest=interest,
				covariates.names=interest.names,function.use=function.use,
				table.name="\\% Higher Educ")

  cat("\n\n##  CAG ##\n\n")
  foo <- covariates.cag
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

  ## Age at baseline
  cat("\n\n##  AGE AT BL ##\n\n")
  foo <- covariates.baseage
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

 
  ## Gender
  cat("\n\n##  GENDER ##\n\n")
  foo <- covariates.gender
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

  ## Education
  cat("\n\n##  EDUCATION ##\n\n")
  foo <- covariates.educ
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

  #################
  ## motor onset ##
  #################
  onset.ages <- c("hdage_nobase")

  onset.names <- c("When DCL=4 post-BL")

  function.use <- "motor.onset"
  motor.onset.out <- NULL
  for(kk in 1:length(onset.ages)){
     motor.onset.out.tmp <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages[kk],
				onset.names=onset.names[kk],
				function.use=function.use,
				use.pharos=use.pharos,filler=onset.names[kk],
				show.gene.know=FALSE)
    motor.onset.out <- rbind(motor.onset.out,motor.onset.out.tmp)

    ##cat("\n\n## ", onset.names[kk],"##\n\n")
    ##print(xtable(t(onset.out)))
  }

  cat("\n\n## Onset/Gene knowledge ##\n\n")
  foo <- motor.onset.out
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)

####################
## MCI covariates ##
####################
  onset.ages <- c("sdmt")

  onset.names <- c("SDMT score")

  filler.names <- c("When MCI occurs based on SDMT")

  function.use <- "mci.onset"
  mci.onset.out <- NULL
  for(kk in 1:length(onset.ages)){
    mci.onset.out.tmp <- summarize.data.sets.covariates(data.sets,
				covariates.interest=NULL,
				covariates.names=NULL,
				onset.age.use=onset.ages[kk],
				onset.names=onset.names[kk],
				function.use=function.use,
				use.pharos=use.pharos, filler=filler.names[kk],
				show.gene.know=FALSE)
    mci.onset.out <- rbind(mci.onset.out,mci.onset.out.tmp)
    ##cat("\n\n## ", onset.names[kk],"##\n\n")
    ##print(xtable(t(onset.out)))
  }

  cat("\n\n## MCI Onset ##\n\n")
  foo <- mci.onset.out
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)  
}







#####################################################
## new function to summarize tables for stat paper ##
#####################################################
get.censoring <- function(x,digits=2){
  tmp.out <- c(mean(x,na.rm=TRUE),mean(1-x,na.rm=TRUE))*100
  tmp.out <- round(tmp.out,digits)
  out <- paste(tmp.out[1]," (",tmp.out[2],")",sep="")
  return(out)
}

get.my.tables.stat <- function(all.data,zz.use,s.use.names,delta.names,cutoff=50){

  ########################################
  ## convert uniform CAG to regular CAG ##
  ########################################
  all.data$CAG <- convert.cag(all.data$CAG,xmin=36,xmax=cutoff)

  #################
  ## sample size ##
  #################
  sample.size <- nrow(all.data)
  names(sample.size) <- "Sample size"

  #####################
  ## censoring rates ##
  #####################
  censoring.out <- apply(all.data[,delta.names],2,get.censoring)
  names(censoring.out) <- s.use.names
  

  ####################
  ## covariate info ##
  ####################

  info.covariates <- function(name){
    if(name=="base_age"){
      out <- get.mean.sd(all.data[,name],digits=2)
      names(out) <- "Average age at baseline (SD)"
   } else if(name=="CAG"){
      out <- get.mean.sd(all.data[,name],digits=2)
      names(out) <- "Average CAG-repeat length (SD)"
   } else if(name=="gender"){
      out <- round(mean(all.data[,name])*100,digits=2)
      names(out) <- " \\% Male"
   } else if(name=="educ_cat"){
      out <- round(mean(all.data[,name])*100,digits=2)
      names(out) <- " \\% Subjects with $\\geq$ 15 years of education"
   } else if(grepl("gene.*",name)){
     out <- round(mean(all.data[,name])*100,digits=2)
     names(out) <- " \\% Subjects with gene knowledge known"
   }
    return(out)
  }

  aout <- NULL
  cov.use <- c("CAG",zz.use)
  for(ii in 1:length(cov.use)){
    aout <- c(aout,info.covariates(cov.use[ii]))
  }
  
  data.out <- data.matrix(c(sample.size,censoring.out,aout))

  return(data.out)
}






