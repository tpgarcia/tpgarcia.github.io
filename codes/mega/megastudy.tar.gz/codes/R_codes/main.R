#############
## Library ##
#############
#library(Hmisc)
library(xtable)
#library(rgl)
library(abind)  
library(mgcv)
library(gamm4)
library(sandwich)
library(splines)
library(cubature)
library(mnormt)
library(survival)

###################################
## R code for simulation_study.R ##
###################################

#########################
## functions for lists ##
#########################
nrow.apply <- function(x){
  return(nrow(x))
}

length.apply <- function(x){
  return(length(x))
}

double.length.apply <- function(x){
  return(lapply(x,function(y) length(y)))
}

double.get.label <- function(x){
  return(lapply(x,function(y) 1:y))
}

double.null <- function(x){
  return(lapply(x,function(y) is.null(y)))
}

#########################
## true beta and alpha ##
#########################
gt <- function(gtmod,t){
  if(gtmod=="log"){
    out <- log(t/50)
  } else if(gtmod=="all"){
    #out <- 0.002*(t-52)^2
    #out <- (t)^2
    #out <- log(50*t)
    out <- log(t/50)
  } else if(gtmod=="noall"){
    #out <- 0.004*(t-52)^2
    #out <- (t)^2
    out <- log(t/50)
  }
  return(out)
}

gtinv <- function(gtmod,t){
  if(gtmod=="log"){
    out <- 50*exp(t)
  } else if(gtmod=="all"){
    #out <- sqrt(abs(t)) #+ 52
     out <- 50*exp(t)
  } else if(gtmod=="noall"){
    #out <- sqrt(abs(t)) #+ 52
     out <- 50*exp(t)
  }
  return(out)
}


beta.true.value <- function(gtmod,beta0,t){
  out <- beta0 * gt(gtmod,t)
  return(out)
}

alpha.x <- function(a0,axmod,x){
  if(axmod=="line"){
    out <- a0 * x
  } else if(axmod=="all1"){
    out <- 2 * x /(1+exp(-5*(x-0.35)))
  } else if(axmod=="all2"){
    out <- 1 * x /(1+exp(-4*(x-0.35)))
  } else if(axmod=="cohort1"){
    out <- 0.75 *x*sin(x/0.15)+x
  } else if(axmod=="cohort2"){
    out <- 2 * x /(1+exp(-5*(x-0.35)))
  } else if(axmod=="predict1"){
    out <- 1 *x/(1+exp(-5*(x-0.35)))
  } else if(axmod=="predict2"){
    out <- 2 * x /(1+exp(-4*(x-0.35)))
  } else if(axmod=="pharos1"){
    out <- 0.5 *x*sin(x/0.10)
  } else if(axmod=="pharos2"){
    out <- 1.5 *x/(1+exp(-4*(x-0.35)))
  } else if(axmod=="logx"){
    out <- a0*x*log((1.+x))
  } else if(axmod=="expx"){
    out <- a0*x*exp(sin(pi*x-pi/2.)+0.1)
  } else if(axmod=="wah2"){
    out <- a0 *sin(pi * x)
  } else if(axmod=="wah3"){
    out <- a0*x**11.*(10.*(1-x))**6.+a0*(10.*x)**3.*(1-x)**10.
  } else if(axmod=="wah4"){
    out <- a0*x**11.*(10.*(1-x))**6.
  } else if(axmod=="sinx"){
    out <- a0 *sin(x)
  } else if(axmod=="lgit"){
    out <- a0*x/(1+exp(-7.*(x-0.5)))
  }
  return(out)
}


alpha.true <- function(a0,axmod,x,t,gtmod){
  out <- alpha.x(a0,axmod,x)
  out <- out * gt(gtmod,t)
  return(out)
}

get.truth <- function(combi.study,combi.choice,combi.names,real_data,num_study,np,lb,num_time,
	  param.label,beta0int,beta0,gamma.param,omega.param,time_val,num_xx,a0,
          axmod,la,xks,zeval,z.choice,sigmar,sigmau,gtmod,use.random.effects){

  beta.true <- array(0,dim=c(num_study,np,num_time,length(param.label)),
                     dimnames=list(
                       paste("ss",1:num_study,sep=""),
                       paste("np",1:np,sep=""),
                       paste("t",time_val,sep=""),
                       param.label))

  alphas.true <- array(0,dim=c(num_study,np,num_xx,num_time,la),
                       dimnames=list(
                         paste("ss",1:num_study,sep=""),
                         paste("np",1:np,sep=""),
                         paste("xx",1:num_xx,sep=""),
                         paste("t",time_val,sep=""),
                         paste("la",1:la,sep="")))

  Ft.true <- array(0,dim=c(num_study,np,z.choice,num_xx,num_time),
                       dimnames=list(
                         paste("ss",1:num_study,sep=""),
                         paste("np",1:np,sep=""),
                         paste("zz",1:z.choice,sep=""),
                         paste("xx",1:num_xx,sep=""),
                         paste("t",time_val,sep="")))

  if(num_study > 1){
    ## study differences considered only if num_study > 1
    beta.diff <- array(0,dim=c(combi.study,np,num_time,length(param.label)),
                     dimnames=list(
		       combi.names,
                       paste("np",1:np,sep=""),
                       paste("t",time_val,sep=""),
                       param.label))

    alphas.diff <- array(0,dim=c(combi.study,np,num_xx,num_time,la),
                       dimnames=list(
		         combi.names,
                         paste("np",1:np,sep=""),
                         paste("xx",1:num_xx,sep=""),
                         paste("t",time_val,sep=""),
                         paste("la",1:la,sep="")))

    Ft.diff <- array(0,dim=c(combi.study,np,z.choice,num_xx,num_time),
                       dimnames=list(
		         combi.names,
                         paste("np",1:np,sep=""),
                         paste("zz",1:z.choice,sep=""),
                         paste("xx",1:num_xx,sep=""),
                         paste("t",time_val,sep="")))
  } else {
    beta.diff <- NULL
    alphas.diff <- NULL
    Ft.diff <- NULL    
  }

  if(real_data==FALSE){
    if(!is.null(beta0int)){
      ## for intercept term
      for(tt in 1:num_time){
        beta.true[,,tt,"beta0"] <- beta.true.value(gtmod,beta0int,time_val[tt])
      }
    }

    if(!is.null(gamma.param)){
      ## gamma_i term
      for(ii in 1:np){
        for(tt in 1:num_time){
  	  beta.true[,ii,tt,"gamma"] <- beta.true.value(gtmod,gamma.param[ii],time_val[tt])
	}
      }
    }

    if(!is.null(omega.param)){
      ## omega_s term
      for(ss in 1:num_study){
        for(tt in 1:num_time){
	  beta.true[ss,,tt,"omega"] <- beta.true.value(gtmod,omega.param[ss],time_val[tt])
	}
      }
    }

    for(ss in 1:num_study){
      for(ii in 1:np){
        for(tt in 1:num_time){
	  beta.index <- 1:lb[[ss]][[ii]]

          beta.true[ss,ii,tt,paste("beta",beta.index,sep="")] <- beta.true.value(gtmod,
	  				 beta0[[ss]][[ii]],time_val[tt])

          for(xx in 1:num_xx){
            alphas.true[ss,ii,xx,tt,] <- alpha.true(a0[[ss]][ii],
	    			      axmod[[ss]][ii],
	    			      xks[[ss]][xx],time_val[tt],gtmod)

            for(zz in 1:z.choice){
              zeval.tmp <- as.matrix(zeval[ss,zz,ii,])
	      betaz.tmp <- beta.true[ss,ii,tt,paste("beta",beta.index,sep="")] %*% zeval.tmp

	      if(!is.null(beta0int)){
	        betaz.tmp <- betaz.tmp + beta.true[1,1,tt,"beta0"] ## intercept
	      }

	      if(!is.null(gamma.param)){
		betaz.tmp <- betaz.tmp + beta.true[ss,ii,tt,"gamma"] ## gamma_i term
	      }

	      if(!is.null(omega.param)){
	        betaz.tmp <- betaz.tmp + beta.true[ss,ii,tt,"omega"] ## omega_s term
	      }

	      
	      if(use.random.effects==FALSE){ ## no random effects in model
                Ft.true[ss,ii,zz,xx,tt] <- Ft.true.value(betaz=betaz.tmp,
                                                alphastmp=alphas.true[ss,ii,xx,tt,la],
                                                rval=0)
              } else {  ## integrate over random effects
	        Ft.integrate <- 
  	        make.Ft.integrate(alphax=alphas.true[ss,ii,xx,tt,la],
						betaz=betaz.tmp,sigmar,sigmau)
		sigma_all <- c(sigmar,sigmau)

	        if(is.null(sigmau)){
                  Ft.true[ss,ii,zz,xx,tt] <- 
	      			  integrate(Ft.integrate,-Inf,Inf)$value
	        } else {
                  Ft.true[ss,ii,zz,xx,tt] <- 
				  adaptIntegrate(Ft.integrate,
					lower=rep(-1,length(sigma_all)),
					upper=rep(1,length(sigma_all)))$integral
	        }
	      }
            }
          }
        }
      }
    }
  }

  if(num_study > 1){
    ## difference function to compare studies if num_study>1
    mydiff <- function(x){
      x[combi.choice[1,]]-x[combi.choice[2,]]
    }

    if(combi.study==1){
      beta.diff[1,,,] <- apply(beta.true,c(2,3,4),mydiff)
      alphas.diff[1,,,,] <- apply(alphas.true,c(2,3,4,5),mydiff)
      Ft.diff[1,,,,] <- apply(Ft.true,c(2,3,4,5),mydiff)
    } else {
      beta.diff <- apply(beta.true,c(2,3,4),mydiff)
      alphas.diff <- apply(alphas.true,c(2,3,4,5),mydiff)
      Ft.diff <- apply(Ft.true,c(2,3,4,5),mydiff)
    }
  }

  alphas.true.mean <- apply(alphas.true,c(1,2,3,4),mean,drop=FALSE)
  list(beta.true=beta.true,alphas.true=alphas.true,
                alphas.true.mean=alphas.true.mean,
                Ft.true=Ft.true,
		beta.diff=beta.diff,alphas.diff=alphas.diff,
		Ft.diff=Ft.diff)
}


######################################
## function to get common procedure ##
######################################
common.procedure <- function(num_study,count.store,data,num_time,time_val,p,n,nmax,m,
                 maxm,m0_qvs,family.data,common.param.estimation){
    norisk_ind_start <- data$norisk_ind_start
    y_start <- data$y_start
    ymiss_ind_start <- data$ymiss_ind_start
    z_start <- data$z_start
    x_start <- data$x_start
    s_start <- data$s_start
    q_start <- data$q_start
    delta_start <- data$delta_start

    ##print(c(min(s_start),max(s_start)))
    n <- n
    m <- m
    y <- y_start
    ymiss_ind <- ymiss_ind_start
    z <- z_start
    x <- x_start
    s <- s_start
    q <- q_start
    delta <- delta_start

    ## censoring
    print(1-apply(delta,1,sum)/apply(m,1,sum))

    #################################
    ## Apply KM-jacknife estimator ##
    #################################
    kmjack <- get.kmjack(num_study,n,nmax,maxm,num_time,time_val,
    	      p,m0_qvs,y,ymiss_ind,s,q,delta,common.param.estimation)

    ynew <- kmjack$ynew
    #    print(ynew)

    ###################
    ## update counts ##
    ###################

    new.count <- get.count(num_study,n,m,maxm,time_val,num_time,ynew,delta)

   # new.count.tmp <- array(0,dim=c(num_study,num_time,5),
#                               dimnames=list(
#                                       paste("ss",1:num_study,sep=""),
#                                       paste("tt",time_val,sep=""),
#                                       c("time",dimnames(new.count)[[3]])))
    new.count.tmp <- NULL

    for(ss in 1:num_study){
       ##print(ss)
       ss.tmp <- rep(ss,length(time_val))
       my.counts.tmp <- new.count[ss,,]/sum(m[ss,1:n[ss]])
       new.count.tmp <- rbind(new.count.tmp,cbind(ss.tmp,tt=time_val,my.counts.tmp,row.names=NULL))
    }
    count.store <- rbind(count.store,new.count.tmp)

    ##count.store <- abind(count.store,new.count.tmp,along=2)
    ##count.store <- rbind(count.store,cbind(time_val,new.count/sum(m)))

    list(count.store=count.store,n=n,m=m,y=y,
        ymiss_ind=ymiss_ind,z=z,x=x,s=s,q=q,delta=delta,ynew=ynew)
}


################################
## Functions to generate data ##
################################

make.uniform <- function(min=-1,max=1,type="none"){
  if(type=="none"){
    function(nr,par1,par2){
      runif(nr,min=min,max=max)
    }
  } else if(type=="par1"){
    function(nr,par1,par2){
      runif(nr,min=par1,max=max)
    }
  } else if(type=="par2"){
    function(nr,par1,par2){
      runif(nr,min=min,max=par2)
    }
  }
}

make.normal <- function(mean=0,sd=1,type="none"){
  if(type=="none"){
    function(nr,par1,par2){
      rnorm(nr,mean=mean,sd=sd)
    }
  } else if(type=="par2"){
    ## sd changes
    function(nr,par1,par2){
      rnorm(nr,mean=mean,sd=abs(par2))
    }
  } else if(type=="par1"){
    ## mean changes
    function(nr,par1,par2){
      rnorm(nr,mean=par1,sd=sd)
    }
  }
}


make.gamma <- function(shape=1.5,scale=2,type="none"){
  if(type=="none"){
    function(nr,par1,par2){
      rgamma(nr,shape=shape,scale=scale)
    }
  } else if(type=="par1"){
    function(nr,par1,par2){
      rgamma(nr,shape=par1,scale=scale)
    }
  } else if(type=="par2"){
    function(nr,par1,par2){
      rgamma(nr,shape=shape,scale=abs(par2))
    }
  }
}


make.t <- function(df=3,ncp=-2,type="none"){
  if(type=="none"){
    function(nr,par1,par2){
      rt(nr,df=df,ncp=ncp)
    }
  } else if(type=="par1"){
    function(nr,par1,par2){
      rt(nr,df=par1,ncp=ncp)
    }
  } else if(type=="par2"){
    function(nr,par1,par2){
      rt(nr,df=df,ncp=par2)
    }
  }
}

make.mixture.normals <- function(mean1=0,sd1=1,mean2=1,sd2=2,mix=0.5,type="none"){
  if(type=="none"){
    function(nr,par1,par2){
      if(runif(1) < mix){
        rnorm(nr,mean=mean1,sd=sd1)
      } else {
        rnorm(nr,mean=mean2,sd=sd2)
      }
    }
  } else if(type=="par2"){
    function(nr,par1,par2){
      if(runif(1) < mix){
        rnorm(nr,mean=mean1,sd=abs(par2))
      } else {
        rnorm(nr,mean=mean2,sd=abs(par2))
      }
    }
  } else if(type=="gamm"){
    function(nr,par1,par2){
      if(runif(1) < mix){
        rnorm(nr,mean=mean1,sd=sd1)
      } else {
        rgamma(nr,shape=mean2,scale=sd2)
      }
    }
  }
}

## function to compute beta^Tz
get.z.etas <- function(mtmp,lb,beta0int,beta0,gamma.param,omega.param,ztmp){
  out <- rep(0,mtmp)

  for(jj in 1:mtmp){
    if(lb[[jj]] > 1){
      out[jj] <- ztmp[jj,1:lb[[jj]]] %*% beta0[[jj]]
    } else {
      out[jj] <- ztmp[jj] %*% beta0[[jj]]
    }

    if(!is.null(gamma.param)){
      out[jj] <- out[jj] + gamma.param[jj]
    }
  }

  ## add intercept
  if(!is.null(beta0int)){
    out <- out + beta0int
  }

  if(!is.null(omega.param)){
    out <- out + omega.param
  }

  return(out)
}

get.x.etas <- function(m,a0,axmod,x){
  out <- rep(0,m)

  for(jj in 1:m){
    out[jj] <- alpha.x(a0[jj],axmod[jj],x)
  }
  return(out)
}

## uniform Ft
get.unif.Ft <- function(m){
  out <- rep(0,m)
  tol <- 1e-6
  for(kk in 1:m){
    out[kk] <- min(max(runif(1),tol),1-tol)
  }
  return(out)
}


## generate onset ages
invFt <- function(m,etas_z,etas_x,r,Ft,gtmod){
  out <- rep(0,m)
  w <- rep(0,m)

  for(kk in 1:m){
    w[kk] <- etas_z[kk] + etas_x[kk]
    out[kk] <- gtinv(gtmod,(-log(1/Ft[kk]-1)-r)/w[kk])
  }
  return(out)
}


## generate censoring times
genc <- function(onset_age,censorrate){
  if(censorrate==0){
    out <- onset_age + 1
    return(out)
  } else if(censorrate==30){
    # actually this corresponds to 40% censoring
    min_unif <-38
    max_unif <- 80
  } else if(censorrate==50){
    min_unif <- 38
    max_unif <- 65
  }
  out <- runif(1,min=min_unif,max=max_unif)
  return(out)
}

####################################
## Function to get simulated data ##
####################################
simu.data <- function(randomeffects.covariates.dependent,z_tmp.list,
		      x_tmp.list,delta_tmp.list,s_tmp.list,
                      a0,axmod,num_time,censorrate,
                      frform,fzrform,fxform,
                      type_fr,type_fzr,type_fx,
                      par1_fr,par2_fr,
		      par_fu,
		      par1_fr2,par2_fr2,mix_n,
                      par1_fx,par2_fx,
                      par1_fzr,par2_fzr,
                      real_data,time_val,
                      p,beta0int,beta,gamma.param,omega.param,
		      n,nmax,m,maxm,la,lb,num_study,np,gtmod,use.random.effects){

  tol <- 1e-6

  ##########################
  ## set values for output ##
  ############################
  y <- array(0,dim=c(num_study,num_time,nmax,maxm),
             dimnames=list(
               paste("ss",1:num_study,sep=""),
               paste("t",time_val,sep=""),
               paste("n",1:nmax,sep=""),
               paste("m",1:maxm,sep="")))

  ymiss_ind<- y
  ytest <- y   ## for testing pseudo-values

  z <- array(0,dim=c(num_study,nmax,np,lb.max),
             dimnames=list(
               paste("ss",1:num_study,sep=""),
               paste("n",1:nmax,sep=""),
               paste("np",1:np,sep=""),
               paste("lb",1:lb.max,sep="")))

  x <- array(0,dim=c(num_study,nmax),
             dimnames=list(
                paste("ss",1:num_study,sep=""),
                paste("n",1:nmax,sep="")
                ))

  s <- array(0,dim=c(num_study,nmax,maxm),
             dimnames=list(
                paste("ss",1:num_study,sep=""),
                paste("n",1:nmax,sep=""),
                paste("m",1:maxm,sep="")))

  delta <- s
  onset_age_orig <- s
  norisk_ind <- s

  count <- array(0,dim=c(num_study,num_time,3),
                 dimnames=list(
                   paste("ss",1:num_study,sep=""),
                   paste("t",time_val,sep=""),
                   c("one","zero","other")))

  q <- array(0,dim=c(num_study,p,nmax,maxm),
             dimnames=list(
               paste("ss",1:num_study,sep=""),
               paste("p",1:p,sep=""),
               paste("n",1:nmax,sep=""),
               paste("m",1:maxm,sep="")))

  #######################
  ## additional values ##
  #######################
  r <- x
  bb <- x

  etas_z <- s
  etas_x <- s
  Ft <- s
  onset_age <- s
  cens <- s

  ##############################################
  ## mixture probabilities for km jack method ##
  ##############################################
  for(ss in 1:num_study){
    for(i in 1:n[ss]){
      for(j in 1:m[ss,i]){
        q[ss,j,i,j]  <- 1
      }
    }
  }

  if(real_data==FALSE){
    if(!is.null(par_fu)){
      ## u_s random effect (random effect for study)
      fs <- make.normal(mean=par_fu["mean"],sd=par_fu["sd"],type=type_fr)

      ## generate random effect
      us <- fs(num_study,par_fu["mean"],par_fu["sd"])

      ## center random effect
      us <- us - mean(us)
    } else {
      us <- rep(0,num_study)
    }

    if(use.random.effects==FALSE){ ## no random effects	
      us <- rep(0,num_study)
    }

    for(ss in 1:num_study){
      ##########################################
      ## set up functions for generating data ##
      ##########################################
      ## distribution for f_R

      if(frform=="norm"){
        ## R ~ Normal(mean.fr,sd.fr^2)
        fr <- make.normal(mean=par1_fr[ss],sd=par2_fr[ss],type=type_fr)
      } else if(frform=="gamm"){
        ## R ~ Gamma
        fr <- make.gamma(shape=par1_fr[ss],scale=par2_fr[ss],type=type_fr)
      } else if(frform=="unif"){
        ## R ~ uniform
        fr <- make.uniform(min=par1_fr[ss],max=par2_fr[ss],type=type_fr)
      } else if(frform=="tdis"){
        ## R ~ t
        fr <- make.t(df=par1_fr[ss],ncp=par2_fr[ss],type=type_fr)
      } else if(frform=="mixn"){
        ## R ~ mixture of Normals
        fr <- make.mixture.normals(mean1=par1_fr[ss],sd1=par1_fr[ss],
                               mean2=par2_fr2[ss],sd2=par2_fr2[ss],mix=mix_n[ss],type=type_fr)
      }


      ## Set distribution f_Z
      if(fzrform=="norm"){
        ## Z|R ~Normal
        fzr <- make.normal(mean=par1_fzr[ss],sd=par2_fzr[ss],type=type_fzr)
      } else if(fzrform=="unif"){
        fzr <- make.uniform(min=par1_fzr[ss],max=par2_fzr[ss],type=type_fzr)
      }

      ## Set distribution f_X
      if(fxform=="norm"){
        ## Z|R ~Normal
        fx <- make.normal(mean=par1_fx[ss],sd=par2_fx[ss],type=type_fx)
      } else if(fxform=="unif"){
        fx <- make.uniform(min=par1_fx[ss],max=par2_fx[ss],type=type_fx)
      }

      ####################
      ## simulated data ##
      ####################
      if(randomeffects.covariates.dependent==TRUE){
        ## add dependence
        bb[ss,1:n[ss]] <- rnorm(n[ss],sd=0.05)
      } else {
        bb[ss,1:n[ss]] <- rep(0,n[ss])
      }

      ############################
      ## generate random effect ##
      ############################
      if(use.random.effects==TRUE){ ## we generate random effects
        r[ss,1:n[ss]] <- fr(n[ss],par1_fr[ss],par2_fr[ss]) + bb[ss,1:n[ss]]
      }

      ## center random effect, within each study
      #r[ss,1:n[ss]] <- r[ss,1:n[ss]] - mean(r[ss,1:n[ss]])
    }

    ## center random effect
    r <- r - mean(r)

    for(ss in 1:num_study){
      for(i in 1:n[ss]){
        ##print(i)
        ## generate deviate for z-covariates
        for(k in 1:np){
          z[ss,i,k,1:lb[[ss]][[k]]] <- fzr(lb[[ss]][[k]],par1_fzr[ss],par2_fzr[ss]) + bb[ss,i]
        }

        ## generate deviate for x-covariates
        x[ss,i] <- fx(1,par1_fx[ss],par2_fx[ss]) + bb[ss,i]

        ## form z_etas and x_etas
        etas_z[ss,i,1:m[ss,i]] <- get.z.etas(m[ss,i],lb[[ss]],beta0int,beta[[ss]],
			       gamma.param,omega.param[ss],
                               z[ss,i,,])
        etas_x[ss,i,1:m[ss,i]] <- get.x.etas(m[ss,i],a0[[ss]],axmod[[ss]],
                                x[ss,i])

        ########################
        ## generate onset age ##
        ########################
        Ft[ss,i,] <- get.unif.Ft(m[ss,i])
        onset_age[ss,i,] <- invFt(m[ss,i],etas_z[ss,i,],etas_x[ss,i,],r[ss,i]+us[ss],Ft[ss,i,],gtmod)

        for(j in 1:m[ss,i]){
          cens[ss,i,j] <- genc(onset_age[ss,i,j],censorrate=censorrate[ss])

          if(onset_age[ss,i,j] <= cens[ss,i,j]){
            s[ss,i,j] <- onset_age[ss,i,j]
            delta[ss,i,j] <- 1
          } else {
            s[ss,i,j] <- cens[ss,i,j]
            delta[ss,i,j] <- 0
          }
        }
      }
    }
   } else {
      ###############
      ## real data ##
      ###############
      for(ss in 1:num_study){
        for(k in 1:np){
          z[ss,1:n[ss],k,1:lb[[ss]][[k]]] <- z_tmp.list[[ss]][1:n[ss],k,1:1:lb[[ss]][[k]]]
        }
        x[ss,1:n[ss]] <- x_tmp.list[[ss]]
        s[ss,1:n[ss],1:max(m[ss,])] <- s_tmp.list[[ss]]
        delta[ss,1:n[ss],1:max(m[ss,])] <- delta_tmp.list[[ss]]
     }
   }

  ##################
  ## form Y terms ##
  ##################
  for(ss in 1:num_study){
    for(i in 1:n[ss]){
      for(j in 1:m[ss,i]){
        for(tt in 1:num_time){
          if(delta[ss,i,j] > tol){
            ## person not censored
            if(s[ss,i,j] <= time_val[tt]){
              y[ss,tt,i,j] <- 1
              count[ss,tt,1] <- count[ss,tt,1] + 1

               #ytest[ss,tt,i,j] <- 999  ## in no censoring case, pseudo-values agree with 0/1 output
               #ymiss_ind[ss,tt,i,j] <- 1

            } else {
              y[ss,tt,i,j] <- 0
              count[ss,tt,2] <- count[ss,tt,2] + 1

              #ytest[ss,tt,i,j] <- 999
              #ymiss_ind[ss,tt,i,j] <- 1


            }
          } else {

            ## person is censored
            if(s[ss,i,j] >= time_val[tt]){
              # c_ij >= t_0
              y[ss,tt,i,j] <- 0
              count[ss,tt,2] <- count[ss,tt,2] + 1
            } else {
              ## value not observed
              y[ss,tt,i,j] <- 999
              ymiss_ind[ss,tt,i,j] <- 1
              count[ss,tt,3] <- count[ss,tt,3] + 1
            }
          }
        }
      }
    }
  }

  list(y_start=y,ymiss_ind_start=ymiss_ind,
       z_start=z,x_start=x,s_start=s,q_start=q,delta_start=delta,
       onset_age_orig_start=onset_age_orig,
       norisk_ind_start=norisk_ind,count=count,
       ytest=ytest)
}

get.kmjack <- function(num_study,n,nmax,maxm,num_time,time_val,p,m0_qvs,y,ymiss_ind,s,q,
			delta,common.param.estimation){
  ## needs to take in original n for storage

  ## set for f90
  storage.mode(num_time) <- "integer"
  storage.mode(n) <- "integer"
  storage.mode(m) <- "integer"
  storage.mode(maxm) <- "integer"
  storage.mode(time_val) <- "double"
  storage.mode(p) <- "integer"
  storage.mode(m0_qvs) <- "integer"
  storage.mode(y) <- "double"
  storage.mode(ymiss_ind) <- "double"
  storage.mode(s) <- "double"
  storage.mode(q) <- "double"
  storage.mode(delta) <- "double"

  ## output
  ynew_out <- array(0,dim=c(num_study,num_time,nmax,maxm),
             dimnames=list(
               paste("ss",1:num_study,sep=""),
               paste("t",time_val,sep=""),
               paste("n",1:nmax,sep=""),
               paste("m",1:maxm,sep="")))


  if(common.param.estimation==FALSE){ # no common alpha, beta
    for(ss in 1:num_study){
      ynew <- array(0,dim=c(num_time,n[ss],maxm),
             dimnames=list(
               paste("t",time_val,sep=""),
               paste("n",1:n[ss],sep=""),
               paste("m",1:maxm,sep="")))

      storage.mode(ynew) <- "double"

      out <- .Fortran("kmjack",num_time,n[ss],m[ss,1:n[ss]],maxm,
		  time_val,p,m0_qvs,
                  y[ss,,1:n[ss],],ymiss_ind[ss,,1:n[ss],],s[ss,1:n[ss],],
                  q[ss,,1:n[ss],],delta[ss,1:n[ss],],ynew=ynew)
      ynew_out[ss,,1:n[ss],] <- out$ynew
    }
  } else { # common alpha, beta
    n.all <- sum(n)

    m.all <- NULL
    y.all <- NULL
    ymiss_ind.all <- NULL 
    s.all <- NULL
    q.all <- NULL
    delta.all <- NULL
    
    for(ss in 1:num_study){
      m.all <- abind(m.all,m[ss,1:n[ss]],along=1)  
      y.all <- abind(y.all,y[ss,,1:n[ss],],along=2)     
      ymiss_ind.all <- abind(ymiss_ind.all,
      		    ymiss_ind[ss,,1:n[ss],],along=2)   
      s.all <- abind(s.all,s[ss,1:n[ss],],along=1)  
      q.all <- abind(q.all,q[ss,,1:n[ss],],along=2)
      delta.all <- abind(delta.all,delta[ss,1:n[ss],],along=1)     
    }

    ynew <- array(0,dim=c(num_time,n.all,maxm),
             dimnames=list(
               paste("t",time_val,sep=""),
               paste("n",1:n.all,sep=""),
               paste("m",1:maxm,sep="")))

    storage.mode(ynew) <- "double"

    out <- .Fortran("kmjack",num_time,n.all,m.all,maxm,time_val,p,m0_qvs,
                  y.all,ymiss_ind.all,s.all,q.all,delta.all,ynew=ynew)

    tmp <- 0   
    for(ss in 1:num_study){
      ynew_out[ss,,1:n[ss],] <- out$ynew[,(tmp+1):(tmp+n[ss]),]
      tmp <- tmp + n[ss]
    }
  }

  fix.tolerance <- function(a){
    if(abs(a)< 1e-10){
      a <- 0
    }
    return(a)
  }

  ynew_out <- apply(ynew_out,c(1,2,3,4),fix.tolerance)
  

  list(ynew=ynew_out)
}

##################################
## bootstrap to compare studies ##
##################################

boot.compare.studies <- function(combi.study,combi.choice,combi.names,
	   num_study,boot,np,data,num_xx,num_time,time_val,xks,
	   p,n,nmax,m,
           maxm,la,lb,lb.max,a0,axmod,axmod2,truth,real_data,m0_qvs,
           knot.length,
           family.data,zeval,z.choice,
	   param.label,beta0int,gamma.param,omega.param,spline.constrain,common.param.estimation,
	   par_fu,analyze.separately){

  ########################
  ## set up for storage ##
  ########################
  betaest.boot.store <- array(0,dim=c(num_study,boot,np,num_time,
  		     length(param.label)),
                         dimnames=list(
                           paste("ss",1:num_study,sep=""),
                           paste("bb",1:boot,sep=""),
                           paste("np",1:np,sep=""),
                           paste("t",time_val,sep=""),
                           param.label))

  alphasest.boot.store <- array(0,dim=c(num_study,boot,np,
  		       num_xx,num_time,la),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("bb",1:boot,sep=""),
                             paste("np",1:np,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             paste("la",1:la,sep="")))

  Ftest.boot.store <- array(0,dim=c(num_study,boot,np,z.choice,
  		   num_xx,num_time),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("bb",1:boot,sep=""),
                             paste("np",1:np,sep=""),
                             paste("zz",1:z.choice,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep="")))


  beta.diff <- array(0,dim=c(combi.study,boot,np,
                length(time_val),length(param.label)),
                         dimnames=list(
                          combi.names,
			  paste("bb",1:boot,sep=""),
                          paste("np",1:np,sep=""),
                           paste("t",time_val,sep=""),
                           param.label))

  alphas.diff <- array(0,dim=c(combi.study,boot,np,num_xx,num_time,la),
                           dimnames=list(
			     combi.names,
			     paste("bb",1:boot,sep=""),
                             paste("np",1:np,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             paste("la",1:la,sep="")
                             ))




  Ft.diff <- array(0,dim=c(combi.study,boot,np,z.choice,num_xx,num_time),
                           dimnames=list(
                             combi.names,
			     paste("bb",1:boot,sep=""),
                             paste("np",1:np,sep=""),
                             paste("zz",1:z.choice,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep="")
                             ))

  betabootci <- array(0,dim=c(combi.study,np,num_time,
  	     length(param.label),3),
                         dimnames=list(
			   combi.names,
                           paste("np",1:np,sep=""),
                           paste("t",time_val,sep=""),
                           param.label,
                           c("est","lo","hi")))


  alphasbootci <- array(0,dim=c(combi.study,np,num_xx,num_time,la,3),
                           dimnames=list(
			     combi.names,
                             paste("np",1:np,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             paste("la",1:la,sep=""),
                             c("est","lo","hi")))


  Ftbootci <- array(0,dim=c(combi.study,np,z.choice,num_xx,num_time,3),
                           dimnames=list(
                             combi.names,
                             paste("np",1:np,sep=""),
                             paste("zz",1:z.choice,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             c("est","lo","hi")))
  
  count.store <- NULL

  norisk_ind_orig <- data$norisk_ind_start
  y_orig <- data$y_start
  ymiss_ind_orig <- data$ymiss_ind_start
  z_orig <- data$z_start
  x_orig <- data$x_start
  s_orig <- data$s_start
  q_orig <- data$q_start
  delta_orig <- data$delta_start


  ## function to get array
  get.array <- function(x){
    return(array(0,dim=dim(x),dimnames=dimnames(x)))
  }
  norisk_ind_boot <- get.array(norisk_ind_orig)
  y_boot <- get.array(y_orig)
  ymiss_ind_boot <- get.array(ymiss_ind_orig)
  z_boot <- get.array(z_orig)
  x_boot <- get.array(x_orig)
  s_boot <- get.array(s_orig)
  q_boot <- get.array(q_orig)
  delta_boot <- get.array(delta_orig)
  m_boot <- get.array(m)

  bb <- 1
  while(bb <= boot){
    ###########################
    ## get bootstrapped data ##
    ###########################
    for(ss in 1:num_study){
      index.random <- sample(1:n[ss],replace=TRUE)
      norisk_ind_boot[ss,1:n[ss],] <- norisk_ind_orig[ss,index.random,]
      y_boot[ss,,1:n[ss],] <- y_orig[ss,,index.random,]
      ymiss_ind_boot[ss,,1:n[ss],] <- ymiss_ind_orig[ss,,index.random,]
      if(family.data==FALSE){
        z_boot[ss,1:n[ss],,] <- z_orig[ss,index.random,,,drop=FALSE]
        x_boot[ss,1:n[ss]] <- x_orig[ss,index.random,drop=FALSE]
      } else {
        z_boot[ss,1:n[ss],,] <- z_orig[ss,index.random,,]
        x_boot[ss,1:n[ss],] <- x_orig[ss,index.random,]
      }
      s_boot[ss,1:n[ss],] <- s_orig[ss,index.random,]
      q_boot[ss,,1:n[ss],] <- q_orig[ss,,index.random,]
      delta_boot[ss,1:n[ss],] <- delta_orig[ss,index.random,]
      m_boot[ss,1:n[ss]] <- m[ss,index.random]
    }

    data.boot <- list(norisk_ind_start=norisk_ind_boot,
                     y_start=y_boot,
                     ymiss_ind_start=ymiss_ind_boot,
                     z_start=z_boot,
                     x_start=x_boot,
                     s_start=s_boot,
                     q_start=q_boot,
                     delta_start=delta_boot)


    ######################
    ## apply new_method ##
    ######################
    new.boot <- gamm4.estimates(num_study,np,count.store,data.boot,num_time,
                                time_val,p,n,nmax,m,maxm,
                                la,lb,lb.max,xks,truth,m0_qvs,
                                num_xx,knot.length,real_data,
                                family.data,
                                zeval,z.choice,
				param.label,beta0int,gamma.param,omega.param,
				spline.constrain,common.param.estimation,par_fu,analyze.separately)

    eflag <- new.boot$eflag

    check.constraint <- function(theta){
      if(sum(apply(theta,1:length(dim(theta)),function(x) x>100))){
        return(TRUE)
      } else {
        return(FALSE)
      }
    }


    if(eflag!=-1){
       beta.est <- new.boot$betaest
       alphas.est <- new.boot$alphasest
       count.store <- new.boot$count.store
       Ft.est <- new.boot$Ftest

       if(!check.constraint(beta.est) && !check.constraint(alphas.est) && !check.constraint(Ft.est)){


         ###################
  	 ## store results ##
       	 ###################
       	 betaest.boot.store[,bb,,,] <- beta.est
       	 alphasest.boot.store[,bb,,,,] <- alphas.est
       	 Ftest.boot.store[,bb,,,,] <- Ft.est
       	 bb <- bb+1
       } 
    } else {
      ## used for testing.
      cat("crazy boot values, bb=",bb,"\n")
    }
  }

  #####################
  ## get differences ##
  ####################

    ## difference function
    mydiff <- function(x){
      x[combi.choice[1,]]-x[combi.choice[2,]]
    }

    if(combi.study==1){
      beta.diff[1,,,,] <- apply( betaest.boot.store,c(2,3,4,5),mydiff)
      alphas.diff[1,,,,,] <- apply(alphasest.boot.store,c(2,3,4,5,6),
    			   mydiff)
      Ft.diff[1,,,,,] <- apply(Ftest.boot.store,c(2,3,4,5,6),mydiff)
    } else {
      beta.diff <- apply( betaest.boot.store,c(2,3,4,5),mydiff)
      alphas.diff <- apply(alphasest.boot.store,c(2,3,4,5,6),mydiff)
      Ft.diff <- apply(Ftest.boot.store,c(2,3,4,5,6),mydiff)
    }


    #######################
    ## summarize results ##
    #######################
    betadiff.mean <- apply(beta.diff,c(1,3,4,5),mean)
    betadiff.var <- apply(beta.diff,c(1,3,4,5),var)

    betadiff.max.tmp <- sweep(beta.diff,c(1,3,4,5),betadiff.mean,FUN="-")
    betadiff.max.tmp <- sweep(abs(betadiff.max.tmp),c(1,3,4,5),
  		   sqrt(betadiff.var),FUN="/")
    betadiff.max <- apply(betadiff.max.tmp,c(1,2,3,5),max)
    betadiff.max.quantile <- apply(betadiff.max,c(1,3,4),myquantiles)

    betabootci.tmp <- sweep(sqrt(betadiff.var),c(1,2,4),
				betadiff.max.quantile,FUN="*")
    betabootci[,,,,"est"] <- betadiff.mean
    betabootci[,,,,"lo"] <- betadiff.mean - betabootci.tmp
    betabootci[,,,,"hi"] <- betadiff.mean + betabootci.tmp


    ## alphas 
    alphasdiff.mean <- apply(alphas.diff,c(1,3,4,5,6),mean)
    alphasdiff.var <- apply(alphas.diff,c(1,3,4,5,6),var)

    alphasdiff.max.tmp <- sweep(alphas.diff,c(1,3,4,5,6),alphasdiff.mean,FUN="-")
    alphasdiff.max.tmp <- sweep(abs(alphasdiff.max.tmp),c(1,3,4,5,6),
  		   sqrt(alphasdiff.var),FUN="/")
    alphasdiff.max <- apply(alphasdiff.max.tmp,c(1,2,3,4,6),max)
    alphasdiff.max.quantile <- apply(alphasdiff.max,c(1,3,4,5),myquantiles)

    alphasbootci.tmp <- sweep(sqrt(alphasdiff.var),c(1,2,3,5),
				alphasdiff.max.quantile,FUN="*")
    alphasbootci[,,,,,"est"] <- alphasdiff.mean 
    alphasbootci[,,,,,"lo"] <- alphasdiff.mean - alphasbootci.tmp
    alphasbootci[,,,,,"hi"] <- alphasdiff.mean + alphasbootci.tmp


    ## Ft 
    Ftdiff.mean <- apply(Ft.diff,c(1,3,4,5,6),mean)
    Ftdiff.var <- apply(Ft.diff,c(1,3,4,5,6),var)

    Ftdiff.max.tmp <- sweep(Ft.diff,c(1,3,4,5,6),
  		     	Ftdiff.mean,FUN="-")
    Ftdiff.max.tmp <- sweep(abs(Ftdiff.max.tmp),c(1,3,4,5,6),
  		   sqrt(Ftdiff.var),FUN="/")
    Ftdiff.max <- apply(Ftdiff.max.tmp,c(1,2,3,4,5),max) ## this is difference with alphas.diff
    Ftdiff.max.quantile <- apply(Ftdiff.max,c(1,3,4,5),myquantiles)

    Ftbootci.tmp <- sweep(sqrt(Ftdiff.var),c(1,2,3,4),Ftdiff.max.quantile,FUN="*") 
  	       	  				## this is difference with alphas.diff
    Ftbootci[,,,,,"est"] <- Ftdiff.mean 
    Ftbootci[,,,,,"lo"] <- Ftdiff.mean - Ftbootci.tmp
    Ftbootci[,,,,,"hi"] <- Ftdiff.mean + Ftbootci.tmp


  list(betabootci=betabootci,
       alphasbootci=alphasbootci,
       Ftbootci=Ftbootci,
        count.store.boot=count.store)
}


###################
## get new count ##
###################
get.count <- function(num_study,n,m,maxm,time_val,num_time,ynew,delta){
  ## storage for f90
  storage.mode(n) <- "integer"
  storage.mode(m) <- "integer"
  storage.mode(maxm) <- "integer"
  storage.mode(num_time) <- "integer"
  storage.mode(ynew) <- "double"
  storage.mode(delta) <- "double"

  count_new_out <- array(0,dim=c(num_study,num_time,4),
                     dimnames=list(
                       paste("ss",1:num_study,sep=""),
                       paste("t",time_val,sep=""),
                       c("one","zero_nocens","zero_cens","other")))

  tmp <- array(0,dim=c(num_time,4),
                     dimnames=list(
                       paste("t",time_val,sep=""),
                       c("one","zero_nocens","zero_cens","other")))

  for(ss in 1:num_study){
    count_new <- tmp
    storage.mode(count_new) <- "double"

    out <- .Fortran("get_count_new",n[ss],m[ss,1:n[ss]],maxm,num_time,ynew[ss,,1:n[ss],],
                        delta[ss,1:n[ss],],count_new=count_new)
    count_new_out[ss,,] <- out$count_new
  }

  return(count_new_out)
}

##+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
## Functions for gamm4
##+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+--+

## put NAs into data set
get.nas <- function(n,m,ynew,z,x){
  ynew2 <- ynew[,1:n,,drop=FALSE]
  z2 <- z[1:n,,,drop=FALSE]
  m <- m[1:n]
  x <- x[1:n]

  maxm <- max(m)
  for(i in 1:n){
      if(m[i]<maxm){
        ynew2[,i,(m[i]+1):maxm] <- NA
     }
  }
  list(m=m,ynew=ynew2,z=z2,x=x)
}

##################################
## make empty lists for storage ##
##################################
get.empty.list <- function(names){
  out <-  vector("list",length(names))
  names(out) <- names
  return(out)
}


make.data.set <- function(num_study,time_val,n,nmax,
				m,lb,y,x,z,nn,real_data,
				gamma.param,omega.param){
  names <- paste("ss",1:num_study,sep="")
  study.list <- get.empty.list(names)
  family.list <- get.empty.list(names)
  yy.list <- get.empty.list(names)
  x.list <- get.empty.list(names)
  z.list <- get.empty.list(names)
  gamma.list <- get.empty.list(names)
  omega.list <- get.empty.list(names)

  for(ss in 1:num_study){

    ###################
    ## get NA values ##
    ###################
    out.na <- get.nas(n[ss],m[ss,],y[ss,,,],adrop(z[ss,,,,drop=FALSE],drop=1),x[ss,])
    m_ss <- out.na$m
    y_ss <- out.na$ynew
    z_ss <- out.na$z
    x_ss <- out.na$x

    ## vector indicating which study each observation belongs
    study <- rep(ss,times=sum(m_ss))
    study.list[[ss]] <- study


    ## vector indicating which family each observation belongs
    family <- rep(1:n[ss],times=m_ss)
    family.list[[ss]] <- family

    yy <- array(0,dim=c(sum(m_ss),length(time_val)),
              dimnames=list(paste("i",1:sum(m_ss),sep=""),
                paste("t",time_val,sep="")))

    for(tt in 1:length(time_val)){
      ## make  y into a vector of values
      new.y <- as.vector(t(y_ss[tt,,]))
      new.y <- as.vector(na.omit(new.y))
      yy[,tt] <- new.y
    }

    yy.list[[ss]] <- yy

    new.x <- NULL
    for(i in 1:n[ss]){
      tmp.x <- matrix(0,m_ss[i],m_ss[i])
      diag(tmp.x) <- x_ss[i]
      new.x <- rbind(new.x,tmp.x)
    }
    x.list[[ss]] <- new.x

    if(!is.null(gamma.param)){
      ## design matrix for gamma parameters
      new.gamma <- NULL
      for(i in 1:n[ss]){
        tmp.gamma <- matrix(0,m_ss[i],m_ss[i])
        diag(tmp.gamma) <- 1
	tmp.gamma <- as.matrix(tmp.gamma[,-1])
        new.gamma <- rbind(new.gamma,tmp.gamma)
      }
      gamma.list[[ss]] <- new.gamma
    }

    if(!is.null(omega.param)){
      ## design matrix for omega parameters
      if(ss!=1){
        omega.list[[ss]] <- rep(1,n[ss])
      } else {
        omega.list[[ss]] <- rep(0,n[ss])
      }
    }

    ## make z into a matrix of values
    z.values <- NULL
    for(i in 1:n[ss]){
      tmp.z <- matrix(0,nrow=m_ss[i],ncol=sum(unlist(lb[[ss]])))
      tmp.index <- 1
      for(k in 1:length(lb[[ss]])){
        tmp.z[k,tmp.index:(tmp.index+lb[[ss]][[k]]-1)] <- z_ss[i,k,1:lb[[ss]][[k]]]
        tmp.index <- tmp.index + lb[[ss]][[k]]
      }
      z.values <- rbind(z.values,tmp.z)
    }

    ## get names
    z.names <- NULL
    lb.tmp <- unlist(lb[[ss]])
    for(k in 1:length(lb.tmp)){
      z.names <- c(z.names,paste(paste("Z",k,"_",sep=""),1:lb.tmp[k],sep=""))
    }
    colnames(z.values) <- z.names

    z.list[[ss]] <- z.values
  }

  list(study=study.list,family=family.list,
        yy=yy.list,new.x=x.list,z.values=z.list,
	gamma.list=gamma.list,omega.list=omega.list)
}

get.data.gamm <- function(n,m,num_study,tt,study,family,y,new.x,z.values,
			gamma.list,omega.list,
			beta0int,gamma.param,omega.param,common.param.estimation){

  data.set.out <- NULL
  xx.names <- NULL
  zz.names <- NULL
  omega.names <- NULL
  gamma.names <- NULL

  for(ss in 1:num_study){

    data.set.tmp <- data.frame(cbind(study[[ss]],family[[ss]],y[[ss]][,tt]))
    colnames(data.set.tmp) <- c("study","family","Y")
    data.set.out <- rbind(data.set.out,data.set.tmp)

    if(common.param.estimation==FALSE){ # no common alpha, beta
      xx.names <- c(xx.names,paste("study_",ss,"_X_",1:ncol(new.x[[ss]]),sep=""))
      zz.names <- c(zz.names,paste("study_",ss,"_",colnames(z.values[[ss]]),sep=""))

      if(!is.null(omega.param)){
        if(ss!=1){
          omega.names <- c(omega.names,paste("study_",ss,"_omega_Z",sep=""))
        }	
      }
    } else { # common alpha,beta
      xx.names <- paste("X_",1:ncol(new.x[[ss]]),sep="")
      zz.names <- paste(colnames(z.values[[ss]]),sep="")
    }
  }

  if(!is.null(gamma.param)){
    gamma.names <- paste("gamma_",1:ncol(gamma.list[[1]])+1,"_Z",sep="")
  }

  ########################################################
  ## Create X and Z part, gamma and omega design matrix ##
  ########################################################

  xx_tmp <- array(0,dim=c(nrow(data.set.out),length(xx.names)),
                        dimnames=list(rownames(data.set.out),xx.names))
  zz_tmp <- array(0,dim=c(nrow(data.set.out),length(zz.names)),
                        dimnames=list(rownames(data.set.out),zz.names))
  gamma_tmp <- array(0,dim=c(nrow(data.set.out),length(gamma.names)),
                        dimnames=list(rownames(data.set.out),gamma.names))
  omega_tmp <- array(0,dim=c(nrow(data.set.out),length(omega.names)),
                        dimnames=list(rownames(data.set.out),omega.names))

  index_tmp <- 1

  for(ss in 1:num_study){
    if(common.param.estimation==FALSE){
      xx.names.tmp <- paste("study_",ss,"_X_*",sep="")
    } else {
      xx.names.tmp <- paste("X_*",sep="")
    }
    index.xx.names <- grep(glob2rx(xx.names.tmp),colnames(xx_tmp))
    xx_tmp[index_tmp:(index_tmp+sum(m[ss,1:n[ss]])-1),index.xx.names] <- new.x[[ss]]

    if(common.param.estimation==FALSE){
      zz.names.tmp  <- paste("study_",ss,"_Z*",sep="")
    } else {
      zz.names.tmp  <- paste("Z*",sep="")
    }
    index.zz.names <- grep(glob2rx(zz.names.tmp),colnames(zz_tmp))
    zz_tmp[index_tmp:(index_tmp+sum(m[ss,1:n[ss]])-1),index.zz.names] <- z.values[[ss]]

    if(!is.null(gamma.param)){
      ## gamma data matrix
      gamma_tmp[index_tmp:(index_tmp+sum(m[ss,1:n[ss]])-1),] <- gamma.list[[ss]]
    }

    if(!is.null(omega.param)){
      if(common.param.estimation==FALSE & ss!=1){
        omega.names.tmp <- paste("study_",ss,"_omega_Z",sep="")
        index.omega.names <- grep(glob2rx(omega.names.tmp),colnames(omega_tmp))
        omega_tmp[index_tmp:(index_tmp+sum(m[ss,1:n[ss]])-1),index.omega.names] <- omega.list[[ss]]
      }
    }

    index_tmp <- sum(m[ss,1:n[ss]])+ index_tmp
  }

  if(!is.null(beta0int)){
    ## for intercept
    zz_tmp <- cbind(1,zz_tmp)
    colnames(zz_tmp)[1] <- "Z0"
  }

  data.set.out <- cbind(data.set.out,gamma_tmp,omega_tmp,xx_tmp,zz_tmp)
  data.set.out$study <- as.factor(data.set.out$study)
  data.set.out$family <- as.factor(data.set.out$family)

  tmp.np <- NULL
  for(ss in 1:num_study){
    for(ii in 1:n[ss]){
      tmp.np <- c(tmp.np,1:m[ss,ii])
    }
  }

  data.set.out$np <- as.factor(tmp.np)

  ## including the term R_si
  data.set.out <- transform(data.set.out,int=interaction(data.set.out$study,data.set.out$family))

  return(data.set.out)
}


## function to append lists
appendList <- function (x, val){
  stopifnot(is.list(x), is.list(val))
  xnames <- names(x)
  for (v in names(val)) {
    x[[v]] <- if (v %in% xnames && is.list(x[[v]]) && is.list(val[[v]]))
      appendList(x[[v]], val[[v]])
    else c(x[[v]], val[[v]])
  }
  x
}


## gamm.mle with the constraint: ax=0 at x=0
gamm.mle.new <- function(num_study,np,lb,num_xx,xks,
                        data.gamm,
                        knot.length,zeval,z.choice,real_data,
			param.label,beta0int,gamma.param,omega.param,
			spline.constrain,common.param.estimation,
			par_fu,random.effect){

  beta.est <- array(0,dim=c(num_study,np,length(param.label)),
                         dimnames=list(
                           paste("ss",1:num_study,sep=""),
                           paste("np",1:np,sep=""),
                           param.label))

  beta.var <- beta.est

  alphas.est <- array(0,dim=c(num_study,np,num_xx,la),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("la",1:la,sep="")))
  alphas.var <- alphas.est

  alphas_ij <- NULL
  Ft_ij <- NULL
  
#  alphas_ij <- array(0,dim=c(num_study,np,nmax,la),
#                           dimnames=list(
#                           paste("ss",1:num_study,sep=""),
#                           paste("np",1:np,sep=""),
#                           paste("n",1:nmax,sep=""),
#                           paste("la",1:la,sep="")))

  alphas_ij_var <- alphas_ij

#  Ft_ij <- array(0,dim=c(num_study,np,nmax),
#                           dimnames=list(
#                           paste("ss",1:num_study,sep=""),
#                           paste("np",1:np,sep=""),
#                           paste("n",1:nmax,sep="")))
#
  Ft_ij_var <- Ft_ij

  Ft.est <- array(0,dim=c(num_study,np,z.choice,num_xx),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("zz",1:z.choice,sep=""),
                             paste("xx",1:num_xx,sep="")))

  Ft.var <- Ft.est

  ######################
  ## adjust data.gamm ##
  ######################
  znam.orig <- colnames(data.gamm)[grep(glob2rx("*Z*"),colnames(data.gamm))]
  znam <- znam.orig

  if(spline.constrain==TRUE){
    ##################################
    ## make empty lists for storage ##
    ##################################
    xnam.orig <- NULL
    XX.list <- NULL
    knots.list.full <- list()
    pen.list.full <- list()

    if(common.param.estimation==FALSE){ # no common beta,alpha
      for(ss in 1:num_study){
        ###################################################
    	## add constraint for spline to go through (0,0) ##
      	###################################################
      	names <- paste("study_",ss,"_nn",1:np,sep="")
      	knots.list <- get.empty.list(names)

      	names.X <- paste("study_",ss,"_XX",1:np,"_",sep="")
      	pen.list <- get.empty.list(names.X)

	for(nn in 1:np){
          ## Create a spline basis and penalty, making sure there is a knot
      	  ## at the constraint point, (0 here, but could be anywhere)

      	  ## we suppose X is on [0,1], may need to change!
          knots.list[[nn]] <- data.frame(x=seq(0,1,length=knot.length[nn]))

          index.X <- which(colnames(data.gamm)==paste("study_",ss,"_X_",nn,sep=""))
          colnames(data.gamm)[index.X] <- "X"

          sm <- smoothCon(s(X,k=knot.length[nn],bs="cr"),
                        data.gamm,knots=knots.list[[nn]])[[1]]


          ## 1st parameters is value of spline at knot location 0.
          ## set it to 0 by dropping...
      	  XX.tmp <- paste("study_",ss,"_XX",nn,"_",sep="")

          assign(XX.tmp,sm$X[,-1],envir=globalenv())    ## spline basis
          XX.list <- c(XX.list,XX.tmp)

          S.tmp <- sm$S[[1]][-1,-1]   ## spline penalty
          pen.list[[nn]] <- list(S.tmp)

          colnames(data.gamm)[index.X] <- paste("study_",ss,"_X_",nn,sep="")
        }
      	knots.list.full <- appendList(knots.list.full,knots.list)
      	pen.list.full <- appendList(pen.list.full,pen.list)
      }
    } else { # common beta, alpha
      ###################################################
      ## add constraint for spline to go through (0,0) ##
      ##################################################
      names <- paste("nn",1:np,sep="")
      knots.list <- get.empty.list(names)

      names.X <- paste("XX",1:np,"_",sep="")
      pen.list <- get.empty.list(names.X)

      for(nn in 1:np){
        ## Create a spline basis and penalty, making sure there is a knot
        ## at the constraint point, (0 here, but could be anywhere)

        ## we suppose X is on [0,1], may need to change!
        knots.list[[nn]] <- data.frame(x=seq(0,1,length=knot.length[nn]))

        index.X <- which(colnames(data.gamm)==paste("X_",nn,sep=""))
        colnames(data.gamm)[index.X] <- "X"

        sm <- smoothCon(s(X,k=knot.length[nn],bs="cr"),  ## cubic spline
                        data.gamm,knots=knots.list[[nn]])[[1]]


        ## 1st parameters is value of spline at knot location 0.
        ## set it to 0 by dropping...
        XX.tmp <- paste("XX",nn,"_",sep="")

        assign(XX.tmp,sm$X[,-1],envir=globalenv())    ## spline basis
        XX.list <- c(XX.list,XX.tmp)

        S.tmp <- sm$S[[1]][-1,-1]   ## spline penalty
        pen.list[[nn]] <- list(S.tmp)

        colnames(data.gamm)[index.X] <- paste("X_",nn,sep="")
      }
      knots.list.full <- appendList(knots.list.full,knots.list)
      pen.list.full <- appendList(pen.list.full,pen.list)
    }
    fmla <- as.formula(paste("Y~-1+",paste(znam.orig,collapse="+"),"+",paste(XX.list,collapse="+")))
    eflag <- 0

    ## for random intercept
    random.formula <- as.formula(paste("~1"))

    ## for random intercept + slope
    ## random.formula <- as.formula(paste("~1+",paste(znam.orig,collapse="+")))

    if( sum( abs(data.gamm$Y)<1  & abs(data.gamm$Y)>0 ) > 0   ){
      ## some Y's are fractional
      aout <- tryCatch(
        {
          if(random.effect=="none"){## no random effect
            fm <- gam(fmla,data=data.gamm,paraPen=pen.list.full,
               family=quasibinomial(link=logit), ## quasi
               verbose=FALSE)#,niterPQL=100)

	    fm$gam <- fm
          } else if(random.effect=="event"){  ## random effect for event only
            fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
               family=quasibinomial(link=logit), ## quasi
               random=list(family=~1),verbose=FALSE)#,niterPQL=100)
	  } else if(random.effect=="study"){  ## random effect for study only
	    if(is.null(par_fu)){
              fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
                family=quasibinomial(link=logit), ## quasi
                random=list(study=~1),verbose=FALSE)#,niterPQL=100)
	    } else {
              fm <- gam(fmla,data=data.gamm,paraPen=pen.list.full,
                family=quasibinomial(link=logit), ## quasi
                verbose=FALSE)#,niterPQL=100)
	    }
          } else if(random.effect=="studyevent"){  ## random effect for event and study?
            if(is.null(par_fu)){
	      ## setup is for random intercept r_si 
              fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
               family=quasibinomial(link=logit), ## quasi
               random=list(int=random.formula),verbose=FALSE)#,niterPQL=100)
	    } else {
	      ## setup is for random intercept r_si + u_s
              fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
               family=quasibinomial(link=logit),  ## quasi
               random=list(study=~1,family=~1),verbose=FALSE)#,niterPQL=100)
	    }
          }    
        }, error=function(e){
		cat("ERROR:", conditionMessage(e),"\n")
		eflag=-1
		return(eflag)}
		)
      if(!is.list(aout)){
	    eflag <- aout
      }
    } else {
       ## Y's are not fractional
        if(random.effect=="none"){## no random effect
	  fm <- gam(fmla,data=data.gamm,paraPen=pen.list.full,
               family=binomial(link=logit),
               verbose=FALSE)#,niterPQL=100)
	  fm$gam <- fm
        } else if(random.effect=="event"){  ## random effect for event only
          fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
               family=binomial(link=logit), ## quasi
               random=list(family=~1),verbose=FALSE)#,niterPQL=100)
        } else if(random.effect=="study"){  ## random effect for study only
	    if(is.null(par_fu)){
              fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
                family=binomial(link=logit), ## quasi
                random=list(study=~1),verbose=FALSE)#,niterPQL=100)
	    } else {
              fm <- gam(fmla,data=data.gamm,paraPen=pen.list.full,
                family=binomial(link=logit), ## quasi
                verbose=FALSE)#,niterPQL=100)
	    }
        } else if(random.effect=="studyevent"){  ## random effect for event and study?
          if(is.null(par_fu)){
            ## setup is for random intercept r_si ONLY
            fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
               family=binomial(link=logit), 
               random=list(int=random.formula),verbose=FALSE)#,niterPQL=100)
	  } else {
            ## setup is for random intercept r_si + u_s
            fm <- gamm(fmla,data=data.gamm,paraPen=pen.list.full,
               family=binomial(link=logit),
               random=list(study=~1,family=~1),verbose=FALSE)#,niterPQL=100)
	  }
        }
     }
  } else {
    ## no constraint
    xnam.orig <- colnames(data.gamm)[grep(glob2rx("*X*"),colnames(data.gamm))]
    xnam <- paste("s(",xnam.orig,")",sep="")    

    fmla <- as.formula(paste("Y~-1+",paste(znam,collapse="+"),"+",paste(xnam,collapse="+")))

    
    if(random.effect=="event"){
      random.formula <- as.formula(paste("~(1|family)",sep=""))
    } else if(random.effect=="study"){
      random.formula <- as.formula(paste("~(1|study)",sep=""))
    } else if(random.effect=="studyevent"){
      if(is.null(par_fu)){
        ## for partially crossed random effects
        random.formula <- as.formula(paste("~(1|study:family)",sep=""))
      } else {
        ## for random effects: study + study:family
        random.formula <- as.formula(paste("~(1|study/family)",sep=""))
      }
    }

    ## setup is for random intercept ONLY
    if( sum( abs(data.gamm$Y)<1  & abs(data.gamm$Y)>0 ) > 0   ){
      if(random.effect=="none"){  ## no random effect
        ## some Y's are fractional
        fm <- gam(fmla,data=data.gamm,family=quasibinomial(link=logit)) ##quasi
	fm$gam <- fm
      } else {
        ## some Y's are fractional
        fm <- gamm4(fmla,data=data.gamm,family=quasibinomial(link=logit), ##quasi
	      random=random.formula)
        # ## PQL fails to converge
        # fm <- gamm(fmla,data=data.gamm,
        #            family=quasibinomial(link=logit),
        #            random=list(family=~1),verbose=FALSE)

      }
    } else {
      if(random.effect=="none"){  ## event analyzed separately, no random effect
        fm <- gam(fmla,data=data.gamm,family=binomial)
	fm$gam <- fm
      } else {
        fm <- gamm4(fmla,data=data.gamm,family=binomial,random=random.formula)
      }
    }
  }


  if(eflag!=-1){
    ##################################
    ## get beta, alpha, Ft estimate ##
    ##################################

    thetas.est <- theta.prediction(num_study,np,xx=xks,zz.val=NULL,
                        fm,knot.length,knots.list.full,lb,
			xnam.orig,znam.orig,zeval,z.choice,
			param.label,beta0int,gamma.param,omega.param,
			spline.constrain,common.param.estimation,par_fu,random.effect)
    beta.est <- thetas.est$beta.est
    beta.var <- thetas.est$beta.var
    alphas.est[,,,la] <- thetas.est$alphas.est
    alphas.var[,,,la] <- thetas.est$alphas.var
    Ft.est <- thetas.est$Ft.est
    Ft.var <- thetas.est$Ft.var
  }


  list(beta.est=beta.est,beta.var=beta.var,
       alphas.est=alphas.est,alphas.var=alphas.var,
       alphas_ij=alphas_ij,alphas_ij_var=alphas_ij_var,
       Ft_ij=Ft_ij,Ft_ij_var=Ft_ij_var,
       Ft.est=Ft.est,Ft.var=Ft.var,eflag=eflag)
}


##########################################
## function to predict beta,alpha(x),Ft ##
##########################################
theta.prediction <- function(num_study,np,xx,zz.val,
                        fm,knot.length,knots.list.full,lb,
			xnam.orig,znam.orig,zeval,z.choice,
			param.label,beta0int,gamma.param,omega.param,
			spline.constrain,common.param.estimation,par_fu,random.effect){

  num_xx <- max(unlist(lapply(xx,length.apply)))

  beta.est <- array(0,dim=c(num_study,np,length(param.label)),
                         dimnames=list(
                           paste("ss",1:num_study,sep=""),
                           paste("np",1:np,sep=""),
                           param.label))
  beta.var <- beta.est

  alphas.est <- array(0,dim=c(num_study,np,num_xx),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("xx",1:num_xx,sep="")))

  alphas.var <- alphas.est

  if(is.null(z.choice)){
    Ft.est <- array(0,dim=c(num_study,np,num_xx),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("xx",1:num_xx,sep="")))
  } else {
    Ft.est <- array(0,dim=c(num_study,np,z.choice,num_xx),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("zz",1:z.choice,sep=""),
                             paste("xx",1:num_xx,sep="")))
  }
  dFt.est <- Ft.est

  Ft.var <- Ft.est

  coef.names <- names(fm$gam$coefficients)

  if(random.effect!="none"){ ## we have random effects
    ## standard devation for random intercept only
    if(spline.constrain==TRUE){
      if(is.null(par_fu)){
        sigmar <- as.numeric(VarCorr(fm$lme)["(Intercept)","StdDev"])
        sigmau <- NULL
      } else {
        tmp.sigma <- as.numeric(VarCorr(fm$lme)[,"StdDev"])
        tmp.sigma <- tmp.sigma[!is.na(tmp.sigma)][1:2]
        sigmau <- tmp.sigma[1]
        sigmar <- tmp.sigma[2]
      }
    } else {
      mycor <- data.frame(VarCorr(fm$mer),row.names=1)
      sigmar <- mycor["study:family","sdcor"]
      if(is.null(par_fu)){
        sigmau <- NULL      
      } else {
        sigmau <- mycor["study","sdcor"]
      }
    }
  }

  if(spline.constrain==FALSE){
    ## won't work with xks as a list!!
    newdata <- data.frame(cbind(matrix(rep(1,length(xks)*length(znam.orig)),ncol=length(znam.orig)),
    	       matrix(rep(xks,length(xnam.orig)),ncol=length(xnam.orig))))
    colnames(newdata) <- c(znam.orig,xnam.orig)
    my.predict <- predict(fm$gam,newdata,type="terms",se.fit=TRUE) ## directly gets \wh alpha(x)
    my.predict2 <- predict(fm$gam,newdata,type="lpmatrix") ## used to form \wh alpha(x)=a* B(x)
  }

  if(!is.null(beta0int)){
    ## for intercept
    index.use.int <- which(coef.names=="Z0")    
    beta.est[,,"beta0"] <- summary(fm$gam)$p.coef[index.use.int]
    beta.var[,,"beta0"] <- summary(fm$gam)$se[index.use.int]^2
  } else {
    index.use.int <- NULL
  }

  for(ss in 1:num_study){
    for(nn in 1:np){
      
      ## get gamma estimate
      if(!is.null(gamma.param) && nn!=1){
        gamma.tmp <- paste("gamma_",nn,"_Z",sep="")
	index.use.gamma <- grep(glob2rx(gamma.tmp),coef.names)
        beta.est[ss,nn,"gamma"] <- summary(fm$gam)$p.coef[index.use.gamma]       
        beta.var[ss,nn,"gamma"] <- summary(fm$gam)$se[index.use.gamma]^2
      } else {
        index.use.gamma <- NULL
      }

      ## get omega estimate
      if(!is.null(omega.param) && ss!=1){
        omega.tmp <- paste("study_",ss,"_omega_Z",sep="")
	index.use.omega <- grep(glob2rx(omega.tmp),coef.names)
        beta.est[ss,nn,"omega"] <- summary(fm$gam)$p.coef[index.use.omega]       
        beta.var[ss,nn,"omega"] <- summary(fm$gam)$se[index.use.omega]^2
      } else {
        index.use.omega <- NULL
      }

      ## get other beta estimates
      beta.index <- paste("beta",1:lb[[ss]][[nn]],sep="")
      if(common.param.estimation==FALSE){ # no common beta, alpha
        ZZ.tmp <- paste("study_",ss,"_Z",nn,"_*",sep="")
      } else { # common beta, alpha
        ZZ.tmp <- paste("Z",nn,"_*",sep="")
      }
      index.use.z <- grep(glob2rx(ZZ.tmp),coef.names)

      ## get beta estimate
      beta.est[ss,nn,beta.index] <- summary(fm$gam)$p.coef[index.use.z]
      beta.var[ss,nn,beta.index] <- summary(fm$gam)$se[index.use.z]^2

      ## get alpha estimates
      if(spline.constrain==TRUE){
        if(common.param.estimation==FALSE){ # no common beta, alpha
          XX.tmp <- paste("study_",ss,"_XX",nn,"_*",sep="")
	} else { # common beta, alpha
          XX.tmp <- paste("XX",nn,"_*",sep="")
	}
        index.use.x <- grep(glob2rx(XX.tmp),coef.names)

	if(common.param.estimation==FALSE){ # no common beta, alpha
          index.knots.use <- which(names(knots.list.full)==paste("study_",ss,"_nn",nn,sep=""))
 	} else { # common beta, alpha
          index.knots.use <- which(names(knots.list.full)==paste("nn",nn,sep=""))
	}
	xx.tmp <- xx[[ss]]
        sm.predict <- smoothCon(s(xx.tmp,k=knot.length[nn],bs="cr"),
                        data.frame(xx.tmp),knots=knots.list.full[[index.knots.use]])[[1]]
        xx.spline <- sm.predict$X[,-1]
      } else {
        ## unconstrained
	if(common.param.estimation==FALSE){ # no common beta, alpha
	  XX.tmp <- paste("s(study_",ss,"_X_",nn,").*",sep="")
	} else { # common beta, alpha
	  XX.tmp <- paste("s(X_",nn,").*",sep="")
	}

	index.use.x <- grep(glob2rx(XX.tmp),coef.names)
	xx.spline <- my.predict2[,index.use.x]
      }

      alphas.est[ss,nn,1:length(xks[[ss]])] <- as.numeric(xx.spline %*% 
      					       fm$gam$coefficients[index.use.x])
      if(spline.constrain==FALSE){
        ## adjust for identifiability constraint
	alphas.est[ss,nn,1:length(xks[[ss]])] <- alphas.est[ss,nn,1:length(xks[[ss]])] + 
			      	 		mean(alphas.est[ss,nn,1:length(xks[[ss]])])
      }

      alphas.var.tmp  <- xx.spline %*% fm$gam$Vp[index.use.x,index.use.x] %*% t(xx.spline)
      alphas.var[ss,nn,1:length(xks[[ss]])] <- diag( alphas.var.tmp )

      
      index.use <- c(index.use.int,index.use.gamma,index.use.omega,index.use.z,index.use.x)

      ## get Ft estimates

      if(!is.null(z.choice)){
        for(kk in 1:z.choice){
          zeval.tmp <- as.matrix(zeval[ss,kk,nn,1:lb[[ss]][[nn]]])
          betaz <- rep(beta.est[ss,nn,beta.index] %*% zeval.tmp,
	  	   				  length(alphas.est[ss,nn,1:length(xks[[ss]])]))
	  ## for intercept
	  if(!is.null(beta0int)){
	    betaz <- betaz + beta.est[1,1,"beta0"]
	  }

	  ## for gamma parameter
	  if(!is.null(gamma.param) && nn!=1){
	    betaz <- betaz + beta.est[ss,nn,"gamma"]
	  }

	  ## for omega parameter
	  if(!is.null(omega.param) && ss!=1){
	    betaz <- betaz + beta.est[ss,nn,"omega"]
	  }

          for(jj in 1:length(xx[[ss]])){
	    if(random.effect=="none"){ ## event analyzed separately, no random effects
	      rval.tmp <- 0
              Ft.est[ss,nn,kk,jj] <- Ft.true.value(betaz=betaz[jj],
                                             alphastmp=alphas.est[ss,nn,jj],
                                                     rval=rval.tmp)

              dFt.est[ss,nn,kk,jj] <- dFt.value.integrand(betaz=betaz[jj],
                                             alphastmp=alphas.est[ss,nn,jj],
                                                     rval.eval=rval.tmp)
	    } else { ## we have random effects
              Ft.integrate <- make.Ft.integrate(alphax=alphas.est[ss,nn,jj],betaz[jj],sigmar,sigmau)
              dFt.integrate <- make.dFt.integrate(alphax=alphas.est[ss,nn,jj],betaz[jj],sigmar,sigmau)
  	      sigma_all <- c(sigmar,sigmau)

	      if(is.null(sigmau)){
                Ft.est[ss,nn,kk,jj] <- integrate(Ft.integrate,-Inf,Inf)$value
                dFt.est[ss,nn,kk,jj] <- integrate(dFt.integrate,-Inf,Inf)$value
 	      } else {
                Ft.est[ss,nn,kk,jj] <- 
 				   adaptIntegrate(Ft.integrate,
					lower=rep(-1,length(sigma_all)),
					upper=rep(1,length(sigma_all)))$integral
                dFt.est[ss,nn,kk,jj] <- 
  				   adaptIntegrate(dFt.integrate,
					lower=rep(-1,length(sigma_all)),
					upper=rep(1,length(sigma_all)))$integral
	      }

            }
	  }
	  
	  xx.eval.tmp <- zeval.tmp
	  if(!is.null(beta0int)){
	    xx.eval.tmp <- rbind(1,xx.eval.tmp)
	  }

	  if(!is.null(gamma.param)){
	    if(!is.null(beta0int)){
  	      if(nn!=1){
  	        xx.eval.tmp <- rbind(1,xx.eval.tmp)
	      }
	    } else {
  	        xx.eval.tmp <- rbind(1,xx.eval.tmp)
	    }   
	  }

	  if(!is.null(omega.param)){
	    if(!is.null(beta0int)){
  	      if(ss!=1){
  	        xx.eval.tmp <- rbind(1,xx.eval.tmp)
	      }
	    } else {
  	        xx.eval.tmp <- rbind(1,xx.eval.tmp)
	    }
	  }

	  xx.eval.tmp <- t(xx.eval.tmp)

          g.tmp <- cbind(dFt.value.new(dFt.est[ss,nn,kk,1:length(xks[[ss]])],xx.eval=xx.eval.tmp),
                        dFt.value.new(dFt.est[ss,nn,kk,1:length(xks[[ss]])],xx.eval=xx.spline))

          #g.tmp <- cbind(dFt.value(betaz=betaz,
	  #	 alphastmp=alphas.est[ss,nn,length(xks[[ss]])],rval.eval=rval.tmp,
          #                     xx.eval=t(zeval.tmp)),
          #              dFt.value(betaz=betaz,
	  #			alphastmp=alphas.est[ss,nn,length(xks[[ss]])],rval.eval=rval.tmp,
          #                     xx.eval=xx.spline))

          Ft.var[ss,nn,kk,1:length(xks[[ss]])] <- diag( g.tmp %*% 
	  				       	  	fm$gam$Vp[index.use,index.use] %*% t(g.tmp))
        }
      }
    }
  }

  list(beta.est=beta.est,beta.var=beta.var,alphas.est=alphas.est,alphas.var=alphas.var,
        Ft.est=Ft.est,Ft.var=Ft.var)
}

make.Ft.integrate <- function(alphax,betaz,sigmar,sigmau){
  if(!is.null(sigmau)){
    Sigma <- diag(c(sigmar^2,sigmau^2))
    mean_use <- rep(0,2)
  } else {
    Sigma <- sigmar^2
    mean_use <- 0
  }

  function(r){
    if(is.null(sigmau)){
      ## 1-dimensional
      out <- Ft.true.value(betaz,alphax,r) * dnorm(r,mean=0,sd=sigmar)
    } else {
      ## any dimension
      out <- Ft.true.value(betaz,alphax,sum(r/(1-r^2))) * dmnorm(r/(1-r^2),mean_use,Sigma) * 
    	   					 ((1+r^2)/(1-r^2)^2) 
    }
    return(out)
  }
}

make.dFt.integrate <- function(alphax,betaz,sigmar,sigmau){
  if(!is.null(sigmau)){
    Sigma <- diag(c(sigmar^2,sigmau^2))
    mean_use <- rep(0,2)
  } else {
    Sigma <- sigmar^2
    mean_use <- 0
  }

  function(r){
    if(is.null(sigmau)){
      ## 1-dimensional
      out <- dFt.value.integrand(betaz,alphax,r) * dnorm(r,mean=0,sd=sigmar)
    } else {
      ## any dimension
      out <- dFt.value.integrand(betaz,alphax,sum(r/(1-r^2))) * dmnorm(r/(1-r^2),mean_use,Sigma) * 
    	   					 ((1+r^2)/(1-r^2)^2) 
    }
    return(out)
  }
}

dFt.value.new <- function(betaz,xx.eval){
  out <- matrix(0,ncol=ncol(xx.eval),nrow=length(betaz))

  for(kk in 1:ncol(xx.eval)){
    out[,kk] <- betaz * xx.eval[,kk]
  }
  return(out)
}

## expit function
expit <- function(x){
  1/(1+exp(-x))
}

Ft.true.value <- function(betaz,alphastmp,rval){
  rval.use <- rval 

  total.sum <- betaz + alphastmp + rval.use 
  den <- 1+exp(-total.sum)

  out <- length(rval.use)

  for(kk in 1:length(rval.use)){
    if(abs(den[kk])< 1e-6 | abs(den[kk])>=Inf){
      out[kk] <- 0
    } else {
      out[kk] <- expit(total.sum[kk])
    }
  }
  return(out)
}

dFt.value.integrand <- function(betaz,alphastmp,rval.eval){
  rval.use <- rval.eval

  total.sum <- betaz + alphastmp + rval.use
  den <- (1+exp(-total.sum))^2

  out <- length(rval.use)

  for(kk in 1:length(rval.use)){
    if(abs(den[kk])< 1e-6 | abs(den[kk])>=Inf){
      out[kk] <- 0
    } else {
      out[kk] <- exp(-total.sum[kk])  / den[kk]
    }
  }
  return(out)
}

dFt.value <- function(betaz,alphastmp,rval.eval,xx.eval){
  out <- matrix(0,ncol=ncol(xx.eval),nrow=length(betaz))

  total.sum <- betaz + alphastmp + rval.eval
  for(kk in 1:ncol(xx.eval)){
    out[,kk] <- exp(-total.sum) * xx.eval[,kk] / (1+exp(-total.sum))^2
  }
  return(out)
}


#####################################
## function to get gamm4 estimates ##
#####################################
gamm4.estimates <- function(num_study,np,count.store,data,num_time,time_val,p,n,nmax,m,
                        maxm,la,lb,lb.max,xks,truth,m0_qvs,num_xx,knot.length,
                        real_data,family.data,zeval,z.choice,
			param.label,beta0int,gamma.param,omega.param,
			spline.constrain,common.param.estimation,
			par_fu,analyze.separately){

  ##########################
  ## km jackknife on data ##
  ##########################

  common.out <- common.procedure(num_study,count.store,data,num_time,
                        time_val,p,n,nmax,m,maxm,m0_qvs,family.data,
			common.param.estimation)
  count.store <- common.out$count.store
  n <- common.out$n
  m <- common.out$m
  ynew <- common.out$ynew
  ymiss_ind <- common.out$ymiss_ind
  z <- common.out$z
  x <- common.out$x

  ###############
  ## main part ##
  ###############
  gamm4.main.out <- gamm4.main(num_study,np,n,nmax,m,maxm,ynew,
  		    ymiss_ind,z,x,
                    time_val,lb,lb.max,la,xks,truth,
                    num_time,num_xx,knot.length,real_data,
                    family.data,zeval,z.choice,
		    param.label,beta0int,gamma.param,omega.param,
		    spline.constrain,common.param.estimation,par_fu,analyze.separately)

  eflag <- gamm4.main.out$eflag
		    
  betaest <- gamm4.main.out$betaest
  alphasest <- gamm4.main.out$alphasest
  betavar <- gamm4.main.out$betavar
  alphasvar <- gamm4.main.out$alphasvar
  Ftest <- gamm4.main.out$Ftest
  Ftvar <- gamm4.main.out$Ftvar
  alphasijest <- gamm4.main.out$alphasijest
  alphasijvar <- gamm4.main.out$alphasijvar
  Ftijest <- gamm4.main.out$Ftijest
  Ftijvar <- gamm4.main.out$Ftijvar

  list(betaest=betaest,betavar=betavar,
        alphasest=alphasest,alphasvar=alphasvar,count.store=count.store,
        Ftest=Ftest,Ftvar=Ftvar,
        alphasijest=alphasijest,alphasijvar=alphasijvar,Ftijest=Ftijest,Ftijvar=Ftijvar,eflag=eflag)
}


########################
## main part of gamm4 ##
########################

gamm4.main <- function(num_study,np,n,nmax,m,maxm,ynew,ymiss_ind,z,x,
			time_val,lb,lb.max,
                        la,xks,truth,num_time,
                        num_xx,knot.length,real_data,
                        family.data,zeval,z.choice,
			param.label,beta0int,gamma.param,omega.param,
			spline.constrain,common.param.estimation,par_fu,analyze.separately){

  betaest <- array(0,dim=c(num_study,np,length(time_val),
			length(param.label)),
                         dimnames=list(
                           paste("ss",1:num_study,sep=""),
                           paste("np",1:np,sep=""),
                           paste("t",time_val,sep=""),
                           param.label))
  betavar <- betaest

  alphasest <- array(0,dim=c(num_study,np,num_xx,length(time_val),la),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep=""),
                             paste("la",1:la,sep="")))

  alphasvar <- alphasest

  Ftest <- array(0,dim=c(num_study,np,z.choice,num_xx,length(time_val)),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("zz",1:z.choice,sep=""),
                             paste("xx",1:num_xx,sep=""),
                             paste("t",time_val,sep="")))
  Ftvar <- Ftest

  alphasijest <- array(0,dim=c(num_study,np,nmax,length(time_val),la),
                           dimnames=list(
                                paste("ss",1:num_study,sep=""),
                                paste("np",1:np,sep=""),
                                paste("n",1:nmax,sep=""),
                                paste("t",time_val,sep=""),
                                paste("la",1:la,sep="")))

  alphasijvar <- alphasijest

  Ftijest <- array(0,dim=c(num_study,np,nmax,length(time_val)),
                           dimnames=list(
                             paste("ss",1:num_study,sep=""),
                             paste("np",1:np,sep=""),
                             paste("n",1:nmax,sep=""),
                             paste("t",time_val,sep="")))
  Ftijvar <- Ftijest

  data.org.gamm <- make.data.set(num_study,time_val,n,nmax,m,lb,ynew,
  		   x,z,nn,real_data,gamma.param,omega.param)

  ############################
  ## Organize data for GAMM ##
  ############################

  ## just for checking
  ##if(1==2){

  for(tt in 1:length(time_val)){
     ###########################################
     ## organize data for a particular time t ##
     ###########################################
     data.gamm <- get.data.gamm(n,m,num_study,tt,
                                 study=data.org.gamm$study,
                                 family=data.org.gamm$family,
                                 y=data.org.gamm$yy,
                                 new.x=data.org.gamm$new.x,
                                 z.values=data.org.gamm$z.values,
				 gamma.list=data.org.gamm$gamma.list,		
				 omega.list=data.org.gamm$omega.list,
				 beta0int,gamma.param,omega.param,
				 common.param.estimation)

     if(analyze.separately=="studyevent"){ ## no random effects: each study and each event analyzed separately

       ## adjust param.label just to run the code. We only have intercept plus beta*z terms.
       param.label.tmp <- param.label[grep(glob2rx("beta*"),param.label)]	   
       index.beta.use <- param.label.tmp

       if(!is.null(beta0int)|| !is.null(gamma.param) || !is.null(omega.param)){
         param.label.tmp <- c("beta0",param.label.tmp)
	 param.label.tmp <- unique(param.label.tmp)

	 if(is.null(beta0int)){
  	   index.beta.use <- c(param.label[1],index.beta.use)
	   index.beta.use <- unique(index.beta.use)
	 }
       }
       
     
       index.beta.use <- param.label.tmp

       for(ss in 1:num_study){
	 ##print(ss)
         for(kk in 1:np){
	 ##print(kk)
	   ## get subset of data
	   index.use <- which(data.gamm$study==ss & data.gamm$np==kk)
	   data.gamm.use <- data.gamm[index.use,]

	   ## get appropriate columns
	   names.X <- paste("study_",ss,"_X_",kk,sep="")
	   names.Z <- paste("study_",ss,"_Z",kk,"_*",sep="")
	   
	   get.index.X <- grep(glob2rx(names.X), colnames(data.gamm.use))
	   get.index.Z <- grep(glob2rx(names.Z), colnames(data.gamm.use))

	   ## get appropriate columns
	   data.gamm.use2 <- data.gamm.use[,c("study","family",
	       		      "Y","np","int")]  

	   if(!is.null(beta0int) || !is.null(gamma.param) || !is.null(omega.param)){
	     data.gamm.use2 <- cbind(data.gamm.use2,"Z0"=1)
	   } 

	   data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.X])
           if(length(get.index.X)==1){
             colnames(data.gamm.use2)[length(colnames(data.gamm.use2))] <-
                                        colnames(data.gamm.use)[get.index.X]
           }

	   data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.Z])	
           if(length(get.index.Z)==1){
             colnames(data.gamm.use2)[length(colnames(data.gamm.use2))] <-
                                        colnames(data.gamm.use)[get.index.Z]
           }

	   ## make study index 1
  	   mynames <- colnames(data.gamm.use2)
	   mynames.index <- which(substring(mynames,1,7)==paste("study_",ss,sep=""))
	   colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("study_",ss,"_",sep=""),"study_1_",mynames[mynames.index])

	   ## make event index 1
  	   mynames <- colnames(data.gamm.use2)
	   mynames.index <- which(substring(mynames,9,11)==paste("X_",kk,sep=""))
	   colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("X_",kk,sep=""),"X_1",mynames[mynames.index])

  	   mynames <- colnames(data.gamm.use2)
	   mynames.index <- which(substring(mynames,9,10)==paste("Z",kk,sep=""))
	   colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("Z",kk,sep=""),"Z1",mynames[mynames.index])


	   ## run the new code
	   gamm.fit <- gamm.mle.new(num_study=1,np=1,
		      lb=list(study1=lb[[ss]]),
		      num_xx,xks[ss],
               data.gamm.use2,
	       knot.length[kk],zeval[ss,,kk,,drop=FALSE],
	       z.choice,real_data,
	       param.label=param.label.tmp,
	       beta0int=1,gamma.param=NULL,omega.param=NULL,  ## feeding in only intercept model
	       spline.constrain,common.param.estimation,
	       par_fu,random.effect="none")
       	     eflag <- gamm.fit$eflag

       	   if(eflag!=-1){
             ###################
             ## store results ##
             ###################
             betaest[ss,kk,tt,index.beta.use] <- gamm.fit$beta.est
             betavar[ss,kk,tt,index.beta.use] <- gamm.fit$beta.var
             alphasest[ss,kk,,tt,] <- gamm.fit$alphas.est
             alphasvar[ss,kk,,tt,] <- gamm.fit$alphas.var
             Ftest[ss,kk,,,tt] <- gamm.fit$Ft.est
             Ftvar[ss,kk,,,tt] <- gamm.fit$Ft.var

   	     alphasijest <- NULL
       	     alphasijvar <- NULL
       	     Ftijest <- NULL
       	     Ftijvar <- NULL
           } else {
             break
       	   }
	 }
       }
     } else if(analyze.separately=="study"){

       ## adjust param.label just to run the code. We only have intercept, gamma, plus beta*z terms.
       param.label.tmp <- param.label[grep(glob2rx("beta*"),param.label)]	   
       index.beta.use <- param.label.tmp

       if(!is.null(gamma.param)){
         param.label.tmp <- c("gamma",param.label.tmp)
	 param.label.tmp <- unique(param.label.tmp)
       }
     
       index.beta.use <- param.label.tmp

       for(ss in 1:num_study){
         ## get subset of data
	 index.use <- which(data.gamm$study==ss)
	 data.gamm.use <- data.gamm[index.use,]

	 ## get appropriate columns
	 names.X <- paste("study_",ss,"_X_*",sep="")
	 names.Z <- paste("study_",ss,"_Z*",sep="")
	 names.gamma <- "gamma*"
	   
	 get.index.X <- grep(glob2rx(names.X), colnames(data.gamm.use))
	 get.index.Z <- grep(glob2rx(names.Z), colnames(data.gamm.use))
	 get.index.gamma <- grep(glob2rx(names.gamma), colnames(data.gamm.use))

         ## get appropriate columns
	 data.gamm.use2 <- data.gamm.use[,c("study","family",
	       		      "Y","np","int")]  

	 if(!is.null(beta0int)){
	     data.gamm.use2 <- cbind(data.gamm.use2,"Z0"=1)
	 } 


	 data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.X])
         if(length(get.index.X)==1){
           colnames(data.gamm.use2)[length(colnames(data.gamm.use2))] <-
                                        colnames(data.gamm.use)[get.index.X]
         }

	 data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.Z])	
         if(length(get.index.Z)==1){
           colnames(data.gamm.use2)[length(colnames(data.gamm.use2))] <-
                                        colnames(data.gamm.use)[get.index.Z]
         }

	 data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.gamma])	 
  	   
	 mynames <- colnames(data.gamm.use2)
	 mynames.index <- which(substring(mynames,1,7)==paste("study_",ss,sep=""))
	 colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("study_",ss,"_",sep=""),"study_1_",mynames[mynames.index])

         tmp.col <- length(colnames(data.gamm.use2))-length(get.index.gamma)
         colnames(data.gamm.use2)[(tmp.col+1):length(colnames(data.gamm.use2))] <-
                                        colnames(data.gamm.use)[get.index.gamma]

	 ## run the new code
	 gamm.fit <- gamm.mle.new(num_study=1,np=np,
		      lb=list(study1=lb[[ss]]),
		      num_xx,xks[ss],
               data.gamm.use2,
	       knot.length,zeval[ss,,,,drop=FALSE],
	       z.choice,real_data,
	       param.label=param.label.tmp,
	       beta0int=beta0int,gamma.param=gamma.param,
			omega.param=NULL,  
	       spline.constrain,common.param.estimation,
	       par_fu,random.effect="event")
       	     eflag <- gamm.fit$eflag

       	 if(eflag!=-1){
             ###################
             ## store results ##
             ###################
             betaest[ss,,tt,index.beta.use] <- gamm.fit$beta.est
             betavar[ss,,tt,index.beta.use] <- gamm.fit$beta.var
             alphasest[ss,,,tt,] <- gamm.fit$alphas.est
             alphasvar[ss,,,tt,] <- gamm.fit$alphas.var
             Ftest[ss,,,,tt] <- gamm.fit$Ft.est
             Ftvar[ss,,,,tt] <- gamm.fit$Ft.var

   	     alphasijest <- NULL
       	     alphasijvar <- NULL
       	     Ftijest <- NULL
       	     Ftijvar <- NULL
         } else {
           break
       	 }
       }
     } else if(analyze.separately=="event"){

       ## adjust param.label just to run the code. We only have intercept, omega, plus beta*z terms.
       param.label.tmp <- param.label[grep(glob2rx("beta*"),param.label)]	   
       index.beta.use <- param.label.tmp

       if(!is.null(omega.param) && common.param.estimation ==FALSE){
         param.label.tmp <- c("omega",param.label.tmp)
	 param.label.tmp <- unique(param.label.tmp)
       }
     
       index.beta.use <- param.label.tmp
       if(common.param.estimation==TRUE){
         num_study.use <- 1
	 xks.use <- xks[1]
	 lb.use <- list(study1=lb[[1]])
	 omega.param.use <- NULL
       } else {
         num_study.use <- num_study
	 xks.use <- xks
	 lb.use <- lb
	 omega.param.use <- omega.param
       }


       for(kk in 1:np){
         ## get subset of data
	 index.use <- which(data.gamm$np==kk)
	 data.gamm.use <- data.gamm[index.use,]

	 ## get appropriate columns
	 names.X <- paste("*X_",kk,sep="")
	 names.Z <- paste("*Z",kk,"_*",sep="")
	 names.omega <- "*omega*"

  	 get.index.X <- grep(glob2rx(names.X),colnames(data.gamm.use))
	 get.index.Z <- grep(glob2rx(names.Z),colnames(data.gamm.use))	   
	 get.index.omega <- grep(glob2rx(names.omega),colnames(data.gamm.use))	   

	 ## get appropriate columns
	 data.gamm.use2 <- data.gamm.use[,c("study","family",
	       		      "Y","np","int")]  

	 if(!is.null(beta0int)){
	   data.gamm.use2 <- cbind(data.gamm.use2,"Z0"=1)
	 } 

         data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.X])
	 if(length(get.index.X)==1){
	   colnames(data.gamm.use2)[length(colnames(data.gamm.use2))] <- 
	   				colnames(data.gamm.use)[get.index.X]	 
	 }
	 
	 data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.Z])
	 if(length(get.index.Z)==1){
	   colnames(data.gamm.use2)[length(colnames(data.gamm.use2))] <- 
	   				colnames(data.gamm.use)[get.index.Z]	 
	 }
	
	 data.gamm.use2 <- cbind(data.gamm.use2,data.gamm.use[,get.index.omega])	

	 mynames <- colnames(data.gamm.use2)
	 if(common.param.estimation==FALSE){
  	   ## make event index 1
	   mynames.index <- which(substring(mynames,9,11)==paste("X_",kk,sep=""))
	   colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("X_",kk,sep=""),"X_1",mynames[mynames.index])

	   mynames <- colnames(data.gamm.use2)
	   mynames.index <- which(substring(mynames,9,10)==paste("Z",kk,sep=""))
	   colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("Z",kk,sep=""),"Z1",mynames[mynames.index])
	 } else {
  	   ## make event index 1
	   mynames.index <- which(substring(mynames,1,3)==paste("X_",kk,sep=""))
	   colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("X_",kk,sep=""),"X_1",mynames[mynames.index])

           mynames <- colnames(data.gamm.use2)
	   mynames.index <- which(substring(mynames,1,2)==paste("Z",kk,sep=""))
	   colnames(data.gamm.use2)[mynames.index] <- 
	 		gsub(paste("Z",kk,sep=""),"Z1",mynames[mynames.index])
	 }	   

	 if(sum(get.index.omega)>0){
	   tmp.col <- length(colnames(data.gamm.use2))-length(get.index.omega)
	   
	   colnames(data.gamm.use2)[(tmp.col+1):length(colnames(data.gamm.use2))] <- 
	   				colnames(data.gamm.use)[get.index.omega]
	 }


	 ## run the new code
	 gamm.fit <- gamm.mle.new(num_study=num_study.use,np=1,
			lb=lb.use,num_xx,xks=xks.use,
                        data.gamm.use2,
			knot.length[kk],zeval[,,kk,,drop=FALSE],
			z.choice,real_data,
			param.label=param.label.tmp,
	       		beta0int=beta0int,gamma.param=NULL,omega.param=omega.param.use,
			spline.constrain,common.param.estimation,
			par_fu,random.effect="none")
       	 eflag <- gamm.fit$eflag

       	 if(eflag!=-1){
           ###################
           ## store results ##
           ###################
	   if(common.param.estimation==TRUE){
             for(ss in 1:num_study){
	       betaest[ss,kk,tt,index.beta.use] <- gamm.fit$beta.est
               betavar[ss,kk,tt,index.beta.use] <- gamm.fit$beta.var
               alphasest[ss,kk,,tt,] <- gamm.fit$alphas.est
               alphasvar[ss,kk,,tt,] <- gamm.fit$alphas.var
               Ftest[ss,kk,,,tt] <- gamm.fit$Ft.est
               Ftvar[ss,kk,,,tt] <- gamm.fit$Ft.var
	     }
	   } else {
             betaest[,kk,tt,index.beta.use] <- gamm.fit$beta.est
             betavar[,kk,tt,index.beta.use] <- gamm.fit$beta.var
             alphasest[,kk,,tt,] <- gamm.fit$alphas.est
             alphasvar[,kk,,tt,] <- gamm.fit$alphas.var
             Ftest[,kk,,,tt] <- gamm.fit$Ft.est
             Ftvar[,kk,,,tt] <- gamm.fit$Ft.var
	   }
   	   alphasijest <- NULL
       	   alphasijvar <- NULL
       	   Ftijest <- NULL
       	   Ftijvar <- NULL
         } else {
           break
       	 }
       }
     } else if(analyze.separately=="none"){  ## we analyze all studies and events together
       ##########################
       ## apply GAMM procedure ##
       ##########################

       if(common.param.estimation==TRUE){
         num_study.use <- 1
       } else {
         num_study.use <- num_study
       }


       gamm.fit <- gamm.mle.new(num_study=num_study.use,np,lb,num_xx,xks,
                                        data.gamm,
					knot.length,zeval,z.choice,
					real_data,
					param.label,beta0int,gamma.param,omega.param,
					spline.constrain,common.param.estimation,
					par_fu,random.effect="studyevent")
       eflag <- gamm.fit$eflag

       if(eflag!=-1){
         ###################
         ## store results ##
         ###################
	 if(common.param.estimation==TRUE){
	   for(ss in 1:num_study){
             betaest[ss,,tt,] <- gamm.fit$beta.est
             betavar[ss,,tt,] <- gamm.fit$beta.var
             alphasest[ss,,,tt,] <- gamm.fit$alphas.est
             alphasvar[ss,,,tt,] <- gamm.fit$alphas.var
             Ftest[ss,,,,tt] <- gamm.fit$Ft.est
             Ftvar[ss,,,,tt] <- gamm.fit$Ft.var
	   }
	 } else {
           betaest[,,tt,] <- gamm.fit$beta.est
           betavar[,,tt,] <- gamm.fit$beta.var
           alphasest[,,,tt,] <- gamm.fit$alphas.est
           alphasvar[,,,tt,] <- gamm.fit$alphas.var
           Ftest[,,,,tt] <- gamm.fit$Ft.est
           Ftvar[,,,,tt] <- gamm.fit$Ft.var
	 }

   	 alphasijest <- NULL
       	 alphasijvar <- NULL
       	 Ftijest <- NULL
       	 Ftijvar <- NULL
       } else {
         break
       }
     }
    }
  

  ##} ## end check


  list(betaest=betaest,betavar=betavar,
        alphasest=alphasest,alphasvar=alphasvar,
        alphasijest=alphasijest,
        alphasijvar=alphasijvar,
        Ftijest=Ftijest,
        Ftijvar=Ftijvar,
        Ftest=Ftest,Ftvar=Ftvar,eflag=eflag)
}




#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+
#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+
#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+

#############################################
## R code to read in data and show results ##
#############################################


######################
## Useful functions ##
######################
make.data.arrays <- function(data.theta.est=data.beta,data.theta.varboot=data.beta.varboot,
				cnames=c("ss","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=1:lb,theta.set2=1:lb,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names,boot.ci){

  colnames(data.theta.est) <- cnames


  theta.array <- array(0,dim=c(num_study,np,length(theta.set2),nsimu,num_time),
			dimnames=list(
			paste("ss",1:num_study,sep=""),
		    	s.names,
                    	paste(theta.interest,theta.set2,sep=""),
                    	paste("iter",1:nsimu,sep=""),
                    	paste("t",time_val,sep="")))

  theta.length <- length(theta.set2)

  if(var.est!="none"){
       data.theta.var <- array(0,dim=c(num_study,np,theta.length*nsimu,length(cnames)),
                                dimnames=list(
					   paste("ss",1:num_study,sep=""),
					   s.names,
                                           paste("ind",1:(theta.length*nsimu),sep=""),
					   cnames))
       data.theta.ci.lo <- data.theta.var
       data.theta.ci.hi <- data.theta.var

       ## get each component
       tmp.row <-nrow(data.theta.varboot)/(np*num_study)
       for(ss in 1:num_study){
         for(nn in 1:np){
           ind <- which(data.theta.varboot[,1]==ss & data.theta.varboot[,2]==nn)
           data.theta.var[ss,nn,,] <- as.matrix(data.theta.varboot[ind[seq(1,tmp.row,by=3)],])
           data.theta.ci.lo[ss,nn,,] <- as.matrix(data.theta.varboot[ind[seq(2,tmp.row,by=3)],])
           data.theta.ci.hi[ss,nn,,] <- as.matrix(data.theta.varboot[ind[seq(3,tmp.row,by=3)],])
         }
       }
       theta.var.array <- theta.array
       theta.ci.lo.array <- theta.array
       theta.ci.hi.array <- theta.array

  } else {
        data.theta.var <- NULL
        data.theta.ci.lo <- NULL
        data.theta.ci.hi <- NULL
  }

  index.interest <- which(cnames==theta.interest)   

  for(ss in 1:num_study){
    ##print(ss)
    for(nn in 1:np){
      ##print(nn)
      for(i in 1:theta.length){
      ##print(i)
        if(is.list(theta.set)){
	  theta.set.tmp <- theta.set[[ss]][i]
	} else {
	  theta.set.tmp <- theta.set[i]
	}
      	index <- which(data.theta.est[,index.interest]==theta.set.tmp & data.theta.est[,"ss"]==ss &
	      	 						       data.theta.est[,"np"]==nn)

	if(length(index)< 1e-6){
	  ## no elements in index, go to next i in for-loop
	  next()
	} else {
	  ## elements in index found
      	  theta.array[ss,nn,i,,] <- as.matrix(data.theta.est[index,paste("t",time_val,sep="")])

      	  index2 <- which(data.theta.var[ss,nn,,theta.interest]==theta.set.tmp)

	  if(length(index2) < 1e-6){
	    ## no elements in index2, go to next i in for-loop
	    next()
	  } else {
	    ## elements in index2 found      	
	    if(var.est!="none"){
              theta.var.array[ss,nn,i,,] <-as.matrix(data.theta.var[ss,nn,index2,
							paste("t",time_val,sep="")])
              if(boot.ci==TRUE){
                theta.ci.lo.array[ss,nn,i,,] <-as.matrix(data.theta.ci.lo[ss,nn,index2,
							paste("t",time_val,sep="")])
                theta.ci.hi.array[ss,nn,i,,] <-as.matrix(data.theta.ci.hi[ss,nn,index2,
							paste("t",time_val,sep="")])
              } else {
                theta.ci.lo.array[ss,nn,i,,] <- theta.array[ss,nn,i,,] + 
			    		qnorm(0.025)*sqrt(theta.var.array[ss,nn,i,,])
		##	if (is.na(sqrt(theta.var.array[ss,nn,i,,]))){
		##	 print(i)
		##	}

                theta.ci.hi.array[ss,nn,i,,] <- theta.array[ss,nn,i,,] + 
			    	 	qnorm(0.975)*sqrt(theta.var.array[ss,nn,i,,])
              }
           } else {
             theta.var.array <- NULL
             theta.ci.lo.array <- NULL
             theta.ci.hi.array <- NULL
           }
          }
        }
      }
    }
  }

  list(theta.array=theta.array,
	data.theta.var=data.theta.var,
	data.theta.ci.lo=data.theta.ci.lo,
	data.theta.ci.hi=data.theta.ci.hi,
	theta.var.array=theta.var.array,
	theta.ci.lo.array=theta.ci.lo.array,
	theta.ci.hi.array=theta.ci.hi.array)
}


make.Ft.arrays <- function(data.Ft,data.Ft.varboot,
		num_study,np,nsimu,num_time,time_val,num_xx,z.choice,z_lab,s.names,
		var.est=var.est,boot.ci){

  data.Ft.est <- data.Ft
  colnames(data.Ft.est) <- c("ss","np","iter","zz","xx",paste("t",time_val,sep=""))

  Ft.array <- array(0,dim=c(num_study,np,z.choice,num_xx,nsimu,num_time),
                     dimnames=list(
		       paste("ss",1:num_study,sep=""),
		       s.names,
		       paste("zz_",z_lab,sep=""),
                       paste("xx",1:num_xx,sep=""),
                       paste("iter",1:nsimu,sep=""),
                       paste("t",time_val,sep="")))

  ## get each component
  if(var.est!="none"){
        data.Ft.varboot <- data.Ft.varboot

        data.Ft.var <- array(0,dim=c(num_study,np,z.choice * num_xx * nsimu,5+length(time_val)),
                                dimnames=list(
					   paste("ss",1:num_study,sep=""),
					   s.names,
                                           paste("ind",1:(z.choice * num_xx * nsimu),sep=""),
                                           c("ss","np","iter","zz","xx",paste("t",time_val,sep=""))))
        data.Ft.ci.lo <- data.Ft.var
        data.Ft.ci.hi <- data.Ft.var

        ## get each component
        tmp.row <-nrow(data.Ft.varboot)/(num_study*np)
	for(ss in 1:num_study){
          for(nn in 1:np){
            ind <- which(data.Ft.varboot[,1]==ss & data.Ft.varboot[,2]==nn )
            data.Ft.var[ss,nn,,] <- as.matrix(data.Ft.varboot[ind[seq(1,tmp.row,by=3)],])
            data.Ft.ci.lo[ss,nn,,] <- as.matrix(data.Ft.varboot[ind[seq(2,tmp.row,by=3)],])
            data.Ft.ci.hi[ss,nn,,] <- as.matrix(data.Ft.varboot[ind[seq(3,tmp.row,by=3)],])
	  }
	}

        Ft.var.array <- Ft.array
        Ft.ci.lo.array <- Ft.array
        Ft.ci.hi.array <- Ft.array

  } else {
       data.Ft.var <- NULL
       data.Ft.ci.lo <- NULL
       data.Ft.ci.hi <- NULL
  }

  for(ss in 1:num_study){
    for(nn in 1:np){
      for(zz in 1:z.choice){
        for(i in 1:num_xx){
          index <- which(data.Ft.est$xx==xx_val[[ss]][i] & data.Ft.est$ss==ss &
	  	   				     data.Ft.est$np==nn & data.Ft.est$zz==zz)

	  if(length(index)<1e-6){
	    ## no elements in index, go to next i in for-loop
	    next()
	  } else{
	    ## elements in index found
            index2 <- which(data.Ft.var[ss,nn,,"xx"]==xx_val[[ss]][i] & data.Ft.var[ss,nn,,"zz"]==zz)

            Ft.array[ss,nn,zz,i,,] <- as.matrix(data.Ft.est[index,paste("t",time_val,sep="")])
	  
	    if(length(index2)<1e-6){
	      ## no elements in index2, go to next i in for-loop
	      next()
	    } else {
	      ## elements in index found
              if(var.est!="none"){
                Ft.var.array[ss,nn,zz,i,,] <- as.matrix(data.Ft.var[ss,nn,index2,
							 paste("t",time_val,sep="")])
                if(boot.ci==TRUE){
                  Ft.ci.lo.array[ss,nn,zz,i,,] <- as.matrix(data.Ft.ci.lo[ss,nn,index2,
							 paste("t",time_val,sep="")])
                  Ft.ci.hi.array[ss,nn,zz,i,,] <- as.matrix(data.Ft.ci.hi[ss,nn,index2,
							 paste("t",time_val,sep="")])
                } else {
	          tmp.var  <- adrop(Ft.var.array[ss,nn,zz,i,,,drop=FALSE],drop=1:4)
	          zero.function <- function(x){
	            if(abs(x)<1e-6){
	              return(0)
	            } else {
	              return(x)
	            }
	          }
	          tmp.var <- apply(tmp.var,c(1,2),zero.function)

                  Ft.ci.lo.array[ss,nn,zz,i,,] <- Ft.array[ss,nn,zz,i,,] +qnorm(0.025)*sqrt(tmp.var)
                  Ft.ci.hi.array[ss,nn,zz,i,,] <- Ft.array[ss,nn,zz,i,,] +qnorm(0.975)*sqrt(tmp.var)
              }
            } else {
              Ft.var.array <- NULL
              Ft.ci.lo.array <- NULL
              Ft.ci.hi.array <- NULL
            }
          }
        }
      }
    }
   }
 }


  list(theta.array=Ft.array,
	data.theta.var=data.Ft.var,
	data.theta.ci.lo=data.Ft.ci.lo,
	data.theta.ci.hi=data.Ft.ci.hi,
	theta.var.array=Ft.var.array,
	theta.ci.lo.array=Ft.ci.lo.array,
	theta.ci.hi.array=Ft.ci.hi.array)
}



make.Ft.diff.arrays <- function(data.Ft.diff,
		num_study,np,nsimu,num_time,time_val,num_xx,z.choice,z_lab,s.names,
		var.est=var.est,combi.study,combi.names){

  data.Ft.est <- data.Ft.diff
  colnames(data.Ft.est) <- c("combi","np","iter","zz","xx",paste("t",time_val,sep=""))

  Ft.array <- array(0,dim=c(combi.study,np,z.choice,num_xx,nsimu,num_time),
                     dimnames=list(
		       combi.names,
		       s.names,
		       paste("zz_",z_lab,sep=""),
                       paste("xx",1:num_xx,sep=""),
                       paste("iter",1:nsimu,sep=""),
                       paste("t",time_val,sep="")))
  Ft.estdiff.array <- Ft.array
  Ft.ci.lo.array <- Ft.array
  Ft.ci.hi.array <- Ft.array

  data.Ft <- array(0,dim=c(combi.study,np,z.choice * num_xx * nsimu,5+length(time_val)),
                                dimnames=list(
				           combi.names,
					   s.names,
                                           paste("ind",1:(z.choice * num_xx * nsimu),sep=""),
                                           c("ss","np","iter","zz","xx",paste("t",time_val,sep=""))))
  data.Ft.estdiff <- data.Ft
  data.Ft.ci.lo <- data.Ft
  data.Ft.ci.hi <- data.Ft

  ## get each component
  tmp.row <-nrow(data.Ft.est)/(combi.study*np)
  for(ss in 1:combi.study){
    for(nn in 1:np){
      ind <- which(data.Ft.est[,1]==combi.names[ss] & data.Ft.est[,2]==nn )
      data.Ft[ss,nn,,] <- as.matrix(data.Ft.est[ind[seq(1,tmp.row,by=4)],])
      data.Ft.estdiff[ss,nn,,] <- as.matrix(data.Ft.est[ind[seq(2,tmp.row,by=4)],])
      data.Ft.ci.lo[ss,nn,,] <- as.matrix(data.Ft.est[ind[seq(3,tmp.row,by=4)],])
      data.Ft.ci.hi[ss,nn,,] <- as.matrix(data.Ft.est[ind[seq(4,tmp.row,by=4)],])
    }
  }

  for(ss in 1:combi.study){
    for(nn in 1:np){
      for(zz in 1:z.choice){
        for(i in 1:num_xx){
	  ## elements in index found
          index2 <- which(data.Ft[ss,nn,,"xx"]==xx_val[[ss]][i] & data.Ft[ss,nn,,"zz"]==zz)

	  if(length(index2)<1e-6){
	    ## no elements in index2, go to next i in for-loop
	    next()
	  } else {
	    ## elements in index found
            Ft.array[ss,nn,zz,i,,] <- as.matrix(data.Ft[ss,nn,index2,
							 paste("t",time_val,sep="")])
            Ft.estdiff.array[ss,nn,zz,i,,] <- as.matrix(data.Ft.estdiff[ss,nn,index2,
							 paste("t",time_val,sep="")])
            Ft.ci.lo.array[ss,nn,zz,i,,] <- as.matrix(data.Ft.ci.lo[ss,nn,index2,
							 paste("t",time_val,sep="")])
            Ft.ci.hi.array[ss,nn,zz,i,,] <- as.matrix(data.Ft.ci.hi[ss,nn,index2,
							 paste("t",time_val,sep="")])
          }
        }
      }
    }
  }
 
  list(theta.array=Ft.array,
	data.theta.estdiff=data.Ft.estdiff,
	data.theta.ci.lo=data.Ft.ci.lo,
	data.theta.ci.hi=data.Ft.ci.hi,
	theta.estdiff.array=Ft.estdiff.array,
	theta.ci.lo.array=Ft.ci.lo.array,
	theta.ci.hi.array=Ft.ci.hi.array)
}

make.data.diff.arrays <- function(data.theta.est=data.beta.diff,
				cnames=c("combi","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=1:lb,theta.set2=1:lb,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names,combi.study,combi.names){

  colnames(data.theta.est) <- cnames


  theta.array <- array(0,dim=c(combi.study,np,length(theta.set2),nsimu,num_time),
			dimnames=list(
			combi.names,
		    	s.names,
                    	paste(theta.interest,theta.set2,sep=""),
                    	paste("iter",1:nsimu,sep=""),
                    	paste("t",time_val,sep="")))

  theta.estdiff.array <- theta.array
  theta.ci.lo.array <- theta.array
  theta.ci.hi.array <- theta.array

  theta.length <- length(theta.set2)

  data.theta <- array(0,dim=c(combi.study,np,theta.length*nsimu,length(cnames)),
                                dimnames=list(
				           combi.names,
					   s.names,
                                           paste("ind",1:(theta.length*nsimu),sep=""),
					   cnames))
  data.theta.estdiff <- data.theta
  data.theta.ci.lo <- data.theta
  data.theta.ci.hi <- data.theta

  ## get each component
  tmp.row <-nrow(data.theta.est)/(np*combi.study)
  for(ss in 1:combi.study){
    for(nn in 1:np){
      ind <- which(data.theta.est[,1]==combi.names[ss] & data.theta.est[,2]==nn)
      data.theta[ss,nn,,] <- as.matrix(data.theta.est[ind[seq(1,tmp.row,by=4)],])
      data.theta.estdiff[ss,nn,,] <- as.matrix(data.theta.est[ind[seq(2,tmp.row,by=4)],])
      data.theta.ci.lo[ss,nn,,] <- as.matrix(data.theta.est[ind[seq(3,tmp.row,by=4)],])
      data.theta.ci.hi[ss,nn,,] <- as.matrix(data.theta.est[ind[seq(4,tmp.row,by=4)],])
    }
  }

  index.interest <- which(cnames==theta.interest)   

  for(ss in 1:combi.study){
    ##print(ss)
    for(nn in 1:np){
      ##print(nn)
      for(i in 1:theta.length){
      ##print(i)
        if(is.list(theta.set)){
	  theta.set.tmp <- theta.set[[ss]][i]
	} else {
	  theta.set.tmp <- theta.set[i]
	}

	index2 <- which(data.theta.estdiff[ss,nn,,theta.interest]==theta.set.tmp)
	if(length(index2) < 1e-6){
	  ## no elements in index2, go to next i in for-loop
	  next()
	} else {
	  ## elements in index2 found      	
          theta.array[ss,nn,i,,] <-as.matrix(data.theta[ss,nn,index2,
							paste("t",time_val,sep="")])
          theta.estdiff.array[ss,nn,i,,] <-as.matrix(data.theta.estdiff[ss,nn,index2,
							paste("t",time_val,sep="")])
          theta.ci.lo.array[ss,nn,i,,] <-as.matrix(data.theta.ci.lo[ss,nn,index2,
							paste("t",time_val,sep="")])
          theta.ci.hi.array[ss,nn,i,,] <-as.matrix(data.theta.ci.hi[ss,nn,index2,
							paste("t",time_val,sep="")])
        }
      }
    }
  }

  list(theta.array=theta.array,
	data.theta.estdiff=data.theta.estdiff,
	data.theta.ci.lo=data.theta.ci.lo,
	data.theta.ci.hi=data.theta.ci.hi,
	theta.estdiff.array=theta.estdiff.array,
	theta.ci.lo.array=theta.ci.lo.array,
	theta.ci.hi.array=theta.ci.hi.array)
}

sort.results <- function(
	     num_xx,
	     num_study,
	     n,
	     nmax,
	     np,
	     lb.max,
	     time_val,
	     xx_val,
	     nsimu,
	     plot.nw,
	     num_time,
	     var.est,
	     data.truth,
	     data.beta,
	     data.beta.varboot,
	     data.beta.diff,
	     #
	     data.gamma,
	     data.gamma.varboot,
	     data.gamma.diff,
	     #
	     data.omega,
	     data.omega.varboot,
	     data.omega.diff,
	     #
	     data.alpha,
	     data.alpha.varboot,
	     data.alpha.diff,
	     data.Ft,
	     data.Ft.varboot,
	     data.Ft.diff,
	     alpha.cut,
	     beta.cut,
	     z.choice,
	     z_lab,
	     s.names,
	     beta0int,
	     gamma.param,
	     omega.param,
	     boot.ci,
	     combi.study,
	     combi.choice,
	     combi.names
	     	     ){

###########
## truth ##
###########
 if(!is.null(beta0int)){
    ## for intercept
    num_beta_index <- 0:lb.max
  } else {
    num_beta_index <- 1:lb.max
  }
  get_beta_index <- 1:length(num_beta_index)

  ## true beta values
  betat <- array(0,dim=c(num_study,np,length(num_beta_index),length(time_val)),
                        dimnames=list(
				   paste("ss",1:num_study,sep=""),
				   s.names,
                                   paste("lb",num_beta_index,sep=""),
                                   paste("t",time_val,sep="")))

  if(!is.null(gamma.param)){
    num_bgamma <- 1
    ## true gamma values
    gammat <- array(0,dim=c(num_study,np,num_bgamma,length(time_val)),
                        dimnames=list(
				   paste("ss",1:num_study,sep=""),
				   s.names,
                                   paste("lb",num_bgamma,sep=""),
                                   paste("t",time_val,sep="")))
  } else {
    num_bgamma <- NULL
    gammat <- NULL
  }

  if(!is.null(omega.param)){
    num_bomega <- 1
    ## true omega values
    omegat <- array(0,dim=c(num_study,np,num_bomega,length(time_val)),
                        dimnames=list(
				   paste("ss",1:num_study,sep=""),
				   s.names,
                                   paste("lb",num_bomega,sep=""),
                                   paste("t",time_val,sep="")))
  } else {
    num_bomega <- NULL
    omegat <- NULL
  }

  alphat <- array(0,dim=c(num_study,np,num_xx,length(time_val)),
                        dimnames=list(
				  paste("ss",1:num_study,sep=""),
				  s.names,
                                  paste("xx",1:num_xx,sep=""),
                                  paste("t",time_val,sep="")))

  Ft <- array(0,dim=c(num_study,np,z.choice,num_xx,length(time_val)),
                        dimnames=list(
				  paste("ss",1:num_study,sep=""),
				  s.names,
				  paste("zz_",z_lab,sep=""),
                                  paste("xx",1:num_xx,sep=""),
                                  paste("t",time_val,sep="")))



for(ss in 1:num_study){
  for(nn in 1:np){
    betat[ss,nn,,] <- as.matrix(data.truth[
    		   which(data.truth[,1]==ss & data.truth[,2]==nn & data.truth[,3]=="beta"),	
		   			    6:ncol(data.truth)])

    if(!is.null(gamma.param)){
      gammat[ss,nn,,] <- as.matrix(data.truth[
    		   which(data.truth[,1]==ss & data.truth[,2]==nn & data.truth[,3]=="gamma"),	
		   			    6:ncol(data.truth)])
    }

    if(!is.null(omega.param)){
      omegat[ss,nn,,] <- as.matrix(data.truth[
    		   which(data.truth[,1]==ss & data.truth[,2]==nn & data.truth[,3]=="omega"),	
		   			    6:ncol(data.truth)])
    }

    alphat[ss,nn,1:length(xx_val[[ss]]),] <- as.matrix(data.truth[
    		which(data.truth[,1]==ss & data.truth[,2]==nn & data.truth[,3]=="alpha"),
					 6:ncol(data.truth)])

    for(zz in 1:z.choice){
      Ft[ss,nn,zz,1:length(xx_val[[ss]]),] <- as.matrix(
      					   data.truth[which(data.truth[,1]==ss & data.truth[,2]==nn & 
     		    	data.truth[,3]=="Ft" & data.truth[,4]==zz),6:ncol(data.truth)])
    }
  }
}

####################
## beta estimates ##
####################
  beta.out <-  make.data.arrays(data.theta.est=data.beta,data.theta.varboot=data.beta.varboot,
				cnames=c("ss","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=get_beta_index,
				theta.set2=num_beta_index,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names=s.names,boot.ci=boot.ci)

  beta.array <- beta.out$theta.array
  data.beta.var <- beta.out$data.theta.var
  data.beta.ci.lo <- beta.out$data.theta.ci.lo  
  data.beta.ci.hi <- beta.out$data.theta.ci.hi  
  beta.var.array <- beta.out$theta.var.array
  beta.ci.lo.array <- beta.out$theta.ci.lo.array
  beta.ci.hi.array <- beta.out$theta.ci.hi.array
  

  if(num_study > 1){
    beta.diff.out <- make.data.diff.arrays(data.theta.est=data.beta.diff,
				cnames=c("combi","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=get_beta_index,
				theta.set2=num_beta_index,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names,combi.study,combi.names)

    beta.diff.array <- beta.diff.out$theta.array
    beta.diff.estdiff.array <- beta.diff.out$theta.estdiff.array
    beta.diff.ci.lo.array <- beta.diff.out$theta.ci.lo.array
    beta.diff.ci.hi.array <- beta.diff.out$theta.ci.hi.array
  } else {
    beta.diff.array <- NULL
    beta.diff.estdiff.array <- NULL
    beta.diff.ci.lo.array <- NULL
    beta.diff.ci.hi.array <- NULL
  }


####################
## gamma estimates ##
####################
  if(!is.null(gamma.param)){
    gamma.out <-  make.data.arrays(data.theta.est=data.gamma,data.theta.varboot=data.gamma.varboot,
				cnames=c("ss","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=1:num_bgamma,
				theta.set2=1:num_bgamma,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names=s.names,boot.ci=boot.ci)

    gamma.array <- gamma.out$theta.array
    data.gamma.var <- gamma.out$data.theta.var
    data.gamma.ci.lo <- gamma.out$data.theta.ci.lo  
    data.gamma.ci.hi <- gamma.out$data.theta.ci.hi  
    gamma.var.array <- gamma.out$theta.var.array
    gamma.ci.lo.array <- gamma.out$theta.ci.lo.array
    gamma.ci.hi.array <- gamma.out$theta.ci.hi.array
  

    if(num_study > 1){
      gamma.diff.out <- make.data.diff.arrays(data.theta.est=data.gamma.diff,
				cnames=c("combi","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=1:num_bgamma,
				theta.set2=1:num_bgamma,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names,combi.study,combi.names)

      gamma.diff.array <- gamma.diff.out$theta.array
      gamma.diff.estdiff.array <- gamma.diff.out$theta.estdiff.array
      gamma.diff.ci.lo.array <- gamma.diff.out$theta.ci.lo.array
      gamma.diff.ci.hi.array <- gamma.diff.out$theta.ci.hi.array
    } else {
      gamma.diff.array <- NULL
      gamma.diff.estdiff.array <- NULL
      gamma.diff.ci.lo.array <- NULL
      gamma.diff.ci.hi.array <- NULL
    }
  } else {
    gamma.out <- NULL
    gamma.array <- NULL
    data.gamma.var <- NULL
    data.gamma.ci.lo <- NULL
    data.gamma.ci.hi <- NULL
    gamma.var.array <- NULL
    gamma.ci.lo.array <- NULL
    gamma.ci.hi.array <- NULL

    gamma.diff.array <- NULL
    gamma.diff.estdiff.array <- NULL
    gamma.diff.ci.lo.array <- NULL
    gamma.diff.ci.hi.array <- NULL
  }


####################
## omega estimates ##
####################
  if(!is.null(omega.param)){
    omega.out <-  make.data.arrays(data.theta.est=data.omega,data.theta.varboot=data.omega.varboot,
				cnames=c("ss","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=1:num_bomega,
				theta.set2=1:num_bomega,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names=s.names,boot.ci=boot.ci)

    omega.array <- omega.out$theta.array
    data.omega.var <- omega.out$data.theta.var
    data.omega.ci.lo <- omega.out$data.theta.ci.lo  
    data.omega.ci.hi <- omega.out$data.theta.ci.hi  
    omega.var.array <- omega.out$theta.var.array
    omega.ci.lo.array <- omega.out$theta.ci.lo.array
    omega.ci.hi.array <- omega.out$theta.ci.hi.array
  

    if(num_study > 1){
      omega.diff.out <- make.data.diff.arrays(data.theta.est=data.omega.diff,
				cnames=c("combi","np","iter","lb",paste("t",time_val,sep="")),
				num_study,np,theta.set=1:num_bomega,
				theta.set2=1:num_bomega,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="lb",s.names,combi.study,combi.names)

      omega.diff.array <- omega.diff.out$theta.array
      omega.diff.estdiff.array <- omega.diff.out$theta.estdiff.array
      omega.diff.ci.lo.array <- omega.diff.out$theta.ci.lo.array
      omega.diff.ci.hi.array <- omega.diff.out$theta.ci.hi.array
    } else {
      omega.diff.array <- NULL
      omega.diff.estdiff.array <- NULL
      omega.diff.ci.lo.array <- NULL
      omega.diff.ci.hi.array <- NULL
    }
  } else {
    omega.out <- NULL
    omega.array <- NULL
    data.omega.var <- NULL
    data.omega.ci.lo <- NULL
    data.omega.ci.hi <- NULL
    omega.var.array <- NULL
    omega.ci.lo.array <- NULL
    omega.ci.hi.array <- NULL
    omega.diff.array <- NULL
    omega.diff.estdiff.array <- NULL
    omega.diff.ci.lo.array <- NULL
    omega.diff.ci.hi.array <- NULL
  }

#####################
## alpha estimates ##
#####################

  alpha.out <-  make.data.arrays(data.theta.est=data.alpha,data.theta.varboot=data.alpha.varboot,
                                cnames=c("ss","np","iter","xx",paste("t",time_val,sep="")),
                                num_study,np,theta.set=xx_val,
				theta.set2=1:num_xx,nsimu,num_time,time_val,
                                var.est=var.est,theta.interest="xx",s.names=s.names,boot.ci=boot.ci)


  alpha.array <- alpha.out$theta.array
  data.alpha.var <- alpha.out$data.theta.var
  data.alpha.ci.lo <- alpha.out$data.theta.ci.lo  
  data.alpha.ci.hi <- alpha.out$data.theta.ci.hi  
  alpha.var.array <- alpha.out$theta.var.array
  alpha.ci.lo.array <- alpha.out$theta.ci.lo.array
  alpha.ci.hi.array <- alpha.out$theta.ci.hi.array


  if(num_study > 1){
    alpha.diff.out <- make.data.diff.arrays(data.theta.est=data.alpha.diff,
				cnames=c("combi","np","iter","xx",paste("t",time_val,sep="")),
				num_study,np,theta.set=xx_val,
				theta.set2=1:num_xx,nsimu,num_time,time_val,
				var.est=var.est,theta.interest="xx",s.names,combi.study,combi.names)

    alpha.diff.array <- alpha.diff.out$theta.array
    alpha.diff.estdiff.array <- alpha.diff.out$theta.estdiff.array
    alpha.diff.ci.lo.array <- alpha.diff.out$theta.ci.lo.array
    alpha.diff.ci.hi.array <- alpha.diff.out$theta.ci.hi.array
  } else {
    alpha.diff.array <- NULL
    alpha.diff.estdiff.array <- NULL
    alpha.diff.ci.lo.array <- NULL
    alpha.diff.ci.hi.array <- NULL
  }

##################
## Ft estimates ##
##################
  Ft.out <- make.Ft.arrays(data.Ft,data.Ft.varboot,
		num_study,np,nsimu,num_time,time_val,num_xx,z.choice,z_lab,s.names,
		var.est=var.est,boot.ci=boot.ci)

  Ft.array <- Ft.out$theta.array
  data.Ft.var <- Ft.out$data.theta.var
  data.Ft.ci.lo <- Ft.out$data.theta.ci.lo  
  data.Ft.ci.hi <- Ft.out$data.theta.ci.hi  
  Ft.var.array <- Ft.out$theta.var.array
  Ft.ci.lo.array <- Ft.out$theta.ci.lo.array
  Ft.ci.hi.array <- Ft.out$theta.ci.hi.array

  if(num_study > 1){
    Ft.diff.out <- make.Ft.diff.arrays(data.Ft.diff,
		num_study,np,nsimu,num_time,time_val,num_xx,z.choice,z_lab,s.names,
		var.est=var.est,combi.study,combi.names)

    Ft.diff.array <- Ft.diff.out$theta.array
    Ft.diff.estdiff.array <- Ft.diff.out$theta.estdiff.array
    Ft.diff.ci.lo.array <- Ft.diff.out$theta.ci.lo.array
    Ft.diff.ci.hi.array <- Ft.diff.out$theta.ci.hi.array
  } else {
    Ft.diff.array <- NULL
    Ft.diff.estdiff.array <- NULL
    Ft.diff.ci.lo.array <- NULL
    Ft.diff.ci.hi.array <- NULL
  }

#####################
## adjust values ? ##
#####################
  make.fix.cutoff <- function(cut){
    function(x){
     if(x>cut){
       return(cut)
     } else if(x < -cut){
       return(-cut)
     } else {
       return(x)
     }
    }
  }

  adjust.value <- function(value,cut.function){
    if(!is.null(value)){
      value <- apply(value,1:length(dim(value)),cut.function)
      return(value)
    } else {
      return(value)
    }
  }

  ## adjust beta?
  if(!is.null(beta.cut)){
    cut.beta <- make.fix.cutoff(beta.cut)    	
    beta.array <- adjust.value(beta.array,cut.beta)
    beta.var.array <- adjust.value(beta.var.array,cut.beta)
    beta.ci.lo.array <- adjust.value(beta.ci.lo.array,cut.beta)
    beta.ci.hi.array <- adjust.value(beta.ci.hi.array,cut.beta)
    data.beta.var <- adjust.value(data.beta.var,cut.beta)
    data.beta.ci.lo <- adjust.value(data.beta.ci.lo,cut.beta)
    data.beta.ci.hi <- adjust.value(data.beta.ci.hi,cut.beta)
  }

 ## adjust alpha?
  if(!is.null(alpha.cut)){
    cut.alpha <- make.fix.cutoff(alpha.cut)    	
    alpha.array <- adjust.value(alpha.array,cut.alpha)
    alpha.var.array <- adjust.value(alpha.var.array,cut.alpha)
    alpha.ci.lo.array <- adjust.value(alpha.ci.lo.array,cut.alpha)
    alpha.ci.hi.array <- adjust.value(alpha.ci.hi.array,cut.alpha)
    data.alpha.var <- adjust.value(data.alpha.var,cut.alpha)
    data.alpha.ci.lo <- adjust.value(data.alpha.ci.lo,cut.alpha)
    data.alpha.ci.hi <- adjust.value(data.beta.ci.hi,cut.alpha)
  }



  ######################
  ## alpha(x,t) vs. x ##
  ######################
  alpha.array.new <- aperm(alpha.array,c(1,2,5,4,3))
  alphat.new <- aperm(alphat,c(1,2,4,3))

  if(var.est!="none"){
        alpha.var.array.new <- aperm(alpha.var.array,c(1,2,5,4,3))
        alpha.ci.lo.array.new <- aperm(alpha.ci.lo.array,c(1,2,5,4,3))
        alpha.ci.hi.array.new <- aperm(alpha.ci.hi.array,c(1,2,5,4,3))
  } else {
    alpha.var.array.new <- NULL
    alpha.ci.lo.array.new <- NULL
    alpha.ci.hi.array.new <- NULL
  }


list(betat=betat,
     gammat=gammat,
     omegat=omegat,
     #
     alphat=alphat,
     Ft=Ft,
     beta.array=beta.array,
     data.beta.var=data.beta.var,
     data.beta.ci.lo=data.beta.ci.lo,
     data.beta.ci.hi=data.beta.ci.hi,
     beta.var.array=beta.var.array,
     beta.ci.lo.array=beta.ci.lo.array,
     beta.ci.hi.array=beta.ci.hi.array,
     beta.diff.array=beta.diff.array,
     beta.diff.estdiff.array=beta.diff.estdiff.array,
     beta.diff.ci.lo.array=beta.diff.ci.lo.array,
     beta.diff.ci.hi.array=beta.diff.ci.hi.array,
     #
     gamma.array=gamma.array,
     data.gamma.var=data.gamma.var,
     data.gamma.ci.lo=data.gamma.ci.lo,
     data.gamma.ci.hi=data.gamma.ci.hi,
     gamma.var.array=gamma.var.array,
     gamma.ci.lo.array=gamma.ci.lo.array,
     gamma.ci.hi.array=gamma.ci.hi.array,
     gamma.diff.array=gamma.diff.array,
     gamma.diff.estdiff.array=gamma.diff.estdiff.array,
     gamma.diff.ci.lo.array=gamma.diff.ci.lo.array,
     gamma.diff.ci.hi.array=gamma.diff.ci.hi.array,
     #
     omega.array=omega.array,
     data.omega.var=data.omega.var,
     data.omega.ci.lo=data.omega.ci.lo,
     data.omega.ci.hi=data.omega.ci.hi,
     omega.var.array=omega.var.array,
     omega.ci.lo.array=omega.ci.lo.array,
     omega.ci.hi.array=omega.ci.hi.array,
     omega.diff.array=omega.diff.array,
     omega.diff.estdiff.array=omega.diff.estdiff.array,
     omega.diff.ci.lo.array=omega.diff.ci.lo.array,
     omega.diff.ci.hi.array=omega.diff.ci.hi.array,
     #
     alpha.array=alpha.array,
     data.alpha.var=data.alpha.var,
     data.alpha.ci.lo=data.alpha.ci.lo,
     data.alpha.ci.hi=data.alpha.ci.hi,
     alpha.var.array=alpha.var.array,
     alpha.ci.lo.array=alpha.ci.lo.array,
     alpha.ci.hi.array=alpha.ci.hi.array,
     alpha.diff.array=alpha.diff.array,
     alpha.diff.estdiff.array=alpha.diff.estdiff.array,
     alpha.diff.ci.lo.array=alpha.diff.ci.lo.array,
     alpha.diff.ci.hi.array=alpha.diff.ci.hi.array,
     #
     Ft.array=Ft.array,
     data.Ft.var=data.Ft.var,
     data.Ft.ci.lo=data.Ft.ci.lo,
     data.Ft.ci.hi=data.Ft.ci.hi,
     Ft.var.array=Ft.var.array,
     Ft.ci.lo.array=Ft.ci.lo.array,
     Ft.ci.hi.array=Ft.ci.hi.array,
     Ft.diff.array=Ft.diff.array,
     Ft.diff.estdiff.array=Ft.diff.estdiff.array,
     Ft.diff.ci.lo.array=Ft.diff.ci.lo.array,
     Ft.diff.ci.hi.array=Ft.diff.ci.hi.array,
     #
     alpha.array.new=alpha.array.new,
     alphat.new=alphat.new,
     alpha.var.array.new =alpha.var.array.new,
     alpha.ci.lo.array.new=alpha.ci.lo.array.new,
     alpha.ci.hi.array.new=alpha.ci.hi.array.new)
}





  
###############################
## Nadaraya-Watson functions ##
###############################
  
## function to get nw estimator
create.nw.estimator <- function(time_val){
  function(theta){
   nw.estimate <- ksmooth(time_val,theta)
   return(nw.estimate$y)
  }
}

## function to get nw estimator time values
create.nw.estimator.time <- function(time_val){
  function(theta){
    nw.estimate <- ksmooth(time_val,theta)
    return(nw.estimate$x)
  }
}


#####################
## Plot functions  ##
#####################


## function to find upper and lower quantiles
myquantiles.lo <-function(x){
  alpha <- 0.05
  B <- length(x)
  lo <- sort(x)[B*alpha/2]
  return(lo)
}

myquantiles.hi <-function(x){
  alpha <- 0.05
  B <- length(x)
  up <- sort(x)[B*(1-alpha/2)]
  return(up)
}

myquantiles <-function(x){
  alpha <- 0.05
  B <- length(x)
  up <- sort(x)[B*(1-alpha)]
  return(up)
}

## convert uniform CAG to real CAG
convert.cag <- function(x,xmin=xmin,xmax=xmax){
  xorig <- x*(xmax-xmin)+xmin
  return(xorig)
}

## convert CAG to uniform CAG
reverse.cag <- function(x,xmin=xmin,xmax=xmax){
  xnew <- (x-xmin)/(xmax-xmin)
  return(xnew)
}


## make Ft monotonic
getF <- function(Ft,p){
  n <- dim(Ft)[1]
  F <- Ft
  for(i in 1:p){
    #print(i)
    tmp <- min(F[2:n,i]-F[1:(n-1),i])
    k <- match(tmp,F[2:n,i]-F[1:(n-1),i])
    while(tmp<0){
      #print(tmp)
      F[k,i]=(F[k+1,i]+F[k,i])/2
      F[k+1,i]=F[k,i]
      tmp <- min(F[2:n,i]-F[1:(n-1),i])
      k <- match(tmp,(F[2:n,i]-F[1:(n-1),i]))
    }
  }
  return(F)
}




get.monotone <- function(theta.array,theta.ci.lo.array,theta.ci.hi.array,z.choice,num_study,np){
  not.interest <- "iter*"
  dim.remove <- grep(glob2rx(not.interest),dimnames(theta.array))  
  theta.array.new <- array(0,dim=dim(theta.array)[-dim.remove],
  		     dimnames=dimnames(theta.array)[-dim.remove])

  theta.ci.lo.array.new <- theta.array.new
  theta.ci.hi.array.new <- theta.array.new

  for(ss in 1:num_study){
    for(nn in 1:np){
      for(zz in 1:z.choice){
          theta.array.tmp <- adrop(theta.array[ss,nn,zz,,,,drop=FALSE],drop=1)
          theta.ci.lo.array.tmp <- adrop(theta.ci.lo.array[ss,nn,zz,,,,drop=FALSE],drop=1)
          theta.ci.hi.array.tmp <- adrop(theta.ci.hi.array[ss,nn,zz,,,,drop=FALSE],drop=1)
	      
	  dim.cut <- c(3,5)

	  ## Find relevant quantities for theta(t0)
  	  theta.array.mean <- apply(theta.array.tmp,dim.cut,mean)
	  theta.ci.lo.array.mean <- apply(theta.ci.lo.array.tmp,dim.cut,mean)
	  theta.ci.hi.array.mean <- apply(theta.ci.hi.array.tmp,dim.cut,mean)

	  

          ## adjust for monotonicity
     	  theta.array.new[ss,nn,zz,,] <- t(getF(t(theta.array.mean),p=length(xx_val)))
     	  theta.ci.hi.array.new[ss,nn,zz,,] <- t(getF(t(theta.ci.hi.array.mean),p=length(xx_val)))
     	  theta.ci.lo.array.new[ss,nn,zz,,] <- t(getF(t(theta.ci.lo.array.mean),p=length(xx_val)))
      }
    }
  }
  
  list(theta.array.new=theta.array.new,theta.ci.hi.array.new=theta.ci.hi.array.new,
	theta.ci.lo.array.new=theta.ci.lo.array.new)
}


get.monotone.ij <- function(theta.array,theta.ci.lo.array,theta.ci.hi.array,num_study,np,
			ii.choose=c(1,2),time_val,nsimu,s.names){

  num_ii <- max(unlist(lapply(ii.choose,length.apply)))

  theta.array.new <- array(0,dim=c(num_study,np,num_ii,nsimu,length(time_val)),
				dimnames=list(
					paste("ss",1:num_study,sep=""),
					s.names,
					paste("ii",1:num_ii,sep=""),
 					paste("iter",1:nsimu,sep=""),
					paste("tt",time_val,sep="")))
  theta.ci.hi.array.new <- theta.array.new
  theta.ci.lo.array.new <- theta.array.new

  for(ss in 1:num_study){
    for(nn in 1:np){
      for(kk in 1:length(ii.choose[[ss]])){
        ## adjust for monotonicity
      	theta.array.new[ss,nn,kk,1,] <- t(getF(as.matrix(theta.array[ss,nn,ii.choose[[ss]][kk],1,]),p=1))
      	theta.ci.hi.array.new[ss,nn,kk,1,] <- t(getF(as.matrix(theta.ci.hi.array[ss,nn,ii.choose[[ss]][kk],1,]),p=1))
      	theta.ci.lo.array.new[ss,nn,kk,1,] <- t(getF(as.matrix(theta.ci.lo.array[ss,nn,ii.choose[[ss]][kk],1,]),p=1))
      }
    }
  }
  
  list(theta.array.new=theta.array.new,theta.ci.hi.array.new=theta.ci.hi.array.new,
	theta.ci.lo.array.new=theta.ci.lo.array.new)
}

## plot of function a(x,t) over t at different x
plot.3d.time <- function(filename,xx_choice,xx_val,time_choice,time_val,estimate,
		    theta.array.lo=NULL,theta.array.hi=NULL,
		    index_xx=which(round(xx_val,3)%in%round(xx_choice,3)),
		    color="lightgreen",cex.lab=3,cex.axis=3,
                    lwd=5,real_data=TRUE,cex.legend=3,
                    legend.position="topright",ylim=NULL,conf.int=FALSE,
		    xmin,xmax,xaxis.cut,name.diff="_diff_x",convert.x=TRUE,label.names=NULL){

  if(convert.x==TRUE){
    x <- convert.cag(xx_val,xmin=xmin,xmax=xmax)
  } else {
   x <- xx_val 
  }

  if(!is.null(xaxis.cut)){
    index.cut <- which(as.numeric(time_val)==xaxis.cut)
  } else {
    index.cut <- length(time_val)
  }
  
  y <- as.numeric(time_val)
  z <- estimate

  
#  postscript(paste(filename,"_persp_t",".eps",sep=""))
#  op <- par(bg="white")
#  persp(x,y,z,theta=60,phi=30,expand=0.5,col=color,axes=TRUE,ticktype="detailed",
#        xlab="",ylab="",zlab="",cex.lab=cex.lab,cex.axis=cex.axis,lwd=lwd)
#  dev.off()
  
#  postscript(paste(filename,"_persp_x",".eps",sep=""))
#  persp(x,y,z,theta=30,phi=30,expand=0.5,col=color,axes=TRUE,ticktype="detailed",
#        xlab="",ylab="",zlab="",cex.lab=cex.lab,cex.axis=cex.axis,lwd=lwd)
#  dev.off()
  
  #############################
  ## plot for different CAGs ##
  #############################

  postscript(paste(filename,name.diff,".eps",sep=""))

  
  if(is.null(ylim)){
    ylim <- c(min(estimate[index_xx,1:index.cut]),max(estimate[index_xx,1:index.cut])) 

    if(conf.int==TRUE){
      ylim <- c(min(estimate[index_xx,1:index.cut],
		theta.array.lo[index_xx,1:index.cut],theta.array.hi[index_xx,1:index.cut]),
		max(estimate[index_xx,1:index.cut],
		theta.array.lo[index_xx,1:index.cut],theta.array.hi[index_xx,1:index.cut]))
    }
  }


  plot(1,type="n",xlab="",ylab="",xlim=c(min(as.numeric(time_val[1:index.cut])),
	max(as.numeric(time_val[1:index.cut]))),
      ylim=ylim,cex.axis=cex.axis,cex.lab=cex.lab)
 

 ## color.list <- c("black","red","blue","green")       
  color.list <- 1:length(index_xx)
  line.names <- NULL	
  tmp <- 0
  for(i in index_xx){
    tmp <- tmp+1
    lines(time_val[1:index.cut],estimate[i,1:index.cut],col=color.list[tmp],lty=1,lwd=lwd)
    if(is.null(label.names)){
      line.names <- c(line.names,paste("CAG",round(x[i]),sep=" "))	
    }

    if(conf.int==TRUE){					     
      lines(time_val[1:index.cut],theta.array.lo[i,1:index.cut],col=color.list[tmp],lty=3,lwd=lwd)
      lines(time_val[1:index.cut],theta.array.hi[i,1:index.cut],col=color.list[tmp],lty=4,lwd=lwd)
    }
  }

  if(!is.null(label.names)){
    line.names <- label.names
  }
  
  if(!is.null(legend.position)){
    legend(legend.position,line.names,
         col=color.list[1:tmp],
         lty=rep(1,length(index_xx)),lwd=rep(lwd,length(index_xx)),
         bty="n",cex=cex.legend) 
  }

  dev.off()
}




## plot of function a(x,t) over t at different x
plot.3d.compare <- function(filename,xx_choice,xx_val,time_choice,time_val,alphax_lab,
		    list.name,
		    s.names,
		    index_xx,
		    estimate,
		    estimate.ci.lo=NULL,estimate.ci.hi=NULL,
		    color="lightgreen",cex.lab=3,cex.axis=3,
                    lwd=5,real_data=TRUE,cex.legend=3,
                    legend.position="topright",ylim=NULL,conf.int=FALSE,
		    xmin,xmax,nn.choice,colors.use){

  if(real_data==TRUE){
    x <- convert.cag(xx_val,xmin=xmin,xmax=xmax)
  } else {
   x <- xx_val 
  }
  
  
  ##########################################
  ## plot comparing Fts at different CAGs ##
  ##########################################
  index_xx<- which(round(xx_val,3)%in%round(xx_choice,3))
  if(is.null(ylim)){
    if(conf.int==FALSE){
      ylim <- c(min(estimate[nn.choice,index_xx,]),max(estimate[nn.choice,index_xx,]))
    } else {
      ylim <- c(min(min(estimate[nn.choice,index_xx,]),
      	      min(estimate.ci.lo[nn.choice,index_xx,]),
	      min(estimate.ci.hi[nn.choice,index_xx,])),
      	      max(max(estimate[nn.choice,index_xx,]),
	      max(estimate.ci.lo[nn.choice,index_xx,]),max(estimate.ci.hi[nn.choice,index_xx,])))
    }
  }

  ##color.list <- c("blue","black","red","green")
  color.list <- colors.use
  ##color.list <- nn.choice

  tmp <-0
  for(i in index_xx){
    tmp <-tmp+1
    postscript(paste(filename,alphax_lab[tmp],".eps",sep=""))
    
    plot(1,type="n",xlab="",ylab="",xlim=c(min(as.numeric(time_val)),max(as.numeric(time_val))),
       ylim=ylim,cex.axis=cex.axis,cex.lab=cex.lab)

    ##tmpa <- 0
    for(nn in nn.choice){
      ##tmpa <- tmpa +1
      lines(time_val,estimate[s.names[nn],i,],col=color.list[s.names[nn]],lty=1,lwd=lwd)
      
      if(conf.int==TRUE){
        lines(time_val,estimate.ci.lo[s.names[nn],i,],col=color.list[s.names[nn]],lty=3,lwd=lwd)      
        lines(time_val,estimate.ci.hi[s.names[nn],i,],col=color.list[s.names[nn]],lty=4,lwd=lwd)      
      }
    }  

    if(!is.null(legend.position)){
      legend(legend.position,list.name[nn.choice],
         col=color.list[s.names[nn.choice]],
         lty=rep(1,length(nn.choice)),lwd=rep(lwd,length(nn.choice)),
         bty="n",cex=cex.legend) 
    }
    dev.off()
  }
}


plot.ij.compare <- function(filename,ii_lab,list.name,
		    estimate,
		    estimate.ci.lo=NULL,estimate.ci.hi=NULL,
		    color="lightgreen",cex.lab=3,cex.axis=3,
                    lwd=5,real_data=TRUE,cex.legend=3,
                    legend.position="topright",ylim=NULL,conf.int=FALSE,
		    xmin,xmax){
  
  ########################################
  ## plot comparing Fts for each person ##
  ########################################
  if(is.null(ylim)){
    if(conf.int==FALSE){
      ylim <- c(min(estimate),max(estimate))
    } else {
      ylim <- c(min(min(estimate),min(estimate.ci.lo),min(estimate.ci.hi)),
      	      max(max(estimate),max(estimate.ci.lo),max(estimate.ci.hi)))
    }
  }

  ##color.list <- c("blue","black","red","green")
  color.list <- 1:np

  postscript(paste(filename,"_compare_",ii_lab,".eps",sep=""))
    
  plot(1,type="n",xlab="",ylab="",xlim=c(min(as.numeric(time_val)),max(as.numeric(time_val))),
       ylim=ylim,cex.axis=cex.axis,cex.lab=cex.lab)

  for(nn in 1:np){
      lines(time_val,estimate[nn,],col=color.list[nn],lty=1,lwd=lwd)
      
      if(conf.int==TRUE){
        lines(time_val,estimate.ci.lo[nn,],col=color.list[nn],lty=3,lwd=lwd)      
        lines(time_val,estimate.ci.hi[nn,],col=color.list[nn],lty=4,lwd=lwd)      
      }
  }  

    legend(legend.position,list.name,
         col=color.list[1:np],
         lty=rep(1,np),lwd=rep(lwd,np),
         bty="n",cex=cex.legend) 
    dev.off()

}


## plot of a(x,t) over x at different t
plot.3d.x <- function(filename,xx_choice,xx_val,time_choice,time_val,estimate,
		    theta.array.lo=NULL,theta.array.hi=NULL,
		    color="lightgreen",cex.lab=3,cex.axis=3,
                    lwd=5,real_data=TRUE,cex.legend=3,
                    legend.position="topright",ylim=NULL,conf.int=FALSE,
		    xmin,xmax,name.diff="_diff_t"){

  if(real_data==TRUE){
    x <- convert.cag(xx_val,xmin=xmin,xmax=xmax)
  } else {
   x <- xx_val 
  }
  
  y <- as.numeric(time_val)
  z <- estimate

  
#  postscript(paste(filename,"_persp_t",".eps",sep=""))
#  op <- par(bg="white")
#  persp(x,y,z,theta=60,phi=30,expand=0.5,col=color,axes=TRUE,ticktype="detailed",
#        xlab="",ylab="",zlab="",cex.lab=cex.lab,cex.axis=cex.axis,lwd=lwd)
#  dev.off()
  
#  postscript(paste(filename,"_persp_x",".eps",sep=""))
#  persp(x,y,z,theta=30,phi=30,expand=0.5,col=color,axes=TRUE,ticktype="detailed",
#        xlab="",ylab="",zlab="",cex.lab=cex.lab,cex.axis=cex.axis,lwd=lwd)
#  dev.off()
  
  #############################
  ## plot for different time ##
  #############################
  postscript(paste(filename,name.diff,".eps",sep=""))
  index_tt<- which(round(time_val,3)%in%time_choice)

  color.list <- c("black","blue","red","green")
 ## color.list <- 1:length(index_tt)
  
  if(is.null(ylim)){
    ylim <- c(min(estimate[,index_tt]),max(estimate[,index_tt])) 

    if(conf.int==TRUE){
	ylim <- c(min(estimate[,index_tt],theta.array.lo[,index_tt],
			theta.array.hi[,index_tt]),
			max(estimate[,index_tt],theta.array.lo[,index_tt],
                        theta.array.hi[,index_tt]))
    }
  }
  

  plot(1,type="n",xlab="",ylab="",xlim=c(min(as.numeric(x)),max(as.numeric(x))),
       ylim=ylim,cex.axis=cex.axis,cex.lab=cex.lab)
         

  line.names <- NULL	
  tmp <- 0
  for(i in index_tt){
    tmp <- tmp+1
    lines(x,estimate[1:length(x),i],col=color.list[tmp],lty=1,lwd=lwd)
    line.names <- c(line.names,paste("t=",round(time_choice[tmp]),sep=" "))	

    if(conf.int==TRUE){					     
      lines(x,theta.array.lo[1:length(x),i],col=color.list[tmp],lty=3,lwd=lwd)
      lines(x,theta.array.hi[1:length(x),i],col=color.list[tmp],lty=4,lwd=lwd)
    }
  }
  
  legend(legend.position,line.names,
         col=color.list[1:tmp],
         lty=rep(1,tmp),lwd=rep(lwd,tmp),
         bty="n",cex=cex.legend) 
  dev.off()
}


alphax.plot <- function(filename="alpha_x_est",tt_choice=NULL,xx_val=NULL,add.legend=FALSE,xlab="",ylab="",
			time_val,alphat,alpha.array,
                        cex.lab=2,cex.axis=2,lwd=2,cex.legend=2,
                        legend.position="topright",real_data=FALSE){
    
  ## Find relevant quantities for beta(t0)
  alpha.array.mean <- apply(alpha.array,c(2,4),mean)
  
  if(real_data==FALSE){
    alpha.array.lo <- apply(alpha.array,c(2,4),myquantiles.lo)
    alpha.array.hi <- apply(alpha.array,c(2,4),myquantiles.hi)
  }

  ## form index
  index_xx<- which(round(time_val,3)%in%tt_choice)
  
  for(i in index_xx){
    ##    print(i)
    postscript(paste(filename,"_",i,"nodiv.eps",sep=""))		
    ## start plot
    par(mar=c(5,4,4,2)+1)
    true<- alphat[i,]
    est <- alpha.array.mean[i,]
    plot(true[order(true)],
	 est[order(true)],
	 xlab=xlab,ylab=ylab,cex.axis=cex.axis,cex.lab=cex.lab,
	 type="l")
    dev.off()	


    postscript(paste(filename,"_",i,"div.eps",sep=""))		
    ## start plot
    par(mar=c(5,4,4,2)+1)
    true<- alphat[i,]/xx_val
    est <- alpha.array.mean[i,]/xx_val
    plot(true[order(true)],
	 est[order(true)],
	 xlab=xlab,ylab=ylab,cex.axis=cex.axis,cex.lab=cex.lab,
	 type="l")
    dev.off()	
  }
}

estimate.plot <- function(filename="thetaest",xx_choose=1:lb,xx_val=1:lb,xx_lab=1:lb,
			plot.nw=FALSE,add.legend=FALSE,xlab="",ylab="",
                        parameter="theta",
                        tt_val,
			thetat,theta.array,theta.ci.lo.array=NULL,theta.ci.hi.array=NULL,
			tt_val_nw=NULL,theta.array.nw=NULL,theta.ci.lo.array.nw=NULL,theta.ci.hi.array.nw=NULL,
			var.est=c("quant","est","none")[1],
                        ##cex.lab=2,cex.axis=2,lwd=2,cex.legend=2,
			cex.lab=3,cex.axis=3,lwd=5,cex.legend=3,
                        legend.position="topright",real_data=FALSE,
			convert=FALSE,xmin,xmax,ylim.set,xaxis.cut){
  
  if(real_data==TRUE && convert==TRUE){
    tt_val=convert.cag(tt_val,xmin=xmin,xmax=xmax)
  }

  if(!is.null(xaxis.cut)){
    index.cut <- which(as.numeric(tt_val)==xaxis.cut)
  } else {
    index.cut <- length(tt_val)
  }

  dim.cut <- c(2,4)
  
  ## Find relevant quantities for theta(t0)
  theta.array.mean <- apply(theta.array,dim.cut,mean)
  
  if(plot.nw==TRUE){
     theta.array.nw.mean <- apply(theta.array.nw,dim.cut,mean)
  }  

  if(var.est=="quant"){
    ## quantiles as 95% CI
    theta.array.lo <- apply(theta.array,dim.cut,myquantiles.lo)
    theta.array.hi <- apply(theta.array,dim.cut,myquantiles.hi)
    
    if(plot.nw==TRUE){
      theta.array.nw.lo <- apply(theta.array.nw,dim.cut,myquantiles.lo)
      theta.array.nw.hi <- apply(theta.array.nw,dim.cut,myquantiles.hi)
    }
  } else if(var.est=="est"){
    ## estimated variability
    theta.array.lo <- apply(theta.ci.lo.array,dim.cut,mean)
    theta.array.hi <- apply(theta.ci.hi.array,dim.cut,mean)

    if(plot.nw==TRUE){
      theta.array.nw.lo <- apply(theta.ci.lo.array.nw,dim.cut,mean)
      theta.array.nw.hi <- apply(theta.ci.lo.array.nw,dim.cut,mean)
    }
   } else {
     ## no estimated variability (this is just to set the limits)
     theta.array.lo <- theta.array.mean
     theta.array.hi <- theta.array.mean

     if(plot.nw==TRUE){
	theta.array.nw.lo <- theta.array.nw.mean
	theta.array.nw.hi <- theta.array.nw.mean
     }
  }

  if(parameter=="Ft"){
     ## adjust for monotonicity
     theta.array.mean <- t(getF(t(theta.array.mean),p=length(xx_val)))
     theta.array.hi <- t(getF(t(theta.array.hi),p=length(xx_val)))
     theta.array.lo <- t(getF(t(theta.array.lo),p=length(xx_val)))
  }
  
  
  ## form index
  if(real_data==TRUE){
    index_xx<- which(round(xx_val,3)%in%round(xx_choose,3))
  } else {
    index_xx<- which(round(xx_val,3)%in%xx_choose)
  }  

  for(k in 1:length(index_xx)){
  #for(i in index_xx){
    i <- index_xx[k]
    ##    print(i)
    postscript(paste(filename,"_",xx_lab[k],".eps",sep=""))		
    
    ################
    ## get limits ##
    ################
    y.min <- min(theta.array.mean[i,],min(theta.array.lo[i,]),min(theta.array.hi[i,]))
    y.max <- max(theta.array.mean[i,],max(theta.array.lo[i,]),max(theta.array.hi[i,]))
    
    if(plot.nw==TRUE){
	y.min <- min(y.min,min(theta.array.nw.mean[i,]),min(theta.array.nw.lo[i,]),min(theta.array.nw.hi[i,]))
	y.max <- max(y.max,max(theta.array.nw.mean[i,]),max(theta.array.nw.lo[i,]),max(theta.array.nw.hi[i,]))
    }

    if(real_data==FALSE){
	## simulated data so we know the truth
	y.min <- min(y.min,min(thetat[,i,]))
	y.max <- max(y.max,max(thetat[,i,]))
    }
    
    ## start plot
    par(mar=c(5,4,4,2)+1)
    ##if(parameter=="beta"){
    ##  ylab=substitute(paste(beta[i],"(t)",sep=""),list(i=i))
    ##} else if(parameter=="alpha"){
    ##  ylab=substitute(paste(alpha,"(x,t)",sep=""))
    ##}

    if(!is.null(ylim.set)){
      ylim = ylim.set
    } else {
      ylim=c(y.min,y.max)
    }

    xlim.set <- c(min(as.numeric(tt_val[1:index.cut])),
			max(as.numeric(tt_val[1:index.cut])))
    plot(1,type="n",xlab=xlab,ylab=ylab,xlim=xlim.set,
         ylim=ylim,cex.axis=cex.axis,cex.lab=cex.lab)

    if(real_data==FALSE){
      ## plot truth
      lines(tt_val[1:index.cut],thetat[,i,1:index.cut],col="black",lty=1,lwd=lwd)
    }

    ## plot estimated theta(t0)
    if(real_data==TRUE){
      lines(tt_val[1:index.cut],theta.array.mean[i,1:index.cut],col="black",lty=1,lwd=lwd)	
    } else {
      lines(tt_val[1:index.cut],theta.array.mean[i,1:index.cut],col="blue",lty=2,lwd=lwd)	
    }   

    if(plot.nw==TRUE){
      ## plot NW estimated beta(t)
      lines(tt_val_nw,theta.array.nw.mean[i,],col="red",lty=2,lwd=lwd)	
    }	
   
    if(var.est!="none"){
      ## plot 2.5% CI and 97.5 % CI for estimated beta(t0)
      if(real_data==TRUE){
        color <- "black"
      } else {
        color <- "blue"
      }
      lines(tt_val[1:index.cut],theta.array.lo[i,1:index.cut],col=color,lty=3,lwd=lwd)	
      lines(tt_val[1:index.cut],theta.array.hi[i,1:index.cut],col=color,lty=4,lwd=lwd)
      
      if(plot.nw==TRUE){
	lines(tt_val_nw,theta.array.nw.lo[i,],col="red",lty=3,lwd=lwd)	
        lines(tt_val_nw,theta.array.nw.hi[i,],col="red",lty=4,lwd=lwd)
      }
    }
    
    if(add.legend==TRUE){
      if(parameter=="beta"&&i==1){
        legend.position<- "bottomright"
         if(var.est!="none"){
 	  if(plot.nw==TRUE){
	     legend(legend.position,c("Truth","Pointwise estimate","Nadaraya-Watson Estimate",
                                   "95% CI (lower)", "95% CI (upper)"),
                 col=c("black","blue","red","black","black"),
                 lty=c(1,2,2,3,4),lwd=rep(lwd,5),
                 bty="n",cex=cex.legend)
          } else {
	        legend(legend.position,c("Truth","Pointwise estimate",
                                   "95% CI (lower)", "95% CI (upper)"),
                 col=c("black","blue","black","black"),
                 lty=c(1,2,3,4),lwd=rep(lwd,4),
                 bty="n",cex=cex.legend)
	  }
        } else {
	  if(plot.nw==TRUE){
            legend(legend.position,c("Pointwise estimate","Nadaraya-Watson Estimate"),
                 col=c("blue","red"),
                 lty=c(2,2),lwd=rep(lwd,2),
                 bty="n",cex=cex.legend)
          } else {
	    legend(legend.position,c("Pointwise estimate"),
                 col=c("blue"),
                 lty=c(2),lwd=rep(lwd,1),
                 bty="n",cex=cex.legend)

	  }
        }
      }

    }
    dev.off()	
  }
}

  ## plot counts
plot.counts <- function(filename,time_val,counts.array,lwd=3,cex.legend=3,cex.axis=3){
  data.count2 <- apply(counts.array,c(2,3),mean)
  
  postscript(paste(filename,"_counts.eps",sep=""))		  
  plot(as.numeric(time_val),as.numeric(data.count2[,1]),col="blue",type="l",lwd=lwd,
	ylim=c(0,1),ylab="",xlab="",cex.axis=cex.axis)
  lines(as.numeric(time_val),as.numeric(data.count2[,2]),col="red",lty=1,lwd=lwd)
  lines(as.numeric(time_val),as.numeric(data.count2[,3]),col="green",lty=1,lwd=lwd)
  lines(as.numeric(time_val),as.numeric(data.count2[,4]),col="black",lty=1,lwd=lwd)
  legend("bottomright",c("Y=1","Y=0, delta=1","Y=0, delta=0","Y in (0,1)"),col=c("blue","red","green","black"),
         lty=c(1,1,1,1),lwd=rep(lwd,4),bty="n",cex=cex.legend)
  dev.off()
}

## IAC calculation
iac.results <- function(theta.array,theta.ci.lo.array,theta.ci.hi.array,time_val,
			time.index=5,iter.index=4,xx_choose=NULL,useFt=FALSE){

  iac.tmp <- (theta.ci.lo.array <= theta.array) & (theta.array <= theta.ci.hi.array)
  iac.sum <- apply(iac.tmp,(1:length(dim(iac.tmp)))[-time.index],sum)
  iac.sum <- sweep(iac.sum,1:length(dim(iac.sum)),length(time_val),FUN="==")
  iac.out <- apply(iac.sum,(1:length(dim(iac.sum)))[-iter.index],mean)

  if(!is.null(xx_choose)){
    if(useFt==FALSE){
      iac.out <- iac.out[,,xx_choose,drop=FALSE]
    } else {
      iac.out <- iac.out[,,,xx_choose,drop=FALSE]
    }
  }

  return(iac.out)
}


## parameter estimates
parameter.results <- function(thetat,theta.array,theta.var.array,tt_val,xx_choose,tt_choose,nsimu,
                     var.est=c("quant","est")[1],np=np,xx_lab,xx_lab_name,s.names,use.xx=FALSE){

  if(use.xx==TRUE){
    lab.tmp <- "xx_"
  } else {
    lab.tmp <- "tt_"
  }

  mean.theta <- apply(theta.array,c(1,2,4),mean)
  emp.var.theta <- apply(theta.array,c(1,2,4),var)

  if(var.est=="est"){
    est.var.theta <- apply(theta.var.array,c(1,2,4),mean)
  } else {
    est.var.theta <- emp.var.theta
  }

  bias <- mean.theta-thetat
  abs.bias <- abs(bias)
  cov.prob <- mean.theta
  mse <- bias^2 + est.var.theta

  for(nn in 1:np){
    for(j in 1:length(tt_val)){
       myvar.mat <- matrix(rep(est.var.theta[nn,,j],nsimu),nrow=nsimu,byrow=TRUE)
       mytruth.mat <- matrix(rep(thetat[nn,,j],nsimu),nrow=nsimu,byrow=TRUE)
       tmp.matrix <- t(theta.array[nn,,,j])
       if(nrow(tmp.matrix)==1) tmp.matrix <- t(tmp.matrix)
       mycov.tmp <- t(apply(abs(tmp.matrix-mytruth.mat)/sqrt(myvar.mat),1,pnorm)<0.975)
       if(nrow(mycov.tmp)==1) mycov.tmp <- t(mycov.tmp)
       cov.prob[nn,,j] <- apply(mycov.tmp,2,sum)/nsimu
    }
  }

#####################
## Average results ##
#####################
  avg.abs.bias <- apply(abs.bias,c(1,2),mean,na.rm=TRUE)
  avg.bias <- apply(bias,c(1,2),mean,na.rm=TRUE)
  avg.emp.var <- apply(emp.var.theta,c(1,2),mean,na.rm=TRUE)
  avg.est.var <- apply(est.var.theta,c(1,2),mean,na.rm=TRUE)
  avg.cov <- apply(cov.prob,c(1,2),mean,na.rm=TRUE)
  avg.mse <-apply(mse,c(1,2),mean,na.rm=TRUE)

  avg.results <- array(0,dim=c(np,6,length(xx_choose)),
                        dimnames=list(rownames(avg.cov),
                                c("abs bias","bias","emp var","est var","95% cov","MSE"),
                                paste(xx_lab_name,xx_lab,sep="")))

  for(nn in 1:np){
    avg.results[nn,,] <- rbind(avg.abs.bias[nn,xx_choose],
                                avg.bias[nn,xx_choose],
                                avg.emp.var[nn,xx_choose],
                                avg.est.var[nn,xx_choose],
                                avg.cov[nn,xx_choose],
                                avg.mse[nn,xx_choose])
  }


#######################
  ## Pointwise results ##
#######################
  time_index <- which(tt_val%in%tt_choose)
  pt.bias <- bias[,,time_index,drop=FALSE]
  pt.est.var <- est.var.theta[,,time_index,drop=FALSE]
  pt.emp.var <- emp.var.theta[,,time_index,drop=FALSE]
  pt.cov <- cov.prob[,,time_index,drop=FALSE]
  pt.mse <- mse[,,time_index,drop=FALSE]



  mytmp <- c("bias","emp_var","est_var","95%_cov","MSE")
  mylabel <- paste(lab.tmp,as.vector(t(outer(tt_choose,mytmp,paste,sep="_"))),sep="")
  pt.results <- array(0,dim=c(np,5*length(time_index),dim(pt.bias)[2]),
                        dimnames=list(s.names,
                                paste(lab.tmp,as.vector(t(outer(tt_choose,mytmp,paste,sep="_"))),
				sep=""),
                                dimnames(pt.bias)[[2]]))
  for(nn in 1:np){
   for (i in 1:length(time_index)){
     pt.results[nn,paste(lab.tmp,tt_choose[i],"_","bias",sep=""),] <- pt.bias[nn,,i]
     pt.results[nn,paste(lab.tmp,tt_choose[i],"_","emp_var",sep=""),] <- pt.emp.var[nn,,i]
     pt.results[nn,paste(lab.tmp,tt_choose[i],"_","est_var",sep=""),] <- pt.est.var[nn,,i]
     pt.results[nn,paste(lab.tmp,tt_choose[i],"_","95%_cov",sep=""),] <- pt.cov[nn,,i]
     pt.results[nn,paste(lab.tmp,tt_choose[i],"_","MSE",sep=""),] <- pt.mse[nn,,i]
   }
  }
  pt.results <- pt.results[,,xx_choose,drop=FALSE]

  list(avg.results=avg.results,pt.results=pt.results)
}


###############################
## put data in form of table ##
###############################

organize.data <- function(avg.results,pt.results,np,tt_choose,xx_choose,zz_choose,
				param="beta",xx_lab=NULL,study=1,use.xx=FALSE,analyze.separately=NULL,
				common.param.estimation=NULL){
  if(use.xx==TRUE){
    lab.tmp <- "xx_" 
  } else {
    lab.tmp <- "tt_"
  }

  ##############################
  ## organize average results ##
  ##############################
  out.avg <- NULL
  avg.label <- NULL
  for(nn in 1:np){
    tmp.index <- paste("np",nn,sep="")
    tmp.label <- paste("np",nn,"_",dimnames(avg.results)[[3]],sep="")
    avg.label <- c(avg.label,tmp.label)
    out.avg <- cbind(out.avg,avg.results[tmp.index,,])
  }
  colnames(out.avg) <- avg.label

  np_index <- 1:np

  if(common.param.estimation==FALSE){
    s.use <- "s"
    study.use <- study
  } else {
    s.use <- NULL
    study.use <- NULL
  }

  if(param=="beta"){

    latex.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_lab)),s.use,
    		       rep(xx_lab,np),
    		       "}(\\cdot)$",sep="")
    latex.study.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_lab)),
    			study.use,rep(xx_lab,np),"}(\\cdot)$",sep="")

    index.beta0 <- grep(glob2rx("*0*"),latex.avg.label)
    if(!is.null(index.beta0)){
      if(analyze.separately=="study"){
        latex.avg.label[index.beta0] <- paste("$\\wh\\",param,"_{",s.use,0,"}(\\cdot)$",sep="")
 	latex.study.avg.label[index.beta0] <- paste("$\\wh\\",param,"_{",study.use,
					      0,"}(\\cdot)$",sep="")
	
	latex.avg.label[index.beta0[2:length(index.beta0)]] <- "%NONE"
	latex.study.avg.label[index.beta0[2:length(index.beta0)]] <- "%NONE"
      } else if(analyze.separately=="none"){
        latex.avg.label[index.beta0] <- paste("$\\wh\\",param,"_{",0,"}(\\cdot)$",sep="")
        latex.study.avg.label[index.beta0] <- paste("$\\wh\\",param,"_{",0,"}(\\cdot)$",sep="")

	latex.avg.label[index.beta0[2:length(index.beta0)]] <- "%NONE"
	latex.study.avg.label[index.beta0[2:length(index.beta0)]] <- "%NONE"     
      }

      #if(length(xx_lab)==2){
      #  # xx_lab=c(0,1)
      #	latex.avg.label[-index.beta0] <-  paste("$\\wh\\",param,"_{",
      #				      	  rep(np_index,each=length(xx_lab)-1),"s",
      #					  "}(\\cdot)$",sep="")
      #	latex.study.avg.label[-index.beta0] <-  paste("$\\wh\\",param,"_{",
      #				      	  rep(np_index,each=length(xx_lab)-1),study,
      #					  "}(\\cdot)$",sep="")
      #
      #}
    }

    if(length(xx_lab)==1 && length(index.beta0)==0){
      # xx_lab=1
      latex.avg.label <-  paste("$\\wh\\",param,"_{",
				      	  rep(np_index,each=length(xx_lab)),s.use,
					  "}(\\cdot)$",sep="")
      latex.study.avg.label <-  paste("$\\wh\\",param,"_{",
				      	  rep(np_index,each=length(xx_lab)),study.use,
					  "}(\\cdot)$",sep="")
      
    }
    			
  } else if(param=="gamma" || param=="omega"){
    if(analyze.separately=="study"){
      latex.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_lab)),s.use,
    		       "}(\\cdot)$",sep="")
      latex.study.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_lab)),study.use,
    			"}(\\cdot)$",sep="")
    } else {
      latex.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_lab)),
    		       "}(\\cdot)$",sep="")
      latex.study.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_lab)),
    			"}(\\cdot)$",sep="")      
    }

    ## removing gamma_1 and omega_1
    latex.avg.label[grep(glob2rx("*_{1*}*"),latex.avg.label)] <- "%NONE"
    latex.study.avg.label[grep(glob2rx("*_{1*}*"),latex.study.avg.label)] <- "%NONE"

    ## adjusting output, removing gamma when it doesn't exist in the model
    if(param=="gamma"){
      if(analyze.separately=="event" || analyze.separately=="studyevent"){
        latex.avg.label <- rep("%NONE",length(latex.avg.label))
	latex.study.avg.label <- rep("%NONE",length(latex.study.avg.label))
      }
    }

    if(param=="omega"){
      if(analyze.separately=="study" || analyze.separately=="studyevent" ||
      	(analyze.separately=="event" && common.param.estimation==TRUE)){
        latex.avg.label <- rep("%NONE",length(latex.avg.label))
	latex.study.avg.label <- rep("%NONE",length(latex.study.avg.label))
      }
    }
  } else if(param=="alpha"){
    if(use.xx==FALSE){
      latex.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_choose)),s.use,
      		      	 "}(",rep(xx_choose,np),",\\cdot)$",sep="")
      latex.study.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_choose)),
      		      	 study.use,"}(",rep(xx_choose,np),",\\cdot)$",sep="")
    } else {
      latex.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_choose)),s.use,
				"}(\\cdot,",rep(xx_choose,np),")$",sep="")
      latex.study.avg.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_choose)),
				study.use,"}(\\cdot,",rep(xx_choose,np),")$",sep="")

    }
  } else {
    ## Ft
    latex.avg.label <- paste("$\\wh ",param,"_{",rep(np_index,each=length(xx_choose)),s.use,
    		    "}(\\cdot|","x=",rep(xx_choose,np),",",
		    "z=",rep(zz_choose,each=length(xx_choose)),")$",sep="")    

    latex.study.avg.label <- paste("$\\wh ",param,"_{",rep(np_index,each=length(xx_choose)),
    		    study.use,"}(\\cdot|","x=",rep(xx_choose,np),",",
		    "z=",rep(zz_choose,each=length(xx_choose)),")$",sep="")    
  }

  #############################
  ## organize ptwise results ##
  #############################
  out.pt <- NULL
  pt.label <- NULL

  mylabels <- paste(lab.tmp,as.vector(t(outer(tt_choose,
                rep(dimnames(pt.results)[[3]],np),paste,sep="_"))),sep="")
  mylabels <- paste(rep(rep(paste("np",np_index,sep=""),
                each=length(dimnames(pt.results)[[3]])),length(tt_choose)),
                "_",mylabels,sep="")

  if(param=="beta"){
    latex.pt.label <- paste("$\\wh\\",param,"_{",
    		   rep(np_index,each=length(xx_lab)),s.use,
		   rep(xx_lab,np),"}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
    latex.study.pt.label <- paste("$\\wh\\",param,"_{",
    			 rep(np_index,each=length(xx_lab)),study.use,
			 rep(xx_lab,np),
    			    "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")

    index.beta0 <- grep(glob2rx("*0*"),latex.pt.label)
    if(!is.null(index.beta0)){
      if(analyze.separately=="study"){
        latex.pt.label[index.beta0] <- paste("$\\wh\\",param,"_{",s.use,0,
				       "}(",rep(tt_choose,each=np),")$",sep="")
 	latex.study.pt.label[index.beta0] <- paste("$\\wh\\",param,"_{",study.use,0,
      					"}(",rep(tt_choose,each=np),")$",sep="")	
	
	latex.pt.label[index.beta0[-seq(1,length(index.beta0),by=2)]] <- "%NONE"
	latex.study.pt.label[index.beta0[-seq(1,length(index.beta0),by=2)]] <- "%NONE"
      } else if(analyze.separately=="none"){
        latex.pt.label[index.beta0] <-  paste("$\\wh\\",param,"_{",0,
				       "}(",rep(tt_choose,each=np),")$",sep="")

        latex.study.pt.label[index.beta0] <-  paste("$\\wh\\",param,"_{",0,
      					"}(",rep(tt_choose,each=np),")$",sep="")	
	latex.pt.label[index.beta0[-seq(1,length(index.beta0),by=2)]] <- "%NONE"
	latex.study.pt.label[index.beta0[-seq(1,length(index.beta0),by=2)]] <- "%NONE"
      }
    }    			

    if(length(xx_lab)==1 && length(index.beta0)==0){
      # xx_lab=1
      latex.pt.label <- paste("$\\wh\\",param,"_{",
    		   rep(np_index,each=length(xx_lab)),s.use,
		   "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
      latex.study.pt.label <- paste("$\\wh\\",param,"_{",
    			 rep(np_index,each=length(xx_lab)),study.use,
			 "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
      
    }

  } else if(param=="gamma" || param=="omega"){
    if(analyze.separately=="study"){
      latex.pt.label <- paste("$\\wh\\",param,"_{",
    		   rep(np_index,each=length(xx_lab)),s.use,
		   "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
      latex.study.pt.label <- paste("$\\wh\\",param,"_{",
    			 rep(np_index,each=length(xx_lab)),study.use,
    			    "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
    } else {
      latex.pt.label <- paste("$\\wh\\",param,"_{",
    		   rep(np_index,each=length(xx_lab)),
		   "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
      latex.study.pt.label <- paste("$\\wh\\",param,"_{",
    			 rep(np_index,each=length(xx_lab)),
    			    "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
    }

    ## removing gamma_1 and omega_1
    latex.pt.label[grep(glob2rx("*_{1*}*"),latex.pt.label)] <- "%NONE"
    latex.study.pt.label[grep(glob2rx("*_{1*}*"),latex.study.pt.label)] <- "%NONE"

    ## adjusting output, removing gamma when it doesn't exist in the model
    if(param=="gamma"){
      if(analyze.separately=="event" || analyze.separately=="studyevent"){
        latex.pt.label <- rep("%NONE",length(latex.pt.label))
	latex.study.pt.label <- rep("%NONE",length(latex.study.pt.label))
      }
    }

    if(param=="omega"){
      if(analyze.separately=="study" || analyze.separately=="studyevent" ||
      	(analyze.separately=="event" && common.param.estimation==TRUE)){
        latex.pt.label <- rep("%NONE",length(latex.pt.label))
	latex.study.pt.label <- rep("%NONE",length(latex.study.pt.label))
      }
    }


#  } else if(param=="omega"){
#    latex.pt.label <- paste("$\\wh\\",param,"_{",
#		   "s}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
#    latex.study.pt.label <- paste("$\\wh\\",param,"_{",
#    			 study,
#    			    "}(",rep(tt_choose,each=np*length(xx_lab)),")$",sep="")
  } else if(param=="alpha"){
    if(use.xx==FALSE){
      latex.pt.label <- paste("(",xx_choose,",",
      		     	rep(tt_choose,each=length(xx_choose)*np),")$",sep="")
    } else {
      latex.pt.label <- paste("(",
      		     	rep(tt_choose,each=length(xx_choose)*np),",",xx_choose,")$",sep="")
    }
    latex.pt.label <- paste("$\\wh\\",param,"_{",rep(rep(np_index,each=length(xx_choose)),np),s.use,
    		      "}",
      		     	latex.pt.label,sep="")
    latex.study.pt.label <- paste("$\\wh\\",param,"_{",rep(np_index,each=length(xx_choose)*np),
    			 study.use,"}",
      		     	latex.pt.label,sep="")
  } else {
    latex.pt.label <- paste("$\\wh ",param,"_{",rep(rep(np_index,each=length(xx_choose)),np),
                        s.use,"}",
			"(",rep(tt_choose,each=length(xx_choose)*np),"|x=",xx_choose,
    		        ",z=",rep(zz_choose,each=length(xx_choose)),
                        ")$",sep="")

    latex.study.pt.label <- paste("$\\wh ",param,"_{",rep(rep(np_index,each=length(xx_choose)),np),
                        study.use,"}",
			"(",rep(tt_choose,each=length(xx_choose)*np),"|x=",xx_choose,
    		        ",z=",rep(zz_choose,each=length(xx_choose)),
                        ")$",sep="")
  }

  mytmp <- c("bias","emp var","est var","95% cov","MSE")

  out.pt <- array(0,dim=c(length(mytmp),length(mylabels)),
                        dimnames=list(mytmp,mylabels))


  labels.tmp <- dimnames(pt.results)[[2]]
  for(ii in 1:length(tt_choose)){
    for(nn in 1:np){
      get.grep <- paste(lab.tmp,tt_choose[ii],"*",sep="")

      get.index <- grep(glob2rx(get.grep),labels.tmp)
      pt.tmp <- pt.results[paste("np",nn,sep=""),get.index,]

      get.grep2 <- paste("np",nn,"_",lab.tmp,tt_choose[ii],"*",sep="")
      out.pt.index <- grep(glob2rx(get.grep2),colnames(out.pt))

      if(!is.null(dim(pt.tmp))){
        out.pt["bias",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_bias",sep=""),]
        out.pt["emp var",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_emp_var",sep=""),]
        out.pt["est var",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_est_var",sep=""),]
        out.pt["95% cov",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_95%_cov",sep=""),]
        out.pt["MSE",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_MSE",sep=""),]
      } else {
        out.pt["bias",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_bias",sep="")]
        out.pt["emp var",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_emp_var",sep="")]
        out.pt["est var",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_est_var",sep="")]
        out.pt["95% cov",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_95%_cov",sep="")]
        out.pt["MSE",out.pt.index] <- pt.tmp[paste(lab.tmp,tt_choose[ii],"_MSE",sep="")]
      }
    }
  }
  list(out.avg=out.avg,out.pt=out.pt,
		latex.avg.label=latex.avg.label,
		latex.study.avg.label=latex.study.avg.label,
		latex.pt.label=latex.pt.label,
		latex.study.pt.label=latex.study.pt.label)
}


organize.data.diff <- function(avg.results,np,xx_choose,zz_choose,
				param="beta",xx_lab=NULL,use.xx=FALSE){
  if(use.xx==TRUE){
    lab.tmp <- "xx_" 
  } else {
    lab.tmp <- "tt_"
  }

  ######################
  ## organize results ##
  ######################
  out.avg <- NULL
  avg.label <- NULL
  for(nn in 1:np){
    tmp.index <- paste("np",nn,sep="")
    tmp.label <- paste("np",nn,"_",dimnames(avg.results)[[3]],sep="")
    avg.label <- c(avg.label,tmp.label)

    tmp <- as.matrix(avg.results[,tmp.index,])
    if(ncol(tmp)!=1){
      tmp <- t(tmp)
    }
    out.avg <- rbind(out.avg,tmp)
  }
  rownames(out.avg) <- avg.label
  colnames(out.avg) <- dimnames(avg.results)[1]

  np_index <- 1:np

  if(param=="beta"){
    latex.avg.label <- paste("$H_0: \\",param,"_{",rep(np_index,each=length(xx_lab)),"s",rep(xx_lab,np),
    		       "}(t)",sep="")

    latex.avg.label2 <- paste("H_0: \\",param,"_{",rep(np_index,each=length(xx_lab)),"s'",
    		     	rep(xx_lab,np),"}(t)$",sep="")

    latex.avg.label <- paste(latex.avg.label,latex.avg.label2,sep="=")
  } else if(param=="gamma" || param=="omega"){
    latex.avg.label <- paste("$H_0: \\",param,"_{",rep(np_index,each=length(xx_lab)),"s",
    		       "}(t)",sep="")

    latex.avg.label2 <- paste("H_0: \\",param,"_{",rep(np_index,each=length(xx_lab)),"s'",
    		     	"}(t)$",sep="")
    latex.avg.label <- paste(latex.avg.label,latex.avg.label2,sep="=")
  } else if(param=="alpha"){
    latex.avg.label <- paste("$H_0: \\",param,"_{",rep(np_index,each=length(xx_choose)),
      		      	 "s}(",rep(xx_choose,np),",t)",sep="")

    latex.avg.label2 <- paste("H_0: \\",param,"_{",rep(np_index,each=length(xx_choose)),
      		      	 "s'}(",rep(xx_choose,np),",t)$",sep="")

    latex.avg.label <- paste(latex.avg.label,latex.avg.label2,sep="=")
  } else {
    ## Ft
    latex.avg.label <- paste("$H_0: ",param,"_{",rep(np_index,each=length(xx_choose)),
    		    "s}(t|","x=",rep(xx_choose,np),",",
		    "z=",rep(zz_choose,each=length(xx_choose)),")",sep="")    

    latex.avg.label2 <- paste("H_0: ",param,"_{",rep(np_index,each=length(xx_choose)),
    		    "s'}(t|","x=",rep(xx_choose,np),",",
		    "z=",rep(zz_choose,each=length(xx_choose)),")$",sep="")

    latex.avg.label <- paste(latex.avg.label,latex.avg.label2,sep="=")    
  }

  list(out.avg=out.avg,
	latex.avg.label=latex.avg.label)
}




###############################
## combine results for paper ##
###############################
combine.organize.results <- function(org.beta.results,
			 org.gamma.results,
			 org.omega.results,
			 org.alpha.time.results,org.alpha.xx.results,
			 org.Ft.results,np,z.choice){
  full.avg <- NULL
  full.pt <- NULL

  names.full <- NULL
  names.pt <- NULL

  latex.names.full <- NULL
  latex.names.pt <- NULL

  latex.study.names.full <- NULL
  latex.study.names.pt <- NULL

  ##################
  ## beta results ##
  ##################x

  ## beta0
  beta.colnames.tmp <- colnames(org.beta.results$out.avg)
  #index.beta0 <- grep(glob2rx(paste("*beta",0,sep="")),beta.colnames.tmp)

  #if(length(index.beta0)!=0){
  #  index.beta.use <- c(index.beta0[1],(1:length(beta.colnames.tmp))[-index.beta0])
  #} else {
    index.beta.use <- 1:length(beta.colnames.tmp)
  #}

  full.avg <- rbind(full.avg,t(org.beta.results$out.avg)[index.beta.use,])
  names.full <- c(names.full,colnames(org.beta.results$out.avg)[index.beta.use])
  latex.names.full <- c(latex.names.full,org.beta.results$latex.avg.label[index.beta.use])
  latex.study.names.full <- c(latex.study.names.full,
				org.beta.results$latex.study.avg.label[index.beta.use])

  beta.colnames.tmp <- colnames(org.beta.results$out.pt)
  #index.beta0 <- grep(glob2rx("*0*"),beta.colnames.tmp)
  #if(length(index.beta0)!=0){
  #  mynames <- beta.colnames.tmp
  #  mynames.index <- grep(glob2rx(paste("np",2:np,"*","lb0",sep="")),mynames)
  #
  #  index.beta.use <- (1:length(beta.colnames.tmp))[-mynames.index]
  #} else {
    index.beta.use <- 1:length(beta.colnames.tmp)
  #}

  full.pt <- rbind(full.pt,t(org.beta.results$out.pt)[index.beta.use,])
  names.pt <- c(names.pt,colnames(org.beta.results$out.pt)[index.beta.use])
  latex.names.pt <- c(latex.names.pt,org.beta.results$latex.pt.label[index.beta.use])
  latex.study.names.pt <- c(latex.study.names.pt,org.beta.results$latex.study.pt.label[index.beta.use])


  #######################
  ## add gamma results ##
  #######################
  if(!is.null(org.gamma.results)){
    gamma.colnames.tmp <- colnames(org.gamma.results$out.avg)
    
    ## remove event=1
    ##index.gamma.use <- (1:length(gamma.colnames.tmp))[-grep(glob2rx(paste("np",1,"*",sep="")),
##			gamma.colnames.tmp)]
    index.gamma.use <- 1:length(gamma.colnames.tmp)

    full.avg <- rbind(full.avg,t(org.gamma.results$out.avg)[index.gamma.use,])
    names.full <- c(names.full,colnames(org.gamma.results$out.avg)[index.gamma.use])
    latex.names.full <- c(latex.names.full,org.gamma.results$latex.avg.label[index.gamma.use])
    latex.study.names.full <- c(latex.study.names.full,
				org.gamma.results$latex.study.avg.label[index.gamma.use])

    gamma.colnames.tmp <- colnames(org.gamma.results$out.pt)

    ## remove event=1
#    index.gamma.use <- (1:length(gamma.colnames.tmp))[-grep(glob2rx(paste("np",1,"*",sep="")),
#			gamma.colnames.tmp)]
    index.gamma.use <- 1:length(gamma.colnames.tmp)

    full.pt <- rbind(full.pt,t(org.gamma.results$out.pt)[index.gamma.use,])
    names.pt <- c(names.pt,colnames(org.gamma.results$out.pt)[index.gamma.use])
    latex.names.pt <- c(latex.names.pt,org.gamma.results$latex.pt.label[index.gamma.use])
    latex.study.names.pt <- c(latex.study.names.pt,
    			    org.gamma.results$latex.study.pt.label[index.gamma.use])

  }


  #######################
  ## add omega results ##
  #######################
  if(!is.null(org.omega.results)){
    omega.colnames.tmp <- colnames(org.omega.results$out.avg)
    
    ## remove event=1 (this is because for omega, the results are duplicated across events).
#    index.omega.use <- (1:length(omega.colnames.tmp))[-grep(glob2rx(paste("np",1,"*",sep="")),
#			omega.colnames.tmp)]
    index.omega.use <- 1:length(omega.colnames.tmp)

    full.avg <- rbind(full.avg,t(org.omega.results$out.avg)[index.omega.use,])
    names.full <- c(names.full,colnames(org.omega.results$out.avg)[index.omega.use])
    latex.names.full <- c(latex.names.full,org.omega.results$latex.avg.label[index.omega.use])
    latex.study.names.full <- c(latex.study.names.full,
				org.omega.results$latex.study.avg.label[index.omega.use])

    omega.colnames.tmp <- colnames(org.omega.results$out.pt)

    ## remove event=1
#    index.omega.use <- (1:length(omega.colnames.tmp))[-grep(glob2rx(paste("np",1,"*",sep="")),
#			omega.colnames.tmp)]
    index.omega.use <- 1:length(omega.colnames.tmp)

    full.pt <- rbind(full.pt,t(org.omega.results$out.pt)[index.omega.use,])
    names.pt <- c(names.pt,colnames(org.omega.results$out.pt)[index.omega.use])
    latex.names.pt <- c(latex.names.pt,org.omega.results$latex.pt.label[index.omega.use])
    latex.study.names.pt <- c(latex.study.names.pt,
    			    org.omega.results$latex.study.pt.label[index.omega.use])

  }
  

  #######################
  ## add alpha results ##
  #######################

  for(nn in 1:np){
    tmp.time <- colnames(org.alpha.time.results$out.avg)
    index.time <- grep(glob2rx(paste("np",nn,"*",sep="")),tmp.time)

    full.avg <- rbind(full.avg,t(org.alpha.time.results$out.avg)[index.time,])
    names.full <- c(names.full,rownames(t(org.alpha.time.results$out.avg)[index.time,]))
    latex.names.full <- c(latex.names.full,org.alpha.time.results$latex.avg.label[index.time])
    latex.study.names.full <- c(latex.study.names.full,
				org.alpha.time.results$latex.study.avg.label[index.time])

    tmp.time.pt <- colnames(org.alpha.time.results$out.pt)
    index.time.pt <-  grep(glob2rx(paste("np",nn,"*",sep="")),tmp.time.pt)
    full.pt <- rbind(full.pt,t(org.alpha.time.results$out.pt)[index.time.pt,])
    names.pt <- c(names.pt,rownames(t(org.alpha.time.results$out.pt)[index.time.pt,]))
    latex.names.pt <- c(latex.names.pt,org.alpha.time.results$latex.pt.label[index.time.pt])
    latex.study.names.pt <- c(latex.study.names.pt,
				org.alpha.time.results$latex.study.pt.label[index.time.pt])

    tmp.xx <- colnames(org.alpha.xx.results$out.avg)
    index.xx <- grep(glob2rx(paste("np",nn,"*",sep="")),tmp.xx)
    full.avg <- rbind(full.avg,t(org.alpha.xx.results$out.avg)[index.xx,])
    names.full <- c(names.full,rownames(t(org.alpha.xx.results$out.avg)[index.xx,]))
    latex.names.full <- c(latex.names.full,org.alpha.xx.results$latex.avg.label[index.xx])
    latex.study.names.full <- c(latex.study.names.full,
				org.alpha.xx.results$latex.study.avg.label[index.xx])

    ## below is duplicated
    ##tmp.xx.pt <- colnames(org.alpha.xx.results$out.pt)
    ##index.xx.pt <- grep(glob2rx(paste("np",nn,"*",sep="")),tmp.xx.pt)
    ##full.pt <- rbind(full.pt,t(org.alpha.xx.results$out.pt)[index.xx.pt,])
    ##names.pt <- c(names.pt,rownames(t(org.alpha.xx.results$out.pt)[index.xx.pt,]))
  }

  for(nn in 1:np){
    for(zz in 1:z.choice){

      tmp.zz <- colnames(org.Ft.results[[zz]]$out.avg)
      index.zz <- grep(glob2rx(paste("np",nn,"*",sep="")),tmp.zz)

      full.avg <- rbind(full.avg,t(org.Ft.results[[zz]]$out.avg)[index.zz,])
      names.full <- c(names.full,paste(rownames(t(org.Ft.results[[zz]]$out.avg)[index.zz,]),
      		    "_zz_",zz,sep=""))
      latex.names.full <- c(latex.names.full,org.Ft.results[[zz]]$latex.avg.label[index.zz])
      latex.study.names.full <- c(latex.study.names.full,
				org.Ft.results[[zz]]$latex.study.avg.label[index.zz])

      tmp.zz.pt <- colnames(org.Ft.results[[zz]]$out.pt)
      index.zz.pt <- grep(glob2rx(paste("np",nn,"*",sep="")),tmp.zz.pt)	    
      full.pt <- rbind(full.pt,t(org.Ft.results[[zz]]$out.pt)[index.zz.pt,])
      names.pt <- c(names.pt,paste(rownames(t(org.Ft.results[[zz]]$out.pt)[index.zz.pt,]),
      	       	  "_zz_",zz,sep=""))
      latex.names.pt <- c(latex.names.pt,org.Ft.results[[zz]]$latex.pt.label[index.zz.pt])
      latex.study.names.pt <- c(latex.study.names.pt,
				org.Ft.results[[zz]]$latex.study.pt.label[index.zz.pt])
    }
  }

  ##rownames(full.avg) <- names.full
  ##rownames(full.pt) <- names.pt

  list(full.avg=full.avg,full.pt=full.pt,
		names.full=names.full,names.pt=names.pt,
		latex.names.full=latex.names.full,latex.names.pt=latex.names.pt,
		latex.study.names.full=latex.study.names.full,
		latex.study.names.pt=latex.study.names.pt)  
}



combine.organize.diff.results <- function(org.beta.diff.results,
			      org.gamma.diff.results,
			      org.omega.diff.results,
			      org.alpha.diff.results,org.Ft.diff.results,np,z.choice){
  full.avg <- NULL
  names.full <- NULL
  latex.names.full <- NULL


  ## beta results
  beta.rownames.tmp <- rownames(org.beta.diff.results$out.avg)
  full.avg <- rbind(full.avg,org.beta.diff.results$out.avg)
  names.full <- c(names.full,beta.rownames.tmp)
  latex.names.full <- c(latex.names.full,org.beta.diff.results$latex.avg.label)

  ## gamma results
  if(!is.null(org.gamma.diff.results)){
    gamma.rownames.tmp <- rownames(org.gamma.diff.results$out.avg)
    full.avg <- rbind(full.avg,org.gamma.diff.results$out.avg)
    names.full <- c(names.full,gamma.rownames.tmp)
    latex.names.full <- c(latex.names.full,org.gamma.diff.results$latex.avg.label)
  }

  ## omega results
  if(!is.null(org.omega.diff.results)){
    omega.rownames.tmp <- rownames(org.omega.diff.results$out.avg)
    full.avg <- rbind(full.avg,org.omega.diff.results$out.avg)
    names.full <- c(names.full,omega.rownames.tmp)
    latex.names.full <- c(latex.names.full,org.omega.diff.results$latex.avg.label)
  }

  ## alpha results
  tmp.time <- rownames(org.alpha.diff.results$out.avg)
  full.avg <- rbind(full.avg,org.alpha.diff.results$out.avg)
  names.full <- c(names.full,tmp.time)
  latex.names.full <- c(latex.names.full,org.alpha.diff.results$latex.avg.label)


  ## Ft results
  for(nn in 1:np){
    for(zz in 1:z.choice){

      tmp.zz <- rownames(org.Ft.diff.results[[zz]]$out.avg)
      index.zz <- grep(glob2rx(paste("np",nn,"*",sep="")),tmp.zz)

      full.avg <- rbind(full.avg,as.matrix(org.Ft.diff.results[[zz]]$out.avg[index.zz,]))
      names.full <- c(names.full,paste(tmp.zz[index.zz],"_zz_",zz,sep=""))
      latex.names.full <- c(latex.names.full,org.Ft.diff.results[[zz]]$latex.avg.label[index.zz])
    }
  }

  list(full.avg=full.avg,names.full=names.full,latex.names.full=latex.names.full)
}

  
#############################################
## get 95\% CI for time points of interest ##
##   and lb/xx of interest                 ##
#############################################

get.cis <- function(theta.array,theta.ci.lo.array,theta.ci.hi.array,
		xx_val,xx_choose,
		tt_val,time_choice,convert,xmin,xmax,np,nsimu){

  if(convert==TRUE){
    x <- convert.cag(xx_choose,xmin=xmin,xmax=xmax)
  } else {
   x <- xx_val
  }

  ##xx_index <- which(xx_val %in% xx_choose)
  xx_index <- which(round(xx_val,3) %in% round(xx_choose,3))
  tt_index <- which(tt_val %in% time_choice)

  theta.array.new <- theta.array[,xx_index,,tt_index,drop=FALSE]
  theta.ci.lo.array.new <- theta.ci.lo.array[,xx_index,,tt_index,drop=FALSE]  
  theta.ci.hi.array.new <- theta.ci.hi.array[,xx_index,,tt_index,drop=FALSE]  

  out.array <- array(0,dim=c(np,length(xx_index)*length(tt_index),5),
			dimnames=list(paste("np",1:np,sep=""),
				1:(length(xx_index)*length(tt_index)),
				c("xx","tt","est","lo","hi")))
  
  for(nn in 1:np){
    tmp <- 0
    for(ii in 1:length(xx_index)){
      for(jj in 1:length(tt_index)){
        tmp <- tmp + 1
	out.array[nn,tmp,] <- c(x[ii],time_choice[jj],
			      theta.array.new[nn,ii,nsimu,jj],
			      theta.ci.lo.array.new[nn,ii,nsimu,jj],
			      theta.ci.hi.array.new[nn,ii,nsimu,jj])
      }
    }
  }

  return(out.array)
}


get.cis.ij <- function(theta.array,theta.ci.lo.array,theta.ci.hi.array,
		ii_choice,
		tt_val,time_choice,convert,xmin,xmax,np,nsimu){

  if(convert==TRUE){
    x <- convert.cag(xx_choose,xmin=xmin,xmax=xmax)
  } else {
   x <- xx_val
  }

  ##xx_index <- which(xx_val %in% xx_choose)
  xx_index <- which(round(xx_val,3) %in% round(xx_choose,3))
  tt_index <- which(tt_val %in% time_choice)

  theta.array.new <- theta.array[,xx_index,,tt_index,drop=FALSE]
  theta.ci.lo.array.new <- theta.ci.lo.array[,xx_index,,tt_index,drop=FALSE]  
  theta.ci.hi.array.new <- theta.ci.hi.array[,xx_index,,tt_index,drop=FALSE]  

  out.array <- array(0,dim=c(np,length(xx_index)*length(tt_index),5),
			dimnames=list(paste("np",1:np,sep=""),
				1:(length(xx_index)*length(tt_index)),
				c("xx","tt","est","lo","hi")))
  
  for(nn in 1:np){
    tmp <- 0
    for(ii in 1:length(xx_index)){
      for(jj in 1:length(tt_index)){
        tmp <- tmp + 1
	out.array[nn,tmp,] <- c(x[ii],time_choice[jj],
			      theta.array.new[nn,ii,nsimu,jj],
			      theta.ci.lo.array.new[nn,ii,nsimu,jj],
			      theta.ci.hi.array.new[nn,ii,nsimu,jj])
      }
    }
  }

  return(out.array)
}


## organize get.cis
org.get.cis <- function(out.array,round.set){

  out.array.new <- array(0,dim=c(dim(out.array)[c(1,2)],3),
			dimnames=list(paste("np",1:np,sep=""),
				c(1:dim(out.array)[2]),
				c("xx","tt","est")))

  for(nn in 1:np){
    for(ii in 1:dim(out.array)[2]){
    
      out.array.new[nn,ii,] <- c(out.array[nn,ii,"xx"],out.array[nn,ii,"tt"],
      			     paste(round(out.array[nn,ii,"est"],round.set),
				" (",round(out.array[nn,ii,"lo"],round.set), ", ",
				round(out.array[nn,ii,"hi"],round.set),")",
				sep=""))
    }
  }

  return(out.array.new)
}

## organize get.cis and track sign change
org.get.cis.track <- function(out.array,round.set){

  out.array.new <- array(0,dim=c(dim(out.array)[c(1,2)],4),
			dimnames=list(paste("np",1:np,sep=""),
				c(1:dim(out.array)[2]),
				c("change","xx","tt","est")))

  for(nn in 1:np){
    for(ii in 1:dim(out.array)[2]){
    
      out.array.new[nn,ii,c("xx","tt","est")] <- c(
      			out.array[nn,ii,"xx"],
			out.array[nn,ii,"tt"],
      			     paste(round(out.array[nn,ii,"est"],
			     round.set),
				" (",round(out.array[nn,ii,"lo"],
				round.set), ", ",
				round(out.array[nn,ii,"hi"],
				round.set),")",
				sep=""))

      mytmp <- sign(out.array[nn,ii,"lo"]) == sign(out.array[nn,ii,"hi"])
				
      if(!is.na(mytmp) && mytmp==TRUE){
        out.array.new[nn,ii,"change"] <- 1
      }

    }
  }

  return(out.array.new)
}
  
  
