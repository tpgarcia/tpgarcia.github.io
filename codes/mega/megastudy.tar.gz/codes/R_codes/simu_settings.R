## This file contains the settings for the parameters 
## to run the simulation study and real data analysis.

#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+
## These are default values for some of the variables ##
#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+

##########################
## for simulation study ##
##########################

## iseed: seed set for simulation study.
if(!exists(as.character(substitute(iseed)))){
  iseed <- 1
}

## num_study: number of studies.
if(!exists(as.character(substitute(num_study)))){
  num_study <- 3
}

## real_data: indicator if this is real data.
if(!exists(as.character(substitute(real_data)))){
  real_data <- FALSE
}

## type_fr: specification of number of unknown parameters in density 
##   for random effect r (this is "v" in the paper). See make.normal() in main.R
if(!exists(as.character(substitute(type_fr)))){
  type_fr <- "par2"
}

## type_fzr: specification of number of unknown parameters in density for covariate Z.
##  see make.normal() in main.R
if(!exists(as.character(substitute(type_fzr)))){
  type_fzr <- "none"
}

## type_fx: specification of number of unknown parameters in density for covariate X.
## see make.normal() in main.R.
if(!exists(as.character(substitute(type_fx)))){
  type_fx <- "none"
}

## frform: specification of density for random effect R (this is "v" in the paper).
if(!exists(as.character(substitute(frform)))){
  frform <- "norm"
}

## fzrform: specification of density for covariate Z.
if(!exists(as.character(substitute(fzrform)))){
  fzrform <- "unif"
  ##fzrform <- "norR"
  ##fzrform <- "uniR"	
}

## fxform: specification of density for covariate X.
if(!exists(as.character(substitute(fxform)))){
  fxform <- "unif"
  ##fxform <- "uniR"	
  ##fxform <- "norR"
}

## random effect R and covariates X,Z dependent?
if(!exists(as.character(substitute(randomeffects.covariates.dependent)))){
  randomeffects.covariates.dependent <- FALSE
}

## censorrate: censoring rate for the studies
if(!exists(as.character(substitute(censorrate)))){
  censorrate <- rep(0,num_study)
}

## use.random.effects: generate data with random effects
if(!exists(as.character(substitute(use.random.effects)))){
  use.random.effects <- TRUE
}

## common.param.data: common alpha, beta across studies in data generation
if(!exists(as.character(substitute(common.param.data)))){
  common.param.data <- FALSE
}

###################
## for real data ##
###################

## data.type: if the data is from the cohort, pharos or predict study
if(!exists(as.character(substitute(data.type)))){
  data.type <- NULL
}

## covariates.use: covariates used in the analysis.
if(!exists(as.character(substitute(covariates.use)))){
  covariates.use <- c("base_age","educ_cat","gender")
}

## use.gene: indicator if we use genetic status. Not used in this analysis.
if(!exists(as.character(substitute(use.gene)))){
  use.gene <- "none" ## covariate not used
  ##use.gene <- "r"  ## rater
  ##use.gene <- "rs"  ## rater, subject
}



################
## estimation ##
################

## family.data: indicator if the clusters are families (i.e., each member in the cluster is different).
##  In this paper, the cluster within a study corresponds to events from the same individual.
##  That is, the cluster info is from the same individual.
if(!exists(as.character(substitute(family.data)))){
  family.data <- FALSE
}

## spline.constrain: to keep the design matrix correct, we need to have B(0)=0.
if(!exists(as.character(substitute(spline.constrain)))){
  spline.constrain <- TRUE
}

## analyze.separately: study events and studies, or just events, or just studies, or none separately
if(!exists(as.character(substitute(analyze.separately)))){
  analyze.separately <- "studyevent"
}

## check.study.equality: check if studies are similar? using bootstrap joint confidence interval.
if(!exists(as.character(substitute(check.study.equality)))){
  ##if(analyze.separately=="event" || analyze.separately=="none"){
  if(analyze.separately=="none"){
    check.study.equality <- FALSE ##TRUE  ## Set to FALSE and simulations run faster since they don't run 100 bootstraps. 
  } else {
    check.study.equality <- FALSE 
  }
}


## common.param.estimation: common alpha, beta across studies
if(!exists(as.character(substitute(common.param.estimation)))){
  common.param.estimation <- FALSE
}

## boot: number of bootstrap replicates used to test equality of studies, 100
if(!exists(as.character(substitute(boot)))){
  boot <- 100 
}

# var.est: variance is estimated using gamm4
if(!exists(as.character(substitute(var.est)))){
  var.est <- "est" # est, quant, none	
}



###################
## result output ##
###################

## time.cut: if we want to see results for only a specific subset of time points.
if(!exists(as.character(substitute(time.cut)))){
  time.cut <- NULL
}

#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+
#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+
#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+

#########################
## Set other variables ##
#########################

if(real_data==FALSE){

  ######################################	
  ## Data setup for simulation study  ##
  ######################################

  simus <- 2			 ## number of simulations, 8
  study.names <- 1:num_study     ## names of the study

  if(num_study==1){		 ## sample size n for each study
    n <- 500
  } else if(num_study==2){
    n <- c(400,500)
  } else if(num_study==3){
    n <- c(300,400,500)
  }
  #n <- rep(500,num_study)  
  #n <- rep(100,num_study)  

  if(num_study==1){              ## censoring rates
    censorrate <- 30
    ##censorrate <- 0
  } else if(num_study==2){
    censorrate <- c(30,50)
    ##censorrate <- c(0,0)
  } else if(num_study==3){
    censorrate <- c(0,30,50)
  }
 


  nmax <- max(n)		 ## maximum sample size across all studies
  time_val <-  c(seq(40,49,by=1),seq(50,60,by=1))   ## time points for estimation
  time_choice <-  get.empty.list(paste("study",1:num_study,sep=""))  ## time points to 
  	      	  						     ##	show individual results at
  for(ss in 1:num_study){
    time_choice[[ss]] <- c(45,55)
  }
  alphat_lab <- time_choice	  ## label for alpha(x,t) in t-dimension

  xks <- get.empty.list(paste("study",1:num_study,sep=""))  ## x's where alpha(x,t) are evaluated at
  xx_choice <- get.empty.list(paste("study",1:num_study,sep=""))  ## x's to show results at
  alphax_lab <- get.empty.list(paste("study",1:num_study,sep=""))  ## alpha(x,t) label in x-dimension
  for(ss in 1:num_study){
    ##xx_choice[[ss]] <- c(0.25,0.50,0.75)
    xx_choice[[ss]] <- c(0.50)
    alphax_lab[[ss]] <- xx_choice[[ss]] * 100
    xks[[ss]] <- seq(0,1,by=0.01)
  }

  ## axmod  and gtmod: alpha(x,t)=a0 * axmod() * gtmod()
  if(common.param.data==FALSE){ ## no common alpha, beta
    if(num_study==1){
      axmod <- list(study1=c("line","wah2"))
      gtmod <- "log"
    } else if(num_study==2){
      axmod <- list(study1=c("line","wah2"),
		  study2=c("wah2","line"))
      gtmod <- "log"
    } else if(num_study==3){
      axmod <- list(study1=c("cohort1","cohort2"),
		  study2=c("predict1","predict2"),
		  study3=c("pharos1","pharos2"))
      gtmod <- "noall"  
    } else if(num_study==10){
      axmod <- list(study1=c("line","wah2"),
		  study2=c("line","wah2"),
		  study3=c("line","wah2"),
		  study4=c("line","wah2"),
		  study5=c("line","wah2"),
		  study6=c("line","wah2"),
		  study7=c("line","wah2"),
		  study8=c("line","wah2"),
		  study9=c("line","wah2"),
		  study10=c("wah2","line"))
      gtmod <- "log"
    }
  } else { ## common alpha, beta
    if(num_study==1){
      axmod <- list(study1=c("line","wah2"))
      gtmod <- "log"
    } else if(num_study==2){
      axmod <- list(study1=c("line","wah2"),
		  study2=c("line","wah2"))
      gtmod <- "log"
    } else if(num_study==3){
      axmod <- list(study1=c("all1","all2"),
		  study2=c("all1","all2"),
		  study3=c("all1","all2"))
      gtmod <- "all"  
    }
  }

  np <- max(unlist((lapply(axmod,length.apply))))   ## number of events (m_i in paper)
  
  ##################################################
  ## True parameter values:beta(t)=beta * gtmod() ##
  ##  Here we specify "beta" values 	  	  ##
  ##################################################	
  
  ## beta0int: intercept
  beta0int <- 0.25  
  ##beta0int <- NULL

  ## gamma_i 
  if(np==1){
    ## gamma_i represents the difference between event i and (i-1)
    gamma.param <- 0
  } else if(np==2){
    gamma.param <- c(0,0.25)
  } else if(np==3){
    gamma.param <- c(0,0.5,1)
  }
  ##gamma.param <- NULL

  ## omega_s 
  ## omega_s represents the difference between study s and (s-1)
  if(num_study==1){
    omega.param <- 0
  } else if(num_study==2){
    omega.param <- c(0,1)
  } else if(num_study==3){
    omega.param <- c(0,0.75,1.25)
  }

  if(common.param.data==TRUE){
    ## there are no differences between the studies.
    omega.param <- rep(0,num_study)
  }
  ##omega.param <- NULL

  if(common.param.estimation==TRUE){
    omega.param <- NULL
  }



  ## beta_is 
  if(common.param.data==FALSE){ ## no common alpha,beta
    if(num_study==1){
      if(np==1){
        ##beta0 <- list(beta01=c(4,2,1))
        beta0 <- list(study1=list(beta01=c(4)))
      } else if(np==2){
        ##beta0 <- list(beta01=c(4,2,1),beta02=c(2,1,1))
        beta0 <- list(study1=list(beta01=c(4),beta02=c(2)))
      } else if(np==3){
        beta0 <-list(study1= list(beta01=c(4),beta02=c(0.5),beta03=c(2)))	
      }
    } else if(num_study==2){
      if(np==1){
        ##beta0 <- list(beta01=c(4,2,1))
        beta0 <- list(study1=list(beta01=c(4)),
		    study2=list(beta01=c(2)))
      } else if(np==2){
        ##beta0 <- list(beta01=c(4,2,1),beta02=c(2,1,1))
        beta0 <- list(study1=list(beta01=c(1),beta02=c(0.25)),
		    study2=list(beta01=c(0.25),beta02=c(1)))
      } else if(np==3){
        ##beta0 <- list(beta01=c(4,2,1),beta02=c(2,1,1),beta03=c(3,1,2))
        beta0 <-list(study1= list(beta01=c(4),beta02=c(0.5),beta03=c(2)),
      	           study2= list(beta01=c(2),beta02=c(1),beta03=c(0.5)))
      }
    } else if(num_study==3){
      if(np==1){
        beta0 <-list(study1= list(beta01=c(-0.25),beta02=c(0.25),beta03=c(0.35)))
      } else if(np==2){
        beta0 <- list(study1=list(beta01=c(-0.25),beta02=c(-0.25)),
		    study2=list(beta01=c(0.25),beta02=c(-0.15)),
		    study3=list(beta01=c(0.35),beta02=c(0.25)))
      } else if(np==3){
        beta0 <-list(study1= list(beta01=c(-0.25),beta02=c(-0.25),beta03=c(-0.25)),
      	           study2= list(beta01=c(0.25),beta02=c(-0.15),beta03=c(0.45)),
		   study3= list(beta01=c(0.35),beta02=c(0.25),beta03=c(0.30)))
      }
    } else if(num_study==10){
      if(np==1){
        beta0 <-list(study1= list(beta01=c(-0.25),beta02=c(0.25),beta03=c(0.35)))
      } else if(np==2){
        beta0 <- list(study1=list(beta01=c(-0.25),beta02=c(-0.25)),
		    study2=list(beta01=c(0.25),beta02=c(-0.15)),
		    study3=list(beta01=c(0.35),beta02=c(-0.35)),
		    study4=list(beta01=c(0.15),beta02=c(-0.15)),
		    study5=list(beta01=c(0.45),beta02=c(-0.45)),
		    study6=list(beta01=c(0.20),beta02=c(-0.25)),
		    study7=list(beta01=c(0.30),beta02=c(-0.35)),
		    study8=list(beta01=c(0.40),beta02=c(-0.40)),
		    study9=list(beta01=c(0.10),beta02=c(-0.10)),
		    study10=list(beta01=c(0.50),beta02=c(-0.50)))
      } else if(np==3){
        beta0 <-list(study1= list(beta01=c(-0.25),beta02=c(-0.25),beta03=c(-0.25)),
      	           study2= list(beta01=c(0.25),beta02=c(-0.15),beta03=c(0.45)),
		   study3= list(beta01=c(0.35),beta02=c(0.25),beta03=c(0.30)))
      }      
    }
  } else { ## common alpha, beta
    if(num_study==1){
      if(np==1){
        ##beta0 <- list(beta01=c(4,2,1))
        beta0 <- list(study1=list(beta01=c(4)))
      } else if(np==2){
        ##beta0 <- list(beta01=c(4,2,1),beta02=c(2,1,1))
        beta0 <- list(study1=list(beta01=c(4),beta02=c(2)))
      } else if(np==3){
        ##beta0 <- list(beta01=c(4,2,1),beta02=c(2,1,1),beta03=c(3,1,2))
        beta0 <-list(study1= list(beta01=c(4),beta02=c(0.5),beta03=c(2)))
      }
    } else if(num_study==2){
      if(np==1){
        beta0 <- list(study1=list(beta01=c(2)),
		    study2=list(beta01=c(2)))
      } else if(np==2){
        beta0 <- list(study1=list(beta01=c(1),beta02=c(0.25)),
		    study2=list(beta01=c(1),beta02=c(0.25)))
      } else if(np==3){
        beta0 <-list(study1= list(beta01=c(3),beta02=c(0.5),beta03=c(2)),
      	           study2= list(beta01=c(3),beta02=c(0.5),beta03=c(2)))
      }
    } else if(num_study==3){
      if(np==1){
        beta0 <- list(study1=list(beta01=c(2)),
		    study2=list(beta01=c(2)),
		    study3=list(beta01=c(2)))
      } else if(np==2){
        beta0 <- list(study1=list(beta01=c(-3),beta02=c(4)),
		    study2=list(beta01=c(-3),beta02=c(4)),
		    study3=list(beta01=c(-3),beta02=c(4)))
      } else if(np==3){
        beta0 <-list(study1= list(beta01=c(-0.25),beta02=c(0.5),beta03=c(0.75)),
      	           study2= list(beta01=c(-0.25),beta02=c(0.5),beta03=c(0.75)),
		   study3= list(beta01=c(-0.25),beta02=c(0.5),beta03=c(0.75)))
      }
    }
  }

  ## lb: list of beta_is dimensions for each study
  lb <- lapply(beta0,double.length.apply)

  ## lb.max: maximum dimension in lb
  lb.max <- max(unlist(lb))

  ## beta_lab: label of beta_is parameters
  beta_lab <- lapply(lb,double.get.label)

  ## Where to evaluate z's at
  ## z.choice: number of z evaluations
  z.choice <- 2
  #z.choice <- 1

  ## zeval: where to evaluate z's at in each study
  zeval <- array(0,dim=c(num_study,z.choice,np,lb.max),
	       dimnames=list(
	       paste("ss",1:num_study,sep=""),
	       paste("zz",1:z.choice,sep=""),
               paste("np",1:np,sep=""),
               paste("lb",1:lb.max,sep="")))

  zeval[,1,,] <- 0.50
  zeval[,2,,] <- 0.75
  z_lab <- c("1","2")

  ##zeval[,1,,] <- 1.5
  ##z_lab <- c("1")

  ###############
  ## for plots ##
  ###############
  alpha.cut <- NULL
  beta.cut <- NULL
  ylim.set <- c(-5,5)	  ## y-axis limits for plots

  ###################################################
  ## for loading fake data			   ##	
  ## we use this "fake" data in real data analysis.##
  ###################################################
  xmin <- NULL
  xmax <- NULL
  z_tmp <- NULL
  x_tmp <- NULL
  s_tmp <- NULL
  delta_tmp <- NULL
  ii.choose <- NULL
  ylim.x <- c(-8,8)
  ylim.beta <- c(-8,8)
  ylim.time <- c(-8,8)
  round.set <- 2
  xx_choice.ci <- xx_choice
  time_choice.ci <- time_choice
  list.name <- paste("np",1:np,sep="")
  s.names <- list.name
  s.names.short <- 1:np

} else {

  ##############################
  ## Data setup for real data ##
  ##############################
  source("../../../../codes/R_codes/real_main.R")

  simus <- 1
  do.plots <- TRUE

  num_study <- length(data.type)


  ylim.set <- c(-10,10)
  ylim.x <- c(-10,10)
  ylim.beta <- c(-2.5,4)
  ylim.time <- c(-10,10)
  round.set <- 2
  ##beta.cut <- 2
  ##alpha.cut <- 10
  beta.cut <- NULL
  alpha.cut <- NULL

  ##################
  ## create lists ##
  ##################
  tmp.list <- get.empty.list(data.type)
  axmod <- tmp.list
  study.names <- tmp.list
  data.tmp.list <- tmp.list
  s_tmp.list <- tmp.list
  delta_tmp.list <- tmp.list
  x_tmp.list <- tmp.list
  z_tmp.list <- tmp.list
  xx_choice <- tmp.list
  alphax_lab <- tmp.list
  xks <- tmp.list
  time_choice <- tmp.list
  time_choice.ci <- tmp.list
  ii.choose <- tmp.list
  xmin <- tmp.list
  xmax <- tmp.list
  beta0.list <- tmp.list
  alphat_lab <- tmp.list

  #########################################
  ## use.gene: who knows genetic status? ##
  #########################################
  if(comp==9){
    use.gene <- "r"
  } else if(comp==10){
    use.gene <- "si"
  }

  ########################################
  ## create a key for labels and colors ##
  ########################################
  full.names <-  c("cog",
    	         "apt2",
		"irb2",
		"dep2",
		"symp",
		"hdage",
		"hdage_nobase",
		"hdage_new",
		"hdage_new_nobase",
		"mmse",
		"verb",
		"sdmt",
		"strcol",
		"strwrd",
		"strint",
		"ind",
		"func",
		"tfc",
		"mcione",
		"behone")

 full.colors <- list(cog="black",
 	     	apt2="chocolate4",
		irb2="orange",
		dep2="mediumspringgreen",
		symp="chocolate4",
		hdage="firebrick1",
		hdage_nobase="firebrick1",
		hdage_new="darkmagenta",
		hdage_new_nobase="darkmagenta",
		mmse="green",
		verbflu="dark green",
		sdmt="dodger blue3",
		strcol="orange",
		strwrd="dark grey",
		strint="limegreen",
		ind="deepskyblue",
		func="dark green",
		tfc="orange",
		mcione="dark green",  ## duplicated color
		behone="orange"       ## duplicated color
		)

  full.s.names.short <- list(cog="cog",
  		     apt2="apathy",
		     irb2="irrit",
		     dep2="dep",
		     symp="motor symptom",
		     hdage="aao,bl,dcl=4",
		     #hdage_nobase="aao,dcl=4",
		     hdage_nobase="motor diagnosis",
		     hdage_new="aao,bl,dcl=3,4",
		     hdage_new_nobase="aao,dcl=3,4",
		     mmse="MMSE",
		     verbflu="verbflu",
		     sdmt="sdmt",
		     strcol="strcol",
		     strwrd="strwrd",
		     strint="strint",
		     ind="ind",
		     func="func",
		     tfc="tfc",
		     #mcione="at least one mci",
		     #behone="at least one beh"
		     mcione="cognitive impairment",
		     behone="behavior abnormality")		     

  ################
  ## main setup ##
  ################
  if(comp == 1 | comp == 2 | comp == 3 | comp == 4 | comp == 5 | comp == 6 | comp==7 | comp==8 | comp==9 | comp==10){
    ## zz comparisons 
    if(use.gene!="none"){
      covariates.use <- NULL

      ## compares set where rater knows to rater doesn't know
      zz_comp <- list(comp1=c(1,2))
   } else {
     covariates.use <- c("base_age","educ_cat","gender")

     # compares males to females
     zz_comp <- list(comp1=c(1,3),
		comp2=c(2,4),
		
		# compares no higher ed to higher ed
		comp3=c(1,2),
		comp4=c(3,4))
   }
  } else {
    covariates.use <- NULL
    zz_comp <- list(comp1=c(1,2))
  }



  if(comp==1 | comp==9 | comp==10){
    ## all
    motor.use <- "hdage_nobase"
    mci.use <- "mcione"
    s.use.names <- c("\\% Experience HD motor-diagnosis (\\% censoring)", 
    		   "\\% Experience cognitive impairment (\\% censoring)")
   
    beh.use <- NULL
    time_val <- seq(40,60,by=5)
  } else if(comp==2){
    ## all
    motor.use <- "hdage_new_nobase"
    mci.use <- "mcione"
    s.use.names <- c("\\% Experience HD motor-diagnosis, DCL>=3 (\\% censoring)", 
    		   "\\% Experience cognitive impairment (\\% censoring)")
   
    beh.use <- NULL
    time_val <- seq(45,65,by=5)
  } else if(comp==3){
    ## all
    ## changed 8/26/2015
    motor.use <- "hdage_nobase"
    mci.use <- c("sdmt")#,"strcol","strwrd","strint")

    s.use.names <- c("\\% Experience motor-onset (\\% censoring)", 
    		   "\\% Experience SDMT abnormality (\\% censoring)"#,
		   #"\\% Experience STRCOL abnormality (\\% censoring)",
		   #"\\% Experience STRWRD abnormality (\\% censoring)",
		   #"\\% Experience STRINT abnormality (\\% censoring)"
		   )
    beh.use <- NULL
    time_val <- seq(45,65,by=5)
  } else if(comp==4){
    ## all
    ## changed 8/26/2015
    motor.use <- "hdage_new_nobase"
    mci.use <- c("sdmt")#,"strcol","strwrd","strint")

    s.use.names <- c("\\% Experience motor-onset, DCL>=3 (\\% censoring)", 
    		   "\\% Experience SDMT abnormality (\\% censoring)"#,
		   #"\\% Experience STRCOL abnormality (\\% censoring)",
		   #"\\% Experience STRWRD abnormality (\\% censoring)",
		   #"\\% Experience STRINT abnormality (\\% censoring)"
		   )
    beh.use <- NULL
    time_val <- seq(45,65,by=5)
  } else if(comp==5){
    ## cohort, pharos
    motor.use <- "hdage_nobase"
    mci.use <- NULL
    beh.use <- "behone"
    time_val <- seq(45,65,by=5)

    s.use.names <- c("\\% Experience HD motor-diagnosis (\\% censoring)", 
    		   "\\% Experience behavioral impairment (\\% censoring)")
  }  else if(comp==6){
    ## cohort, pharos
    motor.use <- "hdage_new_nobase"
    mci.use <- NULL
    beh.use <- "behone"
    time_val <- seq(45,65,by=5)

    s.use.names <- c("\\% Experience HD motor-diagnosis, DCL>=3 (\\% censoring)", 
    		   "\\% Experience behavioral impairment (\\% censoring)")
  } else if(comp==7){
    ## cohort, pharos
    motor.use <- "hdage_nobase"
    mci.use <- NULL
    beh.use <- c(#"apt2","irb2",
    	       "dep2")
    time_val <- seq(45,65,by=5)

    s.use.names <- c("\\% Experience HD motor-diagnosis (\\% censoring)", 
    		   #"\\% Experience apathy (\\% censoring)",
		   #"\\% Experience irritability (\\% censoring)",
		   "\\% Experience depression (\\% censoring)"
		   ) 
  } else if(comp==8){
    ## cohort, pharos
    motor.use <- "hdage_new_nobase"
    mci.use <- NULL
    beh.use <- c(#"apt2","irb2",
    	       "dep2")
    time_val <- seq(45,65,by=5)

    s.use.names <- c("\\% Experience HD motor-diagnosis, DCL>=3 (\\% censoring)", 
    		   #"\\% Experience apathy (\\% censoring)",
		   #"\\% Experience irritability (\\% censoring)",
		   "\\% Experience depression (\\% censoring)"
		   ) 
  }

  s.names <- c(motor.use,mci.use,beh.use)
  delta.names <- paste("delta.",s.names,sep="")


  if(!is.null(motor.use)){
    ##motor.score.use <- paste("motor.",motor.use,sep="")
    ##motor.score.names <- "TMS"
    ##motor.score.use <- paste("DCL.prior.",motor.use,sep="")
    ##motor.score.use <- paste("DCL.base.",motor.use,sep="")
    motor.score.use <- NULL
  } else {
    motor.score.use <- NULL
    motor.score.names <- NULL
  }

  if(!is.null(mci.use)){
   ## mci.score.use <- NULL
   ## for(ll in 1:length(mci.use)){
   ##   if(mci.use[ll]!="mcione"){
   ##     mci.score.use <- c(mci.score.use,paste("score.",mci.use[ll],sep=""))
   ##   }
   ## }
   ## mci.score.names <- mci.use
    mci.score.use <- NULL
    mci.score.names <- NULL
  } else {
    mci.score.use <- NULL
    mci.score.names <- NULL
  }

  if(!is.null(beh.use)){
    #beh.score.use <- NULL
    #for(ll in 1:length(beh.use)){
    #  if(beh.use[ll]!="behone"){
    #    beh.score.use <- ct(beh.score.use,paste("score.",beh.use[ll],sep=""))
    #  }
    #}
    #beh.score.names <- beh.use 
    beh.score.use <- NULL
    beh.score.names <- NULL
  } else {
    beh.score.use <- NULL
    beh.score.names <- NULL
  }

  if(use.gene=="r"){
    gene.know <- "gene.indep.rater"
  } else if(use.gene=="si"){
    gene.know <- "gene.site.investigator"
  } else if(use.gene=="rs"){
    gene.know <- c("gene.indep.rater",
		 "gene.study.subj")
  } else if(use.gene=="none"){
    gene.know <- NULL
  } else {
    gene.know <- c("gene.indep.rater",
		 "gene.site.investigator")
  }

  if(!is.null(gene.know)){
    gene.use <- as.vector(outer(gene.know,motor.use,paste,sep="."))
  } else {
    gene.use <- NULL
  }

  ##if(data.type=="pharos" & use.gene!=FALSE){
  ##  gene.use <- as.vector(outer(gene.know,motor.use,paste,sep="."))
  ##} else {
  ##  gene.use <- NULL
  ##  gene.names <- NULL
  ##}

  np <- length(s.names)

  for(ss in 1:num_study){
    time_choice.ci[[ss]] <- time_val
    axmod[[ss]] <- rep("real",length(s.names))    
  }

  beta0int <- 0.5
  ##beta0int <- NULL

  ## gamma_i 
  if(np==1){
    ## gamma_i represents the difference between event i and (i-1)
    gamma.param <- 0
  } else if(np==2){
    gamma.param <- c(0,0.5)
  } else if(np==3){
    gamma.param <- c(0,0.5,1)
  }
  ##gamma.param <- NULL

  ## omega_s 
  ## omega_s represents the difference between study s and (s-1)
  if(num_study==1){
    omega.param <- 0
  } else if(num_study==2){
    omega.param <- c(0,0.75)
  } else if(num_study==3){
    omega.param <- c(0,0.75,1.25)
  }

  if(common.param.data==TRUE){
    ## there are no differences between the studies.
    omega.param <- 0
  }
  ##omega.param <- NULL

  if(common.param.estimation==TRUE){
    omega.param <- NULL
  }

  #######################
  ## set up covariates ##
  #######################
  zz.use <- c(motor.score.use,mci.score.use,beh.score.use,covariates.use,gene.use)
  zz.names <- zz.use

  ########################
  ## z's for evaluation ##
  ########################
  get.zz.values <- function(x,xval,beta0int){
    if("gender" %in% x){
      ## gender
      zval <- c(0,1)
      zuse <- xval
    } else if(grepl("educ_cat",x)){
      zval <- c(0,1)
      zuse <- xval
    }else if(grepl("DCL",x)){
      ## DCL
      if(!is.null(xval)){
        if(!is.null(beta0int)){
          zuse <- model.matrix(~factor(xval))[,-1]
        } else {
          zuse <- model.matrix(~-1+factor(xval))
        }
      } else {
       zuse <- NULL
      }
      if(!is.null(beta0int)){
        zz.tmp.length <- 3
      } else {
        zz.tmp.length <- 4
      }
      zval <- get.empty.list(paste(x,1:zz.tmp.length,sep=""))
      for(jj in 1:zz.tmp.length){
        zval[[jj]] <- c(0,1)
      }
    } else if(grepl("gene.",x)){
      ## gene knowledge
      zval <- c(0,1)
      zuse <- xval
    } else if(grepl("score",x)){
      ## return median of xval
      ##return(median(xval))
      zval <- 10
      zuse <- xval
    } else if(grepl("base_age",x)){
      ## return median of base_age
      ##return(median(xval))
      zval <- 40
      zuse <- xval
   }
   list(zval=zval,zuse=zuse)
  }

  ###################
  ## zz components ##
  ###################
  zeval.list <- list()
  for(ll in 1:length(zz.use)){
     zeval.list.tmp <- get.zz.values(zz.use[ll],NULL,beta0int)$zval
     if(is.list(zeval.list.tmp)){
       zeval.list <- appendList(zeval.list,zeval.list.tmp)     	   
     } else{
       tmp <- get.empty.list(zz.use[ll])
       tmp[[1]] <- zeval.list.tmp
       zeval.list <- appendList(zeval.list,tmp)
     }
  }    

  zeval.tmp <- expand.grid(zeval.list)    
  cat("\n\n ## Table of zevaluations ##\n\n")
  print(zeval.tmp)

  z.choice <- nrow(zeval.tmp)

  lb.max <- ncol(zeval.tmp)
  zeval <- array(0,dim=c(num_study,z.choice,np,lb.max),
      	      dimnames=list(
	       paste("ss",1:num_study,sep=""),
	       paste("zz",1:z.choice,sep=""),
               paste("np",1:np,sep=""),
               paste("lb",1:lb.max,sep="")))

  for(ss in 1:num_study){
    for(nn in 1:np){
      zeval[ss,,nn,] <- as.matrix(zeval.tmp)
    }
  }

  z_lab <- paste("zz",letters[1:nrow(zeval.tmp)],sep="")
  
  if(comp==1 | comp==2 | comp==3 | comp==4 | comp==5 | comp==6|
  	     comp==7 | comp==8 ){
    z_lab_names <- c("No HighEd, Female", "HighEd, Female", "No HighEd, Male", "HighEd, Male") 
  } else if(comp==9 | comp==10){
    z_lab_names <- c("Status Unknown", "Status Known")

  #  z_lab_names <- c("No HighEd, Female, Status Unknown", 
  #  		     "HighEd, Female, Status Unknown", 
  #  		     "No HighEd, Male, Status Unknown", 
#		     "HighEd, Male, Status Unknown",
#			"No HighEd, Female, Status Known", 
#		      "HighEd, Female, Status Known",   
#		       "No HighEd, Male, Status Known", 
#		     "HighEd, Male, Status Known"
#		     ) 
  } else {
    z_lab_names <- LETTERS[1:nrow(zeval.tmp)]
  }
  




  #############################
  ## set up other components ##
  #############################
  nn.comparison <- list(nc1=s.names)
  nc1.table <- nn.comparison
  nn.comparison.table <- nn.comparison

  s.names.short <- unlist(full.s.names.short[s.names])
  gene.names <- as.vector(outer(c("rater","subj","site"),
  	     	unlist(full.s.names.short[s.names]),paste,sep=","))
  list.names <- s.names.short
  colors.use <- unlist(full.colors[s.names])

  make.find.names <- function(s.names){
    function(x){
      return(which(s.names %in% x))
    }
  }

  find.names <- make.find.names(s.names)
  nn.comparison <- lapply(nn.comparison,find.names) 
  nn.comparison.table <- lapply(nn.comparison.table,find.names)

  ###############
  ## load data ##
  ###############
  if(sum(grepl("cohort",data.type))>0){
    study <- "cohort"
    study.names[[study]] <- study

    time_choice[[study]] <- c(45,55)
    alphat_lab[[study]] <- 1:length(time_choice[[study]])

    ii.choose[[study]] <- list(NULL)
    xx_choice[[study]] <- c(0.285714285714286, 0.714285714285714)
    ##xx_choice[[study]] <- c(0.3,0.7)
    alphax_lab[[study]] <- 1:length(xx_choice[[study]])


    data.tmp.list[[study]] <- read.table("../../../real_data/clean_cohort.dat",header=TRUE)
    cag.limits <- as.numeric(unlist(read.table("../../../real_data/cohort_cag_limits.dat")))

    ##xmin[[study]] <- cag.limits[1]
    ##xmax[[study]] <- cag.limits[2]
    xmin[[study]] <- 36
    xmax[[study]] <- 50
  }

  if(sum(grepl("pharos",data.type))>0){
    study <- "pharos"
    study.names[[study]] <- study
    time_choice[[study]] <- c(45,55)
    alphat_lab[[study]] <- 1:length(time_choice[[study]])

    ii.choose[[study]] <- list(NULL)

    xx_choice[[study]] <- c(0.285714285714286, 0.714285714285714)
    ##xx_choice[[study]] <- c(0.3,0.7)

    alphax_lab[[study]] <- 1:length(xx_choice[[study]])
    ##xx_choice <- c(0.09090909, 0.636363636363636)

    data.tmp.list[[study]] <- read.table("../../../real_data/clean_pharos.dat",header=TRUE)
    cag.limits <- as.numeric(unlist(read.table("../../../real_data/pharos_cag_limits.dat")))
    ##xmin[[study]] <- cag.limits[1]
    ##xmax[[study]] <- cag.limits[2]
    xmin[[study]] <- 36
    xmax[[study]] <- 50
  } 

  if(sum(grepl("predict",data.type))>0){
    study <- c("predict")
    study.names[[study]] <- study
    time_choice[[study]] <- c(45,55)
    alphat_lab[[study]] <- 1:length(time_choice[[study]])

    ii.choose[[study]] <- list(NULL)

    xx_choice[[study]] <- c(0.285714285714286, 0.714285714285714)
    ##xx_choice[[study]] <- c(0.3, 0.7)
    alphax_lab[[study]] <- 1:length(xx_choice[[study]])
    data.tmp.list[[study]] <- read.table("../../../real_data/clean_predict.dat",header=TRUE)
    cag.limits <- as.numeric(unlist(read.table("../../../real_data/predict_cag_limits.dat")))
    ##xmin[[study]] <- cag.limits[1]
    ##xmax[[study]] <- cag.limits[2]
    xmin[[study]] <- 36
    xmax[[study]] <- 50
  }
  xx_choice.ci <- xx_choice
  time.cut <- max(time_val)

  ############################
  ## extract info from data ##
  ############################
  n <- NULL
  tables.for.print <- NULL
  for(ss in 1:num_study){
    ##print(study.use)

    cat("\n\n ## Study ",study.names[[ss]],"## \n\n")

    study.use <- names(tmp.list)[ss]
    print(study.use)
    data.tmp <- data.tmp.list[[study.use]]

    if(!is.null(gene.use)){
      ## replace NA with 0 (i.e., NO)
      mytmp <- data.tmp[,gene.use] 
      mytmp[is.na(mytmp)] <- 0
      data.tmp[,gene.use] <- mytmp
    }
    print(dim(data.tmp))

    ## 8/26/2015: below needed to run old code
    ##follow <- paste("followup.",s.names,sep="")
    ##if(!is.null(motor.use)){
    ##  extra.motor <- paste(c("motor.","DCL."),motor.use,sep="")
    ##} else {
    ##  extra.motor <- NULL
    ##}

    ##if(!is.null(mci.use)){
    ##  extra.cog <- paste("score.",mci.use,sep="")
    ##} else {
    ##  extra.cog <- NULL
    ##}

    ##if(!is.null(beh.use)){
    ##  extra.beh <- paste("score.",beh.use,sep="")
    ##} else {
    ##  extra.beh <- NULL
    ##}
    ##extra <- c(extra.motor,extra.cog,extra.beh)
    ##data.tmp <- data.tmp[,c("CAG",zz.use,s.names,delta.names,follow,extra)]
    ##data.tmp <- data.tmp[complete.cases(data.tmp[,c("CAG",zz.use,s.names,delta.names)]),]
    ##get.my.tables.stat.old(data.tmp,data.name=study.use)

    
    ## 8/26/2015: NEW tables 
    data.tmp <- data.tmp[,c("CAG",zz.use,s.names,delta.names)]
    data.tmp <- data.tmp[complete.cases(data.tmp),]


    print(dim(data.tmp)) 


    if(comp==1){
      ######################
      ## get Cox ph plots ##
      ######################
      mysubset <- which((data.tmp$CAG<  0.285714285714286       + 0.001 & 
    	     	       data.tmp$CAG >  0.285714285714286    -0.001) |
			(data.tmp$CAG< 0.357142857142857      + 0.001 & 
    	     	       data.tmp$CAG >  0.357142857142857    -0.001) |
      	       	  	 (data.tmp$CAG< 0.428571428571429      + 0.001 & 
    	     	       data.tmp$CAG >  0.428571428571429     -0.001) |
		       (data.tmp$CAG < 0.5   +0.001 &
		       data.tmp$CAG > 0.5   - 0.001))

      data.tmp.use <- data.tmp[mysubset,]
      mycox.fit <- survfit(Surv(hdage_nobase,delta.hdage_nobase)~CAG,data=data.tmp.use)
      
      postscript(paste("cox_",study.use,".eps",sep=""))
      plot(mycox.fit,xlab="",ylab="",col=1:4,lty=1:4,cex.axis=3,cex.lab=3,lwd=5)
      legend("bottomleft",paste("CAG",
        convert.cag(c(0.285714285714286, 0.357142857142857,0.428571428571429,0.5),36,50),
        sep=" "),
	col=1:4,lty=1:4,lwd=rep(5,4),bty="n",cex=3)    
      dev.off()
    }



    	     					     

    #######################
    ## print data tables ##
    #######################
    table.tmp <- get.my.tables.stat(data.tmp,zz.use,s.use.names,
    	      	 delta.names)
    colnames(table.tmp) <- study.names[[ss]]
    tables.for.print <- cbind(tables.for.print,table.tmp)

    #####################
    ## data components ##
    #####################
    ntmp <- nrow(data.tmp)
    n <- c(n,ntmp)
    s_tmp.list[[study.use]] <- as.matrix(data.tmp[,s.names])
    delta_tmp.list[[study.use]] <- as.matrix(data.tmp[,delta.names])
    x_tmp.list[[study.use]] <- as.matrix(data.tmp[,"CAG"])
    ##xks[[study.use]] <- sort(unique(x_tmp.list[[study.use]]))
    xks[[study.use]] <- seq(0,1,by=0.1)
    xks[[study.use]] <- c(xks[[study.use]],0.285714285714286, 0.714285714285714)
    xks[[study.use]] <- sort(xks[[study.use]])

    z_tmp.list[[study.use]] <-  array(0,dim=c(ntmp,np,lb.max),
             dimnames=list(
	       paste("n",1:ntmp,sep=""),
               paste("np",1:np,sep=""),
               paste("lb",1:lb.max,sep="")))

    for(nn in 1:np){
      z_tmp.out <- NULL
      for(ll in 1:length(zz.use)){
        z_tmp.out <- cbind(z_tmp.out,get.zz.values(zz.use[ll],data.tmp[,zz.use[ll]],beta0int)$zuse)  
      }
      z_tmp.list[[study.use]][,nn,] <- as.matrix(z_tmp.out)
    }  

    mynames <- paste("beta0",1:np,sep="")
    beta0 <- get.empty.list(mynames)
    for(nn in 1:np){
      beta0[[nn]] <- rep(1,lb.max)
    }
    beta0.list[[study.use]] <- beta0
  }

  ##################################
  ## print summary tables of data ##
  ##################################
  foo <- tables.for.print
  print(xtable(data.frame(row = rownames(foo),data.frame(foo))),
                                  sanitize.text.function=function(x){x},
                                  include.rownames = FALSE)



  ################################
  ## terms that depend on lists ##
  ################################
  ## study.names
  study.names <- unlist(study.names)

  ## sample size
  nmax <- max(n)

  ## lb
  lb <- lapply(beta0.list,double.length.apply)

  ## lb.max
  lb.max <- max(unlist(lb))
  beta_lab <- lapply(lb,double.get.label)


}

#####################################################
## set terms needed whether real_data=TRUE or FALSE##
#####################################################

## m: number of events in each study for each subject
m <- array(0,dim=c(num_study,nmax),
		dimnames=list(
		   paste("ss",1:num_study,sep=""),
		   paste("n",1:nmax,sep="")))
for(ss in 1:num_study){
  m[ss,1:n[ss]] <- rep(np,n[ss])
}

## for kaplan-meier jack-knife implementation (these are all equal to np: number of events)
maxm  <- max(m)
p <- np
m0_qvs <- p


##########################################
## choice for a0: alpha(x,t)=a0*axmod() ##
##########################################

geta0 <- function(axmod,study,common.param.data){
  if(axmod=="line"){
    if(common.param.data==TRUE){ # common alpha, beta
      a0 <- 2
    } else {
      if(study==1){    
        a0 <- 2 #4
      } else if(study==2){
        a0 <- 1
      } else if(study==3){
        a0 <- 2
      } else if(study==4){
        a0 <- 1
      } else if(study==5){
        a0 <- 2.5
      } else if(study==6){
        a0 <- 3.5
      }	else if(study==7){
        a0 <- 4.5
      } else if(study==8){
        a0 <- 1.5
      } else if(study==9){
        a0 <- 0.75
      } else if(study==10){
        a0 <- 4.75
      }
    }
  } else if(axmod=="logx"){	
    if(common.param.data==TRUE){ # common alpha,beta
      a0 <- 2
    } else {
      if(study==1){
        a0 <- 5
      } else if(study==2){
        a0 <- 3
      } else {
        a0 <- 2
      }
    }
  } else if(axmod=="expx"){
    if(common.param.data==TRUE){ # common alpha, beta
      a0 <- 2
    } else {
      if(study==1){
        a0 <- 5
      } else if(study==2){
        a0 <- 3
      } else {
        a0 <- 2
      }
    }
  } else if(axmod=="wah2"){
    if(common.param.data==TRUE){ # common alpha,beta
      a0 <- 1
    } else {
      if(study==1){    
        a0 <- 2
      } else if(study==2){
        a0 <- 1
      } else if(study==3){
        a0 <- 2
      } else if(study==4){
        a0 <- 1
      } else if(study==5){
        a0 <- 2.5
      } else if(study==6){
        a0 <- 3.5
      }	else if(study==7){
        a0 <- 4.5
      } else if(study==8){
        a0 <- 1.5
      } else if(study==9){
        a0 <- 0.75
      } else if(study==10){
        a0 <- 4.75
      }
    }
  } else if(axmod=="wah4"){
    if(common.param.data==TRUE){ # common alpha, beta
      a0 <- 0.3
    } else{
      if(study==1){
        a0 <- 0.15
      } else if(study==2){
        a0 <- 0.3
      } else {
        a0 <- 0.2
      }
    } 
  } else if(axmod=="lgit"){	
    if(common.param.data==TRUE) { # common alpha, beta
      a0 <- 1.5
    } else {
      if(study==1){
        a0 <- 5
      } else if(study==2){
        a0 <- 3
      } else {
        a0 <- 2
      }
    }
  } else {
    if(common.param.data==TRUE){ # common alpha,beta
      a0 <- 1.5
    } else {
      if(study==1){
       a0 <- 5
      } else if(study==2){
        a0 <- 3
      } else {
        a0 <- 2
      }
    }
 }
 return(a0)
}

a0 <- get.empty.list(paste("study",1:num_study,sep=""))
for(ss in 1:num_study){
  a0.tmp <- NULL
  for(k in 1:np){
    a0.tmp <- c(a0.tmp,geta0(axmod[[ss]][[k]],ss,common.param.data))
  }
  a0[[ss]] <- a0.tmp
}

###############
## for gamm4 ##
###############
## number of knots
get.knot <- function(axmod){
 if(axmod=="wah4" | axmod=="wah3" | axmod=="real"){
   a <- 8
 } else {
   a <- 5
 }
 return(a)
}

## knot length
knot.length <- NULL
for(k in 1:np){
  knot.length <- c(knot.length,get.knot(axmod[k]))
}

## dim of alpha(x,t) in x-dimension
la <- 1

################################
## used for simulation study  ##
################################

############################
## for ueffect (not used) ##
############################
##par_fu <- c(mean=0,sd=1.5) ## u random effect variance
par_fu <- NULL


###################################################
## for density of random effect r ("v" in paper) ##
###################################################

if(frform=="norm"){
  ## normal reffect
  par1_fr <- rep(0,num_study) # mean
  par2_fr <- rep(1,num_study) # sd
} else if(frform=="gamm"){
  ## gamma reffect
  par1_fr <- rep(1.5,num_study) # shape
  par2_fr <- rep(2.,num_study)  # scal
  par3_fr <- rep(1.5,num_study) ## u random effect variance
} else if(frform=="unif"){
  ## unif reffect
  par1_fr <- rep(-1,num_study) # low
  par2_fr <- rep(1,num_study)   # hi
  par3_fr <- rep(1.5,num_study) ## u random effect variance
} else if(frform=="tdis"){
  ## noncentral t reffect
  par1_fr <- rep(3,num_study) # df
  par2_fr <- rep(0,num_study)  # ncp
  par3_fr <- rep(1.5,num_study) ## u random effect variance
} else if(frform=="mixn"){
  ## mixture of normal reffect
  par1_fr <- rep(3,num_study)  # mean1
  par2_fr <- rep(1,num_study)    # sd1
  par1_fr2 <- rep(-3,num_study) # mean2
  par2_fr2 <- rep(0.25,num_study) # sd2
  mix_n <- rep(0.9,num_study)   # mix_n
  par3_fr <- rep(1.5,num_study) ## u random effect variance
}


######################
## for density of Z ##
######################
if(fzrform=="norm"){
  ## normal zeffect
  par1_fzr <- rep(0,num_study) # mean
  par2_fzr <- rep(1,num_study) # sd
} else {
  ## unif zeffect
  par1_fzr <- rep(0,num_study) # low
  par2_fzr <- rep(1,num_study)  # hi
}

######################
## for density of X ##
######################
if(fxform=="norm"){
  ## normal xeffect
  par1_fx <-rep(0,num_study) # mean
  par2_fx <- rep(1,num_study)  # sd
} else {
  ## unif xeffect
  par1_fx <- rep(0,num_study)  # low
  par2_fx <- rep(1,num_study)  # hi
}

#########################
## for plotting output ##
#########################
do.plots <- FALSE	## do.plots: do we produce plots?
##do.plots <- TRUE

plot.nw <- FALSE	## plot.nw: do we produce Nadaraya-Watson estimator plots? (not used).
boot.ci <- FALSE	## use bootstrap confidence intervals?

########################
## set up for storage ##
#######################
## label for "beta" parameters (these include beta0, gamma_i,omega_s, beta_is)
param.label <- NULL

## if we have gamma_i terms
if(!is.null(gamma.param)){
  param.label <- c(param.label,"gamma")
}

## if we have omega_s terms
if(!is.null(omega.param)){
  param.label <- c(param.label,"omega")
}

## if we have beta0
if(!is.null(beta0int)){
  param.label <- c(param.label,"beta0")
}

## for remaining beta_is terms
param.label <- c(param.label,paste("beta",1:lb.max,sep=""))




#########################
## filename for output ##
#########################
filename <- paste("cens_",censorrate[1],
		  "_num_study_",num_study,
                  "_iseed_",iseed,".dat",sep="")

if(real_data==TRUE){
  filename <- paste("real_",filename,sep="")
}


