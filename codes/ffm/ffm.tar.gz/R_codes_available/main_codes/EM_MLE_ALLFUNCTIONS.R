# Notes on Updates:
#
# April 15, 2011 : This is the CORRECT code with codes for plots

# March 29, 2011 : This is the modified 
#     		 code, includes linear and nonlinear mean model
#    			 and EM_MLE algorithm. This is most updated & correct code
#
# May 4, 2011 : This code includes codes for plotting and making tables for paper
#
# May 5, 2011 : This code implements the EM-MLE algorithm from Huang, Chen, Maadooliat, Pourahmadi (2011)
#               This code ASSUMES there ARE missing values in the data set; for complete data set use EM_MLE.R with EM="FALSE"
#
# May 18 2011 : This code match with results from Mehdi's code and works perfectly
#		    This code contains all the functions needed to run em_mle & simulation study!
#
# May 25th 2011: This code gives exactly same MLE's as Mehdi's "A cautionary note on generalised linear models for covariance of unbalanced longitudinal data" 2011 
# June 6th fixed all defaults: tol, Nmax,Nlambda,linat,miss,EM,near.pd
# February 11, 2012: Fixed to incorporate new editor's model


###############
# Libraries   #
###############
library(mnormt)		# used for generating data

library(fts)     		# Used for removing NA entries
	
library(gdata)   		# Used for converting matrix to vector

library(stats) 		# Used for Netwon-Raphson

library(BB) 		# Used for dfsane

library(maxLik)

library(MASS)		# Used for multivariate normal

library(Matrix)

library(graphics)		# Used for scatterplot matrix

library(corpcor)		# Used for partial correlation matrix

library(lasso2) 		# Used for trace function tr()

library(xtable)		# for LaTeX Tables

##############################
# Simulation Study Functions #
##############################

#########################################################
# function to make t1 which is used for making Zphi.mat #
#########################################################

get.t1 <- function(n){
	# n : number of observations per subject
	t1 <- rep(0, sum(1:(n-1)))
	
	dummy  <- 0
	for(i in (n-1):1){
		t1[(dummy+1):(dummy+i)] <- n-i
		dummy <- dummy + i	
	}
	return(t1)
}

get.Zphi.mat <- function(Zphi.uniq,n,forEDITOR="model_orig"){
	# n : number of observations per subject
	t1 <- rep(0, sum(1:(n-1)))
	Zphi.mat<-matrix(0,length(t1),ncol(Zphi.uniq))
	if(forEDITOR=="model2"){
		dummy <- 0
		for(i in (n-1):1){
			#print(i)
			Zphi.mat[(dummy+1):(dummy+i),(1:ncol(Zphi.uniq))] <- matrix(Zphi.uniq[1:i,(1:ncol(Zphi.uniq))],ncol(Zphi.uniq))
			dummy <- dummy + i	
		}

	} else {
		dummy  <- 0
		for(i in (n-1):1){
			#print(i)
			Zphi.mat[(dummy+1):(dummy+i),(1:ncol(Zphi.uniq))] <- matrix(rep(Zphi.uniq[n-i,(1:ncol(Zphi.uniq))],i),i,ncol(Zphi.uniq),byrow=TRUE)
			dummy <- dummy + i	
		}
	}
	return(Zphi.mat)
}

#################################
# function to make missing data #
#################################

# percent : whole percentage of how many to miss

get.miss <- function(percent,data){
	data.vector <- unmatrix(data,byrow=TRUE)
	size <- (percent/100) * length(data.vector)
	miss.val <- sample(1:length(data.vector),size=size)
	data.vector[miss.val] <- NA
	data.miss <- matrix(data.vector,nrow=nrow(data),ncol=ncol(data),byrow=TRUE)
	return(data.miss)
}

#############################
# function to generate data #
#############################
# model1 : \phi_{t,t-1}=\gamma_0, \phi_{t,t-j}=0
# model2 : \phi_{t,j}
# model_orig: \phi_{t,t-j}= cubic model

gen.data <- function(m,n,beta,lambda,gamma,linear,miss,percent,forEDITOR="model_orig"){
	# m : number of subjects
	# n : number of observations per subject
	# beta : mean parameter
	# lambda, gamma: covariance
	
	# time
	time <- seq(1,n)

	# matrix formed just to get m row and n columns to feed into TD.form()
	data.dummy<-matrix(0,m,n)

	# mean structure
	if(linear=="TRUE"){
		X.mat <- cbind(rep(1,n),poly(time,deg=length(beta)-1)[1:n,])
	}else{
		X.mat <- time	
	}
	mu <- s.func(beta,X.mat,linear)

	# covariance structure
	Z.mat <- cbind(rep(1,n),poly(time,deg=length(lambda)-1)[1:n,])


	if(forEDITOR=="model1"){
		t1 <- get.t1(n)
	} else if(forEDITOR=="model2"){
		t1 <- NULL
		for(i in (n-1):1){
			t1 <- c(t1,seq(1,i))
		}
	} else {
		t1 <- get.t1(n)
	}

	
	if(forEDITOR=="model1"){
		# Zphi.mat is a column only
		Zphi.uniq <- as.matrix(c(1,rep(0,n-2)),ncol=1)
		Zphi.mat <- as.matrix(c(rep(1,n-1),rep(0,sum((n-2):1))),ncol=1)
	} else if(forEDITOR=="model2"){
		# Zphi.mat has 4 columns (i.e, \gamma_0,\gamma_1,\gamma_2,\gamma_3)
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(length(gamma)-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	} else {
		##Mehdi's Code for Zphi.mat: uncomment if this is to be used
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(length(gamma)-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	}
	
	TD <- TD.form(data.dummy,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)
      T.mat <- TD$T.mat
      D <- TD$D
      Sigma.inv <- t(T.mat) %*% solve(D) %*% T.mat
	Sigma <- solve(Sigma.inv)
	#Sigma<-solve(T.mat)%*%D%*%solve(t(T.mat))
	
	# initiate data
	data<-matrix(0,m,n)
	
	# generate data
	#data <- mvrnorm(m,mu,Sigma)
	
	#  Independent for each subject
	for(i in 1:m){
		data[i,]<-rmnorm(1,mu,Sigma)
	}

	# original data, no missingness
	data.orig <- data

	# generate missing data
	if(miss=="TRUE"){
		data <- get.miss(percent,data)
	}

	#generate missingness Mehdi's way
	#if(miss=="TRUE"){
	#for(i in 1:m){	
	#		ind.mis<-sample(1:n,percent)
	#		data[i,ind.mis]<-NA
	#	}	
	#}	

	list(data=data,data.orig=data.orig,X.mat=X.mat,Z.mat=Z.mat,Zphi.mat=Zphi.mat)
}

###################################
# Function to do simulation study #
###################################

simulation.study <- function(EM,simu,iseed,m,n,beta,lambda,gamma,
				beta.0,lambda.0,gamma.0,
				tol,Nmax,linear,miss,percent,Nlambda,near.pd,forEDITOR="model_orig"){
	# simu : number of simulations
	# iseed : seed to start generating random data

	# matrix for storing parameter values

	beta.val <- matrix(0,nrow=simu,ncol=length(beta))
	gamma.val <- matrix(0,nrow=simu,ncol=length(gamma))
	lambda.val <- matrix(0,nrow=simu,ncol=length(lambda))
	
	#array for storing error messages

	NoLambdaUpdate<-matrix(0,nrow=simu,ncol=1)
	Q0Inf<-matrix(0,nrow=simu,ncol=1)
	Q1Inf<-matrix(0,nrow=simu,ncol=1)

	# array for storing standard errors

	beta.std.err <- matrix(0,nrow=simu,ncol=length(beta))
	gamma.std.err <- matrix(0,nrow=simu,ncol=length(gamma))
	lambda.std.err <- matrix(0,nrow=simu,ncol=length(lambda))

	# set random seed
	#set.seed(iseed)  	# Need to change this because otherwise always same!!
	
	# simulation study
	for(i in 1:simu){
		#print("simu")
		#print(i)
		all.data <- gen.data(m,n,beta,lambda,gamma,linear,miss,percent,forEDITOR=forEDITOR)
		
		data <- all.data$data	
		#print(data[1,])
		X.mat <- all.data$X.mat
		Z.mat <- all.data$Z.mat
		Zphi.mat <- all.data$Zphi.mat


		if(forEDITOR=="model1"){
			Zphi2.mat <-1
			for(j in 1:(n-2)){
				Zphi2.mat <- as.matrix(c(Zphi2.mat,c(rep(0,j),1)),ncol=1)
			}
		} else if(forEDITOR=="model2"){		
			t2 <- 1
			for(j in 2:(n-1)){
				t2 <- c(t2,seq(1,j))
			}
			Zphi2.mat <- cbind(rep(1,length(t2)),poly(t2,deg=length(gamma)-1)[1:length(t2),])
		} else {
			t2 <- 1
			for (j in 2:(n-1)){
				t2 <- c(t2,seq(j,1))	
			}
			Zphi2.mat <- cbind(rep(1,length(t2)),poly(t2,deg=length(gamma)-1)[1:length(t2),])
		}

		

		# we run the algorithm
		output<- alg(init="gen",EM,beta.init=beta.0,lambda.init=lambda.0,
			gamma.init=gamma.0,beta=rep(10,length(beta.0)),data,X.mat,Z.mat,Zphi.mat,Zphi2.mat,tol,Nmax,linear,Nlambda,near.pd,forEDITOR=forEDITOR)		


		# store parameter values
		beta.val[i,] <- output$beta
		lambda.val[i,] <- output$lambda
		gamma.val[i,] <- output$gamma
		
		#store counters: Noupdates for labda, Infinite log likelihood
		NoLambdaUpdate[i,]<-output$NoLambdaUpdate
		Q0Inf[i,]<-output$Q0Inf
		Q1Inf[i,]<-output$Q1Inf
		
		# store data.nomiss
		data.nomiss <- output$data.nomiss
			
		# get standard errors
		beta.std.err[i,] <- output$beta.se
		lambda.std.err[i,] <- output$lambda.se
		gamma.std.err[i,] <- output$gamma.se
	}	
	
	# summarize results

	param.out <- matrix(0,nrow=7,ncol=sum(length(beta),length(gamma),length(lambda)))
	colnames(param.out) <- c(rep("beta",length(beta)),rep("gamma",length(gamma)),
					rep("lambda",length(lambda)))
	rownames(param.out) <- c("mean","bias","emp.se","est.se","no.update","Q0Inf","Q1Inf")

	param.out["mean",]   <- c(apply(beta.val,2,mean), apply(gamma.val,2,mean), apply(lambda.val,2,mean))
	param.out["bias",]<-param.out["mean",]-c(beta,gamma,lambda)
	param.out["emp.se",] <- c(apply(beta.val,2,sd), apply(gamma.val,2,sd), apply(lambda.val,2,sd))
	param.out["est.se",] <- c(apply(beta.std.err,2,mean),apply(gamma.std.err,2,mean),apply(lambda.std.err,2,mean))
	param.out["no.update",] <- c(mean(NoLambdaUpdate),rep(NA,ncol(param.out)-1))
	param.out["Q0Inf",] <- c(mean(Q0Inf),rep(NA,ncol(param.out)-1))
	param.out["Q1Inf",] <- c(mean(Q1Inf),rep(NA,ncol(param.out)-1))	

	list(param.out=round(param.out,digits=3),beta.val=beta.val,gamma.val=gamma.val,lambda.val=lambda.val,
					beta.std.err=beta.std.err,lambda.std.err=lambda.std.err,gamma.std.err=gamma.std.err,NoLambdaUpdate=NoLambdaUpdate,Q0Inf=Q0Inf,Q1Inf=Q1Inf)
}

################################
# Function to analyze FFM data #
################################

# NLS results

get.NLS.results <- function(data){
	# get results from NLS
	
	m <- nrow(data)
	n <- ncol(data)
	time.NLS <- rep(seq(1,n),m)
	y.val <- unmatrix(data,byrow=TRUE)
	FFM.data <- as.data.frame(matrix(c(time.NLS,y.val),ncol=2))
	FFM.mod <- nls(y.val ~ beta1/(1 + exp(-(time.NLS-beta2)/beta3)),
 		start=list(beta1 = -2.5, beta2 = 1/-4.5, beta3 = -1/0.3),
 		trace=FALSE,na.action=na.omit)


	beta <- summary(FFM.mod)$parameters[,1]
	beta.se <- sqrt(diag(summary(FFM.mod)$cov.unscaled))
	sigma   <- summary(FFM.mod)$sigma
	loglik  <- logLik(FFM.mod)
	BIC     <- AIC(FFM.mod,k=log(m)) /m
	BIC.mod <- AIC(FFM.mod,k=sqrt(m) * log(m))/m

	out <- rbind(beta,beta.se,c(sigma,rep(0,length(beta)-1)),
			c(BIC,rep(0,length(beta)-1)),
			c(BIC.mod,rep(0,length(beta)-1)),
			c(loglik,rep(0,length(beta)-1)))
	rownames(out) <- c("beta","beta.se","sigma","BIC","BIC.mod","loglik")
	return(out)
}



# Function to find best fitting polynomial mean model based on 
# BIC (Pan and MacKenzie, 2003) and BIC.mod (Hong and Preston, 2009)

poly.mod <- function(p,forEDITOR="model_orig"){
	beta <- rep(0,p+1)			# initial parameter estimates
	if(forEDITOR=="model1"){
		gamma <- rep(0,1)
	} else {
		gamma <-  rep(0,4)
	}
 
	lambda <- rep(0,4) 

	linear <- "TRUE"		# linear model

	out.lin<-store.realdata.files(name,file=1,iseed,simu,EM=EM,m,n,beta,lambda,gamma,
	beta.0=beta,lambda.0=lambda,gamma.0=gamma,tol=tol,Nmax=Nmax,linear=linear,miss=miss,percent=percent,Nlambda=Nlambda,near.pd=near.pd,forEDITOR=forEDITOR)

	# see summary of results
	return(out.lin)
}


realdata.study <- function(name,EM,simu,beta,lambda,gamma, beta.0,lambda.0,
			gamma.0,tol,Nmax,linear,miss,percent,Nlambda,near.pd,forEDITOR="model_orig"){

	# matrix for storing parameter values

	beta.val <- matrix(0,nrow=simu,ncol=length(beta))
	gamma.val <- matrix(0,nrow=simu,ncol=length(gamma))
	lambda.val <- matrix(0,nrow=simu,ncol=length(lambda))
	
	#array for storing error messages

	NoLambdaUpdate<-matrix(0,nrow=simu,ncol=1)
	Q0Inf<-matrix(0,nrow=simu,ncol=1)
	Q1Inf<-matrix(0,nrow=simu,ncol=1)

	# array for storing standard errors

	beta.std.err <- matrix(0,nrow=simu,ncol=length(beta))
	gamma.std.err <- matrix(0,nrow=simu,ncol=length(gamma))
	lambda.std.err <- matrix(0,nrow=simu,ncol=length(lambda))

	
	# simulation study
	for(i in 1:simu){
		#print("simu")
		#print(i)
		all.data <- gen.data(m,n,beta,lambda,gamma,linear,miss,percent,forEDITOR=forEDITOR)
		data <- read.table(name,header=FALSE)	

		#print(data[1,])
		X.mat <- all.data$X.mat
		Z.mat <- all.data$Z.mat
		Zphi.mat <- all.data$Zphi.mat


		if(forEDITOR=="model1"){
			Zphi2.mat <-1
			for(j in 1:(n-2)){
				Zphi2.mat <- as.matrix(c(Zphi2.mat,c(rep(0,j),1)),ncol=1)
			}
		} else if(forEDITOR=="model2"){		
			t2 <- 1
			for(j in 2:(n-1)){
				t2 <- c(t2,seq(1,j))
			}
			Zphi2.mat <- cbind(rep(1,length(t2)),poly(t2,deg=length(gamma)-1)[1:length(t2),])
		} else {
			t2 <- 1
			for (j in 2:(n-1)){
				t2 <- c(t2,seq(j,1))	
			}
			Zphi2.mat <- cbind(rep(1,length(t2)),poly(t2,deg=length(gamma)-1)[1:length(t2),])
		}

		# we run the algorithm
		output<- alg(init="gen",EM,beta.init=beta.0,lambda.init=lambda.0,
			gamma.init=gamma.0,beta=rep(10,length(beta.0)),data,X.mat,Z.mat,Zphi.mat,Zphi2.mat,tol,Nmax,linear,Nlambda,near.pd,forEDITOR=forEDITOR)	


		# store parameter values
		beta.val[i,] <- output$beta
		lambda.val[i,] <- output$lambda
		gamma.val[i,] <- output$gamma
		
		#store counters: Noupdates for labda, Infinite log likelihood
		NoLambdaUpdate[i,]<-output$NoLambdaUpdate
		Q0Inf[i,]<-output$Q0Inf
		Q1Inf[i,]<-output$Q1Inf
		
		# store data.nomiss
		data.nomiss <- output$data.nomiss
			
		# get standard errors
		beta.std.err[i,] <- output$beta.se
		lambda.std.err[i,] <- output$lambda.se
		gamma.std.err[i,] <- output$gamma.se
		
		# get BIC
		BIC   <-output$BIC.val
		BIC.mod <- output$BIC.mod
		loglik  <- output$loglik
		
	}	
	
	# summarize results

	param.out <- matrix(0,nrow=10,ncol=sum(length(beta),length(gamma),length(lambda)))
	colnames(param.out) <- c(rep("beta",length(beta)),rep("gamma",length(gamma)),
					rep("lambda",length(lambda)))
	rownames(param.out) <- c("mean","bias","emp.se","est.se","BIC","BIC.mod","loglik","no.update","Q0Inf","Q1Inf")

	param.out["mean",]   <- c(apply(beta.val,2,mean), apply(gamma.val,2,mean), apply(lambda.val,2,mean))
	param.out["bias",]<-param.out["mean",]-c(beta,gamma,lambda)
	param.out["emp.se",] <- c(apply(beta.val,2,sd), apply(gamma.val,2,sd), apply(lambda.val,2,sd))
	param.out["est.se",] <- c(apply(beta.std.err,2,mean),apply(gamma.std.err,2,mean),apply(lambda.std.err,2,mean))
	param.out["BIC",]    <- c(BIC,rep(NA,ncol(param.out)-1))
	param.out["BIC.mod",]    <- c(BIC.mod,rep(NA,ncol(param.out)-1))
	param.out["loglik",]    <- c(loglik,rep(NA,ncol(param.out)-1))
	param.out["no.update",] <- c(mean(NoLambdaUpdate),rep(NA,ncol(param.out)-1))
	param.out["Q0Inf",] <- c(mean(Q0Inf),rep(NA,ncol(param.out)-1))
	param.out["Q1Inf",] <- c(mean(Q1Inf),rep(NA,ncol(param.out)-1))	

	list(param.out=round(param.out,digits=3),beta.val=beta.val,gamma.val=gamma.val,lambda.val=lambda.val,
					beta.std.err=beta.std.err,lambda.std.err=lambda.std.err,gamma.std.err=gamma.std.err,NoLambdaUpdate=NoLambdaUpdate,Q0Inf=Q0Inf,Q1Inf=Q1Inf)
}




###########################################################
# Function to write output from simulation.study to files #
###########################################################

# file: a number, this will be the end of the file name

store.simu.files <- function(file=1,iseed,simu,EM,m,n,beta,lambda,gamma,
			beta.0,lambda.0,gamma.0, tol,Nmax,linear,miss,percent,Nlambda,near.pd,forEDITOR="model_orig"){

	output <- simulation.study(EM,simu,iseed,m,n,beta,lambda,gamma,
				beta.0,lambda.0,gamma.0,
				tol,Nmax,linear,miss,percent,Nlambda,near.pd,forEDITOR=forEDITOR)
	
	OutputFile<-cbind(output$beta.val,output$gamma.val,output$lambda.val,output$beta.std.err,output$gamma.std.err,output$lambda.std.err,output$NoLambdaUpdate,output$Q0Inf,output$Q1Inf)
	#print("start")
	#write(t(OutputFile),ncolumns=ncol(OutputFile),file="",append=TRUE)
	list(Main=output$param.out,Values=OutputFile)	
}

###########################################################
# Function to write output from realdata.study to files #
###########################################################

# file: a number, this will be the end of the file name

store.realdata.files <- function(name,file=1,iseed,simu,EM,m,n,beta,lambda,gamma,
				beta.0,lambda.0,gamma.0,tol,Nmax,linear,miss,percent,Nlambda,near.pd,forEDITOR="model_orig"){

	output <- realdata.study(name,EM,simu=1,beta,lambda,gamma, beta.0,lambda.0,
			gamma.0,tol,Nmax,linear,miss,percent,Nlambda,near.pd,forEDITOR=forEDITOR)

	OutputFile<-cbind(output$beta.val,output$gamma.val,output$lambda.val,output$beta.std.err,output$gamma.std.err,output$lambda.std.err,output$NoLambdaUpdate,output$Q0Inf,output$Q1Inf)
	#print("start")
	#write(t(OutputFile),ncolumns=ncol(OutputFile),file="",append=TRUE)
	list(Main=output$param.out,Values=OutputFile)	
}




######################################################
# Function to make plots of profile and regressogram #
######################################################

plots.profreg <- function(m,n,beta,lambda,gamma,linear,miss,percent,forEDITOR="model_orig"){

	all.data <- gen.data(m,n,beta,lambda,gamma,linear,miss,percent,forEDITOR=forEDITOR)

	data.orig <- all.data$data.orig
	data <- all.data$data
	X.mat <- all.data$X.mat
	Z.mat <- all.data$Z.mat
	Zphi.mat <- all.data$Zphi.mat


	if(forEDITOR=="model1"){
		Zphi2.mat <-1
		for(i in 1:(n-2)){
			Zphi2.mat <- as.matrix(c(Zphi2.mat,c(rep(0,i),1)),ncol=1)
		}
	} else if(forEDITOR=="model2"){		
		t2 <- 1
		for(i in 2:(n-1)){
			t2 <- c(t2,seq(1,i))
		}
		Zphi2.mat <- cbind(rep(1,length(t2)),poly(t2,deg=length(gamma)-1)[1:length(t2),])
	} else {
		t2 <- 1
		for (j in 2:(n-1)){
			t2 <- c(t2,seq(j,1))	
		}
		Zphi2.mat <- cbind(rep(1,length(t2)),poly(t2,deg=length(gamma)-1)[1:length(t2),])
	}

	if(forEDITOR=="model1"){
		t1 <- get.t1(n)
	} else if(forEDITOR=="model2"){
		t1 <- NULL
		for(i in (n-1):1){
			t1 <- c(t1,seq(1,i))
		}
	} else {
		t1 <- get.t1(n)
	}

	time <- seq(1,n)

		
	if(miss=="TRUE"){
		# we want to see how well imputation works
		# this is initial step to imputing missing data
		mean.init <- apply(data,2,mean,na.rm="TRUE")
        	sigma.init <- cov(data,use="pairwise.complete.obs")

		# suppose, by some miracle we had the truth
		#mean.init <- apply(data.orig,2,mean)
		#sigma.init <- cov(data.orig)
		
		sigma.init <- get.pd.mat(sigma.init)
		data.impute <- dist.impute.values(data,mean.init,sigma.init)


		par(mfrow=c(3,3))
		prof.plot(data.orig,"Profile-No Missing Data")
		prof.plot(data,"Profile-Missing Data")
		prof.plot(data.impute,"Profile-Stoch. Reg. Imputed Data")

		reg.iv(cov(data.orig),time,t1,Z.mat,Zphi.mat,"Log IV-No Missing Data")
		reg.iv(get.pd.mat(cov(data,use="pairwise.complete.obs")),time,t1,Z.mat,Zphi.mat,"Log IV-Missing Data")
		reg.iv(cov(data.impute),time,t1,Z.mat,Zphi.mat,"Log IV-Stoc. Reg. Imputed Data")
		
		reg.garp(cov(data.orig),time,t1,Z.mat,Zphi.mat,"GARP-No Missing Data")
		reg.garp(get.pd.mat(cov(data,use="pairwise.complete.obs")),time,t1,Z.mat,Zphi.mat,"GARP-Missing Data")
		reg.garp(cov(data.impute),time,t1,Z.mat,Zphi.mat,"GARP-Stoch. Reg. Imputed Data")

	}else{
		par(mfrow=c(2,2))
		prof.plot(data,"Profile")
		reg.iv(cov(data),time,t1,Z.mat,Zphi.mat,"Log IV")
		reg.garp(cov(data),time,t1,Z.mat,Zphi.mat,"GARP")
	}
}


######################################################################
# Function to do plots with final estimates as compared to the truth #
######################################################################

plot.mean <- function(time,mu,X.mat,beta.values,linear,ylab="Logarithm Mortality",xlab="Time",main="",random){
	plot(time,mu,type="l",ylab=ylab,xlab=xlab,col="black",lwd=2,main=main,cex.main=2.0,cex.lab=2.0) #,ylim=c(min(data,na.rm=TRUE),max(data,na.rm=TRUE)),main="(a)")
        if(random=="TRUE"){
          ind <- sample(1:nrow(beta.values),min(10,nrow(beta.values)),replace=FALSE)       
        } else{
          ind <- seq(1,min(10,nrow(beta.values)))
        }
        j <- 1
        while (j < length(ind)){
          i <- ind[j]
          mean.values<-s.func(beta.values[i,],X.mat,linear)
          lines(time,mean.values,lty=2,lwd=1)
          j <- j+1
        }
}	

plot.logIV <- function(time,D,Z.mat,lambda.values,xlab="Time",ylab="Log innov. var.",main="",random){
	smooth.D <- loess.smooth(1:nrow(D),D,degree=2,family=c("gaussian"))
	plot(smooth.D,type="l",xlab=xlab,main=main,ylab=ylab,col="black",lwd=2,
		ylim=c(min(D,(Z.mat%*%t(lambda.values)))-1,max(D,(Z.mat%*%t(lambda.values)))+1),
		cex.main=2.0,cex.lab=2.0)
	smooth.logIV.mat.X<-matrix(0, length(smooth.D$x),nrow(lambda.values))
	smooth.logIV.mat.Y<-matrix(0, length(smooth.D$y),nrow(lambda.values))

        if(random=="TRUE"){
          ind <- sample(1:nrow(lambda.values),min(10,nrow(lambda.values)),replace=FALSE)       
        } else{
          ind <- seq(1,min(10,nrow(lambda.values)))
        }
        j <- 1
        
	while(j < length(ind)){
          i <- ind[j]
          logIV <- Z.mat%*%lambda.values[i,]
          smooth.logIV <- loess.smooth(1:nrow(D),logIV,degree=2,family=c("gaussian"))
          smooth.logIV.mat.X[,i]=smooth.logIV$x
          smooth.logIV.mat.Y[,i]=smooth.logIV$y
          lines(smooth.logIV,lty=2,lwd=1)
          #plot(smooth.logIV,type="l",lwd=2)	# just for testing
          j <- j+1
        }
#	lines(apply(smooth.logIV.mat.X,1,mean),apply(smooth.logIV.mat.Y,1,mean),lty=2,lwd=1)	
}

plot.GARP <- function(t1,T,Zphi.mat,gamma.values,xlab="Lag",ylab="Autoreg. coef",main="",random){
	smooth.T <- loess.smooth(1:(nrow(T)),T[,1],degree=2,family=c("gaussian"))
	plot(smooth.T,type="l",xlab="Lag",main="",ylab=ylab,col="black",lwd=2,ylim=c(min(T,(Zphi.mat%*%t(gamma.values)))-1,max(T,(Zphi.mat%*%t(gamma.values)))+1),
		cex.main=2.0,cex.lab=2.0)


        if(random=="TRUE"){
          ind <- sample(1:nrow(gamma.values),min(10,nrow(gamma.values)),replace=FALSE)       
        } else{
          ind <- seq(1,min(10,nrow(gamma.values)))
        }
        j <- 1
        
	while(j < length(ind)){
          i <- ind[j]
          GARP<- unique(Zphi.mat%*%gamma.values[i,])
          GARP.smooth<-loess.smooth(1:(nrow(T)),GARP,degree=2,family=c("gaussian"))
          lines(GARP.smooth,lty=2,lwd=1)
          j <- j+1
        }
}

# if printfiles="TRUE", then graphics will be printed onto postscript files with associated file name "file.name"
# if printfiels="FALSE", a graphic will pop up showing all plots together

plots.all <- function(n,beta,lambda,gamma,OutputFile,linear,printfiles="FALSE",filename="simu1",random,forEDITOR="model_orig"){
	time <- seq(1,n)
	if(linear=="TRUE"){
		X.mat <- cbind(rep(1,n),poly(time,deg=length(beta)-1)[1:n,])
	}else{
		X.mat <- time	
	}

	# covariance structure
	Z.mat <- cbind(rep(1,n),poly(time,deg=length(lambda)-1)[1:n,])
	

	if(forEDITOR=="model1"){
		t1 <- get.t1(n)
	} else if(forEDITOR=="model2"){
		t1 <- NULL
		for(i in (n-1):1){
			t1 <- c(t1,seq(1,i))
		}
	} else {
		t1 <- get.t1(n)
	}


	if(forEDITOR=="model1"){
		# Zphi.mat is a column only
		Zphi.uniq <- as.matrix(c(1,rep(0,n-2)),ncol=1)
		Zphi.mat <- as.matrix(c(rep(1,n-1),rep(0,sum((n-2):1))),ncol=1)
	} else if(forEDITOR=="model2"){
		# Zphi.mat has 4 columns (i.e, \gamma_0,\gamma_1,\gamma_2,\gamma_3)
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(length(gamma)-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	} else {
		##Mehdi's Code for Zphi.mat: uncomment if this is to be used
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(length(gamma)-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	}
	


	mu <- s.func(beta,X.mat,linear) 	# TRUE mean
	D <- Z.mat%*%lambda 		      # TRUE log(sigma^2)
	T <- Zphi.mat%*%gamma  			# TRUE phi_{tj}
	T.uniq<-unique(T)		

	# READING OutputFile	
	p<-length(beta)
	q<-length(gamma)
	d<-length(lambda)
		
	# initialte beta, lambda and gamma values matrices
	beta.values<-matrix(0,nrow=nrow(OutputFile),ncol=p)
	gamma.values<-matrix(0,nrow=nrow(OutputFile),ncol=q)
	lambda.values<-matrix(0,nrow=nrow(OutputFile),ncol=d)
		

	beta.values[,1:p]<-OutputFile[,1:p]
	gamma.values[,1:q]<-OutputFile[,(p+1):(p+q)]
	lambda.values[,1:d]<-OutputFile[,(p+q+1):(p+d+q)]
	
	#####################################
	# One graphic of all plots together #
	# NOT printed to a separate file    #
	#####################################
	if(printfiles=="FALSE"){
		par(mfrow=c(2,2))

		plot.mean(time,mu,X.mat,beta.values,linear,ylab="Logarithm Mortality",xlab="Time",main="",random)		# Plot for beta's or mean
		plot.logIV(time,D,Z.mat,lambda.values,xlab="Time",ylab="Log innov. var.",main="",random)	# Plot for lambdas or Log IV's
		plot.GARP(t1,T.uniq,Zphi.mat,gamma.values,xlab="Lag",ylab="Autoreg. coef",main="",random)		# Plot for gammas or GARPS

	}else{

		postscript(paste("MeanPlot_",filename,".ps",sep=""))										
		plot.mean(time,mu,X.mat,beta.values,linear,ylab="Logarithm Mortality",xlab="Time",main="",random)		# Plot for beta's or mean
		dev.off()

		postscript(paste("LogIVPlot_",filename,".ps",sep=""))
		plot.logIV(time,D,Z.mat,lambda.values,xlab="Time",ylab="Log innov. var.",main="",random)	# Plot for lambdas or Log IV's
		dev.off()

		postscript(paste("GARPPlot_",filename,".ps",sep=""))
		plot.GARP(t1,T.uniq,Zphi.mat,gamma.values,xlab="Lag",ylab="Autoreg. coef",main="",random)		# Plot for gammas or GARPS
		dev.off()
	}
}





#################################################
# Functions to do plots for analyzing real data #
#################################################


real.plot.mean <- function(data,time,mu.nls,mu.lin,mu.nlin,lwd=3){
	mean.real <- apply(data,2,mean,na.rm="TRUE")
	par(mar=c(5, 4, 4, 2)+1)

	plot(time,mean.real,col="black",lwd=2,type="l",ylab="Logarithm Mortality",xlab="Time",main="",ylim=c(min(mu.lin,mu.nlin,mean.real)-1,max(mu.lin,mu.nlin,mean.real)+1),
		cex.main=2.0,cex.lab=2.0)
	lines(time,mu.lin,lty=2,lwd=lwd)
	lines(time,mu.nlin,lty=4,lwd=lwd)
	lines(time,mu.nls,lty=3,lwd=lwd)
}

real.plot.logiv <- function(data,time,t1,Z.mat.lin,Zphi.mat.lin,D.nls,D.lin,D.nlin,plot.ols="FALSE",lwd=3){
	par(mar=c(5, 4, 4, 2)+1)
	reg.iv(cov(data,use="pairwise.complete.obs"),time,t1,Z.mat.lin,Zphi.mat.lin,"",plot.ols)

	smooth.D.lin <- loess.smooth(1:nrow(D.lin),D.lin,degree=2,family=c("gaussian"))
	lines(smooth.D.lin,lty=2,lwd=lwd)

	smooth.D.nlin <- loess.smooth(1:nrow(D.nlin),D.nlin,degree=2,family=c("gaussian"))
	lines(smooth.D.nlin,lty=4,lwd=lwd)

	smooth.D.nls <- loess.smooth(1:length(D.nls),D.nls,degree=2,family=c("gaussian"))
	lines(smooth.D.nls,lty=3,lwd=lwd)
}



real.plot.garp <- function(data,time,t1,Z.mat,Z.mat.lin,Zphi.mat.lin,T.nls,T.uniq.lin,T.uniq.nlin,plot.ols="FALSE",lwd=3,forEDITOR="model_orig"){
	par(mar=c(5, 4, 4, 2)+1)
	reg.garp(cov(data,use="pairwise.complete.obs"),time,t1,Z.mat.lin,Zphi.mat.lin,"",plot.ols)
	
	if(forEDITOR=="model1"){
		y.lin <- c(T.uniq.lin[1,1],rep(T.uniq.lin[2,1],length(time)-2))
		x <- time[-length(time)]
		lines(x,y.lin,lty=2,lwd=lwd)

		y.nlin <- c(T.uniq.nlin[1,1],rep(T.uniq.nlin[2,1],length(time)-2))		
		lines(x,y.nlin,lty=4,lwd=lwd)

		
	} else {
		smooth.T.lin <- loess.smooth(1:(nrow(T.uniq.lin)),T.uniq.lin[,1],degree=2,family=c("gaussian"))
		lines(smooth.T.lin,lty=2,lwd=lwd)

		smooth.T.nlin <- loess.smooth(1:(nrow(T.uniq.nlin)),T.uniq.nlin[,1],degree=2,family=c("gaussian"))
		lines(smooth.T.nlin,lty=4,lwd=lwd)
	}
	smooth.T.nls <- loess.smooth(1:length(T.nls),T.nls,degree=2,family=c("gaussian"))
	lines(smooth.T.nls,lty=3,lwd=lwd)


}



real.plot.mean.new <- function(data,time,mu.nls,mu.nlin.orig,mu.nlin.model1,lwd=3,plot.nls="FALSE",plot.fit="TRUE"){
	par(mar=c(5, 4, 4, 2)+1)
	mean.real <- apply(data,2,mean,na.rm="TRUE")

	plot(time,mean.real,col="black",lwd=2,type="l",ylab="Logarithm Mortality",xlab="Time",main="",ylim=c(min(mu.nlin.orig,mu.nlin.model1,mean.real)-1,max(mu.nlin.orig,mu.nlin.model1,mean.real)+1),
		cex.main=2.0,cex.lab=2.0)

	if(plot.fit=="TRUE"){
		lines(time,mu.nlin.model1,lty=2,lwd=lwd)
		lines(time,mu.nlin.orig,lty=4,lwd=lwd)
		if(plot.nls=="TRUE"){
			lines(time,mu.nls,lty=3,lwd=lwd)
		}
	}
}

real.plot.logiv.new <- function(data,time,t1,Z.mat,Zphi.mat,D.nls,D.nlin.orig,D.nlin.model1,plot.ols="FALSE",lwd=3,plot.nls="FALSE",plot.fit="TRUE"){
	par(mar=c(5, 4, 4, 2)+1)
	reg.iv(cov(data,use="pairwise.complete.obs"),time,t1,Z.mat,Zphi.mat,"",plot.ols)
	
	if(plot.fit=="TRUE"){
		smooth.D.nlin.model1 <- loess.smooth(1:nrow(D.nlin.model1),D.nlin.model1,degree=2,family=c("gaussian"))
		lines(smooth.D.nlin.model1,lty=2,lwd=lwd)

		smooth.D.nlin.orig <- loess.smooth(1:nrow(D.nlin.orig),D.nlin.orig,degree=2,family=c("gaussian"))
		lines(smooth.D.nlin.orig,lty=4,lwd=lwd)

		if(plot.nls=="TRUE"){
			smooth.D.nls <- loess.smooth(1:length(D.nls),D.nls,degree=2,family=c("gaussian"))
			lines(smooth.D.nls,lty=3,lwd=lwd)
		}
	}
}


real.plot.garp.new <- function(data,time,t1,Z.mat,Zphi.mat,T.nls,T.uniq.nlin.orig,T.uniq.nlin.model1,plot.ols="FALSE",lwd=3, plot.nls="FALSE",plot.fit="TRUE"){
	par(mar=c(5, 4, 4, 2)+1)
	reg.garp(cov(data,use="pairwise.complete.obs"),time,t1,Z.mat,Zphi.mat,"",plot.ols)
	
	if(plot.fit=="TRUE"){
		y.nlin.model1 <- c(T.uniq.nlin.model1[1,1],rep(T.uniq.nlin.model1[2,1],length(time)-2))
		x <- time[-length(time)]
		lines(x,y.nlin.model1,lty=2,lwd=lwd)

		smooth.T.nlin.orig <- loess.smooth(1:(nrow(T.uniq.nlin.orig)),T.uniq.nlin.orig[,1],degree=2,family=c("gaussian"))
		lines(smooth.T.nlin.orig,lty=4,lwd=lwd)

		if(plot.nls=="TRUE"){
			smooth.T.nls <- loess.smooth(1:length(T.nls),T.nls,degree=2,family=c("gaussian"))
			lines(smooth.T.nls,lty=3,lwd=lwd)
		}
	}
}




real.plots.all <- function(out.nls,data,n,p1,q1,d1,p2,q2=q1,d2=d1,Output.Lin,Output.Nonlin,
			printfiles="FALSE",filename="simu1",forEDITOR="model_orig"){
	time <- seq(1,n)

	###########################
	# Results for linear case #
	###########################
	
	Z.mat.lin <- cbind(rep(1,n),poly(time,deg=d1-1)[1:n,])
	
	if(forEDITOR=="model1"){
		t1 <- get.t1(n)
	} else if(forEDITOR=="model2"){
		t1 <- NULL
		for(i in (n-1):1){
			t1 <- c(t1,seq(1,i))
		}
	} else {
		t1 <- get.t1(n)
	}

	
	if(forEDITOR=="model1"){
		# Zphi.mat is a column only
		Zphi.uniq <- as.matrix(c(1,rep(0,n-2)),ncol=1)
		Zphi.mat <- as.matrix(c(rep(1,n-1),rep(0,sum((n-2):1))),ncol=1)
	} else if(forEDITOR=="model2"){
		# Zphi.mat has 4 columns (i.e, \gamma_0,\gamma_1,\gamma_2,\gamma_3)
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(q1-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	} else {
		##Mehdi's Code for Zphi.mat: uncomment if this is to be used
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(q1-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	}
	


	Zphi.mat.lin <- Zphi.mat
	X.mat.lin <- cbind(rep(1,n),poly(time,degree=p1-1)[1:n,])


	# Parameter values from linear
	beta.lin <-Output.Lin[,1:p1]
	gamma.lin <-Output.Lin[,(p1+1):(p1+q1)]
	lambda.lin <-Output.Lin[,(p1+q1+1):(p1+d1+q1)]

	# Results for Linear
	mu.lin <- s.func(beta.lin,X.mat.lin,linear=TRUE) 	# TRUE mean
	D.lin <- Z.mat.lin%*%lambda.lin 		      # TRUE log(sigma^2)
	T.lin <- Zphi.mat.lin%*%gamma.lin  			# TRUE phi_{tj}
	T.uniq.lin<-unique(T.lin)		

	

	###############################
	# Results for non-linear case #
	###############################
	
	Z.mat.nlin <- cbind(rep(1,n),poly(time,deg=d2-1)[1:n,])

	if(forEDITOR=="model1"){
		# Zphi.mat is a column only
		Zphi.mat <- as.matrix(c(rep(1,n-1),rep(0,sum((n-2):1))),ncol=1)
	} else if(forEDITOR=="model2"){
		# Zphi.mat has 4 columns (i.e, \gamma_0,\gamma_1,\gamma_2,\gamma_3)
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(q2-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	} else {
		##Mehdi's Code for Zphi.mat: uncomment if this is to be used
		Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(q2-1)))
		Zphi.mat<-get.Zphi.mat(Zphi.uniq,n,forEDITOR=forEDITOR) 
	}
	


	Zphi.mat.nlin <- Zphi.mat



	X.mat.nlin <- time

	# Parameter values from non-linear
	beta.nlin <-Output.Nonlin[,1:p2]
	gamma.nlin <-Output.Nonlin[,(p2+1):(p2+q2)]
	lambda.nlin <-Output.Nonlin[,(p2+q2+1):(p2+d2+q2)]


	# Results for Linear
	mu.nlin <- s.func(beta.nlin,X.mat.nlin,linear=FALSE) 	# TRUE mean
	D.nlin <- Z.mat.nlin%*%lambda.nlin 		      	# TRUE log(sigma^2)
	T.nlin <- Zphi.mat.nlin%*%gamma.nlin  			# TRUE phi_{tj}
	T.uniq.nlin<-unique(T.nlin)		


	########################
	# Results for NLS case #
	########################
	# Parameter values from NLS
	beta.nls <- out.nls["beta",]					# beta value
	cov.nls <- diag(out.nls["sigma",1]^2,nrow=n)		# to get lambda and gamma
	TD.nls <- TD.matrix(cov.nls)
	
	# Results for NLS
	mu.nls <- s.func(beta.nls,X.mat.nlin,linear=FALSE)
	T.nls  <- TD.nls$T.mat[-1,1]	
	D.nls  <- log(diag(TD.nls$D))

	
	#####################################
	# One graphic of all plots together #
	# NOT printed to a separate file    #
	#####################################
	if(printfiles=="FALSE"){
		par(mfrow=c(2,2))

		# profile plot for 
		prof.plot(data,"")
	
		# plot mean
		real.plot.mean(data,time,mu.nls,mu.lin,mu.nlin)		

		# plot for lambdas or Log IVs
		real.plot.logiv(data,time,t1,Z.mat.lin,Zphi.mat.lin,D.nls,D.lin,D.nlin)		


				

		# plot for gammas or GARPS
		real.plot.garp(data,time,t1,Z.mat,Z.mat.lin,Zphi.mat.lin,T.nls,T.uniq.lin,T.uniq.nlin,forEDITOR=forEDITOR)		

	}else{
		postscript(paste("Real_Profile_",filename,".eps",sep=""))
		prof.plot(data,"")
		dev.off()	

		postscript(paste("Real_MeanPlot_",filename,".eps",sep=""))										
		real.plot.mean(data,time,mu.nls,mu.lin,mu.nlin)	
		dev.off()

		postscript(paste("Real_LogIVPlot_",filename,".eps",sep=""))
		real.plot.logiv(data,time,t1,Z.mat.lin,Zphi.mat.lin,D.nls,D.lin,D.nlin)		
		dev.off()

		postscript(paste("Real_GARPPlot_",filename,".eps",sep=""))
		real.plot.garp(data,time,t1,Z.mat,Z.mat.lin,Zphi.mat.lin,T.nls,T.uniq.lin,T.uniq.nlin,forEDITOR=forEDITOR)		
		dev.off()
	}
}







# function to plot logistic mean with \sigma^2 I covariance model, cubic covariance model, and constant covariance model

real.plots.all.orig.model1 <- function(out.nls,data,n,p1,q1,d1,p2,q2=q1,d2=d1,Output.Nonlin.orig,Output.Nonlin.model1,
			printfiles="FALSE",filename="simu1",plot.nls="FALSE",plot.fit="TRUE"){

	time <- seq(1,n)
	X.mat.nlin <- time
	Z.mat.nlin <- cbind(rep(1,n),poly(time,deg=d2-1)[1:n,])
	t1 <- get.t1(n)


	#####################################
	# Results for non-linear case: orig #
	#####################################
	
	Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(q1-1)))
	Zphi.mat.nlin.orig<-get.Zphi.mat(Zphi.uniq,n,forEDITOR="model_orig") 

	# Parameter values from non-linear orig
	beta.nlin.orig <-Output.Nonlin.orig[,1:p1]
	gamma.nlin.orig <-Output.Nonlin.orig[,(p1+1):(p1+q1)]
	lambda.nlin.orig <-Output.Nonlin.orig[,(p1+q1+1):(p1+d1+q1)]

	# Results for Non-Linear orig
	mu.nlin.orig <- s.func(beta.nlin.orig,X.mat.nlin,linear=FALSE) 	# TRUE mean
	D.nlin.orig <- Z.mat.nlin%*%lambda.nlin.orig		      	# TRUE log(sigma^2)
	T.nlin.orig <- Zphi.mat.nlin.orig%*%gamma.nlin.orig  			# TRUE phi_{tj}
	T.uniq.nlin.orig<-unique(T.nlin.orig)		



	#######################################
	# Results for non-linear case: model1 #
	#######################################
	
	Zphi.mat.nlin.model1 <- as.matrix(c(rep(1,n-1),rep(0,sum((n-2):1))),ncol=1)


	# Parameter values from non-linear model1
	beta.nlin.model1 <-Output.Nonlin.model1[,1:p2]
	gamma.nlin.model1 <-Output.Nonlin.model1[,(p2+1):(p2+q2)]
	lambda.nlin.model1 <-Output.Nonlin.model1[,(p2+q2+1):(p2+d2+q2)]

	# Results for Non-Linear model1
	mu.nlin.model1 <- s.func(beta.nlin.model1,X.mat.nlin,linear=FALSE) 	# TRUE mean
	D.nlin.model1 <- Z.mat.nlin%*%lambda.nlin.model1	      	# TRUE log(sigma^2)
	T.nlin.model1 <- Zphi.mat.nlin.model1%*%gamma.nlin.model1  			# TRUE phi_{tj}
	T.uniq.nlin.model1<-unique(T.nlin.model1)		


	########################
	# Results for NLS case #
	########################
	# Parameter values from NLS
	beta.nls <- out.nls["beta",]					# beta value
	cov.nls <- diag(out.nls["sigma",1]^2,nrow=n)		# to get lambda and gamma
	TD.nls <- TD.matrix(cov.nls)
	
	# Results for NLS
	mu.nls <- s.func(beta.nls,X.mat.nlin,linear=FALSE)
	T.nls  <- TD.nls$T.mat[-1,1]	
	D.nls  <- log(diag(TD.nls$D))

	
	#####################################
	# One graphic of all plots together #
	# NOT printed to a separate file    #
	#####################################
	if(printfiles=="FALSE"){
		par(mfrow=c(2,2))

		# profile plot for 
		prof.plot(data,"")
	
		# plot mean
		real.plot.mean.new(data,time,mu.nls,mu.nlin.orig,mu.nlin.model1,plot.nls=plot.nls,plot.fit=plot.fit)		

		# plot for lambdas or Log IVs
		real.plot.logiv.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.orig,D.nls,D.nlin.orig,D.nlin.model1,plot.nls=plot.nls,plot.fit=plot.fit)		

		# plot for gammas or GARPS
		real.plot.garp.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.orig,T.nls,T.uniq.nlin.orig,T.uniq.nlin.model1,plot.nls=plot.nls,plot.fit=plot.fit)		

	}else{
		postscript(paste("Real_Profile_",filename,".eps",sep=""))
		prof.plot(data,"")
		dev.off()	

		postscript(paste("Real_MeanPlot_",filename,".eps",sep=""))										
		real.plot.mean.new(data,time,mu.nls,mu.nlin.orig,mu.nlin.model1,plot.nls=plot.nls,plot.fit=plot.fit)		
		dev.off()

		postscript(paste("Real_LogIVPlot_",filename,".eps",sep=""))
		real.plot.logiv.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.orig,D.nls,D.nlin.orig,D.nlin.model1,plot.nls=plot.nls,plot.fit=plot.fit)		
		dev.off()

		postscript(paste("Real_GARPPlot_",filename,".eps",sep=""))
		real.plot.garp.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.orig,T.nls,T.uniq.nlin.orig,T.uniq.nlin.model1,plot.nls=plot.nls,plot.fit=plot.fit)		
		dev.off()
	}
}





# function to plot logistic mean with \sigma^2 I covariance model, cubic covariance model, and constant covariance model

real.plots.all.orig.model2 <- function(out.nls,data,n,p1,q1,d1,p2,q2=q1,d2=d1,Output.Nonlin.orig,Output.Nonlin.model2,
			printfiles="FALSE",filename="simu1",plot.nls="FALSE",plot.fit="TRUE"){

	time <- seq(1,n)
	X.mat.nlin <- time
	Z.mat.nlin <- cbind(rep(1,n),poly(time,deg=d2-1)[1:n,])
	t1 <- NULL
	for(i in (n-1):1){
		t1 <- c(t1,seq(1,i))
	}



	#####################################
	# Results for non-linear case: orig #
	#####################################
	
	Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(q1-1)))
	Zphi.mat.nlin.orig<-get.Zphi.mat(Zphi.uniq,n,forEDITOR="model_orig") 

	# Parameter values from non-linear orig
	beta.nlin.orig <-Output.Nonlin.orig[,1:p1]
	gamma.nlin.orig <-Output.Nonlin.orig[,(p1+1):(p1+q1)]
	lambda.nlin.orig <-Output.Nonlin.orig[,(p1+q1+1):(p1+d1+q1)]

	# Results for Non-Linear orig
	mu.nlin.orig <- s.func(beta.nlin.orig,X.mat.nlin,linear=FALSE) 	# TRUE mean
	D.nlin.orig <- Z.mat.nlin%*%lambda.nlin.orig		      	# TRUE log(sigma^2)
	T.nlin.orig <- Zphi.mat.nlin.orig%*%gamma.nlin.orig  			# TRUE phi_{tj}
	T.uniq.nlin.orig<-unique(T.nlin.orig)		



	#######################################
	# Results for non-linear case: model2 #
	#######################################
	Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(q2-1)))

	Zphi.mat.nlin.model2 <- get.Zphi.mat(Zphi.uniq,n,forEDITOR="model2") 

	# Parameter values from non-linear model2
	beta.nlin.model2 <-Output.Nonlin.model2[,1:p2]
	gamma.nlin.model2 <-Output.Nonlin.model2[,(p2+1):(p2+q2)]
	lambda.nlin.model2 <-Output.Nonlin.model2[,(p2+q2+1):(p2+d2+q2)]

	# Results for Non-Linear model2
	mu.nlin.model2 <- s.func(beta.nlin.model2,X.mat.nlin,linear=FALSE) 	# TRUE mean
	D.nlin.model2 <- Z.mat.nlin%*%lambda.nlin.model2	      	# TRUE log(sigma^2)
	T.nlin.model2 <- Zphi.mat.nlin.model2%*%gamma.nlin.model2  			# TRUE phi_{tj}
	T.uniq.nlin.model2<-unique(T.nlin.model2)		


	########################
	# Results for NLS case #
	########################
	# Parameter values from NLS
	beta.nls <- out.nls["beta",]					# beta value
	cov.nls <- diag(out.nls["sigma",1]^2,nrow=n)		# to get lambda and gamma
	TD.nls <- TD.matrix(cov.nls)
	
	# Results for NLS
	mu.nls <- s.func(beta.nls,X.mat.nlin,linear=FALSE)
	T.nls  <- TD.nls$T.mat[-1,1]	
	D.nls  <- log(diag(TD.nls$D))

	
	#####################################
	# One graphic of all plots together #
	# NOT printed to a separate file    #
	#####################################
	if(printfiles=="FALSE"){
		par(mfrow=c(2,2))

		# profile plot for 
		prof.plot(data,"")
	
		# plot mean
		real.plot.mean.new(data,time,mu.nls,mu.nlin.orig,mu.nlin.model2,plot.nls=plot.nls,plot.fit=plot.fit)		

		# plot for lambdas or Log IVs
		real.plot.logiv.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.model2,D.nls,D.nlin.orig,D.nlin.model2,plot.nls=plot.nls,plot.fit=plot.fit)		

		# plot for gammas or GARPS
		real.plot.garp.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.model2,T.nls,T.uniq.nlin.orig,T.uniq.nlin.model2,plot.nls=plot.nls,plot.fit=plot.fit)		

	}else{
		postscript(paste("Real_Profile_",filename,".eps",sep=""))
		prof.plot(data,"")
		dev.off()	

		postscript(paste("Real_MeanPlot_",filename,".eps",sep=""))										
		real.plot.mean.new(data,time,mu.nls,mu.nlin.orig,mu.nlin.model2,plot.nls=plot.nls,plot.fit=plot.fit)		
		dev.off()

		postscript(paste("Real_LogIVPlot_",filename,".eps",sep=""))
		real.plot.logiv.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.model2,D.nls,D.nlin.orig,D.nlin.model2,plot.nls=plot.nls,plot.fit=plot.fit)		
		dev.off()

		postscript(paste("Real_GARPPlot_",filename,".eps",sep=""))
		real.plot.garp.new(data,time,t1,Z.mat.nlin,Zphi.mat.nlin.model2,T.nls,T.uniq.nlin.orig,T.uniq.nlin.model2,plot.nls=plot.nls,plot.fit=plot.fit)		
		dev.off()
	}
}






#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#




#########
# Plots #
#########

prof.plot<- function(data,title.name){

	t <- seq(1,ncol(data))
	
	plot(t,data[1,],col="light gray",type="l",ylab="Logarithm Mortality",xlab="Time",ylim=c(min(data,na.rm=TRUE),max(data,na.rm=TRUE)),
		main=title.name,cex.main=2.0,cex.lab=2.0)

	for( i in 1:nrow(data) ){
			lines(t,data[i,],col="gray")
		}
	lines(t,apply(data,2,mean,na.rm="TRUE"),col="black",lwd=3)
}


TD.fitted <- function(cov.mat,Z.mat,Zphi.mat){
	TD.mat<- TD.matrix(cov.mat)
	T <- TD.mat$T.mat
	D <- TD.mat$D

	n <- nrow(T)
	y <- diag(T[2:n,1:(n-1)])
	for(i in 2:(n-2)){
		x <- T[(i+1):n,1:(n-i)]
		y <- c(y,diag(x))
	#print("i=")
	#print(i)
	#print("diagx=")
	#print(length(diag(x)))
	#print("y=")
	#print(length(y))
	}
	y <- c(y,T[n,1])
	y <- -y

# THis part is WRONG!!	
#	y<-diag(T[2:11,1:10])
#	for(i in 2:10){
#		x<-T[(i+1):11,1:(11-i)]
#		y<-c(y,diag(x))
#	}
#	y<-c(y,T[11,1])
	
	log.in <- as.vector(log(diag(D)))

	D.fit <- lm(log.in~Z.mat-1)	
	D.fitted <- D.fit$fitted.values
	D.coeff <- D.fit$coefficients
	D.cov <- anova(D.fit)$"Mean Sq"[2] * solve(t(Z.mat) %*% Z.mat)

	T.fit <- lm(y~ Zphi.mat-1)		
	T.fitted <- T.fit$fitted.values
	T.coeff <- T.fit$coefficients
	T.cov <- anova(T.fit)$"Mean Sq"[2] * solve( t(Zphi.mat) %*% Zphi.mat)

	list(D.fitted=D.fitted,T.fitted=T.fitted,D.coeff=D.coeff,T.coeff=T.coeff,D.cov=D.cov,T.cov=T.cov,y=y,D=D)
}


reg.plot <- function(cov.mat,time,t1,Z.mat,Zphi.mat,title1,title2){
	D.fit <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D.fitted	
	T.fit <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$T.fitted
	y <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$y
	D <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D
	# FIX!!!
	
	#par(mfrow=c(2,1))
	plot(t1,y,type="p",xlab="LAG",main=title1,ylab="GARP",ylim=c(min(y,T.fit)-1,max(y,D.fit)+1))
	par(new=TRUE)
	plot(t1,T.fit,ylab="",xlab="",type="l",lwd=1,ylim=c(min(y,T.fit)-1,max(y,D.fit)+1))
	
	plot(seq(1,11),log(diag(D)),xlab="LAG",main=title2,ylab="Log IV",ylim=c(min(log(diag(D)),D.fit)-1,max(log(diag(D)),D.fit)+1))
	lines(time,D.fit,lty=1,lwd=2)	
}



reg.garp <- function(cov.mat,time,t1,Z.mat,Zphi.mat,title1,plot.ols="TRUE"){
	D.fit <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D.fitted	
	T.fit <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$T.fitted
	y <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$y ##sample 
	D <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D ##sample

	#par(mfrow=c(2,1))
	plot(t1,y,type="p",xlab="Lag",main=title1,ylab="Autoreg. coef.",ylim=c(min(y,T.fit)-1,max(y,T.fit)+1),
		cex.main=2.0,cex.lab=2.0)
	if(plot.ols=="TRUE"){
		lines(unique(t1),unique(round(T.fit,6)),lty=1,lwd=3)
	}
}

reg.iv <- function(cov.mat,time,t1,Z.mat,Zphi.mat,title2,plot.ols="TRUE"){
	D.fit <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D.fitted	
	T.fit <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$T.fitted
	y <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$y
	D <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D

	plot(time,log(diag(D)),xlab="Time",main=title2,ylab="Log innov. var.",ylim=c(min(log(diag(D)),D.fit)-1,max(log(diag(D)),D.fit)+1),
		cex.main=2.0,cex.lab=2.0)
	if(plot.ols=="TRUE"){
		lines(time,D.fit,lty=1,lwd=3)	
	}
}


make.tri<-function(mat.lo,mat.up,diag.mat){			# Puts mat.lo as lower triangular matrix, mat.up as upper triangular matrix
	mat.out <- mat.lo
	upper.part <- mat.up[lower.tri(mat.up)]
	n <- ncol(mat.lo)
	k <- seq(n-1,1,by=-1)
	r <- 0
	
	for (i in 1:(n-1)){
		l <- k[i]
		y <- rep(0,l)
		for(j in 1:l){
			y[j]<- upper.part[r+j]
		}
		mat.out[i,(i+1):n] <-y
		r<- r+l
	}
	diag(mat.out) <- diag.mat
	return(mat.out)
}	


# get covariances for fitted means

fitmean.cov <- function(beta,cov.mat,t){
        logis.func <- exp(-(t-beta[2])/beta[3])
        f.beta <- rep(0,3)
        f.beta[1] <- 1/ (1 + logis.func)
        f.beta[2] <- ( -beta[1]*logis.func/beta[3] ) / ( 1+ logis.func)^2
        f.beta[3] <- f.beta[2] * (t-beta[2]) / beta[3]^2

        cov.out <- t(f.beta) %*% cov.mat %*% f.beta
        return(cov.out)
}

fitmean.se <- function(beta,cov.mat,t){
        cov.val <- rep(0,length(t))
        for(i in 1:length(t)){
                cov.val[i] <- fitmean.cov(beta,cov.mat,t[i])
        }
        return(sqrt(cov.val))
}

getci <- function(mean.mat,std.err,alpha=0.025){
        out <- matrix(0,nrow=length(mean.mat),ncol=2)
        out[,1] <- mean.mat + qnorm(alpha)*std.err
        out[,2] <- mean.mat - qnorm(alpha)*std.err
        return(out)
}

# get covariances for Gamma and Lambda 

fitmean2.cov <- function(estimate,info,design.mat){
        gamma.func <- design.mat %*% estimate
        f.gamma <- design.mat
        cov.out <- t(f.gamma) %*% info %*% f.gamma
        return(cov.out)
}

fitmean2.se <- function(estimate,info,design.mat){
        cov.val <- rep(0,nrow(design.mat))
        for(i in 1:(nrow(design.mat))){
                cov.val[i] <- fitmean2.cov(estimate,info,design.mat[i,])
        }
        return(sqrt(cov.val))
}
  

# function to get fitted curve for mean, and 95% CIs

mean.fit.ci <- function(beta,time,cov.mat,alpha=0.025){
	mean.fit <- s.func(beta,time)
	mean.se  <- fitmean.se(beta,cov.mat,time)
	mean.ci  <- getci(mean.fit,mean.se,alpha)
	list(mean.fit=mean.fit,mean.se=mean.se,mean.ci=mean.ci)
}

# function to get fitted curve involving gamma, and 95% CIs

gamma.fit.ci <- function(data,X.mat,Zphi.mat,Zphi3.mat,Z.mat,lambda,gamma,beta){
	gamma.I <- gamma.info(data,X.mat,Zphi.mat,Zphi3.mat,Z.mat,lambda,gamma,beta)  # Regressogram from estimated gamma
	lag<-seq(1:(n-1))
	#Zphi.gamma.mat<-cbind(rep(1,length(lag)),poly(lag,deg=3)[1:length(lag),])   	# design matrix of lags
	Zphi.gamma.mat <- unique(Zphi.mat)
	gamma.mean<-  Zphi.gamma.mat%*%(-gamma) 							# fitted curve from fitted gamma
	gamma.se<-fitmean2.se(-gamma,solve(gamma.I),Zphi.gamma.mat)				# estimated standard errors of fitted curve
	gamma.ci   <- getci(gamma.mean,gamma.se)							# 95% CI lines for fitted gamma curve
	list(gamma.mean=gamma.mean,gamma.se=gamma.se,gamma.ci=gamma.ci)
}

# function to get fitted curve involving lambda, and 95% CIs

lambda.fit.ci <- function(data,Z.mat,lambda){
	lambda.I <- lambda.info(data,Z.mat)								# Regressogram from estimated lambda
	lambda.mean <- Z.mat%*%lambda								      # fitted curve from fitted lambda
	lambda.se <- fitmean2.se(lambda,solve(lambda.I),Z.mat)				# estimated standard errors of fitted curve
	lambda.ci   <- getci(lambda.mean,lambda.se)						# 95% CI lines for fitted lambda curve
	list(lambda.mean=lambda.mean,lambda.se=lambda.se,lambda.ci=lambda.ci)
}

#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#


#######
# OLS #
#######

sample.mean.cov <- function(data){
	samp.mean <- mean(data)
	samp.cov <- cov(data)
	list(samp.mean=samp.mean,samp.cov=samp.cov)	
}



para.ols <- function(cov.mat,data,X.mat,Z.mat,Zphi.mat){
	lambda.ols <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D.coeff     	# OLS
	gamma.ols <- -TD.fitted(cov.mat,Z.mat,Zphi.mat)$T.coeff
	beta.ols <- init.value(data,X.mat)$beta

	lambda.se <- sqrt(diag(TD.fitted(cov.mat,Z.mat,Zphi.mat)$D.cov))
	gamma.se <- sqrt(diag(TD.fitted(cov.mat,Z.mat,Zphi.mat)$T.cov))
	beta.se <-sqrt(diag(init.value(data,X.mat)$beta.cov))
	
	list(beta=round(beta.ols,3),lambda=round(lambda.ols,3),gamma=round(gamma.ols,3),beta.se=round(beta.se,3),
		lambda.se=round(lambda.se,3),gamma.se=round(gamma.se,3))
}

para.ols.cov <- function(cov.mat,data,X.mat,Z.mat,Zphi.mat){
	lambda.ols <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D.coeff     	# OLS
	gamma.ols <- -TD.fitted(cov.mat,Z.mat,Zphi.mat)$T.coeff
	beta.ols <- init.value(data,X.mat)$beta

	lambda.cov <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$D.cov
	gamma.cov <- TD.fitted(cov.mat,Z.mat,Zphi.mat)$T.cov
	beta.cov <-init.value(data,X.mat)$beta.cov
	
	list(beta=beta.ols,lambda=lambda.ols,gamma=gamma.ols,beta.cov=beta.cov,
		lambda.cov=lambda.cov,gamma.cov=gamma.cov)
}


#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+

######################################
# Functions for NEW EM-MLE algorithm #
######################################

# THIS IS WRONG BECAUSE SIGMA* IS NOT ORGANIZED PROPERLY!!
# form \hat V_i
#Vi.form <- function(data.miss, mu,sigma){
#	m <- nrow(data.miss)
#	n <- ncol(data.miss)

#	Vi <- array(0,dim=c(m,n,n))
#
#	e  <- data.miss - matrix(rep(mu,m),nrow=m,ncol=n,byrow=T)		# Form e (all subjects, even missing values)
#
#	for (i in 1:m){
#		miss.values<- is.na(data.miss[i,])	# Determine if each row has missing values
#
#		if( sum(miss.values) > 0 ){		# If there are missing values, impute them
#			index.miss <- which(miss.values)	# Location of Missing values
#			ei.obs   <- e[i,-index.miss]
#			n.obs    <- length(ei.obs)			
#
#			expect.eistar <- c(ei.obs, sigma[index.miss,-index.miss] %*% solve( sigma[-index.miss,-index.miss] ) %*% ei.obs )
#			var.eistar    <- matrix(0,ncol=n,nrow=n)
#			var.eistar[(n.obs+1):n, (n.obs+1):n] <-  sigma[index.miss,index.miss] - sigma[index.miss,-index.miss] %*% solve(sigma[-index.miss,-index.miss]) %*% sigma[-index.miss,index.miss]
#		
#			Vi[i,,] <- expect.eistar %*% t(expect.eistar) + var.eistar
#		} else{
#			Vi[i,,] <- e[i,] %*% t( e[i,] )
#		}
#	}
#	return(Vi)
#}



beta.update.em <- function(start="TRUE",sigma.init,beta,data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR="model_orig"){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)

	mu <- s.func(beta,X.mat,linear)
	if(start=="TRUE") {
		sigma=sigma.init
	}else {
	      TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)		# Form updated Sigma
      	T.mat <- TD$T.mat
      	D <- TD$D
      	sigma <- solve( t(T.mat) %*% solve(D) %*% T.mat ) 
		#print(sigma)
	}
	e  <- data - matrix(rep(mu,m),nrow=m,ncol=n,byrow=TRUE)		# Form e (all subjects, even missing values)
	term1 <- 0
	term2 <- 0	

	for (i in 1:m){
		#print(i)

		miss.values<- is.na(data[i,])	# Determine if each row has missing values
		
		if( sum(miss.values) > 0 ){		# If there are missing values, impute them
			index.miss <- which(miss.values)	# Location of Missing values
			sigma.obs <- sigma[-index.miss,-index.miss]
			X.mat.obs <- X.mat[-index.miss,]
		
			term1 <- term1 + t(X.mat.obs) %*% solve(sigma.obs) %*% X.mat.obs 
			term2 <- term2 + t(X.mat.obs) %*% solve(sigma.obs) %*% data[i,-index.miss] 	
		} else{
			term1 <- term1 + t(X.mat) %*% solve(sigma) %*% X.mat
			term2 <- term2 + t(X.mat) %*% solve(sigma) %*% data[i,]
		}
	}
	out <- solve(term1) %*% term2
	return(out)
}

# This function  for linear and nonlinear case

form.beta.update.em <- function(data,start,sigma.init,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR="model_orig"){
	m <- nrow(data)                                # setting dimensions
      n <- ncol(data)
	
	if(start=="TRUE"){
		sigma=sigma.init
	}else{
	      TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)		# Form updated Sigma
      	T.mat <- TD$T.mat
      	D <- TD$D
      	sigma <- solve( t(T.mat) %*% solve(D) %*% T.mat )
	}

	function(beta){
		mu <- s.func(beta,X.mat,linear)
		term1 <- 0
		for (i in 1:m){
			#print(i)
			miss.values<- is.na(data[i,])	# Determine if each row has missing values

			if( sum(miss.values) > 0 ){		# If there are missing values, impute them
				index.miss <- which(miss.values)	# Location of Missing values
				sigma.obs <- sigma[-index.miss,-index.miss]
				if(linear=="TRUE") {
					X.mat.obs <- X.mat[-index.miss,]
				} else {
					X.mat.obs <- X.mat[-index.miss]	
				}
				term1 <- term1 + t(data[i,-index.miss]-s.func(beta,X.mat.obs,linear)) %*% solve(sigma.obs) %*% (data[i,-index.miss] -s.func(beta,X.mat.obs,linear))
			} else{
			term1 <- term1 + t(data[i,]-mu) %*% solve(sigma) %*% (data[i,]-mu)
			}
		}
		return(term1)
	}
	
}



# Form \hat Vi
Vi.form <- function(data.miss, mu,sigma){
	m <- nrow(data.miss)
	n <- ncol(data.miss)

	Vi <- array(0,dim=c(m,n,n))

	e  <- data.miss - matrix(rep(mu,m),nrow=m,ncol=n,byrow=TRUE)		# Form e (all subjects, even missing values)
	e.replace <- e			# Vector we will be replacing	

	for (i in 1:m){
		miss.values<- is.na(data.miss[i,])		# Determine if each row has missing values

		if( sum(miss.values) > 0 ){			# If there are missing values, impute them
			index.miss <- which(miss.values)	# Location of Missing values

			ei.obs   <- e[i,-index.miss]

			e.replace[i,index.miss] <- sigma[index.miss,-index.miss] %*% solve( sigma[-index.miss,-index.miss] ) %*% ei.obs
			expect.eistar2 <- e.replace[i,] %*% t (e.replace[i,])

			var.eistar <- matrix(0,ncol=n,nrow=n)
			var.eistar[index.miss,index.miss] <- sigma[index.miss,index.miss] - sigma[index.miss,-index.miss] %*% solve(sigma[-index.miss,-index.miss]) %*% sigma[-index.miss,index.miss]

			Vi[i,,] <- expect.eistar2 + var.eistar 			
		} else{
			Vi[i,,] <- e[i,] %*% t( e[i,] )
	}
	}
	return(Vi)
}


# Function used in constructing gamma.score, this is inner summand w.r.t. time (t)

S.gamma <- function(i,data,Vi,Z.mat,Zphi.uniq,sigma.vec,gamma){
	m <- nrow(data)
	n <- ncol(data)

	term1 <- 0
	term2 <- 0

	for(j in 2:n){
		if(j==2){
			term1 <- term1 + sigma.vec[j] * Vi[i,1:(j-1),1:(j-1)] *  Zphi.uniq[(j-1):1,]  %*% t( Zphi.uniq[(j-1):1,] )
			term2 <- term2 + sigma.vec[j] * Vi[i,1:(j-1),j] *  Zphi.uniq[(j-1):1,] 
		}else{
			term1 <- term1 + sigma.vec[j] * t( Zphi.uniq[(j-1):1,] ) %*% Vi[i,1:(j-1),1:(j-1)] %*% Zphi.uniq[(j-1):1,] 
			term2 <- term2 + sigma.vec[j] * t( Zphi.uniq[(j-1):1,] ) %*% Vi[i,1:(j-1),j]
		}
	}

	out <- term2 - term1 %*% gamma
	return(out)
}

# Update gamma

gamma.update <- function(start="TRUE",sigma.init,data,Vi,Z.mat,Zphi.uniq,lambda){
	m <- nrow(data)
	n <- ncol(data)
	if(start=="TRUE") {
		sigma.vec<-1/diag(sigma.init)
	}else {	
		sigma.vec <- 1 / exp(Z.mat %*% lambda) 
	}
	term1 <- 0
	term2 <- 0

	for(i in 1:m){
		for(j in 2:n){
			if(j==2){
				term1 <- term1 + sigma.vec[j] *  Vi[i,1:(j-1),1:(j-1)] *  Zphi.uniq[(j-1):1,]  %*% t( Zphi.uniq[(j-1):1,] )
				term2 <- term2 + sigma.vec[j]  * Vi[i,1:(j-1),j] *  Zphi.uniq[(j-1):1,] 
			}else{
				term1 <- term1 + sigma.vec[j] * t( Zphi.uniq[(j-1):1,] ) %*% Vi[i,1:(j-1),1:(j-1)] %*% Zphi.uniq[(j-1):1,] 
				term2 <- term2 + sigma.vec[j] * t( Zphi.uniq[(j-1):1,] ) %*% Vi[i,1:(j-1),j]
			}
		}
	}	
	gamma <- solve ( term1 ) %*% term2
	return(gamma)
}

# Form \hat RS

RS.hat <- function(i,t,Vi,Zphi.uniq,gamma){
	if(t==1) {
		RS.hat<-Vi[i,t,t]
		}else if(t==2){
		RS.hat <- Vi[i,t,t] - 2 * Vi[i,1:(t-1),t] * t(gamma) %*%    Zphi.uniq[(t-1):1,]+ Vi[i,1:(t-1),1:(t-1)] * t(gamma) %*%   Zphi.uniq[(t-1):1,]  %*% t( Zphi.uniq[(t-1):1,])  %*% gamma
	}else{
		RS.hat <- Vi[i,t,t] - 2 * t(gamma) %*% t(Zphi.uniq[(t-1):1,])   %*% Vi[i,1:(t-1),t]  + t(gamma) %*%  t( Zphi.uniq[(t-1):1,] )  %*% Vi[i,1:(t-1),1:(t-1)] %*% Zphi.uniq[(t-1):1,]  %*% gamma
	}
	return(RS.hat)
}


# Function used in constructing lambda.score, this is inner summand w.r.t. time (t)

S.lambda <- function(i,data,Vi,Z.mat,Zphi.uniq,sigma.vec,gamma){
	m <- nrow(data)
	n <- ncol(data)

	term <- 0
	for(j in 1:n){
		term <- term + (1-RS.hat(i,j,Vi,Zphi.uniq,gamma) * sigma.vec[j] ) * Z.mat[j,]	
	}
	term <- -1/2 * term

	return(term)
}

# Form lambda.score 

make.lambda.score <- function(start="TRUE",sigma.init,data,Vi,Z.mat,Zphi.uniq,gamma){
	m <- nrow(data)
	n <- ncol(data)

	function(lambda){	
		if(start=="TRUE") {
			sigma.vec<-1/diag(sigma.init)
		}else {	
			sigma.vec <- 1 / exp(Z.mat %*% lambda) 
		}

		term <- 0 
		for (i in 1:m){
			term <- term + S.lambda(i,data,Vi,Z.mat,Zphi.uniq,sigma.vec,gamma)
		}
		return(term)
	}
} 


# Form lambda.hess 

make.lambda.hess <- function(start="TRUE",sigma.init,data,Vi,Z.mat,Zphi.uniq,gamma){
	m <- nrow(data)
	n <- ncol(data)

	function(lambda){	
		if(start=="TRUE") {
			sigma.vec<-1/diag(sigma.init)
		}else {	
			sigma.vec <- 1 / exp(Z.mat %*% lambda) 
		}

		term <- 0 
		for (i in 1:m){
			for(j in 1:n){
				term <- term + as.numeric(RS.hat(i,j,Vi,Zphi.uniq,gamma) * sigma.vec[j])  * Z.mat[j,] %*% t( Z.mat[j,] )	
			}
		}
		term <- -1/2 * term
		return(term)
	}
}


# Form loglikelihood w.r.t. lambda 

make.loglik.lambda <- function(start="TRUE",sigma.init,data,Vi,Z.mat,Zphi.mat,Zphi.uniq,gamma,forEDITOR="model_orig"){
	m <- nrow(data)                                # setting dimensions
      n <- ncol(data)
	InfLik<-0
	function(lambda){
		if(start=="TRUE") {
			sigma.vec<-diag(sigma.init)
		}else {	
			sigma.vec <- exp(Z.mat %*% lambda) 
		}

		TD.new<-TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)
		D.new<-TD.new$D
		T.new<-TD.new$T.mat
		Sigma.new<-solve(T.new)%*%D.new%*%solve(t(T.new)) ###updated sigma
		#sigma.vec<-diag(Sigma.new) ## WE NEED TO ASK MEHDI !!!
		if(kappa(Sigma.new)<1e-7 || kappa(Sigma.new)>1e7){
			term1<-Inf
			InfLik <- 1
		}else{
			term1 <- 0

			for(i in 1:m){
				term1<-term1+log(det(Sigma.new))+tr(solve(Sigma.new)%*%Vi[i,,])	
				}
			}
		list(term1=term1,InfLik=InfLik)
	}
}

# Step-halving 


lambda.update <-function(start,sigma.init,data,Vi,Z.mat,Zphi.mat,Zphi.uniq,gamma,lambda,Nlambda,forEDITOR="model_orig"){
	lambda.score <- make.lambda.score(start,sigma.init,data,Vi,Z.mat,Zphi.uniq,gamma)
	lambda.hess  <- make.lambda.hess(start,sigma.init,data,Vi,Z.mat,Zphi.uniq,gamma)
	lambda.loglik <- make.loglik.lambda(start,sigma.init,data,Vi,Z.mat,Zphi.mat,Zphi.uniq,gamma,forEDITOR=forEDITOR)

	Q0Inf<-0		# When -2Q(lambda0) is infinity
	Q1Inf<-0		# When -2Q(lambda1) is infinity
	Noupdate <- 0 		# When lambda is not updated
	iter.lambda <- 1 	# Iteration count for lambda

	lambda0 <- lambda
	Q0.lambda.out <- lambda.loglik(lambda0)
	Q.lambda0 <- Q0.lambda.out$term1
	Q0Inf <- Q0Inf + Q0.lambda.out$InfLik

	Delta.lambda <- - solve(lambda.hess(lambda0)) %*% lambda.score(lambda0)
	lambda1     <- lambda0 + Delta.lambda
	
	Q1.lambda.out    <- lambda.loglik(lambda1)
	Q.lambda1 <- Q1.lambda.out$term1
	Q1Inf<-Q1Inf+Q1.lambda.out$InfLik

		
#	while( Q.lambda1 >= Q.lambda0){ 
	while( Q.lambda1 >= Q.lambda0 & iter.lambda< Nlambda){	# added condition so that max number of iterations is Nlambda

		Delta.lambda <- 1/2 * Delta.lambda
		lambda1     <- lambda0 + Delta.lambda
		
		Q1.lambda.out    <- lambda.loglik(lambda1)
		Q.lambda1 <- Q1.lambda.out$term1
		Q1Inf<-Q1Inf+Q1.lambda.out$InfLik

		iter.lambda <- iter.lambda+1
		#print("Q.lambda")
		#print(round(c(Q.lambda1,Q.lambda0),9))
	}
	if(iter.lambda<Nlambda) {
		list(lambda=lambda1,Noupdate=Noupdate,Q0Inf=Q0Inf,Q1Inf=Q1Inf)   ###may or may not be updated!!!
	}else {
		#print(iter.lambda)
		Noupdate <- Noupdate+1
		list(lambda=lambda0,Noupdate=Noupdate,Q0Inf=Q0Inf,Q1Inf=Q1Inf)
		}
		
#	lambda.new <- check.lambda(lambda1,lambda,data,Z.mat,Zphi.uniq,gamma,forEDITOR=forEDITOR)
#	return(lambda.new)
}


# function to check if lambda creates bad Sigma (i.e., singular)

check.lambda <- function(lambda,lambda.old,data,Z.mat,Zphi.uniq,gamma,forEDITOR="model_orig"){
	TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)		# Form updated Sigma
      T.mat <- TD$T.mat
      D <- TD$D
      sigma <- solve(T.mat) %*% D %*% solve( t( T.mat )) 
	#print("lambda")
	#print(lambda)

	#print("lambda.old")
	#print(lambda.old)

	if(kappa(sigma)<1e-5 || kappa(sigma)>1e5){
		#print("bad lambda=")
		#print(lambda)
		return(lambda.old)
	}else{
		return(lambda)
	}
}


# Construct function to maximize loglikelihood w.r.t. beta 

make.beta.em.loglik <- function(data,X.mat,Z.mat,Zphi.mat,Zphi.uniq,gamma,lambda,linear,forEDITOR="model_orig"){
  	m <- nrow(data)                                # setting dimensions
      n <- ncol(data)

      TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)		# Form updated Sigma
      T.mat <- TD$T.mat
      D <- TD$D
      #Sigma <- solve( t(T.mat) %*% solve(D) %*% T.mat )
	Sigma <- solve( (T.mat)) %*% D %*% solve(t(T.mat))   ##changed this because sigular matrix

	sigma.vec <- exp(Z.mat %*% lambda)			# Form sigma^{2} based on D


	function(beta){
		#form Vi
		mu <- data - s.func(beta,X.mat,linear)
		Vi <- Vi.form(data, mu,Sigma)
		term1 <- 0
		
		for (i in 1:m){
			#term1 <- term1 + sum( log(sigma.vec[2:n]) ) + sum ( RS.hat(i,2:n,Vi,Zphi.uniq,gamma) / sigma.vec[2:n] )
			for(t in 1:n){
				term1 <- term1 + log(sigma.vec[t]) + RS.hat(i,t,Vi,Zphi.uniq,gamma) / sigma.vec[t]
			}
		}
		return(term1)
	}
}

##################################
# Construct BIC using new EM-MLE #
##################################

get.em.BIC <- function(data,start,Vi,sigma.init,X.mat,Z.mat,Zphi.mat,Zphi.uniq,lambda,gamma,beta,linear,forEDITOR="model_orig"){
	m <- nrow(data)		# number of samples in study
	p <- length(beta)		# dimension of beta
	q <- length(lambda)	# dimension of lambda
	d <- length(gamma)	# dimension of gamma

	# form -2*loglik (from Pourahmadi's paper)
	loglik <- make.loglik.lambda(start,sigma.init,data,Vi,Z.mat,Zphi.mat,Zphi.uniq,gamma,forEDITOR=forEDITOR)
	#loglik <- make.beta.em.loglik(data,X.mat,Z.mat,Zphi.mat,Zphi.uniq,gamma,lambda,linear,forEDITOR=forEDITOR)
	loglik.val  <- loglik(lambda)$term1

	# form BIC: -2 * loglik / m + ( p + q + d) * log(m)/m
	BIC.val <- loglik.val / m + ( p + q + d ) * log(m)/m 
	BIC.mod <- loglik.val /m + (p + q + d) * sqrt(m) * log(m) /m
	loglik.print  <- -1/2 * loglik.val
	
	# BIC.mod was obtained from Hong and Preson (2006). "Bayesian averaging prediction and nonnested model selection".

	list(BIC.val=BIC.val,BIC.mod=BIC.mod,loglik=loglik.print)
}



##############################################################
# Functions to calculate standard errors for new EM-MLE code #
##############################################################

gamma.lambda.info <- function(lambda,gamma,data,Vi,Z.mat,Zphi.uniq){
	m <- nrow(data)
	n <- ncol(data)
	sigma.vec <- 1 / exp(Z.mat %*% lambda) 
	dim.lambda.gamma <- sum(length(lambda),length(gamma))	

	out <- matrix(0, nrow=dim.lambda.gamma,ncol=dim.lambda.gamma)

	for(i in 1:m){
		tmp <- c( S.gamma(i,data,Vi,Z.mat,Zphi.uniq,sigma.vec,gamma), S.lambda(i,data,Vi,Z.mat,Zphi.uniq,sigma.vec,gamma) )
		out <- out + tmp %*% t(tmp)
	}	
	return(out)
}


beta.em.se <- function(data, X.mat, Z.mat, Zphi.uniq, lambda, gamma, beta,beta.hess,linear,forEDITOR="model_orig"){
	TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)		# Form updated Sigma
      T.mat <- TD$T.mat
      D <- TD$D
      sigma <- solve( t(T.mat) %*% solve(D) %*% T.mat ) 
	sigma.inv <- solve(sigma)

	if(linear=="TRUE"){
		m <- nrow(data)				# setting dimensions
		n <- ncol(data)

		term1 <- 0
	
		for (i in 1:m){
			miss.values<- is.na(data[i,])	# Determine if each row has missing values

			if( sum(miss.values) > 0 ){		# If there are missing values, impute them
				index.miss <- which(miss.values)	# Location of Missing values
				sigma.obs <- sigma[-index.miss,-index.miss]
				if(linear=="TRUE") {
					X.mat.obs <- X.mat[-index.miss,]
				} else {
					X.mat.obs <- X.mat[-index.miss]	
				}
			
				# our original code			
				#term1 <- term1 + t(X.mat.obs) %*% solve(sigma.obs) %*% X.mat.obs

				# mehdi's code
				term1 <- term1 + t(X.mat.obs) %*% sigma.inv[-index.miss,-index.miss] %*% X.mat.obs
			} else{
				term1 <- term1 + t(X.mat) %*% sigma.inv %*% X.mat
			}
		}

		beta.se <- sqrt(diag(solve(term1)))
		return(beta.se)	
	}else {
	      out <- sqrt(diag(solve(beta.hess)))
        	return(out)
	}
}

std.error.em <- function(data,beta.hess,X.mat,Z.mat,Zphi.mat,Zphi.uniq,Vi,lambda,gamma,beta,linear,forEDITOR="model_orig"){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	d <- length(gamma)	# dimension of gamma
	q <- length(lambda)	# dimension of lambda

	beta.se <- beta.em.se(data, X.mat, Z.mat, Zphi.uniq, lambda, gamma, beta,beta.hess,linear,forEDITOR=forEDITOR)
	
	gamma.lambda.I <- gamma.lambda.info(lambda,gamma,data,Vi,Z.mat,Zphi.uniq)
	gamma.lambda.se <- sqrt(diag(solve(gamma.lambda.I)))					

	gamma.se <- gamma.lambda.se[1:d]
	lambda.se <- gamma.lambda.se[(d+1):length(gamma.lambda.se)]
	
	list(beta.se = beta.se, lambda.se = lambda.se, gamma.se = gamma.se)
}





###############
# Imputations #
###############
# Imputation Method 1

impute.values <- function(data,mu,sigma){
	data.impute <- data			# Form matrix to be filled in

	simu.val <- mvrnorm(nrow(data.impute),mu,sigma)	# Generate multivariate normals
	
	index.miss <- which(is.na(data.impute),arr.ind=TRUE) 	# Find location of NA's 
	
	for(i in 1:nrow(index.miss)){
		data.impute[index.miss[i,1],index.miss[i,2]] <- simu.val[index.miss[i,1],index.miss[i,2]]
	}
	return(data.impute)
}


# Extrapolation

dist.impute.values <- function(data,mu,sigma){

	data.impute <- data			# Form matrix to be filled in
		
	for(i in 1:nrow(data)){
		miss.values<- is.na(data.impute[i,])	# Determine if each row has missing values

		if( sum(miss.values) > 0 ){		# If there are missing values, impute them

			index.miss <- which(miss.values)	# Location of Missing values
			#print(solve(sigma[-index.miss,-index.miss]))
			#print(as.vector(t(data.impute[i,-index.miss]-mu[-index.miss])))

			mean.cond <- mu[index.miss] + 
					sigma[index.miss,-index.miss] %*% solve(sigma[-index.miss,-index.miss]) %*% as.vector(t(data.impute[i,-index.miss]-mu[-index.miss]))
			
			cov.cond <- sigma[index.miss,index.miss] - sigma[index.miss,-index.miss] %*% solve(sigma[-index.miss,-index.miss]) %*% sigma[-index.miss,index.miss]
			#print(eigen(cov.cond,only.values = TRUE))
			#print(i)
			simu.values <- mvrnorm(1,mean.cond,cov.cond)
	
			data.impute[i,index.miss] <- simu.values
		}
	}
	return(data.impute)
}



# Multiple imputation

# Performs MLE and OLS calculation

mult.impute <- function(M,data,X.mat,Z.mat,Zphi.mat,Zphi2.mat,tol=tol,Nmax=Nmax,beta.hess,linear)
{
	beta.out <- matrix(0,nrow=M,ncol=ncol(X.mat))
	gamma.out <- matrix(0,nrow=M,ncol=ncol(Z.mat))
	lambda.out <- matrix(0,nrow=M,ncol=ncol(Zphi.mat))


	beta.ols.out <- matrix(0,nrow=M,ncol=ncol(X.mat))
	gamma.ols.out <- matrix(0,nrow=M,ncol=ncol(Z.mat))
	lambda.ols.out <- matrix(0,nrow=M,ncol=ncol(Zphi.mat))	

	cov.beta.1 <- 0
	cov.gamma.1 <- 0
	cov.lambda.1 <-0

	cov.beta.ols.1 <- 0
	cov.gamma.ols.1 <- 0
	cov.lambda.ols.1 <-0


	for(i in 1:M){
		data.dist.impute <- dist.impute.values(data,mu.fit,sigma.fit)
		output <- alg(init="gen",beta.init=c(rep(0,ncol(X.mat))),lambda.init=c(rep(0,ncol(Z.mat))),
			gamma.init=c(rep(0,ncol(Zphi.mat))),beta=c(rep(10,ncol(X.mat))),data.dist.impute,X.mat,Z.mat,Zphi.mat,Zphi2.mat,tol,Nmax,forEDITOR=forEDITOR)
		
		beta.out[i,] <- output$beta
		gamma.out[i,] <- output$gamma
		lambda.out[i,] <- output$lambda	
	
		cov.calc <- cov.mat(data.dist.impute,X.mat,Z.mat,Zphi.mat,Zphi2.mat,lambda.out[i,],gamma.out[i,],beta.out[i,],beta.hess,linear)
		cov.beta.1 <- cov.beta.1 + cov.calc$beta.cov
		cov.gamma.1 <- cov.gamma.1 + cov.calc$gamma.cov
		cov.lambda.1 <- cov.lambda.1 + cov.calc$lambda.cov


		output.ols <- para.ols.cov(cov(data.dist.impute),data.dist.impute,X.mat,Z.mat,Zphi.mat)
		
		beta.ols.out[i,] <- output.ols$beta
		gamma.ols.out[i,] <- output.ols$gamma
		lambda.ols.out[i,] <- output.ols$lambda

		cov.beta.ols.1 <- cov.beta.ols.1 + output.ols$beta.cov
		cov.gamma.ols.1 <- cov.gamma.ols.1 + output.ols$gamma.cov
		cov.lambda.ols.1 <- cov.lambda.ols.1 + output.ols$lambda.cov
		
		
	}
	
	beta.mean <- apply(beta.out,MARGIN=2,FUN=mean)
	gamma.mean <- apply(gamma.out,MARGIN=2,FUN=mean)
	lambda.mean <- apply(lambda.out,MARGIN=2,FUN=mean)

	beta.ols.mean <- apply(beta.ols.out,MARGIN=2,FUN=mean)
	gamma.ols.mean <- apply(gamma.ols.out,MARGIN=2,FUN=mean)
	lambda.ols.mean <- apply(lambda.ols.out,MARGIN=2,FUN=mean)
	
	cov.beta.2 <-0
	cov.lambda.2 <-0
	cov.gamma.2<- 0

	cov.beta.ols.2 <-0
	cov.lambda.ols.2 <-0
	cov.gamma.ols.2<- 0

	for(i in 1:M){
		cov.beta.2 <- cov.beta.2 + (beta.out[i,]-beta.mean) %*% t(beta.out[i,]-beta.mean)
		cov.gamma.2 <- cov.gamma.2 + (gamma.out[i,]-gamma.mean) %*% t(gamma.out[i,]-gamma.mean)
		cov.lambda.2 <- cov.lambda.2 + (lambda.out[i,]-lambda.mean) %*% t(lambda.out[i,]-lambda.mean)


		cov.beta.ols.2 <- cov.beta.ols.2 + (beta.ols.out[i,]-beta.ols.mean) %*% t(beta.ols.out[i,]-beta.ols.mean)
		cov.gamma.ols.2 <- cov.gamma.ols.2 + (gamma.ols.out[i,]-gamma.ols.mean) %*% t(gamma.ols.out[i,]-gamma.ols.mean)
		cov.lambda.ols.2 <- cov.lambda.ols.2 + (lambda.ols.out[i,]-lambda.ols.mean) %*% t(lambda.ols.out[i,]-lambda.ols.mean)
	}

		beta.se <- sqrt(diag(1/M * cov.beta.1 + (1 + 1/M) * (1/ (M-1) ) * cov.beta.2))
		gamma.se <- sqrt(diag(1/M * cov.gamma.1 + (1 + 1/M) * (1/ (M-1) ) * cov.gamma.2))
		lambda.se <- sqrt(diag(1/M * cov.lambda.1 + (1 + 1/M) * (1/ (M-1) ) * cov.lambda.2))


		beta.ols.se <- sqrt(diag(1/M * cov.beta.ols.1 + (1 + 1/M) * (1/ (M-1) ) * cov.beta.ols.2))
		gamma.ols.se <- sqrt(diag(1/M * cov.gamma.ols.1 + (1 + 1/M) * (1/ (M-1) ) * cov.gamma.ols.2))
		lambda.ols.se <- sqrt(diag(1/M * cov.lambda.ols.1 + (1 + 1/M) * (1/ (M-1) ) * cov.lambda.ols.2))

	list(beta.mean=round(beta.mean,3),lambda.mean=round(lambda.mean,3),gamma.mean=round(gamma.mean,3),
		beta.se=round(beta.se,3),lambda.se=round(lambda.se,3),gamma.se=round(gamma.se,3),
		beta.ols.mean=round(beta.ols.mean,3),lambda.ols.mean=round(lambda.ols.mean,3),gamma.ols.mean=round(gamma.ols.mean,3),
		beta.ols.se=round(beta.ols.se,3),lambda.ols.se=round(lambda.ols.se,3),gamma.ols.se=round(gamma.ols.se,3))	
}



mult.ols.impute <- function(M,mu,sigma,data,X.mat,Z.mat,Zphi.mat,Zphi2.mat,tol=tol,Nmax=Nmax){
	beta.ols.out <- matrix(0,nrow=M,ncol=ncol(X.mat))
	gamma.ols.out <- matrix(0,nrow=M,ncol=ncol(Z.mat))
	lambda.ols.out <- matrix(0,nrow=M,ncol=ncol(Zphi.mat))	

	cov.beta.ols.1 <- 0
	cov.gamma.ols.1 <- 0
	cov.lambda.ols.1 <-0


	for(i in 1:M){
		data.dist.impute <- dist.impute.values(data,mu,sigma)
		
		output.ols <- para.ols.cov(cov(data.dist.impute),data.dist.impute,X.mat,Z.mat,Zphi.mat)
		
		beta.ols.out[i,] <- output.ols$beta
		gamma.ols.out[i,] <- output.ols$gamma
		lambda.ols.out[i,] <- output.ols$lambda

		cov.beta.ols.1 <- cov.beta.ols.1 + output.ols$beta.cov
		cov.gamma.ols.1 <- cov.gamma.ols.1 + output.ols$gamma.cov
		cov.lambda.ols.1 <- cov.lambda.ols.1 + output.ols$lambda.cov
		
		
	}
	
	beta.ols.mean <- apply(beta.ols.out,MARGIN=2,FUN=mean)
	gamma.ols.mean <- apply(gamma.ols.out,MARGIN=2,FUN=mean)
	lambda.ols.mean <- apply(lambda.ols.out,MARGIN=2,FUN=mean)
	
	cov.beta.ols.2 <-0
	cov.lambda.ols.2 <-0
	cov.gamma.ols.2<- 0

	for(i in 1:M){
		
		cov.beta.ols.2 <- cov.beta.ols.2 + (beta.ols.out[i,]-beta.ols.mean) %*% t(beta.ols.out[i,]-beta.ols.mean)
		cov.gamma.ols.2 <- cov.gamma.ols.2 + (gamma.ols.out[i,]-gamma.ols.mean) %*% t(gamma.ols.out[i,]-gamma.ols.mean)
		cov.lambda.ols.2 <- cov.lambda.ols.2 + (lambda.ols.out[i,]-lambda.ols.mean) %*% t(lambda.ols.out[i,]-lambda.ols.mean)
	}

		beta.ols.se <- sqrt(diag(1/M * cov.beta.ols.1 + (1 + 1/M) * (1/ (M-1) ) * cov.beta.ols.2))
		gamma.ols.se <- sqrt(diag(1/M * cov.gamma.ols.1 + (1 + 1/M) * (1/ (M-1) ) * cov.gamma.ols.2))
		lambda.ols.se <- sqrt(diag(1/M * cov.lambda.ols.1 + (1 + 1/M) * (1/ (M-1) ) * cov.lambda.ols.2))

	list(beta.ols.mean=round(beta.ols.mean,3),lambda.ols.mean=round(lambda.ols.mean,3),gamma.ols.mean=round(gamma.ols.mean,3),
		beta.ols.se=round(beta.ols.se,3),lambda.ols.se=round(lambda.ols.se,3),gamma.ols.se=round(gamma.ols.se,3))	
}











############################
# Functions for Algorithm  #
############################


s.func <- function(beta,x,linear){
	if(linear=="TRUE") { 
		out <-as.vector(x %*%beta)                                 # linear case
	} else{
	 	#out <- beta[1] / ( 1+ exp(beta[2] + beta[3]*x) )  # nonlinear case
        	out <- beta[1] /( 1+ (exp((-x+beta[2])/beta[3])))      #new nonlinear case in Davidian (orange paper) style   
	}
	return(out)
}


# Function to get initial value
init.value <- function(data,X.mat){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)

	y <- unmatrix(data,byrow=TRUE)		# forming y-vector 
	
	X<-rbind(
	    do.call(rbind, rep(list(X.mat),m))
	)
	
	fit <- lm(y ~  X-1)			# Ordinary Least squares	
	beta <- fit$coefficients
	beta.cov <- anova(fit)$"Mean Sq"[2]* solve(t(X) %*%X)

	list(beta=beta,beta.cov=beta.cov)
}

TD.matrix <- function(S){			# Makes (T,D) pair using Priya's Code
		c<-nrow(S)
		L<-t(chol(S))
		D<-matrix(0,c,c)
		diag(D)<-(diag(L))^2
		T.mat<-D^(1/2)%*%solve(L)

		list(T.mat=T.mat,D=D)
	}

STD.matrix <- function(data,beta,X.mat,linear){	# Used in Step 2
	
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)

	S <- matrix(rep(0,n*n),nrow=n,ncol=n)
	for (i in 1:m){
		y <- t(data[i,])
		#S <- S+ (y-X.mat %*% beta) %*% t(y-X.mat %*% beta)
		 S <- S+ as.vector(y-s.func(beta,X.mat,linear)) %*% t(as.vector(y-s.func(beta,X.mat,linear)))
	}
	S <- S/m
	
	TD.val <-TD.matrix(S)

	list(S=S,T.mat=TD.val$T.mat,D=TD.val$D)
}

# function for subdiagonal

# v is vector to place
# k is subdiagonal of interest
subdiag <- function(v,k,T.mat){
	# k < 0
	n <- nrow(T.mat)
	j <- 1:(n+k)
        i <- (1 - k):n
        T.mat[cbind(i, j)] <- v
	return(T.mat)
}

# k is subdiagonal of interest
# k<0
get.subdiag <- function(mat,k){
	n <- nrow(mat)
	j <- 1:(n+k)
	i <- (1 - k):n
	v <- mat[cbind(i, j)] 
	return(v)
}


# CHANGED TO HAVE NEW FORM OF Zphi.mat using Zphi.uniq
TD.form <- function(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR="model_orig"){ 		# Forms (T,D) matrices from posited models using lambda and gamma
	m<-nrow(data)
	n<-ncol(data)
	D <- matrix(rep(0,n*n),nrow=n,ncol=n)	# D-matrix
	diag(D) <- exp(Z.mat %*% lambda) 		

	if(forEDITOR=="model1"){
		T.mat <- matrix(rep(0,n*n),nrow=n,ncol=n)	# T-matrix
		diag(T.mat) <- rep(1,n)
		T.mat <- subdiag(-gamma,-1,T.mat)
	} else {
		T.mat <- matrix(rep(0,n*n),nrow=n,ncol=n)	# T-matrix
		diag(T.mat) <- rep(1,n)
		A <- -Zphi.uniq %*% gamma

		k <-seq(n-1,1,by=-1)
		for(i in 2:(n-1)){
			l <- k[i-1]
			y <- rep(A[i-1],l)
			T.mat<-subdiag(y,l-n,T.mat)
		}	
	
		T.mat[n,1] <- A[nrow(A)]
	}

	list(T.mat=T.mat,D=D)
}

R.form <- function(data,X.mat,T.mat,beta,linear){	# R matrix

	m <- nrow(data)				# setting dimensions
	n <- ncol(data)

	r <- matrix(rep(0,n*m),nrow=m,ncol=n)
	for (i in 1:m){
		y <- t(data[i,])
		#r[i,]<-  y-X.mat %*% beta
 		r[i,]<-  y-s.func(beta,X.mat,linear)
	}	

	R <-  ( T.mat %*% t(r) )^2 %*% rep(1,m)	# R-matrix
	list(R=R,r=r)
}


Zi.form <- function(data,X.mat,beta,Zphi2.mat,i,linear){	# Matrix Z(i)

	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	d <- ncol(Zphi2.mat)

	r <- matrix(rep(0,n*m),nrow=m,ncol=n)
	for (l in 1:m){
		y <- t(data[l,])
		#r[l,]<-  y-X.mat %*% beta
		r[l,]<-  y-s.func(beta,X.mat,linear)
	}	

	Zi <- matrix(rep(0,n*d),nrow=n,ncol=d)

	alpha <- 0

	for( t in 2:n ){
		l <- t-1
		y <- matrix(0,nrow=l, ncol =d)
		for (s in 1:l) {
			y[s,] <- Zphi2.mat[alpha+s,]
		}	

		for(j in 1:(t-1)){
		Zi[t,] <- Zi[t,] + r[i,j] * y[j,]
		}
		alpha <- alpha + l
	}	
	return(Zi)			
}

# function for form u.gamma

make.u.gamma <-function(r,D,data,X.mat,beta,Zphi2.mat,gamma,linear){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	d <- ncol(Zphi2.mat)

	u.gamma <- rep(0,d)
	for(i in 1:m){
		Zi <-Zi.form(data,X.mat,beta,Zphi2.mat,i,linear) 
		u.gamma <- u.gamma + t(Zi) %*% solve(D) %*% ( r[i,] - Zi %*% gamma )
	}	
	return(u.gamma)
}





## function to make U.lambda function

make.U.score <- function(a,b,data,X.mat,Z.mat,Zphi.uniq,Zphi2.mat,beta,linear,forEDITOR="model_orig"){
	
function(x){
	lambda <- x[1:a]
	gamma <- x[(a+1):(a+b)]
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	out <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)
	T.mat <- out$T.mat
	D <- out$D
	R <- R.form(data,X.mat,T.mat,beta,linear)$R
	r <- R.form(data,X.mat,T.mat,beta,linear)$r

	u.gamma <- make.u.gamma(r,D,data,X.mat,beta,Zphi2.mat,gamma,linear)	    # U(gamma) function				
	u.lambda <- 1/2 *t(Z.mat) %*% ( solve(D) %*% R - m * rep(1,n) )     # U(lambda) function
	out <- c(u.lambda,u.gamma)
	return(out)
	}
}


alpha.init <- function(T.mat,D,Z.mat,Zphi.mat){
	n <- nrow(T.mat)
	phi <- diag(T.mat[2:n,1:(n-1)])
	for(i in 2:(n-2)){
		x <- T.mat[(i+1):n,1:(n-i)]
		phi <- c(phi,diag(x))
	}
	phi <- c(phi,T.mat[n,1])

	# this is wrong!!
	#phi<-diag(T.mat[2:11,1:10])
	#	for(i in 2:10){
	#		x<-T.mat[(i+1):11,1:(11-i)]
	#		phi<-c(phi,diag(x))
	#	}
	#phi<-c(phi,T.mat[11,1])

	phi <- -phi

	fit.gamma <- lm(phi~Zphi.mat-1)

	fit.lambda <- lm(log(diag(D)) ~  Z.mat-1)

	list(gamma = fit.gamma$coefficients, lambda= fit.lambda$coefficients )
}


bdiag <- function(x){				# Block diagonal matrix
	if(!is.list(x)) stop("x not a list")
     	n <- length(x)
     	if(n==0) return(NULL)
     	x <- lapply(x, function(y) if(length(y)) as.matrix(y) else
     	stop("Zero-length component in x"))
     	d <- array(unlist(lapply(x, dim)), c(2, n))
     	rr <- d[1,]
     	cc <- d[2,]
     	rsum <- sum(rr)
     	csum <- sum(cc)
     	out <- array(0, c(rsum, csum))
     	ind <- array(0, c(4, n))
     	rcum <- cumsum(rr)
     	ccum <- cumsum(cc)
     	ind[1,-1] <- rcum[-n]
     	ind[2,] <- rcum
     	ind[3,-1] <- ccum[-n]
     	ind[4,] <- ccum
     	imat <- array(1:(rsum * csum), c(rsum, csum))
     	iuse <- apply(ind, 2, function(y, imat) imat[(y[1]+1):y[2],
	(y[3]+1):y[4]], imat=imat)
     	iuse <- as.vector(unlist(iuse))
     	out[iuse] <- unlist(x)
     	return(out)
} 

# function to make log-likelihood
make.loglik <- function(data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR="model_orig"){
        m <- nrow(data)                                # setting dimensions
        n <- ncol(data)

        TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)
        T.mat <- TD$T.mat
        D <- TD$D
        Sigma.inv <- t(T.mat) %*% solve(D) %*% T.mat


        function(beta){
                quad.term <-0
                for(i in 1:m){
                        diff.vec <-  as.matrix(data[i,]-s.func(beta,X.mat,linear))
                        quad.term <- quad.term + t(diff.vec) %*% Sigma.inv %*% diff.vec
                }
               # out <- m * sum(log(diag(D))) + quad.term
                out <- quad.term
			return(out)
        }
}

# calculates log-likelihood based on Pourahmadi's method

make.loglik2 <- function(data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR="model_orig"){
        m <- nrow(data)                                # setting dimensions
        n <- ncol(data)

        TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)
        T.mat <- TD$T.mat
        D <- TD$D
        Sigma.inv <- t(T.mat) %*% solve(D) %*% T.mat


        function(beta){
                quad.term <-0
                for(i in 1:m){
                        diff.vec <-  as.matrix(data[i,]-s.func(beta,X.mat,linear))
                        quad.term <- quad.term + t(diff.vec) %*% Sigma.inv %*% diff.vec
                }
                out <- m * sum(log(diag(D))) + quad.term
               # out <- quad.term
			return(out)
        }
}



beta.update <- function(data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR="model_orig"){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)

	TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)
	T.mat <- TD$T.mat
	D <- TD$D
	Sigma.inv <- t(T.mat) %*% solve(D) %*% T.mat
	X.Sigma.y <- rep(0,ncol(X.mat))

	X.Sigma.X <- solve ( m * t(X.mat) %*% Sigma.inv %*% X.mat )
	for (i in 1:m){
		X.Sigma.y <- X.Sigma.y + t(X.mat) %*% Sigma.inv %*% as.vector(data[i,])
	}
	beta <- X.Sigma.X %*% X.Sigma.y
	return(beta)
}

# function to impute missing values

impute.miss <- function(beta,data.miss,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR="model_orig"){
        m <- nrow(data.miss)                                # setting dimensions
        n <- ncol(data.miss)

        TD <- TD.form(data.miss,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)
        T.mat <- TD$T.mat
        D <- TD$D
#        Sigma <- solve ( t(T.mat) %*% solve(D) %*% T.mat )
	Sigma <- solve( t(T.mat)) %*% D %*% solve(T.mat ) 	# changed this because sigular matrix

        mu    <- s.func(beta,X.mat,linear)
        
        data <- dist.impute.values(data.miss,mu,Sigma)
        return(data)
}


orig.para <- function(beta,gamma,lambda,X.mat.R,Z.mat.R,Zphi.mat.R){
	beta <- solve(X.mat.R) %*% beta
	gamma <- solve(Zphi.mat.R)%*% gamma
	lambda <- solve(Z.mat.R) %*% lambda
	list(beta=beta,gamma=gamma,lambda=lambda)
}


# function to check positive definite
isPosDef <- function(M) { if ( all(M == t(M) ) ) 
{  
   if (  all(eigen(M)$values > 0) ) {TRUE} 
        else {FALSE} } # 
         else {FALSE}  # not symmetric 

} 

# function to return closest positive definite matrix
get.pd.mat <- function(cov.mat){
	if(isPosDef(cov.mat)=="TRUE"){
		return(cov.mat)
	}else{
		mat.out <- nearPD(cov.mat)
		mat.out <- as.matrix(mat.out$mat)
		return(mat.out)		
	}
}

# function to get BIC
get.BIC <- function(data,X.mat,Z.mat,Zphi.mat,lambda,gamma,beta,linear,forEDITOR="model_orig"){
	m <- nrow(data)		# number of samples in study
	p <- length(beta)		# dimension of beta
	q <- length(lambda)	# dimension of lambda
	d <- length(gamma)	# dimension of gamma

	# form -2*loglik (from Pourahmadi's paper)
	beta.loglik <- make.loglik2(data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR=forEDITOR)
	loglik  <- beta.loglik(beta)

	# form BIC: -2 * loglik / m + ( p + q + d + 3) * log(m)/m
	BIC.val <- loglik / m + ( p + q + d + 3) * log(m) /m 
	return(BIC.val)
}


#############
# Algorithm #
#############

# NEED to Feed in ORTHOGONAL design matrices for MLE

alg <- function(init="gen",EM,beta.init=c(rep(0,ncol(X.mat))),lambda.init=c(rep(0,ncol(Z.mat))),
gamma.init=c(rep(0,ncol(Zphi.mat))),beta=c(rep(10,ncol(X.mat))),data,X.mat,Z.mat,Zphi.mat,Zphi2.mat,tol=tol,Nmax,linear,Nlambda,near.pd,forEDITOR="model_orig") {
	
	data<-as.matrix(data)

	##########################
	# Step 0 : Set Zphi.uniq #
	##########################
	
	if(forEDITOR=="model1"){
		Zphi.uniq <- as.matrix(c(1,rep(0,n-2)),ncol=1)
	} else {	
		Zphi.uniq <- unique(Zphi.mat)
	}
	#Zphi.uniq <- cbind(1, poly(1:(n-1),degree=(length(gamma)-1))) ##MEHDI's


	##################################
	# Step 1: Initial Value  for beta#
	##################################

	beta.0 <- beta.init
	beta.new<- beta.0	

	###########################################
      # Step 1a: get mu and Sigma_0, and impute #
      ###########################################
	mean.init <- apply(data,2,mean,na.rm="TRUE")

	if(near.pd=="TRUE"){
     		sigma.init <- cov(data,use="pairwise.complete.obs")
		sigma.init <- get.pd.mat(sigma.init)
	}else{
		sigma.init <- diag(1,nrow=ncol(data))
	}

	############################################
	# Step 2: Get T.mat, and D  from sigma.init#
	############################################
	TD.init <- TD.matrix(sigma.init)
	T.init <- TD.init$T.mat
	D.init <- TD.init$D

	#####################################
	# Initial values for (lambda,gamma) #
	#####################################

	alpha.0 <- alpha.init(T.init,D.init,Z.mat,Zphi.mat)
	lambda <- alpha.0$lambda
	gamma <- alpha.0$gamma

	N <- 0
	init.em <- 0

	beta0 <- 1e6		# Dummy values to get simulation started
	gamma0 <- 1e6
	lambda0 <- 1e6

	start <- "TRUE" 		# THIS IS TO USE INITIAL SIGMA FOR FIRST BETA UPDATE

	while(max( abs(beta0-beta.new), abs(gamma0-gamma), abs(lambda0-lambda))>tol & N<Nmax){ 
	#while ( norm(as.matrix(beta-beta.new),type="m") > tol & N<Nmax) {		# Convergence based on beta, NOT (beta,lambda,gamma)
	#print(norm(as.matrix(beta-beta.new),type="m"))
		#print("N")
		#print(N)
		lambda0 <- lambda
		gamma0 <- gamma
		beta0 <- beta.new

		##################
		# Update beta    #
		##################

		if(linear=="TRUE"){
			beta.new <- beta.update.em(start,sigma.init,beta0,data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR=forEDITOR)
			beta.hess<-1
			#print("beta done")
		}else{
			beta.loglik <- form.beta.update.em(data,start,sigma.init,X.mat,Z.mat,Zphi.uniq,lambda,gamma,linear,forEDITOR=forEDITOR)
			beta.out   <- optim(beta0,beta.loglik,hessian=TRUE,control=list(trace=FALSE))
			#beta.loglik <-make.beta.em.loglik(data,X.mat,Z.mat,Zphi.mat,Zphi.uniq,gamma,lambda,linear,forEDITOR=forEDITOR)
 			#print("beta done")		
			beta.new <- beta.out$par
			beta.hess <- beta.out$hessian
		}

		beta <- beta.new

		################
		# Form \hat Vi #
		################
	
		if(init.em == 0){
			sigma <- sigma.init
		}
		mu <- s.func(beta,X.mat,linear)
		Vi <- Vi.form(data,mu,sigma)

		################
		# Update gamma #
		################

		gamma <- gamma.update(start,sigma.init,data,Vi,Z.mat,Zphi.uniq,lambda)
		#print("gamma done")
	
		######################################
		# Update lambda using beta and gamma #
		######################################

		lambda.out <- lambda.update(start,sigma.init,data,Vi,Z.mat,Zphi.mat,Zphi.uniq,gamma,lambda,Nlambda,forEDITOR=forEDITOR) #Nlambda added
		lambda<-lambda.out$lambda
	
		#####################################
		# Update counters on error messages #
		#####################################

		Noupdate<-lambda.out$Noupdate
		Q0Inf<-lambda.out$Q0Inf
		Q1Inf<-lambda.out$Q1Inf

		#print("lambda done")
		#lambda.score <- make.lambda.score(data,Vi,Z.mat,Zphi.uniq,gamma)
		#nr.fit <- dfsane(lambda,lambda.score,control=list(trace=FALSE))			# dfsane gets stuck!
		#lambda <- nr.fit$par

		###############################################
		# Update Sigma using new lambda, gamma values #
		###############################################

		TD <- TD.form(data,Z.mat,Zphi.uniq,lambda,gamma,forEDITOR=forEDITOR)		
      	T.mat <- TD$T.mat
      	D <- TD$D
		sigma <- solve((T.mat)) %*% D %*% solve(t(T.mat)) 

		init.em <- 1
		N<- N+1
		start <- "FALSE"
		#print(N)
	
	}
	beta <- beta.new
	#orig <- orig.para(beta.new,gamma,lambda,X.mat.R,Z.mat.R,Zphi.mat.R)
	#beta <- orig$beta
	#lambda <- orig$lambda
	#gamma <- orig$gamma
	

	########################	
	# Get final BIC value  #
	########################

	BIC.val.out <- get.em.BIC(data,start,Vi,sigma,X.mat,Z.mat,Zphi.mat,Zphi.uniq,lambda,gamma,beta,linear,forEDITOR=forEDITOR)	
	BIC.val <- BIC.val.out$BIC.val
	BIC.mod <- BIC.val.out$BIC.mod
	loglik  <- BIC.val.out$loglik

	#######################
	# Get standard errors #
	#######################
	std.error <- std.error.em(data,beta.hess,X.mat,Z.mat,Zphi.mat,Zphi.uniq,Vi,lambda,gamma,beta,linear,forEDITOR=forEDITOR)
	beta.se <- std.error$beta.se
	lambda.se <- std.error$lambda.se
	gamma.se <- std.error$gamma.se

	list(data.nomiss=data,beta=beta,lambda=lambda, gamma=gamma,
		beta.se=beta.se, lambda.se=lambda.se, gamma.se=gamma.se,
		BIC.val=BIC.val,BIC.mod=BIC.mod,loglik=BIC.val.out$loglik,
		N=N,NoLambdaUpdate=Noupdate,Q0Inf=Q0Inf,Q1Inf=Q1Inf)

}




#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+

#######################
# THESE ARE OLD CODES #
#######################

###################
# Standard Errors #
###################

cov.form <- function(T.mat,D){
	#sigma <- solve(T.mat) %*% D %*% solve (t(T.mat))
	sigma <- solve( t(T.mat)) %*% D %*% solve(T.mat ) # changed this because sigular matrix
	return(sigma)
}


lambda.info <- function(data,Z.mat){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	lambda.I <- 1/2 * m * t(Z.mat) %*% Z.mat
	return(lambda.I)
}


gamma.info <- function(data,X.mat,Zphi.mat,Zphi2.mat,Z.mat,lambda,gamma,beta,linear){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	d <- ncol(Zphi.mat)

	r <- matrix(rep(0,n*m),nrow=m,ncol=n)
	for (i in 1:m){
		y <- t(data[i,])
		#r[i,]<-  y-X.mat %*% beta
		r[i,]<-  y-as.numeric(s.func(beta,X.mat,linear))

	}

	Sigma <- cov(r)

	sigma.t <- exp(Z.mat %*% lambda)

	W <- matrix(rep(0,d*d),nrow=d,ncol=d)
	

	alpha <- 0

	for(t in 2:n){
		Wt <- matrix(rep(0,d*d),nrow=d,ncol=d)

		l <- t-1
		y <- matrix(0,nrow=l, ncol =d)
		for (s in 1:l) {
			y[s,] <- Zphi2.mat[alpha+s,]
		}
		
		for(k in 1:(t-1)){
			for(j in 1:(t-1)){
				Wt<- Wt + Sigma[k,j] * y[k,] %*% t(y[j,])

			}
		}
		
		W<- W+ Wt *1/sigma.t[t] 
		alpha <- alpha + l
	}

	gamma.I <- m * W

	return(gamma.I)
}

std.error <- function(data,beta.hess,X.mat,Z.mat,Zphi.mat,Zphi2.mat,lambda,gamma,beta,linear){

	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	d <- ncol(Zphi.mat)

	beta.se <- beta.info(data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,beta,beta.hess,linear)
	
	lambda.I <- lambda.info(data,Z.mat)
	lambda.se <- sqrt(diag(solve(lambda.I)))					# Changed!

	gamma.I <- gamma.info(data,X.mat,Zphi.mat,Zphi2.mat,Z.mat,lambda,gamma,beta,linear)
	gamma.se <- sqrt(diag(solve(gamma.I)))						# Changed!
	
	list(beta.se =round(beta.se,3), lambda.se = round(lambda.se,3), gamma.se = round(gamma.se,3))
}

cov.mat <- function(data,X.mat,Z.mat,Zphi.mat,Zphi2.mat,lambda,gamma,beta,beta.hess,linear){
	m <- nrow(data)				# setting dimensions
	n <- ncol(data)
	d <- ncol(Zphi.mat)
	beta.I <- beta.info(data,X.mat,Z.mat,Zphi.uniq,lambda,gamma,beta,beta.hess,linear)
	beta.cov <- solve(1/m*beta.I)

	lambda.I <- lambda.info(data,Z.mat)
	lambda.cov <- solve(lambda.I)							# Changed!

	gamma.I <- gamma.info(data,X.mat,Zphi.mat,Zphi2.mat,Z.mat,lambda,gamma,beta,linear)
	gamma.cov <- solve(gamma.I)							# Changed!
		
	list(beta.cov=beta.cov, lambda.cov = lambda.cov, gamma.cov = gamma.cov)
}




