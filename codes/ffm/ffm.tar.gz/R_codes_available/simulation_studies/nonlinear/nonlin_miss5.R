# April 17, 2011
# Code to run simulation study
# Sources: 	Functions to run simulation (FFM_simulation_functions.R)


################
# source files #
################

source("../../main_codes/EM_MLE_ALLFUNCTIONS.R")


####################
# Non-Linear Model #
####################
file <- 1			# file number
iseed <-1			# seed value
simu <- 200			# number of simulations
Nmax <- 500			# number of possible iterates
Nlambda <- 50		# number of possible iterates for lambda


m <- 112			# dimension of data
n <- 11

#beta <- c(-3.8,5.9,-1.1)		# beta, lambda, gamma, values
#lambda <- c(-0.2,-1.1,0.2,0.5)
#gamma <- c(0.1,-1.1,0.7,-1.0)

beta <- c(-3.8,5.9,-1.1)		# beta, lambda, gamma, values
lambda<-c(-0.59,-1.3,-0.19,0.88)
gamma<-c(0.04,-0.49,0.15,-0.53)



linear <- "FALSE"		# linear model

				# simulation parameter values
tol=0.001
EM="TRUE"			# since YES missing data
miss="TRUE"			# because missing data
percent=5			# % missingness
near.pd="FALSE"

# test to see if values for beta, lambda, gamma are decent
#plots.profreg(m,n,beta,lambda,gamma,linear=linear,miss=miss,percent=percent)		
	

# if parameter values okay, run simulation
out <- store.simu.files(file=file,iseed,simu,EM=EM,m,n,beta,lambda,gamma,beta.0=beta+1,lambda.0=lambda+1,gamma.0=gamma+1,tol=tol,Nmax=Nmax,linear=linear,miss=miss,percent=percent,Nlambda=Nlambda,near.pd=near.pd)

# see summary of results
out$Main

# do plot based on output

#plots.all(n,beta,lambda,gamma,out$Values,linear,printfiles="FALSE",filename="nonlin_miss5",random="TRUE")

plots.all(n,beta,lambda,gamma,out$Values,linear,printfiles="TRUE",filename="simu_nonlin_miss5",random="TRUE")


