# April 17, 2011
# Code to run simulation study
# Sources: 	Functions to run simulation (FFM_simulation_functions.R)


################
# source files #
################
source("../../main_codes/EM_MLE_ALLFUNCTIONS.R")


################
# Linear Model #
################
file <- 1			# file number
iseed <- 1
simu <- 200			# number of simulations
Nmax <- 500			# number of possible iterates
Nlambda <- 50		# numer of possible iterates for lambda

m <- 112			# dimension of data
n <- 11


 beta= c(-1.722873, 4.532655, -0.848633, -0.9729529, 0.4095347, 0.3137608, -0.2074213, 0.1219554, -0.1401268, -0.005406317) 
 gamma= c(0.04058029, -0.4917999, 0.1555856, -0.5243019) 
 lambda= c(-0.5941423, -1.304562, -0.1933537, 0.8881996) 

linear <- "TRUE"		# linear model

				# simulation parameter values
tol=0.01
EM="TRUE"			# since YES missing data
miss="TRUE"			# because missing data
percent=5			# % missingness
near.pd<-"FALSE"

# test to see if values for beta, lambda, gamma are decent
#plots.profreg(m,n,beta,lambda,gamma,linear=linear,miss=miss,percent=percent)		

# if parameter values okay, run simulation
out <- store.simu.files(file=file,iseed,simu,EM=EM,m,n,beta,lambda,gamma,
                        beta.0=beta,lambda.0=lambda,gamma.0=gamma,
                        tol=tol,Nmax=Nmax,linear=linear,miss=miss,percent=percent,
                        Nlambda=Nlambda,near.pd=near.pd)

# see summary of results
out$Main

## do plot based on output
plots.all(n,beta,lambda,gamma,out$Values,linear,printfiles="TRUE",filename="simu_lin_miss5",random="TRUE")


