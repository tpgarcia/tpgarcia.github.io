# April 17, 2011
# Code to run simulation study
# Sources: 	Functions to run simulation (FFM_simulation_functions.R)


################
# source files #
################
source("../../main_codes/EM_MLE_ALLFUNCTIONS.R")


################
# Linear Model #
################
file <- 1			# file number
iseed <- 1
simu <- 200			# number of simulations
Nmax <- 500			# number of possible iterates
Nlambda <- 50		# numer of possible iterates for lambda

m <- 112			# dimension of dat
n <- 11

##BAD for 30*11!!
#beta <- c(-1.6,4.6,-0.7,-0.9,0.4,0.3,-0.2,0.2,-0.1,0.1)		# beta, lambda, gamma, values
#lambda <- c(-0.2,-1.2,-0.1,0.6)
#gamma <- c(0.1,-1.6,0.7,-0.9)

###GOOD for 30*11!!
#beta=c(226.2, 230.3333, 246.8667, 265.6333, 281.1667, 294.8667, 304.7333, 312.8667, 315.1333, 324.0667, 325.4667) 
# gamma= c(0.09260634, -0.5368726, 0.4576832, -0.4421082) 
# lambda= c(3.501281, -1.206825, 0.2484660, -0.8976227) 

#beta<-c(-1.7,4.5,-0.8,-0.97,0.41,0.31,-0.21,0.12,-0.14,-0.005)
#lambda<-c(-0.59,-1.3,-0.19,0.88)
#gamma<-c(0.04,-0.49,0.15,-0.53)

 beta= c(-1.722873, 4.532655, -0.848633, -0.9729529, 0.4095347, 0.3137608, -0.2074213, 0.1219554, -0.1401268, -0.005406317) 
 gamma= c(0.04058029, -0.4917999, 0.1555856, -0.5243019) 
 lambda= c(-0.5941423, -1.304562, -0.1933537, 0.8881996) 

linear <- "TRUE"		# linear model

				# simulation parameter values
tol=0.01
EM="TRUE"			# since YES missing data
miss="TRUE"			# because missing data
percent=10			# % missingness
near.pd<-"FALSE"

# test to see if values for beta, lambda, gamma are decent
#plots.profreg(m,n,beta,lambda,gamma,linear=linear,miss=miss,percent=percent)		

# if parameter values okay, run simulation
out <- store.simu.files(file=file,iseed,simu,EM=EM,m,n,beta,lambda,gamma,
				beta.0=beta,lambda.0=lambda,gamma.0=gamma,
				tol=tol,Nmax=Nmax,linear=linear,miss=miss,percent=percent,Nlambda=Nlambda,near.pd=near.pd)

# see summary of results
out$Main

# do plot based on output
plots.all(n,beta,lambda,gamma,out$Values,linear,printfiles="TRUE",filename="simu_lin_miss10",random="TRUE")


