plotfest <- function(f.est,var.est,allestimators=FALSE,
                      plot.ci=TRUE,plot.cdf=TRUE,ylab="F(t)",xlab="time"){
  F <- f.est
  p <- dim(F)[2]
  num_est <- dim(F)[3] # number of estimators
  num_time <- dim(F)[1]   # number of time points
  
  ## adjust fest values so that they are monotone
  F <- adjustfest(F)
  
  ## get estimated standard errors
  se.est <- array(0,dim=c(num_time,p,num_est),
                  dimnames=list(dimnames(f.est)[[1]],
                    paste("se.",dimnames(f.est)[[2]],sep=""),
                    dimnames(f.est)[[3]]))
  for(k in 1:num_est){
    for(j in 1:num_time){
      se.est[j,,k] <- sqrt(diag(var.est[j,,,k]))
    }
  }
  
  if(allestimators==TRUE){
    par(mfrow=c(4,3))
    for(k in 1:num_est){
      mainplot(F,se.est,k,title=dimnames(F)[[3]][k],plot.ci=plot.ci,
              plot.cdf=plot.cdf,ylab=ylab,xlab=xlab)
    }
  } else {
    k <- which(dimnames(F)[[3]]=="EFFAIPW")
    mainplot(F,se.est,k,title=dimnames(F)[[3]][k],plot.ci=plot.ci,
            plot.cdf=plot.cdf,ylab=ylab,xlab=xlab)
  }
}
