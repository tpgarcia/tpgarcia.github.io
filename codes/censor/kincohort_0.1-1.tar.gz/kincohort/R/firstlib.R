.First.lib <- function(lib,pkg)
  {
       library.dynam("kincohortplay",pkg,lib)
          cat("kinchortplay 0.1-1 loaded\n")
     }

