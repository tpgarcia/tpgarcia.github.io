kincohort_play<- function(data,time_points=NULL,
                      distance.btwn.times=2,
                      boot.replicates=100,allestimators=FALSE){
  ## organize data
  q <- t(as.matrix(data$q))
  x <- as.matrix(data$x)
  delta <- as.matrix(data$delta)
  
  if(is.null(time_points)){
    time_points <- as.matrix(seq(from=min(x),to=max(x),
                                    length.out=abs(max(x)-min(x))/
                                    distance.btwn.times))
  }

  lim <- 10
  rat <- 4
  cox <- FALSE
  realdata <- FALSE

  storage.mode(lim) <- "double"
  storage.mode(rat) <- "double"
  storage.mode(cox) <- "logical"
  storage.mode(realdata) <- "logical"
  

  ## set up parameters for fortran 90 program
  storage.mode(q) <- "double"
  storage.mode(x) <- "double"
  storage.mode(delta) <- "double"
  storage.mode(allestimators) <- "logical"
  n <- as.integer(length(x))
  p <- as.integer(nrow(q))
  m <- as.integer(nrow(unique(t(q))))
  storage.mode(time_points) <- "double"
  num_time_points <- as.integer(length(time_points))
  boot <- as.integer(boot.replicates)
  num_estimators <- 11
  
  
  ## initialize storage arrays
  est.names <- c("OLSIPW","OLSAIPW","OLSIMP",
                 "WLSIPW","WLSAIPW","WLSIMP",
                 "EFFIPW","EFFAIPW","EFFIMP",
                 "NPMLE1","NPMLE2")
  f.names <- paste("F",1:p,sep="")
  time.names <- time_points
  
  festfull <- array(0,dim=c(p,num_time_points,num_estimators),
                    dimnames=list(f.names,time.names,est.names) )
  
  vestfull <- array(0,dim=c(p,p,num_time_points,num_estimators),
                    dimnames=list(f.names,f.names,time.names,est.names))
  
  eflag <- as.integer(0)
  
  storage.mode(festfull) <- "double"
  storage.mode(vestfull) <- "double"
  
  
  estimators <- .Fortran("apply_kincohort_estimators",allestimators,n,p,m,q,x,
                         delta,lim,rat,cox,realdata,time_points,
                         num_time_points,boot,
                         festfull=festfull, vestfull=vestfull,
                         eflag=eflag)
  
  f.est <- aperm(estimators$festfull,c(2,1,3))
  var.est <- aperm(estimators$vestfull,c(3,1,2,4))
  list(f.est=f.est,var.est=var.est)
}

